
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation, Navigate } from "react-router-dom";
import { AuthProvider } from "@/components/auth/AuthProvider";
import { useAuth } from "@/hooks/useAuth";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import RecuperarSenha from "./pages/RecuperarSenha";
import ResetarSenha from "./pages/ResetarSenha";
import EmailVerification from "./pages/EmailVerification";
import AuthCallback from "./pages/AuthCallback";
import ProfileSetup from "./pages/ProfileSetup";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/NotFound";
import CompanyProfileSetup from "./pages/CompanyProfileSetup";
import CompanyDashboard from "./pages/CompanyDashboard";
import CreatorDashboard from "./pages/CreatorDashboard";
import { CreatorSearch } from "./components/company/CreatorSearch";
import { CampaignSearch } from "./components/campaign/CampaignSearch";
import Admin from "./pages/Admin";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import PaymentSuccess from "./pages/PaymentSuccess";
import PaymentCancelled from "./pages/PaymentCancelled";
import { useEffect } from "react";
import { CreatorProfileView } from "./components/company/creator/CreatorProfileView";

// Configurar o cliente de consulta para React Query
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000, // 5 minutos
    },
  },
});

// Componente para lidar com rolagem para hash quando componente monta
const ScrollToHashElement = () => {
  const location = useLocation();
  
  useEffect(() => {
    const hash = location.hash;
    if (hash) {
      setTimeout(() => {
        const element = document.getElementById(hash.slice(1));
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } else {
      window.scrollTo(0, 0);
    }
  }, [location]);

  return null;
};

// Componente para redirecionar com base no status de autenticação
const RedirectOnAuth = () => {
  const { isAuthenticated, isCreator, isCompany, isAdmin } = useAuth();
  
  if (!isAuthenticated) {
    return <Navigate to="/auth" replace />;
  }
  
  if (isCreator) {
    return <Navigate to="/dashboard/criador" replace />;
  }
  
  if (isCompany) {
    return <Navigate to="/dashboard/empresa" replace />;
  }
  
  if (isAdmin) {
    return <Navigate to="/dashboard/admin" replace />;
  }
  
  return <Navigate to="/auth" replace />;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <ScrollToHashElement />
          <Routes>
            {/* Rotas Públicas */}
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/auth/recuperar-senha" element={<RecuperarSenha />} />
            <Route path="/auth/reset-password" element={<ResetarSenha />} />
            <Route path="/auth/verify" element={<EmailVerification />} />
            <Route path="/auth/callback" element={<AuthCallback />} />
            
            {/* Redirecionamento padrão */}
            <Route path="/dashboard" element={<RedirectOnAuth />} />
            
            {/* Rotas do Criador */}
            <Route path="/perfil-setup" element={
              <ProtectedRoute allowedUserType="criador">
                <ProfileSetup />
              </ProtectedRoute>
            } />
            
            <Route path="/dashboard/criador" element={
              <ProtectedRoute allowedUserType="criador">
                <CreatorDashboard />
              </ProtectedRoute>
            } />
            
            {/* Rotas da Empresa */}
            <Route path="/empresa-setup" element={
              <ProtectedRoute allowedUserType="empresa">
                <CompanyProfileSetup />
              </ProtectedRoute>
            } />
            
            <Route path="/dashboard/empresa" element={
              <ProtectedRoute allowedUserType="empresa">
                <CompanyDashboard />
              </ProtectedRoute>
            } />
            
            <Route path="/empresa-dashboard" element={
              <ProtectedRoute allowedUserType="empresa">
                <CompanyDashboard />
              </ProtectedRoute>
            } />
            
            <Route path="/empresa-dashboard/buscar" element={
              <ProtectedRoute allowedUserType="empresa">
                <CreatorSearch />
              </ProtectedRoute>
            } />
            
            <Route path="/criadores" element={
              <ProtectedRoute allowedUserType="empresa">
                <CreatorSearch />
              </ProtectedRoute>
            } />
            
            <Route path="/criadores/:id" element={
              <ProtectedRoute>
                <CreatorProfileView onBack={() => null} />
              </ProtectedRoute>
            } />
            
            <Route path="/campanhas" element={
              <ProtectedRoute>
                <CampaignSearch />
              </ProtectedRoute>
            } />
            
            <Route path="/campanha/:id" element={
              <ProtectedRoute>
                <div className="p-8">
                  <h1 className="text-2xl font-bold">Detalhes da campanha</h1>
                  <p className="text-gray-600">Página em construção</p>
                </div>
              </ProtectedRoute>
            } />
            
            {/* Rotas do Admin */}
            <Route path="/dashboard/admin" element={
              <ProtectedRoute allowedUserType="admin">
                <Admin />
              </ProtectedRoute>
            } />
            
            <Route path="/admin" element={
              <ProtectedRoute allowedUserType="admin">
                <Admin />
              </ProtectedRoute>
            } />

            <Route path="/payment-success" element={<PaymentSuccess />} />
            <Route path="/payment-cancelled" element={<PaymentCancelled />} />
            
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
