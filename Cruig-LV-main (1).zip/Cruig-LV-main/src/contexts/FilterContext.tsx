
import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { FilterContextType } from '@/types/filters';

// Create the filter context
const FilterContext = createContext<FilterContextType | undefined>(undefined);

// Initial empty filters state
const initialFilters: Record<string, any> = {};

// Get initial filters from localStorage if available
const getInitialFilters = (): Record<string, any> => {
  try {
    const savedFilters = localStorage.getItem('app-filters');
    if (savedFilters) {
      return JSON.parse(savedFilters);
    }
  } catch (error) {
    console.error('Error restoring filters from localStorage:', error);
  }
  return initialFilters;
};

// Provider component for the FilterContext
export function FilterProvider({ children }: { children: React.ReactNode }) {
  const [filters, setFilters] = useState<Record<string, any>>(getInitialFilters());

  // Save filters to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem('app-filters', JSON.stringify(filters));
    } catch (error) {
      console.error('Error saving filters to localStorage:', error);
    }
  }, [filters]);

  // Set a filter value
  const setFilter = useCallback((key: string, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  }, []);

  // Remove a filter
  const removeFilter = useCallback((key: string) => {
    setFilters(prev => {
      const newFilters = { ...prev };
      delete newFilters[key];
      return newFilters;
    });
  }, []);

  // Clear all filters
  const clearFilters = useCallback(() => {
    setFilters({});
  }, []);

  // Reset filters to initial state
  const resetFilters = useCallback(() => {
    setFilters(initialFilters);
  }, []);

  // Calculate number of active filters
  const activeFilterCount = Object.keys(filters).filter(key => {
    const value = filters[key];
    if (Array.isArray(value)) return value.length > 0;
    if (typeof value === 'boolean') return value;
    if (typeof value === 'number') return value > 0;
    if (typeof value === 'object' && value !== null) {
      // For date ranges and other objects
      return Object.keys(value).length > 0;
    }
    return value !== undefined && value !== null && value !== '';
  }).length;

  // Context value
  const value = {
    filters,
    setFilter,
    removeFilter,
    clearFilters,
    resetFilters,
    activeFilterCount
  };

  return (
    <FilterContext.Provider value={value}>
      {children}
    </FilterContext.Provider>
  );
}

// Hook to use the filter context
export function useFilters() {
  const context = useContext(FilterContext);
  if (context === undefined) {
    throw new Error('useFilters must be used within a FilterProvider');
  }
  return context;
}
