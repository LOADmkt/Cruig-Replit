
import * as React from "react";
import { Command as CommandPrimitive } from "cmdk";
import { cn } from "@/lib/utils";
import { CommandSeparatorProps, CommandSeparatorRef } from "./types";

export const CommandSeparator = React.forwardRef<CommandSeparatorRef, CommandSeparatorProps>(
  ({ className, ...props }, ref) => {
    const safeProps = React.useMemo(() => {
      try {
        const processed = { ...props };
        
        if ('children' in processed) {
          if (processed.children === undefined || processed.children === null) {
            processed.children = [];
          } else if (Array.isArray(processed.children)) {
            processed.children = processed.children.filter(Boolean);
          } else if (!React.isValidElement(processed.children)) {
            processed.children = React.Children.toArray(processed.children).filter(Boolean);
          }
        }
        
        Object.keys(processed).forEach(key => {
          if (processed[key] === undefined) {
            processed[key] = null;
          }
        });
        
        return processed;
      } catch (error) {
        console.error("Error processing CommandSeparator props:", error);
        return {};
      }
    }, [props]);

    return (
      <CommandPrimitive.Separator
        ref={ref}
        className={cn("-mx-1 h-px bg-border", className)}
        {...safeProps}
      />
    );
  }
);

CommandSeparator.displayName = CommandPrimitive.Separator.displayName;
