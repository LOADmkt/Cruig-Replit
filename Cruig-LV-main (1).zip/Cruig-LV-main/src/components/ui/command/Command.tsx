
import * as React from "react";
import { Command as CommandPrimitive } from "cmdk";
import { cn } from "@/lib/utils";
import { CommandProps, CommandElementRef } from "./types";

export const Command = React.forwardRef<CommandElementRef, CommandProps>(
  ({ className, ...props }, ref) => {
    // Create a safe version of props where we ensure children is never undefined
    const safeProps = React.useMemo(() => {
      try {
        const processed = { ...props };
        
        // Ensure children is always an array or valid React element
        if ('children' in processed) {
          if (processed.children === undefined || processed.children === null) {
            processed.children = [];
          } else if (Array.isArray(processed.children)) {
            processed.children = processed.children.filter(Boolean);
          } else if (React.isValidElement(processed.children)) {
            // Single valid React element - keep as is
          } else {
            try {
              // Safely handle any other type of children
              const childrenArray = React.Children.toArray(processed.children);
              processed.children = childrenArray.filter(Boolean);
            } catch (err) {
              console.error("Error processing Command children:", err);
              processed.children = [];
            }
          }
        } else {
          // Ensure children property exists
          processed.children = [];
        }
        
        // Remove any undefined props to avoid React warnings
        Object.keys(processed).forEach(key => {
          if (processed[key] === undefined) {
            processed[key] = null;
          }
        });
        
        return processed;
      } catch (error) {
        console.error("Critical error processing Command props:", error);
        return { children: [] };
      }
    }, [props]);
    
    return (
      <CommandPrimitive
        ref={ref}
        className={cn(
          "flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground",
          className
        )}
        {...safeProps}
      />
    );
  }
);

Command.displayName = CommandPrimitive.displayName;
