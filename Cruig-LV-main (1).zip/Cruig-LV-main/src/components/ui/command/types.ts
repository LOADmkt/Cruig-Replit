
import { DialogProps } from "@radix-ui/react-dialog";
import { Command as CommandPrimitive } from "cmdk";
import { ComponentPropsWithoutRef, ElementRef, ReactNode } from "react";

export type CommandProps = React.ComponentPropsWithoutRef<typeof CommandPrimitive>;
export type CommandElementRef = React.ElementRef<typeof CommandPrimitive>;

export type CommandDialogProps = DialogProps;

export type CommandInputProps = React.ComponentPropsWithoutRef<typeof CommandPrimitive.Input>;
export type CommandInputRef = React.ElementRef<typeof CommandPrimitive.Input>;

export type CommandListProps = React.ComponentPropsWithoutRef<typeof CommandPrimitive.List>;
export type CommandListRef = React.ElementRef<typeof CommandPrimitive.List>;

export type CommandEmptyProps = React.ComponentPropsWithoutRef<typeof CommandPrimitive.Empty>;
export type CommandEmptyRef = React.ElementRef<typeof CommandPrimitive.Empty>;

export interface CommandGroupProps extends React.ComponentPropsWithoutRef<typeof CommandPrimitive.Group> {
  emptyElement?: ReactNode;
}
export type CommandGroupRef = React.ElementRef<typeof CommandPrimitive.Group>;

export type CommandSeparatorProps = React.ComponentPropsWithoutRef<typeof CommandPrimitive.Separator>;
export type CommandSeparatorRef = React.ElementRef<typeof CommandPrimitive.Separator>;

export type CommandItemProps = React.ComponentPropsWithoutRef<typeof CommandPrimitive.Item>;
export type CommandItemRef = React.ElementRef<typeof CommandPrimitive.Item>;

export type CommandShortcutProps = React.HTMLAttributes<HTMLSpanElement>;
