
import * as React from "react";
import { Command as CommandPrimitive } from "cmdk";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { CommandInputProps, CommandInputRef } from "./types";

export const CommandInput = React.forwardRef<CommandInputRef, CommandInputProps>(
  ({ className, ...props }, ref) => {
    const safeValue = typeof props.value === 'string' ? props.value : '';
    
    const otherProps = React.useMemo(() => {
      try {
        const processed = { ...props };
        delete processed.value;
        
        Object.keys(processed).forEach(key => {
          if (processed[key] === undefined) {
            processed[key] = null;
          }
        });
        
        return processed;
      } catch (error) {
        console.error("Error processing CommandInput props:", error);
        return {};
      }
    }, [props]);
    
    return (
      <div className="flex items-center border-b px-3" cmdk-input-wrapper="">
        <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
        <CommandPrimitive.Input
          ref={ref}
          className={cn(
            "flex h-11 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50",
            className
          )}
          value={safeValue}
          {...otherProps}
        />
      </div>
    );
  }
);

CommandInput.displayName = CommandPrimitive.Input.displayName;
