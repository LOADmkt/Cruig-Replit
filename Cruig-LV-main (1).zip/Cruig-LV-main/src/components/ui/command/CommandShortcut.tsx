
import * as React from "react";
import { cn } from "@/lib/utils";
import { CommandShortcutProps } from "./types";

export const CommandShortcut = ({ className, ...props }: CommandShortcutProps) => {
  const safeProps = React.useMemo(() => {
    try {
      const processed = { ...props };
      
      if ('children' in processed) {
        if (processed.children === undefined || processed.children === null) {
          processed.children = [];
        } else if (Array.isArray(processed.children)) {
          processed.children = processed.children.filter(Boolean);
        } else if (!React.isValidElement(processed.children)) {
          processed.children = React.Children.toArray(processed.children).filter(Boolean);
        }
      }
      
      Object.keys(processed).forEach(key => {
        if (processed[key] === undefined) {
          processed[key] = null;
        }
      });
      
      return processed;
    } catch (error) {
      console.error("Error processing CommandShortcut props:", error);
      return {};
    }
  }, [props]);

  return (
    <span
      className={cn(
        "ml-auto text-xs tracking-widest text-muted-foreground",
        className
      )}
      {...safeProps}
    />
  );
};

CommandShortcut.displayName = "CommandShortcut";
