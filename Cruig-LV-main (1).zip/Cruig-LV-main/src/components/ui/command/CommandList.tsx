
import * as React from "react";
import { Command as CommandPrimitive } from "cmdk";
import { cn } from "@/lib/utils";
import { CommandListProps, CommandListRef } from "./types";

export const CommandList = React.forwardRef<CommandListRef, CommandListProps>(
  ({ className, ...props }, ref) => {
    const safeProps = React.useMemo(() => {
      try {
        const processed = { ...props };
        
        // Special handling for children property - crucial for cmdk
        if ('children' in processed) {
          if (processed.children === undefined || processed.children === null) {
            processed.children = []; // Ensure it's an empty array if undefined
          } else if (Array.isArray(processed.children)) {
            // Filter out null, undefined, and any invalid child elements
            processed.children = processed.children.filter(Boolean);
          } else if (React.isValidElement(processed.children)) {
            // Single valid React element - keep as is
          } else {
            // Try to convert to array if not already valid React element
            try {
              const childrenArray = React.Children.toArray(processed.children);
              processed.children = childrenArray.filter(Boolean);
            } catch (err) {
              console.error("Error processing CommandList children:", err);
              processed.children = []; // Fallback to empty array on error
            }
          }
        } else {
          // Ensure children property exists
          processed.children = [];
        }

        // Convert any undefined props to null to avoid React warnings
        Object.keys(processed).forEach(key => {
          if (processed[key] === undefined) {
            processed[key] = null;
          }
        });

        return processed;
      } catch (error) {
        console.error("Critical error processing CommandList props:", error);
        return { children: [] }; // Return safe fallback on error
      }
    }, [props]);

    return (
      <CommandPrimitive.List
        ref={ref}
        className={cn("max-h-[300px] overflow-y-auto overflow-x-hidden", className)}
        {...safeProps}
      />
    );
  }
);

CommandList.displayName = CommandPrimitive.List.displayName;
