
import * as React from "react";
import { Command as CommandPrimitive } from "cmdk";
import { CommandEmptyProps, CommandEmptyRef } from "./types";

export const CommandEmpty = React.forwardRef<CommandEmptyRef, CommandEmptyProps>(
  (props, ref) => {
    const safeProps = React.useMemo(() => {
      try {
        const processed = { ...props };
        
        if ('children' in processed) {
          if (processed.children === undefined || processed.children === null) {
            processed.children = [];
          } else if (Array.isArray(processed.children)) {
            processed.children = processed.children.filter(Boolean);
          } else if (!React.isValidElement(processed.children)) {
            processed.children = React.Children.toArray(processed.children).filter(Boolean);
          }
        }
        
        Object.keys(processed).forEach(key => {
          if (processed[key] === undefined) {
            processed[key] = null;
          }
        });
        
        return processed;
      } catch (error) {
        console.error("Error processing CommandEmpty props:", error);
        return {};
      }
    }, [props]);

    return (
      <CommandPrimitive.Empty
        ref={ref}
        className="py-6 text-center text-sm"
        {...safeProps}
      />
    );
  }
);

CommandEmpty.displayName = CommandPrimitive.Empty.displayName;
