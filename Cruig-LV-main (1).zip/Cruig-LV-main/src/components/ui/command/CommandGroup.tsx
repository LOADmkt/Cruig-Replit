
import * as React from "react";
import { Command as CommandPrimitive } from "cmdk";
import { cn } from "@/lib/utils";
import { CommandGroupProps, CommandGroupRef } from "./types";

export const CommandGroup = React.forwardRef<CommandGroupRef, CommandGroupProps>(
  ({ className, children, emptyElement, ...props }, ref) => {
    // Ensure that children is always a valid React element or array
    const safeChildren = React.useMemo(() => {
      try {
        // Handle undefined or null children
        if (children === undefined || children === null) {
          return [];
        }
        
        // If it's already a valid React element, return as is
        if (React.isValidElement(children)) {
          return children;
        }
        
        // If it's an array, filter out any falsy values
        if (Array.isArray(children)) {
          return children.filter(Boolean);
        }
        
        // Try to convert to array using React's utility
        try {
          const childrenArray = React.Children.toArray(children);
          return childrenArray.filter(Boolean);
        } catch (e) {
          console.error("Failed to process CommandGroup children:", e);
          return [];
        }
      } catch (e) {
        console.error("Failed to process CommandGroup children:", e);
        return [];
      }
    }, [children]);
    
    // Also ensure that other props are safe
    const safeProps = React.useMemo(() => {
      try {
        const processed = { ...props };
        
        // Convert any undefined props to null
        Object.keys(processed).forEach(key => {
          if (processed[key] === undefined) {
            processed[key] = null;
          }
        });
        
        return processed;
      } catch (e) {
        console.error("Error processing CommandGroup props:", e);
        return {};
      }
    }, [props]);
    
    // If there are no valid children and not rendering empty state, don't render anything
    if ((!safeChildren || (Array.isArray(safeChildren) && safeChildren.length === 0)) && 
        !emptyElement) {
      return null;
    }
    
    return (
      <CommandPrimitive.Group
        ref={ref}
        className={cn(
          "overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground",
          className
        )}
        {...safeProps}
      >
        {safeChildren}
        {emptyElement}
      </CommandPrimitive.Group>
    );
  }
);

CommandGroup.displayName = CommandPrimitive.Group.displayName;
