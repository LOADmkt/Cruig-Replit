import * as React from "react";
import { Command as CommandPrimitive } from "cmdk";
import { cn } from "@/lib/utils";
import { CommandItemProps, CommandItemRef } from "./types";

export const CommandItem = React.forwardRef<CommandItemRef, CommandItemProps>(
  ({ className, ...props }, ref) => {
    const safeProps = React.useMemo(() => {
      try {
        const processed = { ...props };
        
        if (processed.children === undefined || processed.children === null) {
          processed.children = [];
        } else if (Array.isArray(processed.children)) {
          processed.children = processed.children.filter(Boolean);
        } else if (React.isValidElement(processed.children)) {
          // Single valid React element - keep as is
        } else {
          try {
            processed.children = React.Children.toArray(processed.children).filter(Boolean);
          } catch (err) {
            console.error("Error processing CommandItem children:", err);
            processed.children = [];
          }
        }

        Object.keys(processed).forEach(key => {
          if (processed[key] === undefined) {
            processed[key] = null;
          }
        });

        return processed;
      } catch (error) {
        console.error("Error processing CommandItem props:", error);
        return { children: [] };
      }
    }, [props]);

    return (
      <CommandPrimitive.Item
        ref={ref}
        className={cn(
          "relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none aria-selected:bg-accent aria-selected:text-accent-foreground data-[disabled=true]:pointer-events-none data-[disabled=true]:opacity-50",
          className
        )}
        {...safeProps}
      />
    );
  }
);

CommandItem.displayName = CommandPrimitive.Item.displayName;
