
import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  maxVisibleButtons?: number;
}

export function Pagination({
  currentPage,
  totalPages,
  onPageChange,
  maxVisibleButtons = 5
}: PaginationProps) {
  // Não renderiza paginação se não houver páginas ou apenas uma
  if (totalPages <= 1) return null;

  const getVisiblePageNumbers = () => {
    if (totalPages <= maxVisibleButtons) {
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }
    
    // Metade (arredondada para baixo) do número máximo de botões visíveis
    const halfMaxButtons = Math.floor(maxVisibleButtons / 2);
    
    // Caso 1: Próximo ao início
    if (currentPage <= halfMaxButtons) {
      return Array.from({ length: maxVisibleButtons }, (_, i) => i + 1);
    }
    
    // Caso 2: Próximo ao fim
    if (currentPage > totalPages - halfMaxButtons) {
      return Array.from({ length: maxVisibleButtons }, (_, i) => totalPages - maxVisibleButtons + i + 1);
    }
    
    // Caso 3: Em algum lugar no meio
    const startPage = currentPage - halfMaxButtons;
    return Array.from({ length: maxVisibleButtons }, (_, i) => startPage + i);
  };

  const visiblePageNumbers = getVisiblePageNumbers();

  const handlePrevious = () => {
    if (currentPage > 1) onPageChange(currentPage - 1);
  };

  const handleNext = () => {
    if (currentPage < totalPages) onPageChange(currentPage + 1);
  };

  const renderPageButton = (pageNumber: number | string, isActive: boolean = false) => {
    // Se for uma string (ex: "..."), apenas renderiza sem ação
    if (typeof pageNumber === 'string') {
      return (
        <div className="px-2 py-1 text-gray-400">
          {pageNumber}
        </div>
      );
    }
    
    return (
      <Button
        key={pageNumber}
        variant={isActive ? "default" : "outline"}
        size="sm"
        className={`px-3 ${isActive ? 'bg-[#94C700] text-white hover:bg-[#75a300]' : 'text-gray-700'}`}
        onClick={() => onPageChange(pageNumber)}
        disabled={isActive}
      >
        {pageNumber}
      </Button>
    );
  };

  return (
    <div className="flex items-center justify-center space-x-1">
      <Button
        variant="outline"
        size="icon"
        onClick={handlePrevious}
        disabled={currentPage === 1}
        className="mr-1"
      >
        <ChevronLeft className="h-4 w-4" />
        <span className="sr-only">Página anterior</span>
      </Button>
      
      {totalPages > maxVisibleButtons && currentPage > Math.floor(maxVisibleButtons / 2) + 1 && (
        <>
          {renderPageButton(1)}
          {renderPageButton("...")}
        </>
      )}
      
      {visiblePageNumbers.map(pageNumber => 
        renderPageButton(pageNumber, pageNumber === currentPage)
      )}
      
      {totalPages > maxVisibleButtons && currentPage < totalPages - Math.floor(maxVisibleButtons / 2) && (
        <>
          {renderPageButton("...")}
          {renderPageButton(totalPages)}
        </>
      )}
      
      <Button
        variant="outline"
        size="icon"
        onClick={handleNext}
        disabled={currentPage === totalPages}
        className="ml-1"
      >
        <ChevronRight className="h-4 w-4" />
        <span className="sr-only">Próxima página</span>
      </Button>
    </div>
  );
}
