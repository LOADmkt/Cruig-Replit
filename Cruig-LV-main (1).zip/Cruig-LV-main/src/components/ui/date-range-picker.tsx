
import * as React from "react";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale"; 
import { DateRange } from "react-day-picker";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface DatePickerWithRangeProps {
  date: DateRange | undefined;
  onSelect: (date: DateRange | undefined) => void;
  className?: string;
  initialDateFrom?: Date;
  initialDateTo?: Date;
}

export function DatePickerWithRange({
  date,
  onSelect,
  className,
  initialDateFrom,
  initialDateTo
}: DatePickerWithRangeProps) {
  const [isOpen, setIsOpen] = React.useState(false);
  
  // Initialize with provided dates or default to current week
  const initialDate = React.useMemo(() => {
    if (date) return date;
    
    return {
      from: initialDateFrom || new Date(),
      to: initialDateTo || undefined
    };
  }, [date, initialDateFrom, initialDateTo]);

  function formatDateString(date: Date | undefined): string {
    if (!date) return "";
    return format(date, "dd/MM/yyyy", { locale: ptBR });
  }

  return (
    <div className={cn("grid gap-2", className)}>
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            id="date"
            variant={"outline"}
            className={cn(
              "min-w-[240px] justify-start text-left font-normal border-2 border-gray-300 focus:border-brand-primary focus:ring-2 focus:ring-brand-primary",
              !date && "text-muted-foreground"
            )}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {date?.from ? (
              date.to ? (
                <>
                  {formatDateString(date.from)} - {formatDateString(date.to)}
                </>
              ) : (
                formatDateString(date.from)
              )
            ) : (
              <span>Selecione um período</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            initialFocus
            mode="range"
            defaultMonth={date?.from || new Date()}
            selected={date}
            onSelect={(newDate) => {
              onSelect(newDate);
              if (newDate?.from && newDate?.to) {
                setIsOpen(false);
              }
            }}
            numberOfMonths={2}
            locale={ptBR}
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}
