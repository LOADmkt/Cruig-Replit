import * as React from "react"
import * as PopoverPrimitive from "@radix-ui/react-popover"

import { cn } from "@/lib/utils"

const Popover = PopoverPrimitive.Root

const PopoverTrigger = PopoverPrimitive.Trigger

const PopoverContent = React.forwardRef<
  React.ElementRef<typeof PopoverPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof PopoverPrimitive.Content>
>(({ className, align = "center", sideOffset = 4, ...props }, ref) => {
  // Enhanced multi-layer safety for props handling
  const safeProps = React.useMemo(() => {
    try {
      const tempProps = { ...props };
      
      // Process children with comprehensive validation
      if (tempProps.children !== undefined && tempProps.children !== null) {
        try {
          // For React elements, keep as is
          if (React.isValidElement(tempProps.children)) {
            // Keep as is, it's valid
          }
          // For arrays, filter out nulls
          else if (Array.isArray(tempProps.children)) {
            tempProps.children = tempProps.children.filter(Boolean);
          }
          // For anything else, use toArray with explicit safeguards
          else {
            const childrenArray = React.Children.toArray(tempProps.children ?? []);
            tempProps.children = childrenArray.filter(Boolean);
          }
        } catch (err) {
          console.error("Error processing PopoverContent children:", err);
          tempProps.children = []; // Empty array is safer than null for iteration
        }
      } else {
        tempProps.children = [];
      }
      
      // Handle remaining props with validation
      Object.keys(tempProps).forEach(key => {
        if (tempProps[key] === undefined) {
          tempProps[key] = null;
        }
      });
      
      return tempProps;
    } catch (e) {
      console.error("Critical error processing PopoverContent props:", e);
      // Return minimal safe props if all else fails
      return { children: [] };
    }
  }, [props]);
  
  // Ensure align and sideOffset are always defined and valid
  const safeAlign = align || "center";
  const safeSideOffset = typeof sideOffset === 'number' ? sideOffset : 4;
  
  return (
    <PopoverPrimitive.Portal>
      <PopoverPrimitive.Content
        ref={ref}
        align={safeAlign}
        sideOffset={safeSideOffset}
        className={cn(
          "z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
          className
        )}
        {...safeProps}
      />
    </PopoverPrimitive.Portal>
  )
})

PopoverContent.displayName = PopoverPrimitive.Content.displayName

export { Popover, PopoverTrigger, PopoverContent }
