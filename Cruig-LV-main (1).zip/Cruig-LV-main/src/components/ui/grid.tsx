
import React from "react";
import { cn } from "@/lib/utils";

type ColValue = 1 | 2 | 3 | 4 | 5 | 6 | "auto";
type ColBreakpointValue = ColValue | number; // Allow number for breakpoints

interface GridProps {
  children: React.ReactNode;
  className?: string;
  cols?: ColValue;
  sm?: ColBreakpointValue;
  md?: ColBreakpointValue;
  lg?: ColBreakpointValue;
  xl?: ColBreakpointValue;
  gap?: number;
}

export function Grid({
  children,
  className,
  cols = 1,
  sm,
  md,
  lg,
  xl,
  gap,
}: GridProps) {
  const getColClass = (breakpoint: string, value: ColBreakpointValue): string => {
    const prefix = breakpoint ? `${breakpoint}:` : "";
    
    // Handle value as number for breakpoints
    if (typeof value === 'number') {
      return `${prefix}grid-cols-${value}`;
    }
    
    // Handle string type separately from number type to avoid comparison errors
    if (value === "auto") {
      return `${prefix}grid-cols-auto`;
    }
    
    // Now handle numeric literal types
    switch (value) {
      case 1:
        return `${prefix}grid-cols-1`;
      case 2:
        return `${prefix}grid-cols-2`;
      case 3:
        return `${prefix}grid-cols-3`;
      case 4:
        return `${prefix}grid-cols-4`;
      case 5:
        return `${prefix}grid-cols-5`;
      case 6:
        return `${prefix}grid-cols-6`;
      default:
        return "";
    }
  };

  const getGapClass = (value: number): string => {
    switch (value) {
      case 1:
        return "gap-1";
      case 2:
        return "gap-2";
      case 3:
        return "gap-3";
      case 4:
        return "gap-4";
      case 5:
        return "gap-5";
      case 6:
        return "gap-6";
      case 8:
        return "gap-8";
      default:
        return "gap-4";
    }
  };

  return (
    <div
      className={cn(
        "grid",
        getColClass("", cols),
        sm && getColClass("sm", sm),
        md && getColClass("md", md),
        lg && getColClass("lg", lg),
        xl && getColClass("xl", xl),
        gap ? getGapClass(gap) : "",
        className
      )}
    >
      {children}
    </div>
  );
}
