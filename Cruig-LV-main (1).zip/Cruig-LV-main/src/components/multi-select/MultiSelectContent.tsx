
import * as React from "react";
import { X, Check, ChevronsUpDown } from "lucide-react";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from "@/components/ui/command";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { MultiSelectOption } from "./types";

interface MultiSelectContentProps {
  options: MultiSelectOption[];
  filteredOptions: MultiSelectOption[];
  selected: string[];
  onSelect: (value: string) => void;
  onClear: () => void;
  inputValue: string;
  setInputValue: (value: string) => void;
  emptyMessage: string;
  searchPlaceholder: string;
  maxHeight?: number;
}

export const MultiSelectContent: React.FC<MultiSelectContentProps> = ({
  options,
  filteredOptions,
  selected,
  onSelect,
  onClear,
  inputValue,
  setInputValue,
  emptyMessage,
  searchPlaceholder,
  maxHeight = 300
}) => {
  const sortedFilteredOptions = React.useMemo(() => {
    // Garantir que filteredOptions é um array antes de ordenar
    const safeFilteredOptions = Array.isArray(filteredOptions) ? filteredOptions : [];
    
    // Ordenar as opções para mostrar itens selecionados primeiro
    return [...safeFilteredOptions].sort((a, b) => {
      const aSelected = selected.includes(a.value);
      const bSelected = selected.includes(b.value);
      if (aSelected && !bSelected) return -1;
      if (!aSelected && bSelected) return 1;
      return 0;
    });
  }, [filteredOptions, selected]);

  return (
    <div className="w-full">
      <div className="flex items-center justify-between pb-2 px-3">
        <p className="text-sm text-gray-500 font-medium">
          {selected.length} selecionado(s)
        </p>
        {selected.length > 0 && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onClear} 
            className="h-7 px-2 text-xs text-gray-600 hover:text-gray-800"
          >
            <X className="h-3.5 w-3.5 mr-1" />
            Limpar
          </Button>
        )}
      </div>
      <Command className="border-0 p-0 shadow-none">
        <div className="flex items-center border-b border-gray-200 px-3">
          <CommandInput 
            placeholder={searchPlaceholder}
            value={inputValue}
            onValueChange={setInputValue}
            className="border-0 focus:ring-0 text-sm h-9 p-2"
          />
        </div>
        <ScrollArea className="overflow-auto" style={{ maxHeight: `${maxHeight}px` }}>
          <CommandEmpty className="py-6 text-center text-sm">{emptyMessage}</CommandEmpty>
          <CommandGroup className="overflow-visible">
            {sortedFilteredOptions.map((option) => {
              const isSelected = selected.includes(option.value);
              return (
                <CommandItem
                  key={option.value}
                  onSelect={() => onSelect(option.value)}
                  className={cn(
                    "flex items-center gap-2 px-2 py-1.5 cursor-pointer my-1 text-sm",
                    isSelected ? "bg-[#99c00d]/10" : "hover:bg-gray-100"
                  )}
                >
                  <div className={cn(
                    "flex h-4 w-4 items-center justify-center rounded-sm border border-gray-300",
                    isSelected ? "bg-[#99c00d] border-[#99c00d]" : "opacity-50"
                  )}>
                    {isSelected && (
                      <Check className="h-3 w-3 text-white" />
                    )}
                  </div>
                  <span>{option.label}</span>
                </CommandItem>
              );
            })}
          </CommandGroup>
        </ScrollArea>
      </Command>
    </div>
  );
};
