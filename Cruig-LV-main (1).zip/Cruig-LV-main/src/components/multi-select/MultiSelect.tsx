
import * as React from 'react';
import { PopoverContent, PopoverTrigger, Popover } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { MultiSelectProps } from './types';
import { useMultiSelect } from './useMultiSelect';
import { MultiSelectTrigger } from './MultiSelectTrigger';
import { MultiSelectContent } from './MultiSelectContent';

export function MultiSelect({
  options,
  selected,
  onChange,
  placeholder = 'Selecionar opções...',
  className,
  searchPlaceholder = 'Buscar opções...',
  emptyMessage = 'Nenhuma opção encontrada.',
  disabled = false,
  maxHeight = 200,
}: MultiSelectProps) {
  const {
    open,
    setOpen,
    inputValue,
    setInputValue,
    safeOptions,
    safeSelected,
    filteredOptions,
    handleUnselect,
    handleSelect,
    handleClear
  } = useMultiSelect(options, selected, onChange);
  
  return (
    <Popover open={disabled ? false : open} onOpenChange={disabled ? undefined : setOpen}>
      <PopoverTrigger asChild>
        <div 
          className={cn(
            'cursor-pointer',
            disabled && 'opacity-50 cursor-not-allowed'
          )}
          onClick={() => !disabled && setOpen(true)}
        >
          <MultiSelectTrigger
            open={open}
            setOpen={setOpen}
            options={safeOptions}
            selected={safeSelected}
            onUnselect={handleUnselect}
            placeholder={placeholder}
            className={className}
          />
        </div>
      </PopoverTrigger>
      <PopoverContent className="w-full p-2" align="start">
        <MultiSelectContent
          options={safeOptions}
          filteredOptions={filteredOptions}
          selected={safeSelected}
          onSelect={handleSelect}
          onClear={handleClear}
          inputValue={inputValue}
          setInputValue={setInputValue}
          emptyMessage={emptyMessage}
          searchPlaceholder={searchPlaceholder}
          maxHeight={maxHeight}
        />
      </PopoverContent>
    </Popover>
  );
}
