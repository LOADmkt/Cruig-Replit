
import * as React from "react";
import { X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { MultiSelectOption } from "./types";

interface BadgeListProps {
  selectedItems: string[];
  options: MultiSelectOption[];
  onUnselect: (item: string) => void;
}

export const BadgeList: React.FC<BadgeListProps> = ({ selectedItems, options, onUnselect }) => {
  try {
    return selectedItems.map((item) => {
      const option = options.find((opt) => opt.value === item);
      if (!option) return null;
      return (
        <Badge
          key={item}
          variant="secondary"
          className="mr-1 mb-1 bg-[#99c00d]/20 text-gray-800 hover:bg-[#99c00d]/30"
        >
          {option.label}
          <button
            className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-[#99c00d] focus:ring-offset-2"
            type="button"
            onMouseDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onUnselect(item);
            }}
          >
            <X className="h-3 w-3 text-gray-700 hover:text-gray-900" />
          </button>
        </Badge>
      );
    }).filter(Boolean);
  } catch (error) {
    console.error("Error rendering badges:", error);
    return null;
  }
};
