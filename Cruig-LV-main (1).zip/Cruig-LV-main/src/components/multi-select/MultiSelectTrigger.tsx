
import * as React from "react";
import { ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { BadgeList } from "./BadgeList";
import { MultiSelectOption } from "./types";

interface MultiSelectTriggerProps {
  open: boolean;
  setOpen: (open: boolean) => void;
  options: MultiSelectOption[];
  selected: string[];
  onUnselect: (item: string) => void;
  placeholder: string;
  className?: string;
}

export const MultiSelectTrigger: React.FC<MultiSelectTriggerProps> = ({
  open,
  setOpen,
  options,
  selected,
  onUnselect,
  placeholder,
  className
}) => {
  return (
    <Button
      variant="outline"
      role="combobox"
      aria-expanded={open}
      className={cn(
        "w-full justify-between overflow-hidden border-2 border-gray-300 hover:border-[#99c00d] focus:border-[#99c00d] focus:ring-2 focus:ring-[#99c00d]", 
        className
      )}
      onClick={() => setOpen(!open)}
      type="button"
    >
      <div className="flex gap-1 flex-wrap">
        {selected.length === 0 ? (
          <span className="text-gray-500">{placeholder}</span>
        ) : (
          <BadgeList 
            selectedItems={selected} 
            options={options} 
            onUnselect={onUnselect} 
          />
        )}
      </div>
      <ChevronDown className="h-4 w-4 text-gray-700 shrink-0" />
    </Button>
  );
};
