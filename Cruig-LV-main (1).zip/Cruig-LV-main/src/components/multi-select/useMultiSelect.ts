
import { useState, useMemo, useCallback } from "react";
import { MultiSelectOption } from "./types";

export function useMultiSelect(
  options: MultiSelectOption[] = [],
  selected: string[] = [], 
  onChange: (value: string[]) => void
) {
  // Estado local
  const [open, setOpen] = useState(false);
  const [inputValue, setInputValue] = useState("");
  
  // Garantir que os arrays sejam seguros (não undefined)
  const safeOptions = Array.isArray(options) ? options : [];
  const safeSelected = Array.isArray(selected) ? selected : [];
  
  // Filtrar opções com base no input de pesquisa
  const filteredOptions = useMemo(() => {
    return safeOptions.filter((option) => {
      const matchesSearch = option.label
        .toLowerCase()
        .includes(inputValue.toLowerCase());
      return matchesSearch;
    });
  }, [safeOptions, inputValue]);
  
  // Manipuladores de eventos
  const handleUnselect = useCallback((value: string) => {
    onChange(safeSelected.filter((item) => item !== value));
  }, [safeSelected, onChange]);
  
  const handleSelect = useCallback((value: string) => {
    if (safeSelected.includes(value)) {
      onChange(safeSelected.filter((item) => item !== value));
    } else {
      onChange([...safeSelected, value]);
    }
  }, [safeSelected, onChange]);
  
  const handleClear = useCallback(() => {
    onChange([]);
    setInputValue("");
  }, [onChange]);

  return {
    open,
    setOpen,
    inputValue,
    setInputValue,
    safeOptions,
    safeSelected,
    filteredOptions,
    handleUnselect,
    handleSelect,
    handleClear
  };
}
