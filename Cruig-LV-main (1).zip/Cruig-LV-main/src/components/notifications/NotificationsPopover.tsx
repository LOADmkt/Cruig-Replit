
import React from "react";
import { Bell, Mail, Flag, CheckCircle2 } from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useNotifications, Notification } from "@/hooks/useNotifications";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { markAllNotificationsAsRead } from "@/lib/notifications";
import { useToast } from "@/hooks/use-toast";

export function NotificationsPopover() {
  const { notifications, isLoading, markAsRead, unreadCount } = useNotifications();
  const { user } = useAuth();
  const { toast } = useToast();

  const getNotificationIcon = (type: Notification["type"]) => {
    switch (type) {
      case "message":
        return <Mail className="h-4 w-4" />;
      case "campaign":
        return <Flag className="h-4 w-4" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleMarkAllAsRead = async () => {
    if (!user) return;

    try {
      const success = await markAllNotificationsAsRead(user.id);
      if (success) {
        // Atualizar a lista de notificações
        window.location.reload(); // Para fins de demonstração - em produção, use revalidação de query
        toast({
          title: "Notificações lidas",
          description: "Todas as notificações foram marcadas como lidas",
        });
      } else {
        throw new Error("Não foi possível marcar as notificações como lidas");
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível marcar as notificações como lidas",
        variant: "destructive",
      });
    }
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 px-1.5 py-0.5 min-w-[1.2rem] h-[1.2rem] flex items-center justify-center text-xs"
            >
              {unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[380px] p-0">
        <div className="flex items-center justify-between p-4 border-b">
          <div>
            <h4 className="text-sm font-medium">Notificações</h4>
            <p className="text-xs text-muted-foreground mt-1">
              Você tem {unreadCount} notificações não lidas
            </p>
          </div>
          {unreadCount > 0 && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs"
              onClick={handleMarkAllAsRead}
            >
              <CheckCircle2 className="h-3 w-3 mr-1" />
              Marcar todas como lidas
            </Button>
          )}
        </div>
        <ScrollArea className="h-[400px]">
          {isLoading ? (
            <div className="p-4 text-center text-sm text-muted-foreground">
              Carregando notificações...
            </div>
          ) : notifications.length === 0 ? (
            <div className="p-4 text-center text-sm text-muted-foreground">
              Nenhuma notificação
            </div>
          ) : (
            <div className="grid gap-1">
              {notifications.map((notification) => (
                <button
                  key={notification.id}
                  className={cn(
                    "w-full text-left px-4 py-3 space-y-1 hover:bg-muted/50 transition-colors",
                    !notification.read && "bg-muted/30"
                  )}
                  onClick={() => markAsRead(notification.id)}
                >
                  <div className="flex items-start gap-2">
                    <div className="mt-1">{getNotificationIcon(notification.type)}</div>
                    <div className="flex-1 space-y-1">
                      <p className={cn(
                        "text-sm",
                        !notification.read && "font-medium"
                      )}>
                        {notification.title}
                      </p>
                      {notification.description && (
                        <p className="text-sm text-muted-foreground">
                          {notification.description}
                        </p>
                      )}
                      <p className="text-xs text-muted-foreground">
                        {formatDate(notification.created_at)}
                      </p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
