
import React from 'react';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';

interface ProfileTypeCardProps {
  title: string;
  description: string;
  price: string;
  priceDescription: string;
  features: string[];
  buttonText: string;
  isPopular?: boolean;
  icon: React.ReactNode;
}

const ProfileTypeCard = ({
  title,
  description,
  price,
  priceDescription,
  features,
  buttonText,
  isPopular = false,
  icon
}: ProfileTypeCardProps) => {
  return (
    <div className={`rounded-xl overflow-hidden border-2 transition-all ${
      isPopular 
        ? 'border-brand-primary shadow-lg scale-105 relative z-10' 
        : 'border-gray-200 shadow-md hover:shadow-lg'
    }`}>
      {isPopular && (
        <div className="bg-brand-primary text-white text-sm font-medium py-1.5 text-center">
          Mais Popular
        </div>
      )}
      <div className="p-6 md:p-8">
        <div className="mb-4 text-brand-primary">{icon}</div>
        <h3 className="text-2xl font-bold mb-2 text-brand-dark">{title}</h3>
        <p className="text-gray-700 mb-6">{description}</p>
        <div className="mb-6">
          <p className="text-3xl font-bold text-brand-dark">
            {price} 
            <span className="text-base font-normal text-gray-600 ml-1">{priceDescription}</span>
          </p>
        </div>
        <ul className="space-y-3 mb-8">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="text-brand-primary mr-2 h-5 w-5 mt-0.5 flex-shrink-0" />
              <span className="text-gray-700">{feature}</span>
            </li>
          ))}
        </ul>
        <Button 
          className={`w-full ${
            isPopular 
              ? 'bg-brand-primary hover:bg-brand-primary/90 text-white shadow-md hover:shadow-lg transition-all' 
              : 'bg-white text-brand-dark border-2 border-brand-primary hover:bg-brand-primary hover:text-white shadow-sm hover:shadow-md transition-all'
          } font-medium`}
          variant={isPopular ? "default" : "outline"}
        >
          {buttonText}
        </Button>
      </div>
    </div>
  );
};

export default ProfileTypeCard;
