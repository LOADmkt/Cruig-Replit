
import React from 'react';
import { 
  BadgeCheck, 
  Search, 
  MessageSquare, 
  Star, 
  BarChart3, 
  Users, 
  Filter, 
  Bell
} from 'lucide-react';
import { motion } from 'framer-motion';

const FeatureCard = ({ 
  icon: Icon, 
  title, 
  description, 
  accentColor = "bg-brand-primary" 
}: { 
  icon: React.ElementType, 
  title: string, 
  description: string,
  accentColor?: string
}) => {
  return (
    <motion.div 
      whileHover={{ y: -5, boxShadow: '0 10px 30px rgba(0,0,0,0.1)' }}
      transition={{ duration: 0.2 }}
      className="bg-white p-8 rounded-xl shadow-md border border-gray-100 hover:border-brand-primary transition-all"
    >
      <div className={`w-14 h-14 rounded-full ${accentColor} flex items-center justify-center mb-5`}>
        <Icon className="text-white" size={28} />
      </div>
      <h3 className="text-xl font-semibold mb-3 text-gray-800">{title}</h3>
      <p className="text-gray-600 leading-relaxed">{description}</p>
    </motion.div>
  );
};

const FeaturesSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div id="recursos" className="py-24 bg-brand-accent/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.span 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-block px-4 py-2 rounded-full bg-brand-primary/10 text-brand-primary font-semibold text-sm mb-4"
          >
            Por que escolher nossa plataforma
          </motion.span>
          
          <motion.h2 
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold mb-6"
          >
            Recursos Exclusivos Para Impulsionar Seu Sucesso
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-gray-600 max-w-3xl mx-auto"
          >
            Nossa plataforma foi desenvolvida para atender às necessidades específicas de criadores de conteúdo e empresas brasileiras, oferecendo ferramentas poderosas para conectar e crescer.
          </motion.p>
        </div>
        
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <motion.div variants={itemVariants}>
            <FeatureCard 
              icon={BadgeCheck}
              title="Selo de Verificação Real"
              description="Validamos a autenticidade dos criadores e empresas para garantir parcerias seguras e confiáveis."
            />
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <FeatureCard 
              icon={BarChart3}
              title="Métricas de Engajamento"
              description="Visualize dados de desempenho e engajamento em tempo real das principais redes sociais com dashboards interativos."
              accentColor="bg-green-600"
            />
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <FeatureCard 
              icon={Search}
              title="Busca Avançada"
              description="Encontre o parceiro ideal com filtros inteligentes por nicho, localização, métricas e muito mais."
              accentColor="bg-green-700"
            />
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <FeatureCard 
              icon={MessageSquare}
              title="Comunicação Direta"
              description="Troque mensagens diretamente com criadores ou empresas sem intermediários, agilizando suas parcerias."
            />
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <FeatureCard 
              icon={Star}
              title="Sistema de Avaliação"
              description="Avaliações e comentários verificados para construir reputação e credibilidade na plataforma."
              accentColor="bg-green-600"
            />
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <FeatureCard 
              icon={Filter}
              title="Filtros por Nicho"
              description="Categorizamos por nichos específicos do mercado brasileiro para facilitar conexões mais relevantes e precisas."
              accentColor="bg-green-700"
            />
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <FeatureCard 
              icon={Users}
              title="Perfis Personalizáveis"
              description="Crie seu perfil único destacando seus diferenciais para atrair os parceiros ideais para sua estratégia digital."
            />
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <FeatureCard 
              icon={Bell}
              title="Sistema de Notificações"
              description="Receba alertas sobre novas oportunidades, mensagens e interações relevantes para seu negócio."
              accentColor="bg-green-600"
            />
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <FeatureCard 
              icon={BarChart3}
              title="Dashboard Completo"
              description="Acompanhe suas campanhas, mensagens e favoritos em um painel intuitivo e totalmente personalizável."
              accentColor="bg-green-700"
            />
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default FeaturesSection;
