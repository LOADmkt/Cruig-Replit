
import React from 'react';
import { Star, Quote } from 'lucide-react';
import { motion } from 'framer-motion';

interface TestimonialProps {
  content: string;
  author: string;
  role: string;
  rating: number;
  imageSrc?: string;
  index: number;
}

const Testimonial = ({ content, author, role, rating, imageSrc, index }: TestimonialProps) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: 0.1 * index }}
      className="bg-white p-8 rounded-xl shadow-md border border-gray-100 hover:shadow-lg transition-shadow"
    >
      <Quote className="h-10 w-10 text-brand-primary/20 mb-4" />
      <div className="flex mb-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star 
            key={i} 
            className={`w-5 h-5 ${i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
          />
        ))}
      </div>
      <p className="text-gray-700 mb-6 text-lg">{content}</p>
      <div className="flex items-center">
        <div className="w-14 h-14 rounded-full bg-brand-primary/20 overflow-hidden mr-4">
          {imageSrc ? (
            <img src={imageSrc} alt={author} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-brand-primary text-white font-medium text-xl">
              {author.charAt(0)}
            </div>
          )}
        </div>
        <div>
          <h4 className="font-semibold text-lg">{author}</h4>
          <p className="text-gray-500">{role}</p>
        </div>
      </div>
    </motion.div>
  );
};

const TestimonialsSection = () => {
  const testimonials = [
    {
      content: "A plataforma me conectou com marcas que realmente combinam com meu conteúdo. Já fechei 3 campanhas em apenas 2 meses!",
      author: "Ana Silva",
      role: "Criadora de Conteúdo de Lifestyle",
      rating: 5
    },
    {
      content: "Como empresa, economizamos tempo e recursos encontrando criadores autênticos que realmente entregam resultados.",
      author: "Roberto Oliveira",
      role: "Gerente de Marketing, TechBrasil",
      rating: 4
    },
    {
      content: "O sistema de verificação dá muita segurança. Sei que estou trabalhando com profissionais reais e comprometidos.",
      author: "Camila Santos",
      role: "Criadora de Conteúdo de Moda",
      rating: 5
    },
    {
      content: "As métricas em tempo real nos ajudam a tomar decisões baseadas em dados, otimizando nossos investimentos em marketing de influência.",
      author: "Lucas Mendes",
      role: "Diretor de Marketing, BeautyStore",
      rating: 5
    }
  ];

  return (
    <div className="py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.span 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-block px-4 py-2 rounded-full bg-brand-primary/10 text-brand-primary font-semibold text-sm mb-4"
          >
            DEPOIMENTOS
          </motion.span>
          
          <motion.h2 
            initial={{ opacity: 0, y: -10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
          >
            O Que Nossos Usuários Dizem
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-gray-600 max-w-3xl mx-auto"
          >
            Veja como a nossa plataforma tem transformado a colaboração entre criadores e marcas no Brasil.
          </motion.p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <Testimonial key={index} {...testimonial} index={index} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default TestimonialsSection;
