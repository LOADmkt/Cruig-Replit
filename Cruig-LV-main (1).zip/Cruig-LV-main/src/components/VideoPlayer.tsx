
import React, { useState, useRef } from 'react';
import { Play, Pause, Volume2, VolumeX } from 'lucide-react';

interface VideoPlayerProps {
  posterUrl: string;
  videoUrl: string;
  className?: string;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ posterUrl, videoUrl, className }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const togglePlay = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play();
        setIsPlaying(true);
      } else {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !videoRef.current.muted;
      setIsMuted(!isMuted);
    }
  };

  return (
    <div className={`relative rounded-xl overflow-hidden shadow-xl ${className}`}>
      <div className="aspect-w-16 aspect-h-9 bg-black rounded-xl overflow-hidden">
        <video 
          ref={videoRef}
          className="w-full h-full object-cover"
          poster={posterUrl}
          preload="metadata"
          onEnded={() => setIsPlaying(false)}
        >
          <source src={videoUrl} type="video/mp4" />
          Seu navegador não suporta o elemento de vídeo.
        </video>
        
        <div className="absolute inset-0 flex flex-col justify-between p-4 bg-gradient-to-b from-black/30 to-black/70 opacity-0 hover:opacity-100 transition-opacity">
          <div className="flex justify-end">
            <button 
              onClick={toggleMute}
              className="bg-black/50 rounded-full p-2 text-white hover:bg-black/70 transition-colors"
            >
              {isMuted ? (
                <VolumeX className="h-5 w-5" />
              ) : (
                <Volume2 className="h-5 w-5" />
              )}
            </button>
          </div>
          
          <div className="flex justify-center">
            <button 
              onClick={togglePlay}
              className="bg-white/90 rounded-full p-3 group-hover:scale-110 transition-transform"
            >
              {isPlaying ? (
                <Pause className="h-8 w-8 text-brand-primary" />
              ) : (
                <Play className="h-8 w-8 text-brand-primary ml-1" />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
