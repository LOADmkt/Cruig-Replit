
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { buttonAnimation, combineAnimations, hoverEffects } from '@/lib/animations';
import { motion } from 'framer-motion';

const CTASection = () => {
  return (
    <div id="planos" className="py-24 bg-gradient-to-b from-white to-brand-accent/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="max-w-5xl mx-auto bg-gradient-to-r from-brand-primary to-brand-primary/90 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-shadow"
        >
          <div className="p-10 md:p-14 text-white text-center md:text-left relative">
            <div className="flex flex-col md:flex-row items-center gap-6">
              {/* Text content */}
              <div className="md:w-3/5">
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
                  Pronto Para Transformar Suas Parcerias Digitais?
                </h2>
                <p className="text-xl opacity-95 mb-10 font-medium">
                  Crie sua conta gratuitamente e comece a descobrir as melhores oportunidades para expandir seu alcance no mercado brasileiro.
                </p>
                <div className="flex flex-col sm:flex-row gap-6 justify-center md:justify-start">
                  <Button 
                    size="xl" 
                    onClick={() => window.location.href = '/auth'}
                    className={combineAnimations(
                      "bg-white text-brand-primary hover:bg-fffee2 shadow-lg hover:shadow-xl text-lg font-semibold",
                      buttonAnimation,
                      hoverEffects.glow
                    )}
                  >
                    Cadastre-se Gratuitamente <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                  <Button 
                    size="xl" 
                    variant="outline"
                    onClick={() => window.location.href = '#recursos'}
                    className={combineAnimations(
                      "border-2 border-[#fffee2] text-[#fffee2] hover:bg-[#fffee2]/20 text-lg font-semibold",
                      buttonAnimation
                    )}
                  >
                    Saiba mais <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </div>
              </div>
              
              {/* Frog Detective Image with animation */}
              <div className="md:w-2/5 flex justify-center md:justify-end">
                <motion.div
                  initial={{ y: 0 }}
                  animate={{ 
                    y: [0, -5, 0],
                    rotate: [-1, 1, -1]
                  }}
                  transition={{ 
                    repeat: Infinity, 
                    duration: 5,
                    ease: "easeInOut"
                  }}
                  className="relative z-10"
                >
                  <img 
                    src="/lovable-uploads/3920ac5b-8afd-4e07-82e3-4ecf89ae8101.png" 
                    alt="Detetive Sapo" 
                    className="max-h-72 md:max-h-80 lg:max-h-96 object-contain"
                  />
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default CTASection;
