
import React from 'react';
import { Button } from "@/components/ui/button";
import { Instagram, Youtube, Check } from 'lucide-react';
import { BrandTiktok } from "@/components/icons/BrandTiktok";

interface SocialConnectButtonProps {
  platform: 'instagram' | 'youtube' | 'tiktok';
  isConnected: boolean;
  onConnect: () => void;
}

export function SocialConnectButton({ platform, isConnected, onConnect }: SocialConnectButtonProps) {
  const getPlatformDetails = () => {
    switch (platform) {
      case 'instagram':
        return {
          icon: <Instagram className="h-5 w-5 mr-2" />,
          text: isConnected ? 'Instagram conectado' : 'Conectar Instagram',
          color: isConnected 
            ? 'bg-green-600 hover:bg-green-700 shadow-md hover:shadow-lg' 
            : 'bg-gradient-to-r from-purple-700 to-pink-600 hover:from-purple-800 hover:to-pink-700 shadow-md hover:shadow-lg',
          textColor: 'text-white font-medium'
        };
      case 'youtube':
        return {
          icon: <Youtube className="h-5 w-5 mr-2" />,
          text: isConnected ? 'YouTube conectado' : 'Conectar YouTube',
          color: isConnected 
            ? 'bg-green-600 hover:bg-green-700 shadow-md hover:shadow-lg'
            : 'bg-red-700 hover:bg-red-800 shadow-md hover:shadow-lg',
          textColor: 'text-white font-medium'
        };
      case 'tiktok':
        return {
          icon: <BrandTiktok className="h-5 w-5 mr-2" />,
          text: isConnected ? 'TikTok conectado' : 'Conectar TikTok',
          color: isConnected 
            ? 'bg-green-600 hover:bg-green-700 shadow-md hover:shadow-lg'
            : 'bg-black hover:bg-gray-900 shadow-md hover:shadow-lg',
          textColor: 'text-white font-medium'
        };
    }
  };

  const details = getPlatformDetails();

  return (
    <Button 
      className={`${details.color} ${details.textColor} ${isConnected ? 'opacity-90' : ''} w-full md:w-auto transition-all rounded-lg`}
      onClick={onConnect}
      disabled={isConnected}
    >
      {isConnected ? <Check className="h-5 w-5 mr-2 text-white" /> : details.icon}
      {details.text}
      {isConnected && (
        <span className="ml-2 bg-green-400 rounded-full h-3 w-3 animate-pulse"></span>
      )}
    </Button>
  );
}
