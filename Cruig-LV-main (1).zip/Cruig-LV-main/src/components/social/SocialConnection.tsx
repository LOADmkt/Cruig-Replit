
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { SocialConnectButton } from "./SocialConnectButton";
import { RefreshCw } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface SocialConnectionProps {
  onComplete?: () => void;
}

export function SocialConnection({ onComplete }: SocialConnectionProps) {
  const { toast } = useToast();
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectedPlatforms, setConnectedPlatforms] = useState<{
    instagram: boolean;
    youtube: boolean;
    tiktok: boolean;
  }>({
    instagram: false,
    youtube: false,
    tiktok: false
  });
  
  const [socialStats, setSocialStats] = useState({
    instagram: {
      followers: 0,
      engagement: 0,
      lastSync: null as Date | null
    },
    youtube: {
      subscribers: 0,
      views: 0,
      lastSync: null as Date | null
    },
    tiktok: {
      followers: 0,
      engagement: 0,
      lastSync: null as Date | null
    }
  });

  const handleConnect = (platform: 'instagram' | 'youtube' | 'tiktok') => {
    setIsConnecting(true);
    
    // Simular o processo de autenticação OAuth
    toast({
      title: "Redirecionando para autorização",
      description: `Você será redirecionado para autenticação do ${platform}`,
    });
    
    // Simular autenticação bem-sucedida após 2 segundos
    setTimeout(() => {
      setConnectedPlatforms(prev => ({
        ...prev,
        [platform]: true
      }));
      
      // Dados simulados
      if (platform === 'instagram') {
        setSocialStats(prev => ({
          ...prev,
          instagram: {
            followers: 15800,
            engagement: 4.2,
            lastSync: new Date()
          }
        }));
      } else if (platform === 'youtube') {
        setSocialStats(prev => ({
          ...prev,
          youtube: {
            subscribers: 25600,
            views: 1200000,
            lastSync: new Date()
          }
        }));
      } else if (platform === 'tiktok') {
        setSocialStats(prev => ({
          ...prev,
          tiktok: {
            followers: 32400,
            engagement: 6.8,
            lastSync: new Date()
          }
        }));
      }
      
      setIsConnecting(false);
      
      toast({
        title: "Conexão realizada com sucesso",
        description: `Sua conta do ${platform} foi conectada e os dados sincronizados`,
      });
    }, 2000);
  };
  
  const handleRefresh = () => {
    toast({
      title: "Sincronizando dados",
      description: "Estamos buscando suas métricas mais recentes",
    });
    
    // Simular atualização de dados
    setTimeout(() => {
      toast({
        title: "Dados atualizados",
        description: "Suas métricas foram sincronizadas com sucesso",
      });
      
      // Atualizar as datas de sincronização
      setSocialStats(prev => ({
        instagram: {
          ...prev.instagram,
          lastSync: connectedPlatforms.instagram ? new Date() : null
        },
        youtube: {
          ...prev.youtube,
          lastSync: connectedPlatforms.youtube ? new Date() : null
        },
        tiktok: {
          ...prev.tiktok,
          lastSync: connectedPlatforms.tiktok ? new Date() : null
        }
      }));
    }, 2000);
  };

  const anyConnected = connectedPlatforms.instagram || connectedPlatforms.youtube || connectedPlatforms.tiktok;

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Conecte suas redes sociais</CardTitle>
        <CardDescription>
          Conecte suas redes para importar métricas e melhorar suas chances de parcerias
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <SocialConnectButton 
              platform="instagram" 
              isConnected={connectedPlatforms.instagram}
              onConnect={() => handleConnect('instagram')} 
            />
            <SocialConnectButton 
              platform="youtube" 
              isConnected={connectedPlatforms.youtube}
              onConnect={() => handleConnect('youtube')} 
            />
            <SocialConnectButton 
              platform="tiktok" 
              isConnected={connectedPlatforms.tiktok}
              onConnect={() => handleConnect('tiktok')} 
            />
          </div>
          
          {anyConnected && (
            <>
              <div className="flex justify-between items-center mt-4">
                <h3 className="text-lg font-medium">Métricas importadas</h3>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleRefresh}
                  className="gap-1"
                >
                  <RefreshCw className="h-4 w-4" />
                  Atualizar agora
                </Button>
              </div>
              
              <Tabs defaultValue={connectedPlatforms.instagram ? "instagram" : connectedPlatforms.youtube ? "youtube" : "tiktok"}>
                <TabsList className="w-full grid grid-cols-3">
                  <TabsTrigger value="instagram" disabled={!connectedPlatforms.instagram}>Instagram</TabsTrigger>
                  <TabsTrigger value="youtube" disabled={!connectedPlatforms.youtube}>YouTube</TabsTrigger>
                  <TabsTrigger value="tiktok" disabled={!connectedPlatforms.tiktok}>TikTok</TabsTrigger>
                </TabsList>
                
                <TabsContent value="instagram" className="mt-4">
                  {connectedPlatforms.instagram && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div className="bg-gray-50 p-3 rounded-lg text-center">
                        <p className="text-sm text-gray-600">Seguidores</p>
                        <p className="font-bold text-xl">{socialStats.instagram.followers.toLocaleString()}</p>
                      </div>
                      <div className="bg-gray-50 p-3 rounded-lg text-center">
                        <p className="text-sm text-gray-600">Engajamento</p>
                        <p className="font-bold text-xl">{socialStats.instagram.engagement}%</p>
                      </div>
                      <div className="bg-gray-50 p-3 rounded-lg text-center md:col-span-1 col-span-2">
                        <p className="text-sm text-gray-600">Última sincronização</p>
                        <p className="font-medium">
                          {socialStats.instagram.lastSync 
                            ? socialStats.instagram.lastSync.toLocaleDateString('pt-BR', {hour: '2-digit', minute: '2-digit'}) 
                            : 'Nunca'}
                        </p>
                      </div>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="youtube" className="mt-4">
                  {connectedPlatforms.youtube && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div className="bg-gray-50 p-3 rounded-lg text-center">
                        <p className="text-sm text-gray-600">Inscritos</p>
                        <p className="font-bold text-xl">{socialStats.youtube.subscribers.toLocaleString()}</p>
                      </div>
                      <div className="bg-gray-50 p-3 rounded-lg text-center">
                        <p className="text-sm text-gray-600">Visualizações</p>
                        <p className="font-bold text-xl">{socialStats.youtube.views.toLocaleString()}</p>
                      </div>
                      <div className="bg-gray-50 p-3 rounded-lg text-center md:col-span-1 col-span-2">
                        <p className="text-sm text-gray-600">Última sincronização</p>
                        <p className="font-medium">
                          {socialStats.youtube.lastSync 
                            ? socialStats.youtube.lastSync.toLocaleDateString('pt-BR', {hour: '2-digit', minute: '2-digit'}) 
                            : 'Nunca'}
                        </p>
                      </div>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="tiktok" className="mt-4">
                  {connectedPlatforms.tiktok && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div className="bg-gray-50 p-3 rounded-lg text-center">
                        <p className="text-sm text-gray-600">Seguidores</p>
                        <p className="font-bold text-xl">{socialStats.tiktok.followers.toLocaleString()}</p>
                      </div>
                      <div className="bg-gray-50 p-3 rounded-lg text-center">
                        <p className="text-sm text-gray-600">Engajamento</p>
                        <p className="font-bold text-xl">{socialStats.tiktok.engagement}%</p>
                      </div>
                      <div className="bg-gray-50 p-3 rounded-lg text-center md:col-span-1 col-span-2">
                        <p className="text-sm text-gray-600">Última sincronização</p>
                        <p className="font-medium">
                          {socialStats.tiktok.lastSync 
                            ? socialStats.tiktok.lastSync.toLocaleDateString('pt-BR', {hour: '2-digit', minute: '2-digit'}) 
                            : 'Nunca'}
                        </p>
                      </div>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
              
              <div className="mt-4 bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium mb-2">Demografia da audiência</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h5 className="text-sm text-gray-600 mb-2">Faixa etária</h5>
                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between text-sm">
                          <span>18-24</span>
                          <span>35%</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div className="h-2 bg-brand-purple rounded-full" style={{ width: '35%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm">
                          <span>25-34</span>
                          <span>42%</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div className="h-2 bg-brand-purple rounded-full" style={{ width: '42%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm">
                          <span>35-44</span>
                          <span>15%</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div className="h-2 bg-brand-purple rounded-full" style={{ width: '15%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm">
                          <span>45+</span>
                          <span>8%</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div className="h-2 bg-brand-purple rounded-full" style={{ width: '8%' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h5 className="text-sm text-gray-600 mb-2">Gênero</h5>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="bg-gray-100 p-3 rounded-lg text-center">
                        <p className="text-xs text-gray-600">Masculino</p>
                        <p className="font-bold">62%</p>
                      </div>
                      <div className="bg-gray-100 p-3 rounded-lg text-center">
                        <p className="text-xs text-gray-600">Feminino</p>
                        <p className="font-bold">36%</p>
                      </div>
                      <div className="bg-gray-100 p-3 rounded-lg text-center">
                        <p className="text-xs text-gray-600">Outro</p>
                        <p className="font-bold">2%</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
          
          {onComplete && (
            <Button 
              className="mt-4 bg-brand-purple hover:bg-brand-purple/90" 
              onClick={onComplete}
            >
              Continuar
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
