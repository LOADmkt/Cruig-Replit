
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Heart, MessageSquare } from 'lucide-react';
import { ProfileSidebar } from './components/ProfileSidebar';
import { ProfileTabs } from './components/ProfileTabs';
import { getCreator, Creator } from '@/services/creatorService';

interface CreatorProfileViewProps {
  creator?: Creator;
  onBack: () => void;
  onToggleFavorite?: (creatorId: string | number) => void;
  isFavorite?: boolean;
}

export function CreatorProfileView({
  creator: providedCreator,
  onBack,
  onToggleFavorite,
  isFavorite = false
}: CreatorProfileViewProps) {
  const params = useParams();
  const navigate = useNavigate();
  const [creator, setCreator] = useState<Creator | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [localIsFavorite, setLocalIsFavorite] = useState(isFavorite);

  useEffect(() => {
    if (providedCreator) {
      setCreator(providedCreator);
      return;
    }

    const loadCreator = async () => {
      const creatorId = params.id;
      if (!creatorId) return;

      setIsLoading(true);
      try {
        const fetchedCreator = await getCreator(creatorId);
        if (fetchedCreator) {
          setCreator(fetchedCreator);
        } else {
          // Handle not found
        }
      } catch (error) {
        console.error('Error loading creator:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadCreator();
  }, [params.id, providedCreator]);

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  const handleToggleFavorite = () => {
    if (!creator) return;
    
    if (onToggleFavorite) {
      onToggleFavorite(creator.id);
    } else {
      setLocalIsFavorite(prev => !prev);
    }
  };

  if (isLoading || !creator) {
    return <LoadingProfile />;
  }

  return (
    <Card className="border border-gray-200 shadow-md">
      <div className="p-4 md:p-6">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-1/3">
            <div className="flex items-center mb-6">
              <Button 
                type="button"
                variant="ghost" 
                size="icon" 
                onClick={handleBack}
                className="mr-2"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <h2 className="text-xl font-bold">Perfil do Criador</h2>
              <div className="ml-auto flex gap-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={handleToggleFavorite}
                  className={isFavorite || localIsFavorite ? "text-red-500 hover:text-red-600" : "text-gray-400 hover:text-red-500"}
                >
                  <Heart className="h-5 w-5" fill={isFavorite || localIsFavorite ? "currentColor" : "none"} />
                </Button>
                <Button
                  type="button"
                  variant="brand"
                  className="flex items-center gap-2"
                >
                  <MessageSquare className="h-4 w-4" /> Contatar
                </Button>
              </div>
            </div>
            
            <ProfileSidebar creator={creator} />
          </div>
          
          <div className="lg:w-2/3">
            <ProfileTabs creator={creator} />
          </div>
        </div>
      </div>
    </Card>
  );
}

function LoadingProfile() {
  return (
    <Card className="border border-gray-200 shadow-md">
      <div className="p-4 md:p-6">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-1/3">
            <div className="flex items-center mb-6">
              <div className="h-10 w-10 rounded-full bg-gray-200 animate-pulse"></div>
              <div className="ml-2 h-6 w-32 bg-gray-200 animate-pulse rounded"></div>
              <div className="ml-auto flex gap-2">
                <div className="h-10 w-10 rounded-full bg-gray-200 animate-pulse"></div>
                <div className="h-10 w-24 rounded bg-gray-200 animate-pulse"></div>
              </div>
            </div>
            
            <ProfileSidebar isLoading={true} creator={{
              id: 'loading',
              name: '',
              verified: false
            }} />
          </div>
          
          <div className="lg:w-2/3">
            <ProfileTabs isLoading={true} creator={{
              id: 'loading',
              name: '',
              verified: false
            }} />
          </div>
        </div>
      </div>
    </Card>
  );
}
