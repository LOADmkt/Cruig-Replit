
import React from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';

interface MessageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  creatorName: string;
  messageText: string;
  setMessageText: (text: string) => void;
  campaignSelect: string;
  setCampaignSelect: (campaign: string) => void;
  onSend: () => void;
}

export function MessageDialog({
  open,
  onOpenChange,
  creatorName,
  messageText,
  setMessageText,
  campaignSelect,
  setCampaignSelect,
  onSend
}: MessageDialogProps) {
  // Handle text change
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessageText(e.target.value);
  };

  const handleSendClick = () => {
    onSend();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Enviar mensagem para {creatorName}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="campaign">Campanha relacionada</Label>
            <Select value={campaignSelect} onValueChange={setCampaignSelect}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma campanha (opcional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="campaign1">Campanha de Verão 2025</SelectItem>
                <SelectItem value="campaign2">Lançamento de Produto</SelectItem>
                <SelectItem value="campaign3">Evento Corporativo</SelectItem>
                <SelectItem value="none">Nenhuma campanha</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Sua mensagem</Label>
            <Textarea
              id="message"
              placeholder="Escreva sua mensagem aqui..."
              value={messageText}
              onChange={handleTextChange}
              className="min-h-[120px]"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} type="button">Cancelar</Button>
          <Button onClick={handleSendClick} type="button">Enviar mensagem</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
