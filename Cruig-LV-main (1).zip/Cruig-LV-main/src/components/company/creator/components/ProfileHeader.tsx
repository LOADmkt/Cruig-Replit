
import React, { memo } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Heart, MessageSquare, CheckCircle } from 'lucide-react';

interface ProfileHeaderProps {
  creatorName: string;
  onBack: () => void;
  onToggleFavorite: () => void;
  onOpenMessageDialog: () => void;
  isFavorite: boolean;
  isSubscribed: boolean;
}

// Use memo to prevent unnecessary re-renders
export const ProfileHeader = memo(function ProfileHeader({
  creatorName,
  onBack,
  onToggleFavorite,
  onOpenMessageDialog,
  isFavorite,
  isSubscribed
}: ProfileHeaderProps) {
  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
      <div className="flex items-center gap-3">
        <Button 
          variant="outline" 
          size="icon" 
          onClick={onBack} 
          type="button"
          className="h-8 w-8"
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h2 className="text-xl font-semibold text-gray-800">
          {creatorName}
          {isSubscribed && (
            <span className="ml-2 text-sm text-green-600 inline-flex items-center">
              <CheckCircle className="h-4 w-4 mr-1" /> Premium
            </span>
          )}
        </h2>
      </div>
      
      <div className="flex items-center gap-2">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onToggleFavorite}
          type="button"
          className={`gap-2 ${isFavorite ? 'text-red-500 border-red-200 hover:text-red-600 hover:border-red-300 hover:bg-red-50' : ''}`}
        >
          <Heart className={`h-4 w-4 ${isFavorite ? 'fill-current' : ''}`} />
          {isFavorite ? 'Favorito' : 'Favoritar'}
        </Button>
        
        <Button 
          variant="default" 
          size="sm" 
          className="bg-[#99c00d] hover:bg-[#86a60b] text-white gap-2"
          onClick={onOpenMessageDialog}
          type="button"
        >
          <MessageSquare className="h-4 w-4" />
          Enviar Mensagem
        </Button>
      </div>
    </div>
  );
});

ProfileHeader.displayName = 'ProfileHeader';
