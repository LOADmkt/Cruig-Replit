
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { User, Instagram, Facebook, Twitter, Youtube, ExternalLink } from 'lucide-react';
import type { Creator } from '@/services/creatorService';
import { Skeleton } from '@/components/ui/skeleton';

interface ProfileSidebarProps {
  creator: Creator;
  isLoading?: boolean;
}

export function ProfileSidebar({ creator, isLoading = false }: ProfileSidebarProps) {
  const getSocialIcon = (network: string) => {
    switch(network.toLowerCase()) {
      case 'instagram': return <Instagram className="h-5 w-5 mr-2" />;
      case 'facebook': return <Facebook className="h-5 w-5 mr-2" />;
      case 'twitter': return <Twitter className="h-5 w-5 mr-2" />;
      case 'youtube': return <Youtube className="h-5 w-5 mr-2" />;
      default: return <ExternalLink className="h-5 w-5 mr-2" />;
    }
  };

  // Format followers number to display
  const formatFollowers = (followers?: number) => {
    if (!followers) return '0';
    return Intl.NumberFormat('pt-BR').format(followers);
  };

  if (isLoading) {
    return (
      <div className="md:w-1/3">
        <div className="flex flex-col items-center text-center p-4 bg-gray-50 rounded-lg border border-gray-100">
          <Skeleton className="h-32 w-32 rounded-full mb-4" />
          <Skeleton className="h-6 w-3/4 mb-1" />
          <Skeleton className="h-4 w-1/2 mb-3" />
          <Skeleton className="h-4 w-1/3 mb-2" />
          <Skeleton className="h-4 w-2/5 mb-4" />
          
          <div className="flex flex-wrap gap-2 justify-center">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-6 w-16" />
            ))}
          </div>
        </div>
        
        <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-100">
          <Skeleton className="h-5 w-1/2 mb-3" />
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="md:w-1/3">
      <div className="flex flex-col items-center text-center p-4 bg-gray-50 rounded-lg border border-gray-100 transition-all duration-300 hover:shadow-md">
        {creator.avatar ? (
          <Avatar className="h-32 w-32 mb-4">
            <AvatarImage src={creator.avatar} alt={creator.name} />
            <AvatarFallback>{creator.name.substring(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
        ) : (
          <div className="h-32 w-32 rounded-full bg-brand-primary/10 flex items-center justify-center mb-4">
            <User className="h-16 w-16 text-brand-primary" />
          </div>
        )}
        
        <h2 className="text-xl font-bold mb-1">{creator.name}</h2>
        <p className="text-gray-500 mb-3">{creator.location || 'Localização não informada'}</p>
        
        {creator.followers !== undefined && (
          <div className="mb-2 text-sm text-gray-700">
            <span className="font-semibold">{formatFollowers(creator.followers)}</span> seguidores
          </div>
        )}
        
        {creator.engagement && (
          <div className="mb-4 text-sm text-gray-700">
            <span className="font-semibold">{creator.engagement}</span> de engagement
          </div>
        )}
        
        <div className="flex flex-wrap gap-2 justify-center">
          {creator.niches?.map((niche, index) => (
            <Badge key={index} variant="secondary" className="text-xs hover:bg-gray-200 transition-colors">
              {niche}
            </Badge>
          ))}
        </div>
      </div>
      
      <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-100 transition-all duration-300 hover:shadow-md">
        <h3 className="font-semibold mb-3 text-gray-800">Redes Sociais</h3>
        <div className="space-y-2">
          {creator.socialNetworks && Object.keys(creator.socialNetworks).length > 0 ? (
            Object.entries(creator.socialNetworks).map(([network, handle]) => (
              <a 
                key={network}
                href={`https://${network}.com/${handle}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center p-2 hover:bg-gray-100 rounded transition-colors"
              >
                {getSocialIcon(network)}
                <span>@{handle}</span>
              </a>
            ))
          ) : creator.socialMedia && creator.socialMedia.length > 0 ? (
            creator.socialMedia.map((network, index) => (
              <a 
                key={index}
                href={`https://${network.platform}.com/${network.username}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center p-2 hover:bg-gray-100 rounded transition-colors"
              >
                {getSocialIcon(network.platform)}
                <span>@{network.username}</span>
              </a>
            ))
          ) : (
            <p className="text-gray-500 text-sm">Nenhuma rede social informada</p>
          )}
        </div>
      </div>
    </div>
  );
}
