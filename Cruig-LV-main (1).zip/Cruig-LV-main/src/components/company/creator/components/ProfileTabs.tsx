
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, DollarSign } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import type { Creator } from '@/services/creatorService';

interface ProfileTabsProps {
  creator: Creator;
  isLoading?: boolean;
}

export function ProfileTabs({ creator, isLoading = false }: ProfileTabsProps) {
  if (isLoading) {
    return (
      <div className="w-full">
        <Skeleton className="h-10 w-3/4 mb-4" />
        <div className="space-y-4">
          <Skeleton className="h-6 w-1/2 mb-2" />
          <Skeleton className="h-24 w-full" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <Tabs defaultValue="sobre" className="w-full">
      <TabsList className="mb-4">
        <TabsTrigger value="sobre">Sobre</TabsTrigger>
        <TabsTrigger value="portfolio">Portfólio</TabsTrigger>
        <TabsTrigger value="metricas">Métricas</TabsTrigger>
      </TabsList>
      
      <TabsContent value="sobre" className="space-y-4 animate-fade-in">
        <div>
          <h3 className="font-semibold mb-2">Bio</h3>
          <p className="text-gray-700">{creator.bio || 'Este criador ainda não adicionou uma bio.'}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 border rounded-md hover:shadow-md transition-all duration-300">
            <h4 className="text-sm font-medium text-gray-500 mb-1">Faixa de preço</h4>
            <div className="flex items-center">
              <DollarSign className="h-4 w-4 text-green-600 mr-1" />
              <span className="font-medium">
                R$ {creator.priceRange?.min || 800} - R$ {creator.priceRange?.max || 3000}
              </span>
            </div>
          </div>
          
          <div className="p-4 border rounded-md hover:shadow-md transition-all duration-300">
            <h4 className="text-sm font-medium text-gray-500 mb-1">Disponibilidade</h4>
            <div className="flex items-center">
              <Calendar className="h-4 w-4 text-blue-600 mr-1" />
              <span className="font-medium">{creator.availability || 'Disponível em 1-2 semanas'}</span>
            </div>
          </div>
          
          <div className="p-4 border rounded-md hover:shadow-md transition-all duration-300">
            <h4 className="text-sm font-medium text-gray-500 mb-1">Público alvo</h4>
            <div className="font-medium">
              {creator.targetAudience ? creator.targetAudience.join(', ') : 'Não informado'}
            </div>
          </div>
          
          <div className="p-4 border rounded-md hover:shadow-md transition-all duration-300">
            <h4 className="text-sm font-medium text-gray-500 mb-1">Experiência</h4>
            <div className="font-medium">{creator.experience || '2+ anos'}</div>
          </div>
        </div>
      </TabsContent>
      
      <TabsContent value="portfolio" className="space-y-4 animate-fade-in">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {creator.portfolio && creator.portfolio.length > 0 ? (
            creator.portfolio.map((item, index) => (
              <div key={index} className="border rounded-md overflow-hidden hover:shadow-lg transition-all duration-300">
                <div className="aspect-video bg-gray-200 overflow-hidden">
                  {(item.image || item.imageUrl) && (
                    <img 
                      src={item.image || item.imageUrl} 
                      alt={item.title} 
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105" 
                    />
                  )}
                </div>
                <div className="p-3">
                  <h4 className="font-medium">{item.title}</h4>
                  <p className="text-sm text-gray-600">{item.description || 'Sem descrição disponível'}</p>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-2 text-center py-8 border rounded-md">
              <p className="text-gray-500">Nenhum item de portfólio disponível</p>
            </div>
          )}
        </div>
      </TabsContent>
      
      <TabsContent value="metricas" className="space-y-4 animate-fade-in">
        <div className="border rounded-md overflow-hidden hover:shadow-md transition-all duration-300">
          <div className="p-4 bg-gray-50 border-b">
            <h3 className="font-medium text-gray-800">Métricas de desempenho</h3>
          </div>
          <div className="p-4">
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Engajamento</span>
                  <span className="text-sm font-medium">{creator.engagement || '5.2%'}</span>
                </div>
                <Progress 
                  value={parseFloat((creator.engagement || '5.2%').replace('%', '') || '5.2') * 5} 
                  className="h-2" 
                />
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Satisfação de marcas</span>
                  <span className="text-sm font-medium">{creator.brandSatisfaction || '96%'}</span>
                </div>
                <Progress 
                  value={parseFloat((creator.brandSatisfaction || '96%').replace('%', '') || '96')} 
                  className="h-2" 
                />
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Campanhas concluídas</span>
                  <span className="text-sm font-medium">
                    {creator.completedCampaigns || creator.campaignsCompleted || 24}
                  </span>
                </div>
                <Progress 
                  value={Math.min(100, ((creator.completedCampaigns || creator.campaignsCompleted || 24) / 30) * 100)} 
                  className="h-2" 
                />
              </div>
            </div>
          </div>
        </div>
      </TabsContent>
    </Tabs>
  );
}
