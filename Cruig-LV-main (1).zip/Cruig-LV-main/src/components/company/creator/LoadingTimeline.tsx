
import React from 'react';
import { CreatorCard } from './CreatorCard';
import { Creator } from '@/services/creatorService';

export function LoadingTimeline() {
  // Create a mock creator for the loading state
  const createLoadingCreator = (index: number): Creator => ({
    id: `loading-${index}`,
    name: '',
    verified: false,
  });

  // Create an array of 9 items to show the skeletons
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
      {Array.from({ length: 9 }).map((_, index) => (
        <CreatorCard
          key={index}
          creator={createLoadingCreator(index)}
          favorite={false}
          isSubscribed={false}
          isLoading={true}
          onToggleFavorite={() => {}}
          onSendMessage={() => {}}
          onViewProfile={() => {}}
        />
      ))}
    </div>
  );
}
