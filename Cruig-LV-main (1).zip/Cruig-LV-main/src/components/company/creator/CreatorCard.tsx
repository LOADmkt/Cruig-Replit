
import React, { useCallback } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User, MessageSquare, Heart, ExternalLink, Instagram, Youtube } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Creator } from '@/services/creatorService';
import { Skeleton } from '@/components/ui/skeleton';

interface CreatorCardProps {
  creator: Creator;
  favorite: boolean;
  isSubscribed: boolean;
  isLoading?: boolean;
  onToggleFavorite: (creatorId: string | number) => void;
  onSendMessage: (creator: Creator) => void;
  onViewProfile: (creatorId: string | number) => void;
}

export function CreatorCard({
  creator,
  favorite,
  isSubscribed,
  isLoading = false,
  onToggleFavorite,
  onSendMessage,
  onViewProfile
}: CreatorCardProps) {
  const handleToggleFavorite = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite(creator.id);
  }, [creator.id, onToggleFavorite]);

  const handleSendMessage = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    onSendMessage(creator);
  }, [creator, onSendMessage]);

  const handleViewProfile = useCallback(() => {
    onViewProfile(creator.id);
  }, [creator.id, onViewProfile]);

  // Format followers number to display
  const formatFollowers = (followers?: number) => {
    if (!followers) return '0';
    return Intl.NumberFormat('pt-BR').format(followers);
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'instagram':
        return <Instagram className="h-4 w-4 text-pink-500" />;
      case 'youtube':
        return <Youtube className="h-4 w-4 text-red-500" />;
      case 'tiktok':
        // Using a div with icon instead of the missing Tiktok component
        return <div className="h-4 w-4 text-black flex items-center justify-center">TT</div>;
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <Card className="overflow-hidden border-gray-200 h-full flex flex-col animate-pulse">
        <CardContent className="p-4">
          <div className="flex items-center gap-3 mb-4">
            <Skeleton className="h-14 w-14 rounded-full" />
            <div>
              <Skeleton className="h-5 w-32 mb-1" />
              <Skeleton className="h-4 w-24" />
            </div>
          </div>

          <Skeleton className="h-12 mb-3" />

          <div className="flex flex-wrap gap-1 mb-3">
            {[1, 2, 3].map(i => (
              <Skeleton key={i} className="h-5 w-16" />
            ))}
          </div>

          <div className="flex justify-between items-center mb-4 mt-auto">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-4 w-24" />
          </div>

          <div className="flex gap-2">
            <Skeleton className="h-9 flex-1" />
            <Skeleton className="h-9 w-9" />
            <Skeleton className="h-9 w-9" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-md border-gray-200 h-full flex flex-col">
      <CardContent className="p-4 flex flex-col h-full">
        <div className="flex items-center gap-3 mb-4">
          {creator.avatar ? (
            <img 
              src={creator.avatar} 
              alt={creator.name} 
              className="h-14 w-14 rounded-full object-cover border transition-transform hover:scale-105"
              loading="lazy"
            />
          ) : (
            <div className="h-14 w-14 rounded-full bg-brand-primary/10 flex items-center justify-center transition-transform hover:scale-105">
              <User className="h-6 w-6 text-brand-primary" />
            </div>
          )}
          <div>
            <h3 className="font-medium text-base">{creator.name}</h3>
            <div className="text-sm text-gray-500">
              {creator.location || 'Localização não informada'}
            </div>
          </div>
        </div>

        <p className="text-sm text-gray-700 line-clamp-2 mb-3 min-h-[40px]">
          {creator.bio || 'Este criador ainda não adicionou uma bio.'}
        </p>

        <div className="flex flex-wrap gap-1 mb-3">
          {creator.niches?.slice(0, 3).map((niche, index) => (
            <Badge key={index} variant="secondary" className="text-xs font-normal hover:bg-gray-200 transition-colors">
              {niche}
            </Badge>
          ))}
          {(creator.niches?.length || 0) > 3 && (
            <Badge variant="outline" className="text-xs font-normal">
              +{(creator.niches?.length || 0) - 3}
            </Badge>
          )}
        </div>

        {creator.socialMedia && creator.socialMedia.length > 0 ? (
          <div className="mb-3">
            <h4 className="text-sm font-medium mb-1">Redes Sociais</h4>
            <ul className="space-y-1">
              {creator.socialMedia.map((network, index) => (
                <li key={index} className="flex items-center text-sm text-gray-600">
                  {getPlatformIcon(network.platform)}
                  <span className="ml-2">{network.username || ''}</span>
                  <span className="ml-auto">{formatFollowers(network.followers)}</span>
                </li>
              ))}
            </ul>
          </div>
        ) : creator.socialNetworks && Object.keys(creator.socialNetworks).length > 0 ? (
          <div className="mb-3">
            <h4 className="text-sm font-medium mb-1">Redes Sociais</h4>
            <ul className="space-y-1">
              {Object.entries(creator.socialNetworks).map(([platform, username], index) => (
                <li key={index} className="flex items-center text-sm text-gray-600">
                  {getPlatformIcon(platform)}
                  <span className="ml-2">@{username}</span>
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        <div className="flex justify-between items-center mb-4 text-xs text-gray-500 mt-auto">
          <div>
            {creator.followers !== undefined && (
              <span>{formatFollowers(creator.followers)} seguidores</span>
            )}
          </div>
          <div>{creator.engagement || '0%'} engagement</div>
        </div>

        <div className="flex justify-between items-center mb-4 text-xs text-gray-500">
          <div>
            <span className="font-medium">{creator.campaignsCompleted || creator.completedCampaigns || 0}</span> campanhas finalizadas
          </div>
          <div>
            <span className="font-medium">{creator.campaignsActive || 0}</span> campanhas ativas
          </div>
        </div>

        <div className="flex gap-2">
          <Button 
            variant="default" 
            className="flex-1 transition-colors" 
            onClick={handleViewProfile}
            size="sm"
            type="button"
          >
            <ExternalLink className="h-4 w-4 mr-1" />
            Ver perfil
          </Button>
          
          <Button 
            variant="outline" 
            size="icon" 
            className={`transition-all ${favorite ? 'text-red-500 border-red-200 hover:text-red-600 hover:border-red-300 hover:bg-red-50' : ''}`}
            onClick={handleToggleFavorite}
            type="button"
          >
            <Heart className={`h-4 w-4 ${favorite ? 'fill-current' : ''}`} />
          </Button>
          
          <Button 
            variant="outline"
            size="icon"
            disabled={!isSubscribed} 
            className={`transition-colors ${!isSubscribed ? 'opacity-60' : ''}`}
            onClick={handleSendMessage}
            type="button"
          >
            <MessageSquare className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
