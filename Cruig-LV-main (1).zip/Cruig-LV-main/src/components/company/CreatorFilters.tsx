
import React, { useCallback, memo } from 'react';
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { BasicFilters } from './filters/BasicFilters';
import { AdvancedFilters } from './filters/AdvancedFilters';
import { ActiveFilterBadges } from './filters/ActiveFilterBadges';
import type { CreatorFiltersProps } from './filters/types';

export const CreatorFilters = memo(function CreatorFilters({ activeFilters, onFilterChange }: CreatorFiltersProps) {
  // Use a stable reference for the reset function to avoid recreating it on every render
  const handleResetFilters = useCallback(() => {
    try {
      onFilterChange({
        nicho: [],
        seguidores: '',
        localizacao: [],
        redeSocial: [],
        verificado: false,
        superCreator: false,
        faixaEtaria: [],
        generoPrincipal: [],
        engajamentoMinimo: 0,
        tipoConteudo: [],
        faixaPreco: '',
      });
    } catch (e) {
      console.error("Erro ao redefinir filtros:", e);
    }
  }, [onFilterChange]);

  // Memoize the function to apply filters
  const handleApplyFilters = useCallback(() => {
    console.log("Filtros aplicados");
    // Note: Actual filter application happens through the onFilterChange in child components
  }, []);

  return (
    <div className="mt-4 space-y-6 p-6 border rounded-lg bg-white shadow-sm">
      <Tabs defaultValue="basico" className="w-full">
        <TabsList className="mb-4 bg-gray-100 p-1">
          <TabsTrigger 
            value="basico" 
            className="data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-brand-primary"
          >
            Filtros Básicos
          </TabsTrigger>
          <TabsTrigger 
            value="avancado"
            className="data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-brand-primary"
          >
            Filtros Avançados
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="basico">
          <BasicFilters activeFilters={activeFilters} onFilterChange={onFilterChange} />
        </TabsContent>

        <TabsContent value="avancado">
          <AdvancedFilters activeFilters={activeFilters} onFilterChange={onFilterChange} />
        </TabsContent>
      </Tabs>

      <Separator className="my-4" />

      <ActiveFilterBadges activeFilters={activeFilters} onFilterChange={onFilterChange} />

      <div className="flex justify-between mt-6">
        <Button 
          variant="outline" 
          onClick={handleResetFilters}
          className="border-2 border-gray-300 text-gray-800 hover:bg-gray-100"
        >
          Limpar Filtros
        </Button>
        <Button
          onClick={handleApplyFilters}
          className="bg-[#99c00d] text-white hover:bg-[#99c00d]/90"
        >
          Aplicar Filtros
        </Button>
      </div>
    </div>
  );
});
