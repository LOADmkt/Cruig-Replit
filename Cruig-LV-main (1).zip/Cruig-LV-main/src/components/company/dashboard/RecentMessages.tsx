
import React from 'react';
import { MessageSquare } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface RecentMessagesProps {
  messagesCount: number;
  onNavigateToMessages: () => void;
  onSearchCreators: () => void;
}

export function RecentMessages({ messagesCount, onNavigateToMessages, onSearchCreators }: RecentMessagesProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center text-brand-dark">
          <MessageSquare className="mr-2 h-5 w-5 text-brand-primary" />
          Mensagens recentes
        </CardTitle>
        <CardDescription>
          Suas conversas com criadores
        </CardDescription>
      </CardHeader>
      <CardContent>
        {messagesCount > 0 ? (
          <div className="space-y-4">
            {[1, 2, 3].map((_, index) => (
              <div 
                key={index} 
                className="p-4 border rounded-lg flex gap-3 bg-white hover:shadow-md transition-all cursor-pointer"
                onClick={onNavigateToMessages}
              >
                <div className="w-10 h-10 rounded-full bg-brand-primary/20 flex-shrink-0 flex items-center justify-center">
                  <span className="font-medium text-brand-primary">J{index + 1}</span>
                </div>
                <div>
                  <h3 className="font-medium text-brand-dark">João Silva</h3>
                  <p className="text-sm text-gray-600 truncate">Olá! Gostaria de saber mais sobre...</p>
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full" onClick={onNavigateToMessages}>Ver todas mensagens</Button>
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-gray-500">Nenhuma mensagem recebida</p>
            <Button variant="brand" onClick={onSearchCreators}>Buscar criadores</Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
