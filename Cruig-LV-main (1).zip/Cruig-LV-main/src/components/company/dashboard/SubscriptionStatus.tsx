
import React from 'react';
import { AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from 'react-router-dom';
import { useSubscription } from '@/hooks/useSubscription';

interface SubscriptionStatusProps {
  subscription: {
    active: boolean;
    planName?: string;
    expiresAt?: string;
  };
  usageCount: {
    messages: number;
    campaigns: number;
    maxFreeMessages: number;
    maxFreeCampaigns: number;
  };
  hasReachedMessageLimit: boolean;
}

export function SubscriptionStatus({ 
  subscription, 
  usageCount, 
  hasReachedMessageLimit 
}: SubscriptionStatusProps) {
  const navigate = useNavigate();

  if (subscription.active) {
    return (
      <Card className="border-2 border-green-500 bg-green-50">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center text-green-800">
            <Badge variant="success" className="mr-2">Premium</Badge>
            Plano {subscription.planName || 'Premium'} Ativo
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p>Você tem acesso a todas as funcionalidades premium da plataforma até {new Date(subscription.expiresAt || "").toLocaleDateString('pt-BR')}.</p>
          <div className="flex gap-2 mt-3">
            <Badge variant="success" className="bg-green-500">Campanhas ilimitadas</Badge>
            <Badge variant="success" className="bg-green-500">Mensagens ilimitadas</Badge>
            <Badge variant="success" className="bg-green-500">Acesso a todos criadores</Badge>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border border-amber-200 bg-amber-50">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-amber-800">
          <AlertCircle className="mr-2 h-5 w-5" />
          Limites da conta gratuita
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span>Mensagens enviadas:</span>
            <span className="font-medium">{usageCount.messages} de {usageCount.maxFreeMessages} permitidas</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className={`h-2.5 rounded-full ${usageCount.messages >= usageCount.maxFreeMessages ? 'bg-red-500' : 'bg-green-500'}`} 
              style={{ width: `${Math.min(usageCount.messages / usageCount.maxFreeMessages * 100, 100)}%` }}
            ></div>
          </div>
          
          <div className="flex justify-between items-center mt-4">
            <span>Campanhas publicadas:</span>
            <span className="font-medium">{usageCount.campaigns} de {usageCount.maxFreeCampaigns} permitidas</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className={`h-2.5 rounded-full ${usageCount.campaigns >= usageCount.maxFreeCampaigns ? 'bg-red-500' : 'bg-green-500'}`} 
              style={{ width: `${Math.min(usageCount.campaigns / usageCount.maxFreeCampaigns * 100, 100)}%` }}
            ></div>
          </div>
        </div>
        
        <p className="mt-4 text-sm text-amber-800">
          Para acesso ilimitado a todas as funcionalidades, assine um de nossos planos premium.
        </p>
        <Button 
          variant="brand"
          className="mt-4"
          onClick={() => navigate('/empresa-dashboard?tab=subscription')}
        >
          Ver planos de assinatura
        </Button>
      </CardContent>
    </Card>
  );
}
