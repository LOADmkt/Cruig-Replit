
import React from 'react';
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Users, ExternalLink, Layers } from "lucide-react";
import { useNavigate } from 'react-router-dom';
import { formatDate } from '@/lib/utils';

interface Campaign {
  id: string;
  name: string;
  status: 'ativa' | 'pausada' | 'planejamento' | 'finalizada';
  creators: number;
  startDate: string;
  endDate: string;
  budget: string;
  creatorType: string;
}

interface CampaignListProps {
  campaigns: Campaign[];
  emptyMessage?: string;
}

export function CampaignList({ campaigns, emptyMessage = "Nenhuma campanha encontrada" }: CampaignListProps) {
  const navigate = useNavigate();
  
  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'ativa':
        return <Badge className="bg-green-500">Ativa</Badge>;
      case 'pausada':
        return <Badge className="bg-amber-500">Pausada</Badge>;
      case 'planejamento':
        return <Badge className="bg-blue-500">Planejamento</Badge>;
      case 'finalizada':
        return <Badge className="bg-gray-500">Finalizada</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const viewCampaignDetails = (id: string) => {
    navigate(`/campanha/${id}`);
  };

  if (!campaigns || campaigns.length === 0) {
    return (
      <Card className="border-dashed border-2 border-gray-200">
        <CardContent className="p-8">
          <div className="text-center">
            <Layers className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-lg font-medium text-gray-900">
              {emptyMessage}
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              Comece criando uma nova campanha para aparecer aqui.
            </p>
            <div className="mt-6">
              <Button 
                className="bg-brand-primary hover:bg-brand-dark text-white"
                onClick={() => navigate('/dashboard/empresa/nova-campanha')}
              >
                Criar Campanha
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {campaigns.map((campaign) => (
        <Card key={campaign.id} className="overflow-hidden shadow-card hover:shadow-card-hover transition-shadow">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-lg">{campaign.name}</h3>
                <div className="mt-2 flex space-x-2">
                  {getStatusBadge(campaign.status)}
                  <Badge variant="outline" className="flex items-center">
                    <Users className="h-3 w-3 mr-1" /> {campaign.creators} criadores
                  </Badge>
                </div>
              </div>
              <div className="text-sm font-medium text-gray-500">
                {campaign.budget}
              </div>
            </div>

            <div className="mt-4 flex items-center text-sm text-gray-500">
              <Calendar className="h-4 w-4 mr-1" />
              <span>{formatDate(campaign.startDate)} - {formatDate(campaign.endDate)}</span>
            </div>
            
            <div className="mt-2 text-sm text-gray-600">
              <span>Tipo de criador: {campaign.creatorType}</span>
            </div>
          </CardContent>
          
          <CardFooter className="bg-gray-50 px-6 py-3">
            <Button 
              variant="ghost" 
              className="ml-auto text-brand-dark hover:text-brand-primary hover:bg-brand-accent/20"
              onClick={() => viewCampaignDetails(campaign.id)}
            >
              Ver Detalhes <ExternalLink className="ml-1 h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}
