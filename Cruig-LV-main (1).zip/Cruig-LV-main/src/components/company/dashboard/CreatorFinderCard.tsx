
import React from 'react';
import { Users } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';

interface CreatorFinderCardProps {
  creatorsCount: number;
  onSearchClick?: () => void;
}

export function CreatorFinderCard({ creatorsCount, onSearchClick }: CreatorFinderCardProps) {
  const navigate = useNavigate();
  
  const handleSearchClick = () => {
    if (onSearchClick) {
      onSearchClick();
    } else {
      navigate('/empresa-dashboard/buscar');
    }
  };
  
  return (
    <Card className="mt-6 border-brand-primary/20 bg-brand-secondary/10">
      <CardHeader>
        <CardTitle className="text-brand-dark">Encontre criadores para suas campanhas</CardTitle>
        <CardDescription>
          Utilize nossa ferramenta de busca avançada para encontrar os criadores ideais para suas campanhas.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-full bg-brand-primary/10">
              <Users className="h-10 w-10 text-brand-primary" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-brand-dark">{creatorsCount} criadores disponíveis</h3>
              <p className="text-sm text-gray-600">Encontre o parceiro perfeito para sua marca</p>
            </div>
          </div>
          <Button variant="brand" onClick={handleSearchClick}>Iniciar busca</Button>
        </div>
      </CardContent>
    </Card>
  );
}
