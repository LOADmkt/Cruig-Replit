
import React from 'react';
import { FileText } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface RecentCampaignsProps {
  campaignsTotal: number;
  onNavigateToCampaigns: () => void;
}

export function RecentCampaigns({ campaignsTotal, onNavigateToCampaigns }: RecentCampaignsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center text-brand-dark">
          <FileText className="mr-2 h-5 w-5 text-brand-primary" />
          Campanhas recentes
        </CardTitle>
        <CardDescription>
          Suas últimas campanhas publicadas
        </CardDescription>
      </CardHeader>
      <CardContent>
        {campaignsTotal > 0 ? (
          <div className="space-y-4">
            {[1, 2].map((_, index) => (
              <div 
                key={index} 
                className="p-4 border rounded-lg bg-white hover:shadow-md transition-all cursor-pointer"
                onClick={onNavigateToCampaigns}
              >
                <div className="flex justify-between">
                  <h3 className="font-medium text-brand-dark">Campanha de Lançamento {index + 1}</h3>
                  <Badge variant="brand-outline">Ativa</Badge>
                </div>
                <p className="text-sm text-gray-600 mt-1">10 candidatos · Criada em 05/06/2023</p>
              </div>
            ))}
            <Button variant="outline" className="w-full" onClick={onNavigateToCampaigns}>Ver todas campanhas</Button>
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-gray-500">Nenhuma campanha criada</p>
            <Button 
              variant="brand" 
              className="mt-4"
              onClick={onNavigateToCampaigns}
            >
              Criar primeira campanha
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
