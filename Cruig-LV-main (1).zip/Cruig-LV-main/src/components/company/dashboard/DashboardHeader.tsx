
import React from 'react';
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";
import { useNavigate } from 'react-router-dom';

interface DashboardHeaderProps {
  userData: any;
}

export function DashboardHeader({ userData }: DashboardHeaderProps) {
  const navigate = useNavigate();
  const userName = userData?.user_metadata?.name || userData?.nome || 'Usuário';

  const handleCreateCampaign = () => {
    navigate('/dashboard/empresa/nova-campanha');
  };

  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-brand-darkGray">
          Bem-vindo(a), {userName}
        </h1>
        <p className="text-gray-600 mt-1">
          Gerencie suas campanhas e conecte-se com criadores de conteúdo
        </p>
      </div>
      <Button
        onClick={handleCreateCampaign}
        className="bg-brand-primary hover:bg-brand-dark text-white"
      >
        <PlusCircle className="mr-2 h-4 w-4" /> Nova Campanha
      </Button>
    </div>
  );
}
