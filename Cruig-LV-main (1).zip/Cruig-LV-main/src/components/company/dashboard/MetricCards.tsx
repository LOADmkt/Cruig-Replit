
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Layers, Check, Users } from "lucide-react";

interface MetricCardsProps {
  dashboardData: any;
}

export function MetricCards({ dashboardData }: MetricCardsProps) {
  const metrics = [
    {
      title: "Campanhas Ativas",
      value: dashboardData?.activeCampaigns || 0,
      icon: <Layers className="h-5 w-5" />,
      color: "bg-brand-primary/10 text-brand-primary"
    },
    {
      title: "Campanhas Finalizadas",
      value: dashboardData?.completedCampaigns || 0,
      icon: <Check className="h-5 w-5" />,
      color: "bg-brand-tertiary/10 text-brand-tertiary"
    },
    {
      title: "Criadores Contratados",
      value: dashboardData?.contractedCreators || 0,
      icon: <Users className="h-5 w-5" />,
      color: "bg-brand-dark/10 text-brand-dark"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {metrics.map((metric, index) => (
        <Card key={index} className="shadow-card hover:shadow-card-hover transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">{metric.title}</p>
                <h3 className="text-3xl font-bold mt-2">{metric.value}</h3>
              </div>
              <div className={`rounded-full p-3 ${metric.color}`}>
                {metric.icon}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
