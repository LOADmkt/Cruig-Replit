
import React from 'react';
import { RecentCampaigns } from './RecentCampaigns';
import { RecentMessages } from './RecentMessages';

interface ActivitySummaryProps {
  dashboardData: {
    campaignsTotal: number;
    messages: number;
  };
  onNavigateToCampaigns: () => void;
  onNavigateToMessages: () => void;
  onSearchCreators: () => void;
}

export function ActivitySummary({
  dashboardData,
  onNavigateToCampaigns,
  onNavigateToMessages,
  onSearchCreators
}: ActivitySummaryProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <RecentCampaigns 
        campaignsTotal={dashboardData.campaignsTotal} 
        onNavigateToCampaigns={onNavigateToCampaigns} 
      />
      <RecentMessages 
        messagesCount={dashboardData.messages}
        onNavigateToMessages={onNavigateToMessages}
        onSearchCreators={onSearchCreators}
      />
    </div>
  );
}
