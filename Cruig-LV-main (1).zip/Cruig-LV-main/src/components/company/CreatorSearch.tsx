
import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { CreatorTimeline } from './CreatorTimeline';
import { useCreatorSearch } from '@/hooks/useCreatorSearch';
import { useToast } from '@/hooks/use-toast';
import { useSubscriptionStatus } from '@/hooks/useSubscriptionStatus';
import { FilterProvider, useFilters } from '@/contexts/FilterContext';
import { FilterPanel } from '@/components/filters/FilterPanel';
import { CreatorBasicFilters } from './filters/CreatorBasicFilters';
import { CreatorAdvancedFilters } from './filters/CreatorAdvancedFilters';
import { ActiveFilterBadges } from './filters/ActiveFilterBadges';
import { creatorFilterConfig } from './filters/CreatorFilterConfig';
import { CreatorProfileView } from './creator/CreatorProfileView';
import { useCreatorTimelineFavorites } from '@/hooks/useCreatorTimelineFavorites';
import { Creator, CreatorFilterOptions } from '@/services/creatorService';
import { SearchHeader } from './search/SearchHeader';

// The inner component that uses the filters context
function CreatorSearchContent() {
  const { toast } = useToast();
  const { 
    isSubscribed, 
    hasReachedCampaignLimit, 
    hasReachedMessageLimit 
  } = useSubscriptionStatus();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [isFiltering, setIsFiltering] = useState(false);
  const [orderBy, setOrderBy] = useState('relevancia');
  const [filterPanelOpen, setFilterPanelOpen] = useState(false);
  const [selectedCreator, setSelectedCreator] = useState<Creator | null>(null);
  
  const { filters } = useFilters();
  const { favorites, toggleFavorite } = useCreatorTimelineFavorites();
  
  // Debounce search term
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [searchTerm]);
  
  const { creators, total, isLoading, currentPage, setCurrentPage } = useCreatorSearch(
    debouncedSearchTerm,
    filters || {}, // Ensure filters is not undefined
    orderBy
  );

  // Create a stable empty filter change function for the ActiveFilterBadges
  const handleEmptyFilterChange = useCallback((filters: CreatorFilterOptions) => {
    console.log("Filter badge clicked, but handled by FilterContext");
  }, []);

  // Apply filters with feedback
  const handleApplyFilters = useCallback(() => {
    setIsFiltering(true);
    // Show loading indicator for a short period to provide visual feedback
    setTimeout(() => {
      setIsFiltering(false);
      toast({
        title: "Filtros aplicados",
        description: "Os resultados foram atualizados conforme os filtros selecionados",
      });
    }, 800);
  }, [toast]);
  
  // Handle creator profile view
  const handleViewProfile = useCallback((creatorId: string | number) => {
    if (!isSubscribed && total > 0 && favorites && !favorites.includes(creatorId)) {
      toast({
        title: "Acesso limitado",
        description: "Assine um plano para ver perfis completos de criadores",
        variant: "destructive"
      });
      return;
    }

    // Find the creator in the list
    const creator = creators.find(c => c.id === creatorId);
    if (creator) {
      setSelectedCreator(creator);
      // Scroll to top for better UX
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [creators, favorites, isSubscribed, toast, total]);
  
  // Memoize the toggle favorite function to prevent recreation on each render
  const handleToggleFavorite = useCallback((creatorId: string | number) => {
    if (toggleFavorite) {
      toggleFavorite(creatorId);
    }
  }, [toggleFavorite]);
  
  // Send message to creator
  const handleSendMessage = useCallback((creator: Creator) => {
    if (hasReachedMessageLimit && !isSubscribed) {
      toast({
        title: "Limite de mensagens atingido",
        description: "Assine um plano para enviar mais mensagens",
        variant: "destructive"
      });
      return;
    }
    setSelectedCreator(creator);
  }, [hasReachedMessageLimit, isSubscribed, toast]);
  
  const handleBack = useCallback(() => {
    setSelectedCreator(null);
  }, []);

  const handleToggleFavoriteForSelectedCreator = useCallback(() => {
    if (selectedCreator && toggleFavorite) {
      toggleFavorite(selectedCreator.id);
    }
  }, [selectedCreator, toggleFavorite]);

  const handlePageChange = useCallback((page: number) => {
    setCurrentPage(page);
    // Scroll to top when changing pages
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [setCurrentPage]);
  
  const handleSearchChange = useCallback((value: string) => {
    setSearchTerm(value);
  }, []);

  const handleOrderByChange = useCallback((value: string) => {
    setOrderBy(value);
  }, []);

  const handleToggleFilters = useCallback(() => {
    setFilterPanelOpen(prev => !prev);
  }, []);

  // If a creator is selected, show their profile
  if (selectedCreator) {
    return (
      <div className="space-y-6 container mx-auto px-4 py-6">
        <CreatorProfileView 
          creator={selectedCreator}
          onBack={handleBack}
          onToggleFavorite={handleToggleFavoriteForSelectedCreator}
          isFavorite={Array.isArray(favorites) && favorites.includes(selectedCreator.id)}
        />
      </div>
    );
  }
  
  return (
    <div className="space-y-6 container mx-auto px-4 py-6">
      <Card className="border border-gray-200 shadow-md">
        <CardHeader className="border-b border-gray-100 pb-4">
          <CardTitle className="flex items-center gap-2 text-gray-800">
            <Users className="h-6 w-6 text-[#99c00d]" />
            Criadores disponíveis
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <SearchHeader
            searchTerm={searchTerm}
            onSearchChange={handleSearchChange}
            orderBy={orderBy}
            onOrderByChange={handleOrderByChange}
            showFilters={filterPanelOpen}
            onToggleFilters={handleToggleFilters}
          />
          
          {/* Filter system */}
          <FilterPanel
            title="Filtrar Criadores"
            onApplyFilters={handleApplyFilters}
            isOpen={filterPanelOpen}
            onOpenChange={setFilterPanelOpen}
            tabs={[
              { id: "basic", label: "Filtros Básicos" },
              { id: "advanced", label: "Filtros Avançados" }
            ]}
          >
            <div>
              <div data-tab="basic">
                <CreatorBasicFilters />
              </div>
              <div data-tab="advanced" className="hidden">
                <CreatorAdvancedFilters />
              </div>
            </div>
          </FilterPanel>
          
          {filters && (
            <ActiveFilterBadges 
              activeFilters={filters} 
              onFilterChange={handleEmptyFilterChange}
              className="mt-4" 
            />
          )}
        </CardContent>
      </Card>

      <CreatorTimeline 
        creators={Array.isArray(creators) ? creators : []} 
        total={typeof total === 'number' ? total : 0}
        isLoading={Boolean(isLoading) || isFiltering}
        currentPage={typeof currentPage === 'number' ? currentPage : 1}
        onPageChange={handlePageChange}
        onViewProfile={handleViewProfile}
        onToggleFavorite={handleToggleFavorite}
        onSendMessage={handleSendMessage}
        favorites={favorites}
        isSubscribed={isSubscribed}
      />
    </div>
  );
}

// The main exported component that provides the filter context
export function CreatorSearch() {
  return (
    <FilterProvider>
      <CreatorSearchContent />
    </FilterProvider>
  );
}
