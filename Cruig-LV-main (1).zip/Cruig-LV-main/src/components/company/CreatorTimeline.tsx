
import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, ExternalLink, ChevronRight, MessageSquare, Instagram, Youtube, Twitter } from 'lucide-react';
import { BrandTiktok } from '@/components/icons/BrandTiktok';
import { Pagination } from '@/components/ui/pagination';
import { Skeleton } from '@/components/ui/skeleton';
import { Creator } from '@/services/creatorService';

interface CreatorTimelineProps {
  creators: Creator[];
  total: number;
  isLoading?: boolean;
  currentPage: number;
  onPageChange: (page: number) => void;
  onViewProfile: (creatorId: string | number) => void;
  onSendMessage?: (creator: Creator) => void;
  onToggleFavorite?: (creatorId: string | number) => void;
  favorites?: (string | number)[];
  isSubscribed?: boolean;
  itemsPerPage?: number;
}

export function CreatorTimeline({
  creators,
  total,
  isLoading = false,
  currentPage,
  onPageChange,
  onViewProfile,
  onSendMessage,
  onToggleFavorite,
  favorites = [],
  isSubscribed = false,
  itemsPerPage = 12
}: CreatorTimelineProps) {
  const totalPages = Math.ceil(total / itemsPerPage);
  
  // Helper function to handle different social network data structures
  const renderSocialNetworks = (creator: Creator) => {
    // If socialMedia is an array
    if (creator.socialMedia && Array.isArray(creator.socialMedia)) {
      return creator.socialMedia.map((network, idx) => {
        let networkType = network.platform || 'unknown';
        let followers = network.followers || 0;
        
        return (
          <div 
            key={idx} 
            className="inline-flex items-center bg-gray-100 px-2 py-1 rounded text-xs font-medium text-gray-700 gap-1"
          >
            {getSocialIcon(networkType)}
            <span>{formatFollowers(followers)}</span>
          </div>
        );
      });
    } 
    // If socialNetworks is an object like { instagram: 'username', youtube: 'username' }
    else if (creator.socialNetworks && typeof creator.socialNetworks === 'object') {
      return Object.entries(creator.socialNetworks).map(([networkName, username], idx) => {
        return (
          <div 
            key={idx} 
            className="inline-flex items-center bg-gray-100 px-2 py-1 rounded text-xs font-medium text-gray-700 gap-1"
          >
            {getSocialIcon(networkName)}
            <span>@{username}</span>
          </div>
        );
      });
    }
    
    // If no valid social networks
    return null;
  };
  
  // Format followers number to display
  const formatFollowers = (followers?: number) => {
    if (!followers) return '0';
    return Intl.NumberFormat('pt-BR').format(followers);
  };

  // Fixed loading state rendering to avoid the re-render loop
  if (isLoading) {
    // Create an array of specified length to map over for skeletons
    return (
      <div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <div className="p-4 flex flex-col h-full">
                <div className="flex items-center space-x-3 mb-4">
                  <Skeleton className="rounded-full h-12 w-12" />
                  <div className="space-y-1 flex-1">
                    <Skeleton className="h-5 w-2/3" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                </div>
                <div className="space-y-3 mb-4">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-5/6" />
                </div>
                <div className="mt-auto pt-4 space-y-2">
                  <Skeleton className="h-9 w-full rounded-md" />
                </div>
              </div>
            </Card>
          ))}
        </div>
        <div className="flex justify-center">
          <Skeleton className="h-10 w-64" />
        </div>
      </div>
    );
  }

  if (creators.length === 0) {
    return (
      <Card className="p-8 text-center">
        <h3 className="text-lg font-medium mb-2">Nenhum criador encontrado</h3>
        <p className="text-gray-500">Tente ajustar seus filtros ou buscar por outros termos.</p>
      </Card>
    );
  }

  // Helper to safely get the icon for a social network
  const getSocialIcon = (network: string) => {
    switch (network.toLowerCase()) {
      case 'instagram':
        return <Instagram className="h-4 w-4" />;
      case 'youtube':
        return <Youtube className="h-4 w-4" />;
      case 'tiktok':
        return <BrandTiktok className="h-4 w-4" />;
      case 'twitter':
        return <Twitter className="h-4 w-4" />;
      default:
        return <ExternalLink className="h-4 w-4" />;
    }
  };

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {creators.map((creator) => {
          const isFavorite = favorites.includes(creator.id);
          
          return (
            <Card 
              key={creator.id} 
              className="overflow-hidden border border-gray-200 shadow-md hover:shadow-lg transition-shadow duration-300 rounded-lg"
            >
              <div className="p-5 flex flex-col h-full">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="h-14 w-14 rounded-full overflow-hidden flex-shrink-0 bg-gray-100 border border-gray-200">
                    {creator.avatar ? (
                      <img 
                        src={creator.avatar} 
                        alt={creator.name} 
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center bg-brand-secondary/30 text-gray-500 font-bold text-xl">
                        {creator.name?.charAt(0) || "C"}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 truncate">
                      {creator.name}
                      {creator.verified && (
                        <span className="inline-block ml-1 text-[#94C700]">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 inline">
                            <path fillRule="evenodd" d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.49 4.49 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clipRule="evenodd" />
                          </svg>
                        </span>
                      )}
                    </h3>
                    <p className="text-sm text-gray-600 truncate">
                      {creator.niches?.join(', ') || 'Criador de conteúdo'}
                    </p>
                  </div>
                  
                  {onToggleFavorite && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(creator.id);
                      }}
                      className="text-gray-400 hover:text-[#94C700] p-2 rounded-full hover:bg-gray-100 transition-colors"
                      title={isFavorite ? "Remover dos favoritos" : "Adicionar aos favoritos"}
                    >
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 24 24" 
                        fill={isFavorite ? "currentColor" : "none"}
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className={`w-5 h-5 ${isFavorite ? 'fill-[#94C700] text-[#94C700]' : ''}`}
                      >
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                      </svg>
                    </button>
                  )}
                </div>
                
                <div className="space-y-3 mb-4 flex-grow">
                  <div className="flex flex-wrap gap-2">
                    {renderSocialNetworks(creator)}
                  </div>
                </div>
                
                <div className="mt-auto pt-4 space-y-2 border-t border-gray-100">
                  <button 
                    type="button"
                    className="w-full bg-[#94C700] hover:bg-[#75a300] text-white py-2 rounded-md font-medium transition-colors"
                    onClick={() => onViewProfile(creator.id)}
                  >
                    Ver perfil completo
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      className="ml-1 h-4 w-4 inline-block"
                    >
                      <path d="m9 18 6-6-6-6" />
                    </svg>
                  </button>
                  
                  {onSendMessage && (
                    <button 
                      type="button"
                      className="w-full border border-gray-300 text-gray-700 hover:bg-gray-50 py-2 rounded-md font-medium transition-colors flex items-center justify-center"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSendMessage && onSendMessage(creator);
                      }}
                      disabled={!isSubscribed}
                    >
                      <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 24 24" 
                        fill="none" 
                        stroke="currentColor" 
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        className="mr-1 h-4 w-4"
                      >
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                      </svg>
                      Entrar em contato
                    </button>
                  )}
                </div>
              </div>
            </Card>
          );
        })}
      </div>
      
      {totalPages > 1 && (
        <div className="flex justify-center mt-8">
          <Pagination 
            currentPage={currentPage} 
            totalPages={totalPages} 
            onPageChange={onPageChange} 
          />
        </div>
      )}
    </div>
  );
}
