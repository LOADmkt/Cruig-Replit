
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSubscription } from '@/hooks/useSubscription';
import { useDashboardData } from '@/hooks/useDashboardData';
import { DashboardHeader } from './dashboard/DashboardHeader';
import { SubscriptionStatus } from './dashboard/SubscriptionStatus';
import { MetricCards } from './dashboard/MetricCards';
import { CampaignList } from './dashboard/CampaignList';
import { CreatorFinderCard } from './dashboard/CreatorFinderCard';
import { Loader2 } from 'lucide-react';

interface CompanyDashboardOverviewProps {
  userData: any;
}

export function CompanyDashboardOverview({ userData }: CompanyDashboardOverviewProps) {
  const navigate = useNavigate();
  const { subscription, usageCount, hasReachedMessageLimit } = useSubscription();
  const { isLoading, error, data } = useDashboardData('company/dashboard');
  
  const handleSearchClick = () => {
    navigate('/empresa-dashboard/buscar');
  };
  
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <Loader2 className="h-12 w-12 animate-spin text-brand-primary mb-4" />
        <p className="text-lg text-gray-600">Carregando seu dashboard...</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center">
        <h3 className="text-lg font-medium text-red-800">Erro ao carregar dados</h3>
        <p className="mt-2 text-red-600">{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 px-4 py-2 bg-brand-tertiary text-white rounded-lg hover:bg-brand-tertiary/80"
        >
          Tentar Novamente
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <DashboardHeader userData={userData} />

      <SubscriptionStatus 
        subscription={subscription} 
        usageCount={usageCount}
        hasReachedMessageLimit={hasReachedMessageLimit}
      />

      <MetricCards dashboardData={data} />

      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-brand-darkGray">Suas Campanhas</h2>
        <CampaignList 
          campaigns={data?.campaigns || []} 
          emptyMessage="Você ainda não tem campanhas criadas"
        />
      </div>

      <CreatorFinderCard 
        creatorsCount={data?.contractedCreators || 0}
        onSearchClick={handleSearchClick}
      />
    </div>
  );
}
