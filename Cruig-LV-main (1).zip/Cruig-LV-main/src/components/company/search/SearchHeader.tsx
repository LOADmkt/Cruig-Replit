
import React from 'react';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface SearchHeaderProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  orderBy: string;
  onOrderByChange: (value: string) => void;
  showFilters: boolean;
  onToggleFilters: () => void;
}

export function SearchHeader({
  searchTerm,
  onSearchChange,
  orderBy,
  onOrderByChange,
  showFilters,
  onToggleFilters
}: SearchHeaderProps) {
  return (
    <div className="flex flex-col gap-4 md:flex-row md:items-center">
      <div className="relative flex-1 search-bar border-2 border-gray-200 rounded-lg focus-within:border-brand-primary">
        <Search className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
        <Input
          placeholder="Buscar por nome, nicho ou localização..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10 border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
        />
        {searchTerm && (
          <button 
            onClick={() => onSearchChange('')}
            className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
            aria-label="Limpar busca"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      
      <Select 
        value={orderBy} 
        onValueChange={onOrderByChange}
        defaultValue="relevancia"
      >
        <SelectTrigger className="w-[180px] border-2 border-gray-200 focus:border-brand-primary text-gray-800">
          <SelectValue placeholder="Ordenar por" />
        </SelectTrigger>
        <SelectContent className="bg-white text-gray-800">
          <SelectItem value="relevancia">Mais relevantes</SelectItem>
          <SelectItem value="seguidores">Maior número de seguidores</SelectItem>
          <SelectItem value="avaliacao">Melhor avaliados</SelectItem>
          <SelectItem value="recentes">Mais recentes</SelectItem>
          <SelectItem value="engajamento">Maior engajamento</SelectItem>
        </SelectContent>
      </Select>
      
      <Button
        variant={showFilters ? "default" : "outline"}
        onClick={onToggleFilters}
        className={`flex items-center gap-2 ${
          showFilters 
            ? "bg-brand-primary text-white hover:bg-brand-primary/90" 
            : "border-2 border-brand-primary text-brand-primary hover:bg-brand-primary hover:text-white"
        } shadow-sm hover:shadow-md transition-all`}
      >
        <SlidersHorizontal className="h-4 w-4" />
        Filtros Avançados
        {showFilters && <X className="h-3 w-3 ml-1" />}
      </Button>
    </div>
  );
}
