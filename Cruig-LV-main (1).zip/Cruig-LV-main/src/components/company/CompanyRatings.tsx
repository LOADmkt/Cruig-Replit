
import React, { useState } from 'react';
import { Search, Star, Filter, User } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function CompanyRatings() {
  const [activeTab, setActiveTab] = useState<string>("recebidas");
  
  // Simulando dados de avaliações recebidas
  const receivedRatings = [
    {
      id: 1,
      creator: {
        id: 101,
        name: 'João Silva',
        avatar: null,
        verified: true
      },
      campaign: 'Campanha de Verão 2023',
      date: '2023-12-05',
      rating: 5,
      comment: 'Ótima empresa para trabalhar! Briefing muito claro e pagamento pontual. Recomendo a todos os criadores.'
    },
    {
      id: 2,
      creator: {
        id: 102,
        name: 'Maria Oliveira',
        avatar: null,
        verified: true
      },
      campaign: 'Lançamento App',
      date: '2023-11-20',
      rating: 4,
      comment: 'Empresa séria e com um ótimo time. Devolutivas rápidas e objetivas. Recomendo.'
    },
    {
      id: 3,
      creator: {
        id: 103,
        name: 'Pedro Santos',
        avatar: null,
        verified: false
      },
      campaign: 'Campanha de Natal',
      date: '2023-11-15',
      rating: 3,
      comment: 'Experiência média. Comunicação um pouco lenta, mas no geral foi uma campanha ok.'
    }
  ];
  
  // Simulando dados de avaliações enviadas
  const sentRatings = [
    {
      id: 1,
      creator: {
        id: 101,
        name: 'João Silva',
        avatar: null,
        verified: true
      },
      campaign: 'Campanha de Verão 2023',
      date: '2023-12-10',
      rating: 5,
      comment: 'Excelente criador! Entregou o conteúdo antes do prazo e com qualidade excepcional.'
    },
    {
      id: 2,
      creator: {
        id: 102,
        name: 'Maria Oliveira',
        avatar: null,
        verified: true
      },
      campaign: 'Lançamento App',
      date: '2023-11-25',
      rating: 4,
      comment: 'Boa comunicação e entregas de qualidade. Engajamento dentro do esperado.'
    },
    {
      id: 3,
      creator: {
        id: 104,
        name: 'Ana Souza',
        avatar: null,
        verified: true
      },
      campaign: 'Campanha de Natal',
      date: '2023-11-18',
      rating: 2,
      comment: 'Não cumpriu com o prazo e a qualidade do conteúdo ficou abaixo do esperado.'
    },
    {
      id: 4,
      creator: {
        id: 103,
        name: 'Pedro Santos',
        avatar: null,
        verified: false
      },
      campaign: 'Campanha de Natal',
      date: '2023-11-17',
      rating: 4,
      comment: 'Criativo e responsivo. Conseguiu adaptar o conteúdo conforme nossas sugestões.'
    }
  ];

  // Calcular média das avaliações recebidas
  const avgRating = receivedRatings.length > 0 
    ? receivedRatings.reduce((sum, item) => sum + item.rating, 0) / receivedRatings.length 
    : 0;
  
  // Verificar se tem selo de Super Empresa (10+ avaliações com média >= 4)
  const isSuperCompany = receivedRatings.length >= 10 && avgRating >= 4;

  // Renderizar estrelas com base na nota
  const renderStars = (rating: number) => {
    return Array(5).fill(0).map((_, index) => (
      <Star 
        key={index} 
        className={`h-4 w-4 ${
          index < rating 
            ? 'text-amber-400 fill-amber-400' 
            : 'text-gray-300'
        }`} 
      />
    ));
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Avaliações</h1>
        <p className="text-gray-600 mt-1">Gerencie suas avaliações e feedback</p>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-brand-purple/10 flex items-center justify-center">
                <Star className="h-8 w-8 text-brand-purple" />
              </div>
              <div>
                <div className="text-3xl font-bold">{avgRating.toFixed(1)}</div>
                <div className="flex items-center gap-1 mt-1">
                  {renderStars(Math.round(avgRating))}
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  {receivedRatings.length} avaliações
                </div>
              </div>
            </div>
            
            {isSuperCompany ? (
              <div className="bg-amber-50 border border-amber-100 rounded-lg p-4 flex items-center gap-3">
                <div className="rounded-full bg-amber-100 p-2">
                  <Star className="h-5 w-5 text-amber-500 fill-amber-500" />
                </div>
                <div>
                  <div className="font-semibold text-amber-800">Super Empresa</div>
                  <div className="text-sm text-amber-700">
                    Parabéns! Você recebeu mais de 10 avaliações positivas.
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <div className="font-medium mb-1">Como conseguir o selo de Super Empresa?</div>
                <div className="text-sm text-gray-600 mb-2">
                  Receba 10 ou mais avaliações com média igual ou superior a 4 estrelas.
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-brand-purple h-2 rounded-full" 
                    style={{ width: `${Math.min(100, (receivedRatings.length / 10) * 100)}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {receivedRatings.length}/10 avaliações
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col md:flex-row gap-4 items-center">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <Input className="pl-10" placeholder="Buscar avaliações..." />
        </div>
        <Button variant="outline" className="w-full md:w-auto">
          <Filter className="mr-2 h-4 w-4" /> Filtros
        </Button>
      </div>

      <Tabs defaultValue="recebidas" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="recebidas">Avaliações Recebidas</TabsTrigger>
          <TabsTrigger value="enviadas">Avaliações Enviadas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="recebidas" className="mt-6">
          {receivedRatings.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-10">
                <div className="rounded-full bg-gray-100 p-3 mb-4">
                  <Star className="h-6 w-6 text-gray-500" />
                </div>
                <h3 className="text-xl font-medium mb-2">Nenhuma avaliação recebida</h3>
                <p className="text-gray-500 text-center mb-6">
                  Você ainda não recebeu avaliações dos criadores. Complete campanhas para receber feedback.
                </p>
                <Button className="bg-brand-purple hover:bg-brand-purple/90">
                  Criar Nova Campanha
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {receivedRatings.map((review) => (
                <Card key={review.id}>
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row gap-6">
                      <div className="md:w-48 flex flex-row md:flex-col items-center md:items-start gap-4 md:gap-2">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                            {review.creator.avatar ? (
                              <img src={review.creator.avatar} alt={review.creator.name} className="w-full h-full rounded-full object-cover" />
                            ) : (
                              <User className="h-5 w-5 text-gray-400" />
                            )}
                          </div>
                          <div>
                            <div className="font-medium flex items-center">
                              {review.creator.name}
                              {review.creator.verified && (
                                <span className="text-blue-500 ml-1">✓</span>
                              )}
                            </div>
                            <div className="text-xs text-gray-500">
                              {new Date(review.date).toLocaleDateString('pt-BR')}
                            </div>
                          </div>
                        </div>
                        <div className="md:mt-2">
                          <div className="flex items-center gap-1">
                            {renderStars(review.rating)}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex-1">
                        <div className="font-medium mb-2">{review.campaign}</div>
                        <p className="text-gray-600">{review.comment}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="enviadas" className="mt-6">
          {sentRatings.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-10">
                <div className="rounded-full bg-gray-100 p-3 mb-4">
                  <Star className="h-6 w-6 text-gray-500" />
                </div>
                <h3 className="text-xl font-medium mb-2">Nenhuma avaliação enviada</h3>
                <p className="text-gray-500 text-center mb-6">
                  Você ainda não avaliou nenhum criador. Avalie os criadores após concluir campanhas.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {sentRatings.map((review) => (
                <Card key={review.id}>
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row gap-6">
                      <div className="md:w-48 flex flex-row md:flex-col items-center md:items-start gap-4 md:gap-2">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                            {review.creator.avatar ? (
                              <img src={review.creator.avatar} alt={review.creator.name} className="w-full h-full rounded-full object-cover" />
                            ) : (
                              <User className="h-5 w-5 text-gray-400" />
                            )}
                          </div>
                          <div>
                            <div className="font-medium flex items-center">
                              {review.creator.name}
                              {review.creator.verified && (
                                <span className="text-blue-500 ml-1">✓</span>
                              )}
                            </div>
                            <div className="text-xs text-gray-500">
                              {new Date(review.date).toLocaleDateString('pt-BR')}
                            </div>
                          </div>
                        </div>
                        <div className="md:mt-2">
                          <div className="flex items-center gap-1">
                            {renderStars(review.rating)}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex-1">
                        <div className="font-medium mb-2">{review.campaign}</div>
                        <p className="text-gray-600">{review.comment}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
