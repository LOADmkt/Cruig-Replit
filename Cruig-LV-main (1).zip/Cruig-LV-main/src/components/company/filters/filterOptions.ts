
export const nichos = [
  { label: 'Moda', value: 'moda' },
  { label: 'Beleza', value: 'beleza' },
  { label: 'Lifestyle', value: 'lifestyle' },
  { label: 'Tecnologia', value: 'tecnologia' },
  { label: 'Games', value: 'games' },
  { label: 'Fitness', value: 'fitness' },
  { label: 'Gastronomia', value: 'gastronomia' },
  { label: 'Viagens', value: 'viagens' },
  { label: 'Finanças', value: 'financas' },
  { label: 'Educação', value: 'educacao' },
  { label: 'Esportes', value: 'esportes' },
  { label: 'Música', value: 'musica' },
  { label: 'Cinema', value: 'cinema' },
  { label: 'Literatura', value: 'literatura' },
  { label: 'Pets', value: 'pets' },
  { label: 'Parentalidade', value: 'parentalidade' },
  { label: 'Sustentabilidade', value: 'sustentabilidade' },
];

export const locations = [
  { label: 'São Paulo', value: 'sao-paulo' },
  { label: 'Rio de Janeiro', value: 'rio-de-janeiro' },
  { label: 'Belo Horizonte', value: 'belo-horizonte' },
  { label: 'Salvador', value: 'salvador' },
  { label: 'Brasília', value: 'brasilia' },
  { label: 'Recife', value: 'recife' },
  { label: 'Porto Alegre', value: 'porto-alegre' },
  { label: 'Fortaleza', value: 'fortaleza' },
  { label: 'Curitiba', value: 'curitiba' },
  { label: 'Manaus', value: 'manaus' },
  { label: 'Florianópolis', value: 'florianopolis' },
  { label: 'Goiânia', value: 'goiania' },
  { label: 'Belém', value: 'belem' },
  { label: 'Natal', value: 'natal' },
  { label: 'Vitória', value: 'vitoria' },
];

export const socialNetworks = [
  { label: 'Instagram', value: 'instagram' },
  { label: 'TikTok', value: 'tiktok' },
  { label: 'YouTube', value: 'youtube' },
  { label: 'LinkedIn', value: 'linkedin' },
  { label: 'Twitter', value: 'twitter' },
  { label: 'Facebook', value: 'facebook' },
  { label: 'Twitch', value: 'twitch' },
];

export const contentTypes = [
  { label: 'Vídeo', value: 'video' },
  { label: 'Foto', value: 'foto' },
  { label: 'Stories', value: 'stories' },
  { label: 'Reels', value: 'reels' },
  { label: 'Texto', value: 'texto' },
  { label: 'Live', value: 'live' },
  { label: 'Podcast', value: 'podcast' },
];

export const priceRanges = [
  { label: 'Até R$ 500', value: 'ate-500' },
  { label: 'R$ 500 - R$ 1.000', value: '500-1000' },
  { label: 'R$ 1.000 - R$ 3.000', value: '1000-3000' },
  { label: 'R$ 3.000 - R$ 5.000', value: '3000-5000' },
  { label: 'R$ 5.000 - R$ 10.000', value: '5000-10000' },
  { label: 'Acima de R$ 10.000', value: 'acima-10000' },
];

export const faixasEtarias = [
  { label: '13-17 anos', value: '13-17' },
  { label: '18-24 anos', value: '18-24' },
  { label: '25-34 anos', value: '25-34' },
  { label: '35-44 anos', value: '35-44' },
  { label: '45-54 anos', value: '45-54' },
  { label: '55+ anos', value: '55+' },
];
