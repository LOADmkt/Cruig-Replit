
import React from 'react';
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useFilters } from '@/contexts/FilterContext';
import { MultiSelect } from '@/components/ui/multi-select';

// Available niche options
const nicheOptions = [
  { value: 'moda', label: 'Moda' },
  { value: 'beleza', label: 'Beleza' },
  { value: 'lifestyle', label: 'Lifestyle' },
  { value: 'fitness', label: 'Fitness' },
  { value: 'saúde', label: 'Saúde' },
  { value: 'gastronomia', label: 'Gastronomia' },
  { value: 'viagens', label: 'Viagens' },
  { value: 'tecnologia', label: 'Tecnologia' },
  { value: 'games', label: 'Games' },
  { value: 'música', label: 'Música' },
  { value: 'arte', label: 'Arte' },
  { value: 'educação', label: 'Educação' },
  { value: 'finanças', label: 'Finanças' },
  { value: 'sustentabilidade', label: 'Sustentabilidade' },
];

// Available platform options
const platformOptions = [
  { value: 'instagram', label: 'Instagram' },
  { value: 'youtube', label: 'YouTube' },
  { value: 'tiktok', label: 'TikTok' },
  { value: 'twitter', label: 'Twitter' },
  { value: 'facebook', label: 'Facebook' },
  { value: 'twitch', label: 'Twitch' },
  { value: 'linkedin', label: 'LinkedIn' },
];

export function CreatorAdvancedFilters() {
  const { filters, setFilter } = useFilters();
  
  // Get filters with defaults
  const niches = filters.niches || [];
  const platforms = filters.platforms || [];
  const highEngagement = filters.highEngagement || false;
  const openToBrands = filters.openToBrands || false;
  const previousCollabs = filters.previousCollabs || false;
  
  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <Label htmlFor="niches">Nicho</Label>
        <MultiSelect
          options={nicheOptions}
          selected={niches}
          placeholder="Selecione os nichos"
          onChange={(values) => setFilter('niches', values)}
        />
      </div>
      
      <div className="space-y-3">
        <Label htmlFor="platforms">Plataformas</Label>
        <MultiSelect
          options={platformOptions}
          selected={platforms}
          placeholder="Selecione as plataformas"
          onChange={(values) => setFilter('platforms', values)}
        />
      </div>
      
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label htmlFor="highEngagement" className="cursor-pointer">
            Alto engajamento (5%+)
          </Label>
          <Switch
            id="highEngagement"
            checked={highEngagement}
            onCheckedChange={(checked) => setFilter('highEngagement', checked)}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <Label htmlFor="openToBrands" className="cursor-pointer">
            Aberto a parcerias com marcas
          </Label>
          <Switch
            id="openToBrands"
            checked={openToBrands}
            onCheckedChange={(checked) => setFilter('openToBrands', checked)}
          />
        </div>
        
        <div className="flex items-center justify-between">
          <Label htmlFor="previousCollabs" className="cursor-pointer">
            Com experiência prévia
          </Label>
          <Switch
            id="previousCollabs"
            checked={previousCollabs}
            onCheckedChange={(checked) => setFilter('previousCollabs', checked)}
          />
        </div>
      </div>
    </div>
  );
}
