
import { type CreatorFilterOptions } from '@/services/creatorService';

export interface FilterOption {
  value: string;
  label: string;
}

export interface CreatorFiltersProps {
  activeFilters: CreatorFilterOptions;
  onFilterChange: (filters: CreatorFilterOptions) => void;
  className?: string;
}
