
import React from 'react';
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { MultiSelect } from "@/components/MultiSelect";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { nichos, locations, socialNetworks } from './filterOptions';
import type { CreatorFiltersProps } from './types';

export function BasicFilters({ activeFilters, onFilterChange }: CreatorFiltersProps) {
  const safeFilters = {
    nicho: Array.isArray(activeFilters?.nicho) ? activeFilters.nicho : [],
    seguidores: activeFilters?.seguidores || '',
    localizacao: Array.isArray(activeFilters?.localizacao) ? activeFilters.localizacao : [],
    redeSocial: Array.isArray(activeFilters?.redeSocial) ? activeFilters.redeSocial : [],
    verificado: Boolean(activeFilters?.verificado),
    superCreator: Boolean(activeFilters?.superCreator),
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div className="space-y-2">
          <Label className="text-gray-800 font-medium">Nicho principal</Label>
          <MultiSelect
            options={nichos}
            selected={safeFilters.nicho}
            onChange={(value) => onFilterChange({ ...activeFilters, nicho: value })}
            placeholder="Selecionar nichos..."
          />
        </div>

        <div className="space-y-2">
          <Label className="text-gray-800 font-medium">Redes sociais</Label>
          <MultiSelect
            options={socialNetworks}
            selected={safeFilters.redeSocial}
            onChange={(value) => onFilterChange({ ...activeFilters, redeSocial: value })}
            placeholder="Selecionar redes..."
          />
        </div>
        
        <div className="space-y-2">
          <Label className="text-gray-800 font-medium">Localização</Label>
          <MultiSelect
            options={locations}
            selected={safeFilters.localizacao}
            onChange={(value) => onFilterChange({ ...activeFilters, localizacao: value })}
            placeholder="Selecionar cidades..."
          />
        </div>

        <div className="space-y-2">
          <Label className="text-gray-800 font-medium">Faixa de seguidores</Label>
          <Select 
            value={safeFilters.seguidores} 
            onValueChange={(value) => onFilterChange({ ...activeFilters, seguidores: value })}
          >
            <SelectTrigger className="border-2 border-gray-300 focus:border-[#99c00d] focus:ring-2 focus:ring-[#99c00d] text-gray-800">
              <SelectValue placeholder="Selecione a faixa" />
            </SelectTrigger>
            <SelectContent className="bg-white text-gray-800">
              <SelectItem value="1k-10k">1k - 10k</SelectItem>
              <SelectItem value="10k-50k">10k - 50k</SelectItem>
              <SelectItem value="50k-100k">50k - 100k</SelectItem>
              <SelectItem value="100k-500k">100k - 500k</SelectItem>
              <SelectItem value="500k-1m">500k - 1M</SelectItem>
              <SelectItem value="1m+">1M+</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex flex-wrap gap-4">
        <div className="flex items-center space-x-2">
          <Switch
            checked={safeFilters.verificado}
            onCheckedChange={(checked) => onFilterChange({ ...activeFilters, verificado: checked })}
            className="data-[state=checked]:bg-[#99c00d]"
          />
          <Label className="text-gray-800 font-medium">Criadores verificados</Label>
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            checked={safeFilters.superCreator}
            onCheckedChange={(checked) => onFilterChange({ ...activeFilters, superCreator: checked })}
            className="data-[state=checked]:bg-[#99c00d]"
          />
          <Label className="text-gray-800 font-medium">Super Criadores</Label>
        </div>
      </div>
    </div>
  );
}
