
import React, { useCallback, memo } from 'react';
import { Badge } from "@/components/ui/badge";
import { nichos, locations, socialNetworks, faixasEtarias, contentTypes, priceRanges } from './filterOptions';
import type { CreatorFiltersProps } from './types';
import type { FilterOption } from './types';

export const ActiveFilterBadges = memo(function ActiveFilterBadges({ activeFilters, onFilterChange, className = "" }: CreatorFiltersProps) {
  if (!activeFilters) {
    return null;
  }
  
  const getOptionLabel = (options: FilterOption[], value: string) => {
    try {
      return options.find(opt => opt.value === value)?.label || value;
    } catch (e) {
      console.error("Erro ao obter label da opção:", e);
      return value;
    }
  };

  // Create a stable function for handling filter removals
  const handleFilterRemove = useCallback((key: string, value: any) => {
    const updatedFilters = { ...activeFilters };
    
    // Handle array-type filters
    if (Array.isArray(updatedFilters[key])) {
      updatedFilters[key] = (updatedFilters[key] as string[]).filter(v => v !== value);
    } 
    // Handle boolean filters
    else if (typeof updatedFilters[key] === 'boolean') {
      updatedFilters[key] = false;
    } 
    // Handle string or number filters
    else {
      updatedFilters[key] = '';
    }
    
    // Only call onFilterChange if it exists
    if (typeof onFilterChange === 'function') {
      onFilterChange(updatedFilters);
    }
  }, [activeFilters, onFilterChange]);

  return (
    <div className={`flex flex-wrap gap-4 ${className}`}>
      {Object.entries({
        nicho: { array: activeFilters.nicho, options: nichos },
        localizacao: { array: activeFilters.localizacao, options: locations },
        redeSocial: { array: activeFilters.redeSocial, options: socialNetworks },
        faixaEtaria: { array: activeFilters.faixaEtaria, options: faixasEtarias },
        tipoConteudo: { array: activeFilters.tipoConteudo || [], options: contentTypes },
      }).flatMap(([key, { array, options }]) => 
        Array.isArray(array) ? array.map(value => (
          <Badge 
            key={`${key}-${value}`} 
            variant="secondary" 
            className="gap-2 bg-[#99c00d]/20 text-gray-800 hover:bg-[#99c00d]/30"
          >
            {getOptionLabel(options, value)}
            <button 
              type="button"
              className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2"
              onClick={() => handleFilterRemove(key, value)}
            >
              ×
            </button>
          </Badge>
        )) : []
      )}

      {activeFilters.seguidores && (
        <Badge variant="secondary" className="bg-[#99c00d]/20 text-gray-800 hover:bg-[#99c00d]/30">
          Seguidores: {activeFilters.seguidores}
          <button 
            type="button"
            className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2"
            onClick={() => handleFilterRemove('seguidores', '')}
          >
            ×
          </button>
        </Badge>
      )}

      {activeFilters.faixaPreco && (
        <Badge variant="secondary" className="bg-[#99c00d]/20 text-gray-800 hover:bg-[#99c00d]/30">
          Preço: {getOptionLabel(priceRanges, activeFilters.faixaPreco)}
          <button 
            type="button"
            className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2"
            onClick={() => handleFilterRemove('faixaPreco', '')}
          >
            ×
          </button>
        </Badge>
      )}

      {Array.isArray(activeFilters.generoPrincipal) && activeFilters.generoPrincipal.map((genero) => (
        <Badge key={genero} variant="secondary" className="bg-[#99c00d]/20 text-gray-800 hover:bg-[#99c00d]/30">
          {genero === 'masculino' ? 'Masculino' : 
           genero === 'feminino' ? 'Feminino' : 'Misto'}
          <button 
            type="button"
            className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2"
            onClick={() => handleFilterRemove('generoPrincipal', genero)}
          >
            ×
          </button>
        </Badge>
      ))}
      
      {activeFilters.verificado && (
        <Badge variant="secondary" className="bg-[#99c00d]/20 text-gray-800 hover:bg-[#99c00d]/30">
          Verificados
          <button 
            type="button"
            className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2"
            onClick={() => handleFilterRemove('verificado', false)}
          >
            ×
          </button>
        </Badge>
      )}
      
      {activeFilters.superCreator && (
        <Badge variant="secondary" className="bg-[#99c00d]/20 text-gray-800 hover:bg-[#99c00d]/30">
          Super Criadores
          <button 
            type="button"
            className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2"
            onClick={() => handleFilterRemove('superCreator', false)}
          >
            ×
          </button>
        </Badge>
      )}
      
      {activeFilters.engajamentoMinimo > 0 && (
        <Badge variant="secondary" className="bg-[#99c00d]/20 text-gray-800 hover:bg-[#99c00d]/30">
          Engajamento mínimo: {activeFilters.engajamentoMinimo}%
          <button 
            type="button"
            className="ml-1 rounded-full outline-none ring-offset-background focus:ring-2 focus:ring-ring focus:ring-offset-2"
            onClick={() => handleFilterRemove('engajamentoMinimo', 0)}
          >
            ×
          </button>
        </Badge>
      )}
    </div>
  );
});
