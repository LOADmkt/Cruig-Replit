
import React from 'react';
import { Label } from "@/components/ui/label";
import { MultiSelect } from "@/components/MultiSelect";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { contentTypes, priceRanges, faixasEtarias } from './filterOptions';
import type { CreatorFiltersProps } from './types';

export function AdvancedFilters({ activeFilters, onFilterChange }: CreatorFiltersProps) {
  const safeFilters = {
    faixaEtaria: Array.isArray(activeFilters?.faixaEtaria) ? activeFilters.faixaEtaria : [],
    tipoConteudo: Array.isArray(activeFilters?.tipoConteudo) ? activeFilters.tipoConteudo : [],
    faixaPreco: activeFilters?.faixaPreco || '',
    generoPrincipal: Array.isArray(activeFilters?.generoPrincipal) ? activeFilters.generoPrincipal : [],
    engajamentoMinimo: typeof activeFilters?.engajamentoMinimo === 'number' ? activeFilters.engajamentoMinimo : 0,
  };

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      <div className="space-y-2">
        <Label className="text-gray-800 font-medium">Faixa etária do público</Label>
        <MultiSelect
          options={faixasEtarias}
          selected={safeFilters.faixaEtaria}
          onChange={(value) => onFilterChange({ ...activeFilters, faixaEtaria: value })}
          placeholder="Selecionar faixas etárias..."
        />
      </div>
      
      <div className="space-y-2">
        <Label className="text-gray-800 font-medium">Tipo de conteúdo</Label>
        <MultiSelect
          options={contentTypes}
          selected={safeFilters.tipoConteudo}
          onChange={(value) => onFilterChange({ ...activeFilters, tipoConteudo: value })}
          placeholder="Selecionar tipos..."
        />
      </div>

      <div className="space-y-2">
        <Label className="text-gray-800 font-medium">Faixa de preço para campanhas</Label>
        <Select 
          value={safeFilters.faixaPreco} 
          onValueChange={(value) => onFilterChange({ ...activeFilters, faixaPreco: value })}
        >
          <SelectTrigger className="border-2 border-gray-300 focus:border-[#99c00d] focus:ring-2 focus:ring-[#99c00d] text-gray-800">
            <SelectValue placeholder="Selecione a faixa de preço" />
          </SelectTrigger>
          <SelectContent className="bg-white text-gray-800">
            {priceRanges.map(range => (
              <SelectItem key={range.value} value={range.value}>{range.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label className="text-gray-800 font-medium">Gênero do público</Label>
        <ToggleGroup 
          type="multiple"
          variant="outline"
          className="justify-start"
          value={safeFilters.generoPrincipal}
          onValueChange={(value) => onFilterChange({ ...activeFilters, generoPrincipal: value })}
        >
          <ToggleGroupItem 
            value="masculino" 
            className="text-gray-800 border-2 data-[state=on]:bg-[#99c00d] data-[state=on]:text-white"
          >
            Masculino
          </ToggleGroupItem>
          <ToggleGroupItem 
            value="feminino"
            className="text-gray-800 border-2 data-[state=on]:bg-[#99c00d] data-[state=on]:text-white"
          >
            Feminino
          </ToggleGroupItem>
          <ToggleGroupItem 
            value="misto"
            className="text-gray-800 border-2 data-[state=on]:bg-[#99c00d] data-[state=on]:text-white"
          >
            Misto
          </ToggleGroupItem>
        </ToggleGroup>
      </div>

      <div className="space-y-2">
        <Label className="text-gray-800 font-medium">Engajamento mínimo (%)</Label>
        <div className="pt-5 px-2">
          <Slider 
            min={0} 
            max={100} 
            step={1} 
            value={[safeFilters.engajamentoMinimo]} 
            onValueChange={(value) => onFilterChange({ ...activeFilters, engajamentoMinimo: value[0] })}
            className="[&_[role=slider]]:bg-[#99c00d] [&_[role=slider]]:border-2 [&_[role=slider]]:border-white"
          />
          <div className="flex justify-between mt-1">
            <span className="text-xs text-gray-700">{safeFilters.engajamentoMinimo}%</span>
            <span className="text-xs text-gray-700">100%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
