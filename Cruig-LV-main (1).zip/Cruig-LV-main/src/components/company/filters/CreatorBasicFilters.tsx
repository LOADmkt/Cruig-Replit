
import React, { useState } from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { useFilters } from '@/contexts/FilterContext';

export function CreatorBasicFilters() {
  const { filters, setFilter } = useFilters();
  
  // Get filters with defaults
  const location = filters.location || '';
  const verified = filters.verified || false;
  const followersRange = filters.followersRange || [0, 1000000];
  
  // Local state for UI
  const [sliderValues, setSliderValues] = useState<number[]>(followersRange);
  
  // Handle followers range change
  const handleSliderChange = (values: number[]) => {
    setSliderValues(values);
    setFilter('followersRange', values);
  };
  
  const formatFollowerCount = (count: number): string => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(0)}K`;
    }
    return count.toString();
  };

  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <Label htmlFor="location">Localização</Label>
        <Input
          id="location"
          type="text"
          placeholder="Digite uma cidade ou estado"
          value={location}
          onChange={(e) => setFilter('location', e.target.value)}
        />
      </div>
      
      <div className="space-y-3">
        <Label>Seguidores</Label>
        <div className="pt-5 px-2">
          <Slider
            defaultValue={sliderValues}
            max={1000000}
            step={1000}
            onValueChange={handleSliderChange}
          />
          <div className="flex justify-between mt-2 text-xs text-gray-500">
            <span>{formatFollowerCount(sliderValues[0])}</span>
            <span>{formatFollowerCount(sliderValues[1])}</span>
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-2">
        <Checkbox 
          id="verified" 
          checked={verified}
          onCheckedChange={(checked) => setFilter('verified', checked === true)}
        />
        <Label htmlFor="verified" className="text-sm cursor-pointer">
          Mostrar apenas criadores verificados
        </Label>
      </div>
    </div>
  );
}
