
import { FilterConfig } from '@/types/filters';

// Creator filter configuration
export const creatorFilterConfig: Record<string, FilterConfig> = {
  nicho: {
    label: "Nicho",
    type: "multi-select",
    options: [
      { value: "Viagens", label: "Viagens" }, 
      { value: "Gastronomia", label: "Gastronomia" }, 
      { value: "Moda", label: "Moda" }, 
      { value: "Beleza", label: "Beleza" }, 
      { value: "Fitness", label: "Fitness" }, 
      { value: "Tecnologia", label: "Tecnologia" }, 
      { value: "Games", label: "Games" }, 
      { value: "Lifestyle", label: "Lifestyle" }
    ],
    defaultValue: [],
    clearable: true
  },
  plataforma: {
    label: "Plataformas",
    type: "multi-select",
    options: [
      { value: "Instagram", label: "Instagram" }, 
      { value: "TikTok", label: "TikTok" }, 
      { value: "YouTube", label: "YouTube" }, 
      { value: "Twitter", label: "Twitter" }, 
      { value: "Facebook", label: "Facebook" }, 
      { value: "Twitch", label: "Twitch" }
    ],
    defaultValue: [],
    clearable: true
  },
  localizacao: {
    label: "Localização",
    type: "multi-select",
    options: [
      { value: "São Paulo", label: "São Paulo" }, 
      { value: "Rio de Janeiro", label: "Rio de Janeiro" }, 
      { value: "Belo Horizonte", label: "Belo Horizonte" }, 
      { value: "Salvador", label: "Salvador" }, 
      { value: "Brasília", label: "Brasília" }, 
      { value: "Curitiba", label: "Curitiba" }, 
      { value: "Recife", label: "Recife" }
    ],
    defaultValue: [],
    clearable: true
  },
  faixaPreco: {
    label: "Faixa de preço",
    type: "multi-select",
    options: [
      { value: "Até R$500", label: "Até R$500" }, 
      { value: "R$500-R$1000", label: "R$500-R$1000" }, 
      { value: "R$1000-R$3000", label: "R$1000-R$3000" }, 
      { value: "R$3000-R$5000", label: "R$3000-R$5000" }, 
      { value: "Acima de R$5000", label: "Acima de R$5000" }
    ],
    defaultValue: [],
    clearable: true
  },
  faixaSeguidores: {
    label: "Seguidores",
    type: "range",
    min: 1000,
    max: 1000000,
    step: 1000,
    defaultValue: [1000, 1000000],
    clearable: true
  },
  engagementRate: {
    label: "Taxa de engajamento",
    type: "range",
    min: 0,
    max: 100,
    step: 0.1,
    defaultValue: [0, 100],
    clearable: true
  },
  tipoConteudo: {
    label: "Tipo de conteúdo",
    type: "multi-select",
    options: [
      { value: "Vídeos", label: "Vídeos" }, 
      { value: "Fotos", label: "Fotos" }, 
      { value: "Stories", label: "Stories" }, 
      { value: "Reels", label: "Reels" }, 
      { value: "Lives", label: "Lives" }, 
      { value: "Textos", label: "Textos" }
    ],
    defaultValue: [],
    clearable: true
  },
  valorCampanha: {
    label: "Valor campanha",
    type: "range",
    min: 100,
    max: 10000,
    step: 100,
    defaultValue: [100, 10000],
    clearable: true
  }
};
