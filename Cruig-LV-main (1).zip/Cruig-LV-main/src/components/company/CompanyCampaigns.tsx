import React, { useState } from 'react';
import { Plus, Filter, Search, Calendar, Users, CreditCard, Edit, Trash2, AlertTriangle, FileText } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { MultiSelect } from "@/components/MultiSelect";

// Esquema de validação para criar/editar campanha
const campaignSchema = z.object({
  titulo: z.string().min(5, {
    message: "Título deve ter pelo menos 5 caracteres"
  }),
  descricao: z.string().min(10, {
    message: "Descrição deve ter pelo menos 10 caracteres"
  }),
  objetivo: z.string().min(1, {
    message: "Objetivo é obrigatório"
  }),
  nichos: z.array(z.string()).min(1, {
    message: "Selecione pelo menos um nicho"
  }),
  faixaSeguidores: z.string().min(1, {
    message: "Faixa de seguidores é obrigatória"
  }),
  generoPublico: z.array(z.string()).min(1, {
    message: "Selecione pelo menos um gênero"
  }),
  faixaEtaria: z.array(z.string()).min(1, {
    message: "Selecione pelo menos uma faixa etária"
  }),
  orcamento: z.string().optional(),
  dataInicio: z.string().min(1, {
    message: "Data de início é obrigatória"
  }),
  dataFim: z.string().min(1, {
    message: "Data de fim é obrigatória"
  })
});
type CampaignFormValues = z.infer<typeof campaignSchema>;
export function CompanyCampaigns() {
  const {
    toast
  } = useToast();
  const [openNewCampaign, setOpenNewCampaign] = useState(false);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [campaigns, setCampaigns] = useState<any[]>([{
    id: 1,
    titulo: "Campanha de Verão 2023",
    descricao: "Promover nossa linha de produtos de verão com criadores de conteúdo de moda e lifestyle.",
    objetivo: "Divulgar produto",
    nichos: ["Moda", "Lifestyle"],
    faixaSeguidores: "10k-50k",
    generoPublico: ["Feminino", "Não-binário"],
    faixaEtaria: ["18-24", "25-34"],
    orcamento: "R$ 5.000,00",
    dataInicio: "2023-12-01",
    dataFim: "2024-01-31",
    status: "ativa",
    candidatos: 12
  }, {
    id: 2,
    titulo: "Lançamento App",
    descricao: "Divulgação do nosso novo aplicativo móvel com foco em criadores de tecnologia e games.",
    objetivo: "Gerar instalações",
    nichos: ["Tecnologia", "Games"],
    faixaSeguidores: "50k-100k",
    generoPublico: ["Todos"],
    faixaEtaria: ["18-24", "25-34", "35-44"],
    orcamento: "R$ 10.000,00",
    dataInicio: "2023-11-01",
    dataFim: "2023-12-31",
    status: "ativa",
    candidatos: 8
  }, {
    id: 3,
    titulo: "Campanha de Natal",
    descricao: "Promoção especial de Natal para nossos produtos com criadores de lifestyle e família.",
    objetivo: "Vendas",
    nichos: ["Lifestyle", "Família"],
    faixaSeguidores: "10k-50k",
    generoPublico: ["Todos"],
    faixaEtaria: ["25-34", "35-44", "45+"],
    orcamento: "R$ 7.500,00",
    dataInicio: "2023-11-15",
    dataFim: "2023-12-25",
    status: "encerrada",
    candidatos: 15
  }]);
  const [campaignToDelete, setCampaignToDelete] = useState<number | null>(null);
  const [editingCampaign, setEditingCampaign] = useState<any | null>(null);
  const [activeTab, setActiveTab] = useState<string>("todas");
  const form = useForm<CampaignFormValues>({
    resolver: zodResolver(campaignSchema),
    defaultValues: {
      titulo: "",
      descricao: "",
      objetivo: "",
      nichos: [],
      faixaSeguidores: "",
      generoPublico: [],
      faixaEtaria: [],
      orcamento: "",
      dataInicio: "",
      dataFim: ""
    }
  });

  // Reset do formulário quando o modal é aberto ou fechado
  React.useEffect(() => {
    if (openNewCampaign) {
      if (editingCampaign) {
        // Preencher o formulário com os dados da campanha para edição
        form.reset({
          titulo: editingCampaign.titulo,
          descricao: editingCampaign.descricao,
          objetivo: editingCampaign.objetivo,
          nichos: editingCampaign.nichos,
          faixaSeguidores: editingCampaign.faixaSeguidores,
          generoPublico: editingCampaign.generoPublico,
          faixaEtaria: editingCampaign.faixaEtaria,
          orcamento: editingCampaign.orcamento?.replace("R$ ", ""),
          dataInicio: editingCampaign.dataInicio,
          dataFim: editingCampaign.dataFim
        });
      } else {
        // Resetar o formulário para nova campanha
        form.reset({
          titulo: "",
          descricao: "",
          objetivo: "",
          nichos: [],
          faixaSeguidores: "",
          generoPublico: [],
          faixaEtaria: [],
          orcamento: "",
          dataInicio: "",
          dataFim: ""
        });
      }
    }
  }, [openNewCampaign, editingCampaign, form]);
  const onSubmit = (data: CampaignFormValues) => {
    console.log("Dados da campanha:", data);

    // Formatar o orçamento se fornecido
    const formattedBudget = data.orcamento ? `R$ ${data.orcamento}` : "";
    if (editingCampaign) {
      // Atualizar campanha existente
      setCampaigns(prevCampaigns => prevCampaigns.map(camp => camp.id === editingCampaign.id ? {
        ...camp,
        titulo: data.titulo,
        descricao: data.descricao,
        objetivo: data.objetivo,
        nichos: data.nichos,
        faixaSeguidores: data.faixaSeguidores,
        generoPublico: data.generoPublico,
        faixaEtaria: data.faixaEtaria,
        orcamento: formattedBudget,
        dataInicio: data.dataInicio,
        dataFim: data.dataFim
      } : camp));
      toast({
        title: "Campanha atualizada",
        description: "A campanha foi atualizada com sucesso."
      });
    } else {
      // Criar nova campanha
      const newCampaign = {
        id: campaigns.length + 1,
        titulo: data.titulo,
        descricao: data.descricao,
        objetivo: data.objetivo,
        nichos: data.nichos,
        faixaSeguidores: data.faixaSeguidores,
        generoPublico: data.generoPublico,
        faixaEtaria: data.faixaEtaria,
        orcamento: formattedBudget,
        dataInicio: data.dataInicio,
        dataFim: data.dataFim,
        status: "ativa",
        candidatos: 0
      };
      setCampaigns(prevCampaigns => [...prevCampaigns, newCampaign]);
      toast({
        title: "Campanha criada",
        description: "Nova campanha criada com sucesso."
      });
    }
    setOpenNewCampaign(false);
    setEditingCampaign(null);
  };
  const handleEdit = (campaign: any) => {
    setEditingCampaign(campaign);
    setOpenNewCampaign(true);
  };
  const handleDelete = (id: number) => {
    setCampaignToDelete(id);
    setOpenDeleteDialog(true);
  };
  const confirmDelete = () => {
    if (campaignToDelete) {
      setCampaigns(prevCampaigns => prevCampaigns.filter(camp => camp.id !== campaignToDelete));
      toast({
        title: "Campanha removida",
        description: "A campanha foi removida com sucesso."
      });
    }
    setOpenDeleteDialog(false);
    setCampaignToDelete(null);
  };
  const filteredCampaigns = campaigns.filter(campaign => {
    if (activeTab === "todas") return true;
    if (activeTab === "ativas") return campaign.status === "ativa";
    if (activeTab === "encerradas") return campaign.status === "encerrada";
    return true;
  });

  // Opções para os selects
  const nichos = ["Moda", "Beleza", "Lifestyle", "Fitness", "Saúde", "Tecnologia", "Games", "Viagem", "Gastronomia", "Finanças", "Educação", "Entretenimento", "Maternidade", "Decoração", "Pets"];
  const objetivos = ["Divulgar produto", "Gerar vendas", "Aumentar seguidores", "Gerar tráfego", "Criar conteúdo", "Gerar instalações", "Outro"];
  const faixasSeguidores = ["1k-10k", "10k-50k", "50k-100k", "100k-500k", "500k-1M", "1M+"];
  const generos = ["Masculino", "Feminino", "Não-binário", "Todos"];
  const faixasEtarias = ["13-17", "18-24", "25-34", "35-44", "45+"];
  return <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Campanhas</h1>
          <p className="text-gray-600 mt-1">Gerencie suas campanhas para criadores</p>
        </div>
        <Dialog open={openNewCampaign} onOpenChange={setOpenNewCampaign}>
          <DialogTrigger asChild>
            <Button className="bg-brand-purple hover:bg-brand-purple/90 bg-brand-primary">
              <Plus className="mr-2 h-4 w-4" /> Nova Campanha
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingCampaign ? "Editar Campanha" : "Nova Campanha"}</DialogTitle>
              <DialogDescription>
                {editingCampaign ? "Modifique os detalhes da sua campanha abaixo." : "Crie uma nova campanha para encontrar os criadores ideais para a sua marca."}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                <FormField control={form.control} name="titulo" render={({
                field
              }) => <FormItem>
                      <FormLabel>Título da campanha</FormLabel>
                      <FormControl>
                        <Input placeholder="Ex: Lançamento coleção verão" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>} />
                
                <FormField control={form.control} name="descricao" render={({
                field
              }) => <FormItem>
                      <FormLabel>Descrição detalhada</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Descreva os detalhes da sua campanha" className="min-h-[100px]" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>} />
                
                <FormField control={form.control} name="objetivo" render={({
                field
              }) => <FormItem>
                      <FormLabel>Objetivo principal</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o objetivo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {objetivos.map(objetivo => <SelectItem key={objetivo} value={objetivo}>
                              {objetivo}
                            </SelectItem>)}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>} />
                
                <FormField control={form.control} name="nichos" render={({
                field
              }) => <FormItem>
                      <FormLabel>Nichos desejados</FormLabel>
                      <FormControl>
                        <MultiSelect options={nichos.map(nicho => ({
                    label: nicho,
                    value: nicho
                  }))} selected={field.value} onChange={field.onChange} placeholder="Selecione os nichos" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>} />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField control={form.control} name="faixaSeguidores" render={({
                  field
                }) => <FormItem>
                        <FormLabel>Faixa de seguidores ideal</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione a faixa" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {faixasSeguidores.map(faixa => <SelectItem key={faixa} value={faixa}>
                                {faixa}
                              </SelectItem>)}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>} />
                  
                  <FormField control={form.control} name="orcamento" render={({
                  field
                }) => <FormItem>
                        <FormLabel>Orçamento estimado (opcional)</FormLabel>
                        <FormControl>
                          <Input placeholder="Ex: 5000" type="text" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>} />
                </div>
                
                <FormField control={form.control} name="generoPublico" render={({
                field
              }) => <FormItem>
                      <FormLabel>Gênero do público ideal</FormLabel>
                      <FormControl>
                        <MultiSelect options={generos.map(genero => ({
                    label: genero,
                    value: genero
                  }))} selected={field.value} onChange={field.onChange} placeholder="Selecione os gêneros" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>} />
                
                <FormField control={form.control} name="faixaEtaria" render={({
                field
              }) => <FormItem>
                      <FormLabel>Faixa etária do público</FormLabel>
                      <FormControl>
                        <MultiSelect options={faixasEtarias.map(faixa => ({
                    label: faixa,
                    value: faixa
                  }))} selected={field.value} onChange={field.onChange} placeholder="Selecione as faixas etárias" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>} />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField control={form.control} name="dataInicio" render={({
                  field
                }) => <FormItem>
                        <FormLabel>Data de início</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>} />
                  
                  <FormField control={form.control} name="dataFim" render={({
                  field
                }) => <FormItem>
                        <FormLabel>Data de fim</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>} />
                </div>
                
                <div className="flex justify-end space-x-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => {
                  setOpenNewCampaign(false);
                  setEditingCampaign(null);
                }}>
                    Cancelar
                  </Button>
                  <Button type="submit" className="bg-brand-purple hover:bg-brand-purple/90">
                    {editingCampaign ? "Atualizar Campanha" : "Criar Campanha"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <Input className="pl-10" placeholder="Buscar campanhas..." />
        </div>
        <Button variant="outline" className="w-full md:w-auto">
          <Filter className="mr-2 h-4 w-4" /> Filtros
        </Button>
      </div>

      <Tabs defaultValue="todas" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="todas">Todas</TabsTrigger>
          <TabsTrigger value="ativas">Ativas</TabsTrigger>
          <TabsTrigger value="encerradas">Encerradas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="todas" className="mt-6">
          {filteredCampaigns.length === 0 ? <Card>
              <CardContent className="flex flex-col items-center justify-center py-10">
                <div className="rounded-full bg-gray-100 p-3 mb-4">
                  <FileText className="h-6 w-6 text-gray-500" />
                </div>
                <h3 className="text-xl font-medium mb-2">Nenhuma campanha encontrada</h3>
                <p className="text-gray-500 text-center mb-6">
                  Você ainda não criou nenhuma campanha. Comece agora criando sua primeira campanha!
                </p>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-brand-purple hover:bg-brand-purple/90">
                      <Plus className="mr-2 h-4 w-4" /> Nova Campanha
                    </Button>
                  </DialogTrigger>
                </Dialog>
              </CardContent>
            </Card> : <div className="space-y-4">
              {filteredCampaigns.map(campaign => <Card key={campaign.id}>
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="text-xl font-semibold">{campaign.titulo}</h3>
                            <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                              <span className={`px-2 py-0.5 rounded-full text-xs ${campaign.status === 'ativa' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                                {campaign.status === 'ativa' ? 'Ativa' : 'Encerrada'}
                              </span>
                              <div className="flex items-center">
                                <Calendar className="h-3 w-3 mr-1" />
                                {new Date(campaign.dataInicio).toLocaleDateString('pt-BR')} até {new Date(campaign.dataFim).toLocaleDateString('pt-BR')}
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="icon" onClick={() => handleEdit(campaign)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(campaign.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                        
                        <p className="text-gray-600 mt-4 mb-4">{campaign.descricao}</p>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-4">
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Objetivo</div>
                            <div className="text-sm">{campaign.objetivo}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Nichos</div>
                            <div className="text-sm">{campaign.nichos.join(', ')}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Seguidores</div>
                            <div className="text-sm">{campaign.faixaSeguidores}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Público</div>
                            <div className="text-sm">{campaign.generoPublico.join(', ')}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Idade</div>
                            <div className="text-sm">{campaign.faixaEtaria.join(', ')}</div>
                          </div>
                          {campaign.orcamento && <div>
                              <div className="text-xs font-medium text-gray-500 mb-1">Orçamento</div>
                              <div className="text-sm">{campaign.orcamento}</div>
                            </div>}
                        </div>
                      </div>
                      
                      <div className="md:w-64 border-t md:border-t-0 md:border-l pt-4 md:pt-0 md:pl-6 mt-4 md:mt-0">
                        <div className="flex flex-col items-center md:items-start">
                          <div className="flex items-center gap-2 mb-3">
                            <Users className="h-5 w-5 text-brand-purple" />
                            <span className="font-semibold">{campaign.candidatos} candidatos</span>
                          </div>
                          <Button disabled={campaign.status !== 'ativa'} className="w-full bg-brand-purple hover:bg-brand-purple/90 mb-2 bg-brand-primary">
                            Ver candidatos
                          </Button>
                          <Button variant="outline" className="w-full" disabled={campaign.status !== 'ativa'}>
                            {campaign.status === 'ativa' ? 'Encerrar campanha' : 'Campanha encerrada'}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>)}
            </div>}
        </TabsContent>
        
        <TabsContent value="ativas" className="mt-6">
          {/* O mesmo conteúdo que a aba "todas", mas filtrado para campanhas ativas */}
          {filteredCampaigns.length === 0 ? <Card>
              <CardContent className="flex flex-col items-center justify-center py-10">
                <div className="rounded-full bg-gray-100 p-3 mb-4">
                  <FileText className="h-6 w-6 text-gray-500" />
                </div>
                <h3 className="text-xl font-medium mb-2">Nenhuma campanha ativa</h3>
                <p className="text-gray-500 text-center mb-6">
                  Você não tem campanhas ativas no momento. Crie uma nova campanha agora!
                </p>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-brand-purple hover:bg-brand-purple/90">
                      <Plus className="mr-2 h-4 w-4" /> Nova Campanha
                    </Button>
                  </DialogTrigger>
                </Dialog>
              </CardContent>
            </Card> : <div className="space-y-4">
              {/* Lista de campanhas (mesmo formato que a aba "todas") */}
              {filteredCampaigns.map(campaign => <Card key={campaign.id}>
                  {/* Mesmo conteúdo que na aba "todas" */}
                  <CardContent className="p-6">
                    {/* ... conteúdo da campanha igual ao da aba "todas" ... */}
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="text-xl font-semibold">{campaign.titulo}</h3>
                            <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                              <span className="px-2 py-0.5 rounded-full text-xs bg-green-100 text-green-800">
                                Ativa
                              </span>
                              <div className="flex items-center">
                                <Calendar className="h-3 w-3 mr-1" />
                                {new Date(campaign.dataInicio).toLocaleDateString('pt-BR')} até {new Date(campaign.dataFim).toLocaleDateString('pt-BR')}
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="icon" onClick={() => handleEdit(campaign)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(campaign.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                        
                        <p className="text-gray-600 mt-4 mb-4">{campaign.descricao}</p>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-4">
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Objetivo</div>
                            <div className="text-sm">{campaign.objetivo}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Nichos</div>
                            <div className="text-sm">{campaign.nichos.join(', ')}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Seguidores</div>
                            <div className="text-sm">{campaign.faixaSeguidores}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Público</div>
                            <div className="text-sm">{campaign.generoPublico.join(', ')}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Idade</div>
                            <div className="text-sm">{campaign.faixaEtaria.join(', ')}</div>
                          </div>
                          {campaign.orcamento && <div>
                              <div className="text-xs font-medium text-gray-500 mb-1">Orçamento</div>
                              <div className="text-sm">{campaign.orcamento}</div>
                            </div>}
                        </div>
                      </div>
                      
                      <div className="md:w-64 border-t md:border-t-0 md:border-l pt-4 md:pt-0 md:pl-6 mt-4 md:mt-0">
                        <div className="flex flex-col items-center md:items-start">
                          <div className="flex items-center gap-2 mb-3">
                            <Users className="h-5 w-5 text-brand-purple" />
                            <span className="font-semibold">{campaign.candidatos} candidatos</span>
                          </div>
                          <Button className="w-full bg-brand-purple hover:bg-brand-purple/90 mb-2 bg-brand-primary">
                            Ver candidatos
                          </Button>
                          <Button variant="outline" className="w-full">
                            Encerrar campanha
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>)}
            </div>}
        </TabsContent>
        
        <TabsContent value="encerradas" className="mt-6">
          {/* O mesmo conteúdo que a aba "todas", mas filtrado para campanhas encerradas */}
          {filteredCampaigns.length === 0 ? <Card>
              <CardContent className="flex flex-col items-center justify-center py-10">
                <div className="rounded-full bg-gray-100 p-3 mb-4">
                  <FileText className="h-6 w-6 text-gray-500" />
                </div>
                <h3 className="text-xl font-medium mb-2">Nenhuma campanha encerrada</h3>
                <p className="text-gray-500 text-center mb-6">
                  Você não tem campanhas encerradas no momento.
                </p>
              </CardContent>
            </Card> : <div className="space-y-4">
              {/* Lista de campanhas (mesmo formato que a aba "todas") */}
              {filteredCampaigns.map(campaign => <Card key={campaign.id}>
                  {/* Mesmo conteúdo que na aba "todas" */}
                  <CardContent className="p-6">
                    {/* ... conteúdo da campanha igual ao da aba "todas" ... */}
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="text-xl font-semibold">{campaign.titulo}</h3>
                            <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                              <span className="px-2 py-0.5 rounded-full text-xs bg-gray-100 text-gray-800">
                                Encerrada
                              </span>
                              <div className="flex items-center">
                                <Calendar className="h-3 w-3 mr-1" />
                                {new Date(campaign.dataInicio).toLocaleDateString('pt-BR')} até {new Date(campaign.dataFim).toLocaleDateString('pt-BR')}
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(campaign.id)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                        
                        <p className="text-gray-600 mt-4 mb-4">{campaign.descricao}</p>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-4">
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Objetivo</div>
                            <div className="text-sm">{campaign.objetivo}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Nichos</div>
                            <div className="text-sm">{campaign.nichos.join(', ')}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Seguidores</div>
                            <div className="text-sm">{campaign.faixaSeguidores}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Público</div>
                            <div className="text-sm">{campaign.generoPublico.join(', ')}</div>
                          </div>
                          <div>
                            <div className="text-xs font-medium text-gray-500 mb-1">Idade</div>
                            <div className="text-sm">{campaign.faixaEtaria.join(', ')}</div>
                          </div>
                          {campaign.orcamento && <div>
                              <div className="text-xs font-medium text-gray-500 mb-1">Orçamento</div>
                              <div className="text-sm">{campaign.orcamento}</div>
                            </div>}
                        </div>
                      </div>
                      
                      <div className="md:w-64 border-t md:border-t-0 md:border-l pt-4 md:pt-0 md:pl-6 mt-4 md:mt-0">
                        <div className="flex flex-col items-center md:items-start">
                          <div className="flex items-center gap-2 mb-3">
                            <Users className="h-5 w-5 text-brand-purple" />
                            <span className="font-semibold">{campaign.candidatos} candidatos</span>
                          </div>
                          <Button className="w-full bg-brand-purple hover:bg-brand-purple/90 mb-2 bg-brand-primary">
                            Ver resultados
                          </Button>
                          <Button variant="outline" className="w-full opacity-50 cursor-not-allowed">
                            Campanha encerrada
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>)}
            </div>}
        </TabsContent>
      </Tabs>

      {/* Diálogo de confirmação de exclusão */}
      <Dialog open={openDeleteDialog} onOpenChange={setOpenDeleteDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Confirmar exclusão
            </DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir esta campanha? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={() => setOpenDeleteDialog(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmDelete}>
              Excluir campanha
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>;
}