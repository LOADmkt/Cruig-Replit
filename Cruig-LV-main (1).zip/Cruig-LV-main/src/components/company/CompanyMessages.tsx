
import React, { useState } from 'react';
import { Search, MessageSquare, Lock, User, Send } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export function CompanyMessages() {
  const [selectedChat, setSelectedChat] = useState<number | null>(null);
  const [messageInput, setMessageInput] = useState('');
  const [showSubscriptionDialog, setShowSubscriptionDialog] = useState(false);
  
  // Simular dados de conversas
  const chats = [
    {
      id: 1,
      creator: {
        id: 101,
        name: 'João Silva',
        avatar: null,
        verified: true,
        followers: '50k'
      },
      lastMessage: 'Olá! Tenho interesse em participar da sua campanha de verão.',
      date: '2023-12-05T14:30:00',
      unread: true,
      messages: [
        {
          id: 1,
          sender: 'creator',
          content: 'Olá! Tenho interesse em participar da sua campanha de verão.',
          timestamp: '2023-12-05T14:30:00'
        }
      ]
    },
    {
      id: 2,
      creator: {
        id: 102,
        name: 'Maria Oliveira',
        avatar: null,
        verified: true,
        followers: '120k'
      },
      lastMessage: 'Gostaria de saber mais detalhes sobre o lançamento do app.',
      date: '2023-12-04T10:15:00',
      unread: false,
      messages: [
        {
          id: 1,
          sender: 'company',
          content: 'Olá Maria, temos uma campanha para o lançamento do nosso app.',
          timestamp: '2023-12-03T09:30:00'
        },
        {
          id: 2,
          sender: 'creator',
          content: 'Gostaria de saber mais detalhes sobre o lançamento do app.',
          timestamp: '2023-12-04T10:15:00'
        }
      ]
    },
    {
      id: 3,
      creator: {
        id: 103,
        name: 'Pedro Santos',
        avatar: null,
        verified: false,
        followers: '35k'
      },
      lastMessage: 'Obrigado pelo convite, vou criar um conteúdo incrível para vocês!',
      date: '2023-12-02T16:45:00',
      unread: false,
      messages: [
        {
          id: 1,
          sender: 'company',
          content: 'Olá Pedro, gostaríamos de convidá-lo para nossa campanha de Natal.',
          timestamp: '2023-12-01T11:20:00'
        },
        {
          id: 2,
          sender: 'creator',
          content: 'Olá! Tenho bastante interesse, podem me enviar mais detalhes?',
          timestamp: '2023-12-01T14:35:00'
        },
        {
          id: 3,
          sender: 'company',
          content: 'Claro! Nossa campanha envolve unboxing de produtos e review em stories e feed.',
          timestamp: '2023-12-02T09:10:00'
        },
        {
          id: 4,
          sender: 'creator',
          content: 'Obrigado pelo convite, vou criar um conteúdo incrível para vocês!',
          timestamp: '2023-12-02T16:45:00'
        }
      ]
    }
  ];

  // Simulando se a empresa tem assinatura
  const hasSubscription = true;

  const handleSendMessage = () => {
    if (!messageInput.trim()) return;
    
    if (!hasSubscription) {
      setShowSubscriptionDialog(true);
      return;
    }
    
    // Lógica para enviar mensagem (simulação)
    console.log('Mensagem enviada:', messageInput);
    setMessageInput('');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Mensagens</h1>
        <p className="text-gray-600 mt-1">Gerencie suas conversas com criadores</p>
      </div>

      {!hasSubscription && (
        <Card className="bg-amber-50 border-amber-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="rounded-full bg-amber-100 p-3">
                <Lock className="h-6 w-6 text-amber-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-amber-800 mb-1">Mensagens disponíveis apenas para assinantes</h3>
                <p className="text-amber-700 text-sm">
                  Assine o plano de R$ 297,00 para enviar mensagens ilimitadas e se comunicar com os criadores.
                </p>
              </div>
              <Button className="bg-brand-purple hover:bg-brand-purple/90">
                Assinar Agora
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-280px)] min-h-[500px]">
        {/* Lista de conversas */}
        <Card className="lg:col-span-1 overflow-hidden flex flex-col">
          <CardHeader className="pb-0">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <Input className="pl-10" placeholder="Buscar mensagens..." />
            </div>
          </CardHeader>
          <CardContent className="p-3 flex-1 overflow-auto">
            <div className="space-y-2">
              {chats.map(chat => (
                <div 
                  key={chat.id}
                  onClick={() => hasSubscription ? setSelectedChat(chat.id) : setShowSubscriptionDialog(true)}
                  className={`p-3 rounded-lg cursor-pointer transition-colors ${
                    selectedChat === chat.id 
                      ? 'bg-brand-purple/10 border-l-4 border-brand-purple' 
                      : 'hover:bg-gray-100 border-l-4 border-transparent'
                  } ${chat.unread && 'font-medium'}`}
                >
                  <div className="flex gap-3">
                    <div className="w-12 h-12 rounded-full bg-gray-200 flex-shrink-0 flex items-center justify-center">
                      {chat.creator.avatar ? (
                        <img src={chat.creator.avatar} alt={chat.creator.name} className="w-full h-full rounded-full object-cover" />
                      ) : (
                        <User className="h-6 w-6 text-gray-400" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between">
                        <span className="font-medium truncate">{chat.creator.name}</span>
                        <span className="text-xs text-gray-500">
                          {new Date(chat.date).toLocaleDateString('pt-BR')}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 truncate">{chat.lastMessage}</p>
                      <div className="flex items-center mt-1">
                        <span className="text-xs text-gray-500">{chat.creator.followers} seguidores</span>
                        {chat.creator.verified && (
                          <span className="ml-2 text-xs bg-blue-100 text-blue-700 px-1.5 rounded-full">Verificado</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        {/* Área de conversa */}
        <Card className="lg:col-span-2 overflow-hidden flex flex-col">
          {selectedChat ? (
            <>
              {/* Cabeçalho da conversa */}
              <CardHeader className="pb-3 border-b">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex-shrink-0 flex items-center justify-center">
                    <User className="h-5 w-5 text-gray-400" />
                  </div>
                  <div>
                    <CardTitle className="text-base">
                      {chats.find(c => c.id === selectedChat)?.creator.name}
                    </CardTitle>
                    <CardDescription>
                      {chats.find(c => c.id === selectedChat)?.creator.followers} seguidores · 
                      {chats.find(c => c.id === selectedChat)?.creator.verified ? ' Verificado' : ' Não verificado'}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              
              {/* Mensagens */}
              <div className="flex-1 overflow-auto p-4 space-y-4">
                {chats.find(c => c.id === selectedChat)?.messages.map(message => (
                  <div 
                    key={message.id}
                    className={`flex ${message.sender === 'company' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div 
                      className={`max-w-[70%] p-3 rounded-lg ${
                        message.sender === 'company' 
                          ? 'bg-brand-purple text-white rounded-tr-none' 
                          : 'bg-gray-100 text-gray-800 rounded-tl-none'
                      }`}
                    >
                      <p>{message.content}</p>
                      <div 
                        className={`text-xs mt-1 ${
                          message.sender === 'company' ? 'text-brand-purple/70' : 'text-gray-500'
                        }`}
                      >
                        {new Date(message.timestamp).toLocaleTimeString('pt-BR', { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Input para enviar mensagem */}
              <div className="p-4 border-t">
                <div className="flex gap-2">
                  <Textarea 
                    placeholder="Digite sua mensagem..." 
                    className="min-h-[60px] resize-none"
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                  />
                  <Button 
                    className="bg-brand-purple hover:bg-brand-purple/90 h-[60px] w-[60px]"
                    onClick={handleSendMessage}
                  >
                    <Send className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-6">
              <div className="rounded-full bg-gray-100 p-4 mb-4">
                <MessageSquare className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-xl font-medium mb-2">Nenhuma conversa selecionada</h3>
              <p className="text-gray-500 text-center mb-6 max-w-md">
                Selecione uma conversa na lista ao lado ou inicie uma nova ao buscar por criadores.
              </p>
              <Button className="bg-brand-purple hover:bg-brand-purple/90">
                Buscar Criadores
              </Button>
            </div>
          )}
        </Card>
      </div>

      {/* Diálogo de assinatura */}
      <Dialog open={showSubscriptionDialog} onOpenChange={setShowSubscriptionDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-brand-purple" />
              Recurso exclusivo para assinantes
            </DialogTitle>
            <DialogDescription>
              Para enviar e receber mensagens ilimitadas dos criadores, assine nosso plano.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-6">
            <div className="bg-gray-50 rounded-lg p-6 mb-6">
              <h3 className="font-bold text-lg mb-4">Plano Empresarial</h3>
              <div className="flex items-baseline mb-4">
                <span className="text-3xl font-bold">R$ 297,00</span>
                <span className="text-gray-500 ml-2">/mês</span>
              </div>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center">
                  <span className="mr-2 text-green-500">✓</span>
                  Mensagens ilimitadas
                </li>
                <li className="flex items-center">
                  <span className="mr-2 text-green-500">✓</span>
                  Busca avançada de criadores
                </li>
                <li className="flex items-center">
                  <span className="mr-2 text-green-500">✓</span>
                  Criação ilimitada de campanhas
                </li>
                <li className="flex items-center">
                  <span className="mr-2 text-green-500">✓</span>
                  Suporte prioritário
                </li>
              </ul>
            </div>
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button 
                variant="outline" 
                onClick={() => setShowSubscriptionDialog(false)}
              >
                Decidir depois
              </Button>
              <Button 
                className="bg-brand-purple hover:bg-brand-purple/90"
                onClick={() => setShowSubscriptionDialog(false)}
              >
                Assinar Agora
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
