import React, { useState } from 'react';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Upload, X, User, Save } from "lucide-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { MultiSelect } from "@/components/MultiSelect";

// Esquema de validação para o perfil
const profileSchema = z.object({
  nomeMarca: z.string().min(2, { message: "Nome da marca deve ter pelo menos 2 caracteres" }),
  descricao: z.string().min(10, { message: "Descrição deve ter pelo menos 10 caracteres" }),
  website: z.string().url({ message: "URL inválida" }).optional().or(z.literal("")),
  segmento: z.string().min(1, { message: "Segmento é obrigatório" }),
});

// Esquema de validação para a conta
const accountSchema = z.object({
  razaoSocial: z.string().min(3, { message: "Razão social deve ter pelo menos 3 caracteres" }),
  nomeResponsavel: z.string().min(3, { message: "Nome do responsável deve ter pelo menos 3 caracteres" }),
  email: z.string().email({ message: "Email inválido" }),
  cnpj: z.string().optional(),
});

// Esquema de validação para a senha
const passwordSchema = z.object({
  senhaAtual: z.string().min(6, { message: "Senha atual é obrigatória" }),
  novaSenha: z.string().min(6, { message: "Nova senha deve ter pelo menos 6 caracteres" }),
  confirmarSenha: z.string(),
}).refine(data => data.novaSenha === data.confirmarSenha, {
  message: "As senhas não coincidem",
  path: ["confirmarSenha"],
});

type ProfileFormValues = z.infer<typeof profileSchema>;
type AccountFormValues = z.infer<typeof accountSchema>;
type PasswordFormValues = z.infer<typeof passwordSchema>;

interface CompanySettingsProps {
  userData: any;
}

export function CompanySettings({ userData }: CompanySettingsProps) {
  const { toast } = useToast();
  const [logoPreview, setLogoPreview] = useState<string | null>(userData?.perfil?.logo || null);
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
  const [isUpdatingAccount, setIsUpdatingAccount] = useState(false);
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);
  
  // Notificações
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [appNotifications, setAppNotifications] = useState(true);
  const [newMessageNotif, setNewMessageNotif] = useState(true);
  const [campaignNotif, setCampaignNotif] = useState(true);
  const [ratingNotif, setRatingNotif] = useState(true);

  // Preparar as cidades para o multiselect
  const cidadesOptions = [
    { value: "São Paulo", label: "São Paulo" }, 
    { value: "Rio de Janeiro", label: "Rio de Janeiro" }, 
    { value: "Belo Horizonte", label: "Belo Horizonte" }, 
    { value: "Brasília", label: "Brasília" }, 
    { value: "Salvador", label: "Salvador" }, 
    { value: "Fortaleza", label: "Fortaleza" }, 
    { value: "Recife", label: "Recife" }, 
    { value: "Porto Alegre", label: "Porto Alegre" }, 
    { value: "Curitiba", label: "Curitiba" }, 
    { value: "Manaus", label: "Manaus" }, 
    { value: "Belém", label: "Belém" },
    { value: "Goiânia", label: "Goiânia" },
    { value: "Campinas", label: "Campinas" },
    { value: "Florianópolis", label: "Florianópolis" },
    { value: "Vitória", label: "Vitória" }
  ];

  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      nomeMarca: userData?.perfil?.nomeMarca || "",
      descricao: userData?.perfil?.descricao || "",
      website: userData?.perfil?.website || "",
      segmento: userData?.perfil?.segmento || "",
    }
  });

  const accountForm = useForm<AccountFormValues>({
    resolver: zodResolver(accountSchema),
    defaultValues: {
      razaoSocial: userData?.razaoSocial || "",
      nomeResponsavel: userData?.nome || "",
      email: userData?.email || "",
      cnpj: userData?.cnpj || "",
    }
  });

  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      senhaAtual: "",
      novaSenha: "",
      confirmarSenha: "",
    }
  });

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeLogo = () => {
    setLogoPreview(null);
  };

  const onProfileSubmit = async (data: ProfileFormValues) => {
    setIsUpdatingProfile(true);
    try {
      // Simulando um atraso na requisição
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Atualizar os dados do usuário no localStorage
      const updatedUserData = {
        ...userData,
        perfil: {
          ...userData.perfil,
          nomeMarca: data.nomeMarca,
          descricao: data.descricao,
          website: data.website,
          segmento: data.segmento,
          logo: logoPreview,
        }
      };
      
      localStorage.setItem('userData', JSON.stringify(updatedUserData));
      
      toast({
        title: "Perfil atualizado",
        description: "Suas informações de perfil foram atualizadas com sucesso.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar perfil",
        description: "Ocorreu um erro ao atualizar seu perfil. Tente novamente.",
      });
    } finally {
      setIsUpdatingProfile(false);
    }
  };

  const onAccountSubmit = async (data: AccountFormValues) => {
    setIsUpdatingAccount(true);
    try {
      // Simulando um atraso na requisição
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Atualizar os dados do usuário no localStorage
      const updatedUserData = {
        ...userData,
        razaoSocial: data.razaoSocial,
        nome: data.nomeResponsavel,
        email: data.email,
        cnpj: data.cnpj,
      };
      
      localStorage.setItem('userData', JSON.stringify(updatedUserData));
      
      toast({
        title: "Conta atualizada",
        description: "Suas informações de conta foram atualizadas com sucesso.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar conta",
        description: "Ocorreu um erro ao atualizar sua conta. Tente novamente.",
      });
    } finally {
      setIsUpdatingAccount(false);
    }
  };

  const onPasswordSubmit = async (data: PasswordFormValues) => {
    setIsUpdatingPassword(true);
    try {
      // Simulando um atraso na requisição
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast({
        title: "Senha atualizada",
        description: "Sua senha foi atualizada com sucesso.",
      });
      
      // Resetar o formulário de senha
      passwordForm.reset({
        senhaAtual: "",
        novaSenha: "",
        confirmarSenha: "",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar senha",
        description: "Ocorreu um erro ao atualizar sua senha. Tente novamente.",
      });
    } finally {
      setIsUpdatingPassword(false);
    }
  };

  // Lista de segmentos para o dropdown
  const segmentos = [
    "Moda e Vestuário", 
    "Beleza e Cosméticos", 
    "Tecnologia", 
    "Alimentação e Bebidas", 
    "Saúde e Bem-estar", 
    "Educação", 
    "Entretenimento", 
    "Finanças", 
    "Automotivo", 
    "Viagens e Turismo", 
    "Imobiliário",
    "Esportes e Fitness",
    "Pets",
    "Decoração e Casa",
    "Outros"
  ];

  const saveNotificationSettings = () => {
    toast({
      title: "Preferências atualizadas",
      description: "Suas preferências de notificação foram salvas com sucesso.",
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Configurações</h1>
        <p className="text-gray-600 mt-1">Gerencie suas informações e preferências</p>
      </div>

      <Tabs defaultValue="perfil">
        <TabsList className="w-full md:w-auto grid grid-cols-2 md:flex">
          <TabsTrigger value="perfil">Perfil</TabsTrigger>
          <TabsTrigger value="conta">Conta</TabsTrigger>
          <TabsTrigger value="senha">Senha</TabsTrigger>
          <TabsTrigger value="notificacoes">Notificações</TabsTrigger>
        </TabsList>
        
        {/* Aba de Perfil */}
        <TabsContent value="perfil" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Informações de Perfil</CardTitle>
              <CardDescription>
                Atualize as informações que serão exibidas para os criadores
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Logo da empresa</label>
                  <div className="flex justify-start">
                    {logoPreview ? (
                      <div className="relative">
                        <img 
                          src={logoPreview} 
                          alt="Logo preview" 
                          className="w-32 h-32 object-cover rounded-full border border-gray-200"
                        />
                        <button 
                          type="button"
                          onClick={removeLogo}
                          className="absolute -top-2 -right-2 bg-white rounded-full p-1 shadow-md"
                        >
                          <X size={16} className="text-gray-700" />
                        </button>
                      </div>
                    ) : (
                      <label className="flex flex-col items-center justify-center w-32 h-32 bg-gray-100 rounded-full border-2 border-dashed border-gray-300 cursor-pointer hover:bg-gray-50">
                        <div className="flex flex-col items-center justify-center">
                          {userData?.perfil?.nomeMarca ? (
                            <span className="font-bold text-2xl text-gray-400">
                              {userData.perfil.nomeMarca.charAt(0)}
                            </span>
                          ) : (
                            <User className="h-8 w-8 text-gray-400" />
                          )}
                          <span className="mt-2 text-sm text-gray-500">Alterar logo</span>
                        </div>
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={handleLogoUpload}
                        />
                      </label>
                    )}
                  </div>
                </div>
                
                <Form {...profileForm}>
                  <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                    <FormField
                      control={profileForm.control}
                      name="nomeMarca"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome público da marca</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="descricao"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Descrição da empresa</FormLabel>
                          <FormControl>
                            <Textarea 
                              className="min-h-[120px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="website"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Site ou rede social oficial (opcional)</FormLabel>
                          <FormControl>
                            <Input placeholder="https://www.seusite.com.br" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="segmento"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Segmento de atuação</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione o segmento" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {segmentos.map((segmento) => (
                                <SelectItem key={segmento} value={segmento}>
                                  {segmento}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="pt-4">
                      <Button 
                        type="submit" 
                        className="bg-brand-purple hover:bg-brand-purple/90"
                        disabled={isUpdatingProfile}
                      >
                        <Save className="mr-2 h-4 w-4" />
                        {isUpdatingProfile ? "Salvando..." : "Salvar alterações"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Aba de Conta */}
        <TabsContent value="conta" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Informações da Conta</CardTitle>
              <CardDescription>
                Atualize suas informações pessoais e de contato
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...accountForm}>
                <form onSubmit={accountForm.handleSubmit(onAccountSubmit)} className="space-y-4">
                  <FormField
                    control={accountForm.control}
                    name="razaoSocial"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Razão Social</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={accountForm.control}
                    name="nomeResponsavel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome do responsável</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={accountForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={accountForm.control}
                    name="cnpj"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>CNPJ (opcional)</FormLabel>
                        <FormControl>
                          <Input placeholder="00.000.000/0000-00" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="pt-4">
                    <Button 
                      type="submit" 
                      className="bg-brand-purple hover:bg-brand-purple/90"
                      disabled={isUpdatingAccount}
                    >
                      <Save className="mr-2 h-4 w-4" />
                      {isUpdatingAccount ? "Salvando..." : "Salvar alterações"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Aba de Senha */}
        <TabsContent value="senha" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Alterar Senha</CardTitle>
              <CardDescription>
                Atualize sua senha para manter sua conta segura
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...passwordForm}>
                <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
                  <FormField
                    control={passwordForm.control}
                    name="senhaAtual"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Senha atual</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={passwordForm.control}
                    name="novaSenha"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nova senha</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={passwordForm.control}
                    name="confirmarSenha"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Confirmar nova senha</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="pt-4">
                    <Button 
                      type="submit" 
                      className="bg-brand-purple hover:bg-brand-purple/90"
                      disabled={isUpdatingPassword}
                    >
                      <Save className="mr-2 h-4 w-4" />
                      {isUpdatingPassword ? "Atualizando..." : "Atualizar senha"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Aba de Notificações */}
        <TabsContent value="notificacoes" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Preferências de Notificação</CardTitle>
              <CardDescription>
                Escolha como e quando deseja receber notificações
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-3">
                  <h3 className="font-medium">Canais de notificação</h3>
                  <div className="flex items-center justify-between py-2">
                    <div className="space-y-0.5">
                      <div className="font-medium">Email</div>
                      <div className="text-sm text-gray-500">Receba atualizações por email</div>
                    </div>
                    <Switch 
                      checked={emailNotifications}
                      onCheckedChange={setEmailNotifications}
                    />
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <div className="space-y-0.5">
                      <div className="font-medium">Notificações no aplicativo</div>
                      <div className="text-sm text-gray-500">Receba atualizações na plataforma</div>
                    </div>
                    <Switch 
                      checked={appNotifications}
                      onCheckedChange={setAppNotifications}
                    />
                  </div>
                </div>
                
                <div className="space-y-3 pt-4 border-t">
                  <h3 className="font-medium">Tipos de notificação</h3>
                  <div className="flex items-center justify-between py-2">
                    <div className="space-y-0.5">
                      <div className="font-medium">Novas mensagens</div>
                      <div className="text-sm text-gray-500">Quando um criador enviar uma mensagem</div>
                    </div>
                    <Switch 
                      checked={newMessageNotif}
                      onCheckedChange={setNewMessageNotif}
                    />
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <div className="space-y-0.5">
                      <div className="font-medium">Atualizações de campanha</div>
                      <div className="text-sm text-gray-500">Quando houver novidades em suas campanhas</div>
                    </div>
                    <Switch 
                      checked={campaignNotif}
                      onCheckedChange={setCampaignNotif}
                    />
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <div className="space-y-0.5">
                      <div className="font-medium">Novas avaliações</div>
                      <div className="text-sm text-gray-500">Quando receber uma nova avaliação</div>
                    </div>
                    <Switch 
                      checked={ratingNotif}
                      onCheckedChange={setRatingNotif}
                    />
                  </div>
                </div>
                
                <div className="pt-4">
                  <Button 
                    className="bg-brand-purple hover:bg-brand-purple/90"
                    onClick={saveNotificationSettings}
                  >
                    <Save className="mr-2 h-4 w-4" />
                    Salvar preferências
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
