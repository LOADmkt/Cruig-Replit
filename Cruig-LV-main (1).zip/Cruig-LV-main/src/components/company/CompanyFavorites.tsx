
import React, { useState } from 'react';
import { Search, Star, Heart, Filter, MessageSquare, Eye, User } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

export function CompanyFavorites() {
  const { toast } = useToast();
  const [showSubscriptionDialog, setShowSubscriptionDialog] = useState(false);
  
  // Simulando se a empresa tem assinatura
  const hasSubscription = true;
  
  // Simular dados de criadores favoritos
  const creators = [
    {
      id: 101,
      name: 'João Silva',
      avatar: null,
      nichos: ['Lifestyle', 'Moda'],
      cidade: 'São Paulo',
      instagram: '45k',
      tiktok: '67k',
      youtube: null,
      engajamento: '3.5%',
      faixaEtaria: ['18-24', '25-34'],
      genero: { feminino: 65, masculino: 35 },
      verified: true,
      superCreator: true
    },
    {
      id: 102,
      name: 'Maria Oliveira',
      avatar: null,
      nichos: ['Beleza', 'Moda'],
      cidade: 'Rio de Janeiro',
      instagram: '120k',
      tiktok: '95k',
      youtube: '35k',
      engajamento: '4.2%',
      faixaEtaria: ['18-24', '25-34', '35-44'],
      genero: { feminino: 80, masculino: 20 },
      verified: true,
      superCreator: false
    },
    {
      id: 103,
      name: 'Pedro Santos',
      avatar: null,
      nichos: ['Tecnologia', 'Games'],
      cidade: 'Curitiba',
      instagram: '25k',
      tiktok: null,
      youtube: '87k',
      engajamento: '5.8%',
      faixaEtaria: ['18-24', '25-34'],
      genero: { feminino: 30, masculino: 70 },
      verified: false,
      superCreator: false
    },
    {
      id: 104,
      name: 'Ana Souza',
      avatar: null,
      nichos: ['Fitness', 'Saúde'],
      cidade: 'Belo Horizonte',
      instagram: '78k',
      tiktok: '56k',
      youtube: '23k',
      engajamento: '6.1%',
      faixaEtaria: ['25-34', '35-44'],
      genero: { feminino: 75, masculino: 25 },
      verified: true,
      superCreator: true
    }
  ];

  const removeFromFavorites = (creatorId: number) => {
    toast({
      title: "Removido dos favoritos",
      description: "Criador removido da sua lista de favoritos.",
    });
  };

  const startConversation = (creatorId: number) => {
    if (!hasSubscription) {
      setShowSubscriptionDialog(true);
      return;
    }
    
    toast({
      title: "Conversa iniciada",
      description: "Envie uma mensagem para iniciar a conversa com este criador.",
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Criadores Favoritos</h1>
        <p className="text-gray-600 mt-1">Gerencie sua lista de criadores salvos</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <Input className="pl-10" placeholder="Buscar favoritos..." />
        </div>
        <Button variant="outline" className="w-full md:w-auto">
          <Filter className="mr-2 h-4 w-4" /> Filtros
        </Button>
      </div>

      {creators.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-10">
            <div className="rounded-full bg-gray-100 p-3 mb-4">
              <Heart className="h-6 w-6 text-gray-500" />
            </div>
            <h3 className="text-xl font-medium mb-2">Nenhum criador favorito</h3>
            <p className="text-gray-500 text-center mb-6">
              Você ainda não adicionou nenhum criador à sua lista de favoritos.
            </p>
            <Button className="bg-brand-purple hover:bg-brand-purple/90">
              Buscar Criadores
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {creators.map((creator) => (
            <Card key={creator.id}>
              <CardContent className="p-6">
                <div className="flex flex-col h-full">
                  {/* Cabeçalho do card */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-14 h-14 rounded-full bg-gray-200 flex items-center justify-center">
                        {creator.avatar ? (
                          <img src={creator.avatar} alt={creator.name} className="w-full h-full rounded-full object-cover" />
                        ) : (
                          <User className="h-6 w-6 text-gray-400" />
                        )}
                      </div>
                      <div>
                        <div className="font-medium text-lg flex items-center gap-1">
                          {creator.name}
                          {creator.verified && (
                            <span className="text-blue-500 ml-1">✓</span>
                          )}
                        </div>
                        <div className="text-sm text-gray-500">{creator.cidade}</div>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-red-500 hover:text-red-600 hover:bg-red-50"
                      onClick={() => removeFromFavorites(creator.id)}
                    >
                      <Heart className="h-5 w-5 fill-current" />
                    </Button>
                  </div>
                  
                  {/* Detalhes do criador */}
                  <div className="space-y-4 mb-6">
                    <div>
                      <div className="text-xs font-medium text-gray-500 mb-1">Nichos</div>
                      <div className="flex flex-wrap gap-1">
                        {creator.nichos.map((nicho, index) => (
                          <span 
                            key={index} 
                            className="text-xs bg-gray-100 px-2 py-1 rounded-full"
                          >
                            {nicho}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <div className="text-xs font-medium text-gray-500 mb-1">Seguidores</div>
                        <div className="space-y-1">
                          {creator.instagram && (
                            <div className="text-sm flex items-center justify-between">
                              <span>Instagram:</span>
                              <span className="font-medium">{creator.instagram}</span>
                            </div>
                          )}
                          {creator.tiktok && (
                            <div className="text-sm flex items-center justify-between">
                              <span>TikTok:</span>
                              <span className="font-medium">{creator.tiktok}</span>
                            </div>
                          )}
                          {creator.youtube && (
                            <div className="text-sm flex items-center justify-between">
                              <span>YouTube:</span>
                              <span className="font-medium">{creator.youtube}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div>
                        <div className="text-xs font-medium text-gray-500 mb-1">Engajamento</div>
                        <div className="text-sm font-medium">{creator.engajamento}</div>
                      </div>
                      
                      <div>
                        <div className="text-xs font-medium text-gray-500 mb-1">Público</div>
                        <div className="text-sm">
                          {creator.genero.feminino}% fem / {creator.genero.masculino}% masc
                        </div>
                      </div>
                      
                      <div>
                        <div className="text-xs font-medium text-gray-500 mb-1">Idade</div>
                        <div className="text-sm">{creator.faixaEtaria.join(', ')}</div>
                      </div>
                    </div>
                    
                    {creator.superCreator && (
                      <div className="flex items-center gap-2 bg-amber-50 p-2 rounded-lg">
                        <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
                        <span className="text-sm text-amber-800 font-medium">Super Criador</span>
                      </div>
                    )}
                  </div>
                  
                  {/* Ações */}
                  <div className="mt-auto pt-4 border-t flex gap-2">
                    <Button 
                      variant="outline" 
                      className="flex-1"
                      onClick={() => window.open('#')}
                    >
                      <Eye className="h-4 w-4 mr-2" /> Ver Perfil
                    </Button>
                    <Button 
                      className="flex-1 bg-brand-purple hover:bg-brand-purple/90"
                      onClick={() => startConversation(creator.id)}
                    >
                      <MessageSquare className="h-4 w-4 mr-2" /> Mensagem
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {/* Diálogo de assinatura */}
      <Dialog open={showSubscriptionDialog} onOpenChange={setShowSubscriptionDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Recurso exclusivo para assinantes</DialogTitle>
            <DialogDescription>
              Para enviar mensagens aos criadores, assine nosso plano.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-6">
            <div className="bg-gray-50 rounded-lg p-6 mb-6">
              <h3 className="font-bold text-lg mb-4">Plano Empresarial</h3>
              <div className="flex items-baseline mb-4">
                <span className="text-3xl font-bold">R$ 297,00</span>
                <span className="text-gray-500 ml-2">/mês</span>
              </div>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center">
                  <span className="mr-2 text-green-500">✓</span>
                  Mensagens ilimitadas
                </li>
                <li className="flex items-center">
                  <span className="mr-2 text-green-500">✓</span>
                  Busca avançada de criadores
                </li>
                <li className="flex items-center">
                  <span className="mr-2 text-green-500">✓</span>
                  Criação ilimitada de campanhas
                </li>
                <li className="flex items-center">
                  <span className="mr-2 text-green-500">✓</span>
                  Suporte prioritário
                </li>
              </ul>
            </div>
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button 
                variant="outline" 
                onClick={() => setShowSubscriptionDialog(false)}
              >
                Mais tarde
              </Button>
              <Button 
                className="bg-brand-purple hover:bg-brand-purple/90"
                onClick={() => setShowSubscriptionDialog(false)}
              >
                Assinar Agora
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
