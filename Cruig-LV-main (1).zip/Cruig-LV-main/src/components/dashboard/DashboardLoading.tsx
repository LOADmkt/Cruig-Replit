
import React from 'react';

export function DashboardLoading() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-brand-secondary/30">
      <div className="animate-pulse flex flex-col items-center p-8">
        <div className="h-16 w-16 bg-brand-primary/30 rounded-full mb-4"></div>
        <div className="h-4 w-32 bg-gray-300 rounded mb-3"></div>
        <div className="h-3 w-24 bg-gray-200 rounded"></div>
      </div>
    </div>
  );
}
