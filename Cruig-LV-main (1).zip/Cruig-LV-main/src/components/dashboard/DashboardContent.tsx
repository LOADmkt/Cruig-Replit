
import React from 'react';
import { CreatorDashboardOverview } from '@/components/creator/CreatorDashboardOverview';
import { CreatorSubscription } from '@/components/creator/CreatorSubscription';
import { CreatorRatings } from '@/components/creator/CreatorRatings';
import { CreatorFavorites } from '@/components/creator/CreatorFavorites';
import { CreatorSettings } from '@/components/creator/CreatorSettings';
import { CreatorAffiliatePanel } from '@/components/affiliate/CreatorAffiliatePanel';
import { CreatorMessages } from '@/components/creator/CreatorMessages';
import { SocialConnection } from '@/components/social/SocialConnection';

interface DashboardContentProps {
  activeTab: string;
  userData: any;
}

export function DashboardContent({ activeTab, userData }: DashboardContentProps) {
  switch (activeTab) {
    case 'overview':
      return <CreatorDashboardOverview userData={userData} />;
    case 'messages':
      return <CreatorMessages />;
    case 'subscription':
      return <CreatorSubscription />;
    case 'ratings':
      return <CreatorRatings />;
    case 'favorites':
      return <CreatorFavorites />;
    case 'settings':
      return <CreatorSettings userData={userData} />;
    case 'affiliate':
      return <CreatorAffiliatePanel />;
    case 'social':
      return <SocialConnection />;
    default:
      return (
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold">Em Desenvolvimento</h3>
          <p className="text-gray-600 mt-2">
            Esta seção está em desenvolvimento e estará disponível em breve.
          </p>
        </div>
      );
  }
}
