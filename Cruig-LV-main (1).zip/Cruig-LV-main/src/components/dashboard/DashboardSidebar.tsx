
import React, { useCallback } from 'react';
import { LayoutDashboard, MessageSquare, FileText, Star, Heart, Settings, LogOut, Menu, X, Search, UserCircle, CreditCard, LinkIcon } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface DashboardSidebarProps {
  userData: any;
  activeTab: string;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  handleTabChange: (tab: string) => void;
  handleLogout: () => void;
  unreadMessagesCount: number;
  isSubscribed: boolean;
}

export function DashboardSidebar({
  userData,
  activeTab,
  sidebarOpen,
  setSidebarOpen,
  handleTabChange,
  handleLogout,
  unreadMessagesCount,
  isSubscribed,
}: DashboardSidebarProps) {
  // Criar uma forma segura de fechar a sidebar no mobile
  const closeSidebar = useCallback(() => {
    setSidebarOpen(false);
  }, [setSidebarOpen]);

  // Tornar a função de mudança de aba segura
  const safeHandleTabChange = useCallback((tab: string) => {
    handleTabChange(tab);
  }, [handleTabChange]);

  // Logout seguro
  const safeHandleLogout = useCallback(() => {
    handleLogout();
  }, [handleLogout]);

  return (
    <div className={`bg-white shadow-lg z-20 ${sidebarOpen ? "fixed inset-y-0 left-0 w-64 transform translate-x-0 transition-transform ease-in-out duration-300 md:relative" : "fixed inset-y-0 left-0 w-64 transform -translate-x-full transition-transform ease-in-out duration-300 md:relative md:translate-x-0 md:w-0 overflow-hidden"}`}>
      <div className="h-full flex flex-col p-4 overflow-y-auto">
        <div className="py-4 flex items-center justify-center">
          <img src="/lovable-uploads/2bf57e0e-db5c-40de-99ba-8d1bfd2dcbc5.png" alt="CreatorMatch" className="h-8" />
          <button 
            className="md:hidden absolute right-4 top-4 text-gray-500"
            onClick={closeSidebar}
            type="button"
          >
            <X size={24} />
          </button>
        </div>
        
        <div className="mb-6 flex flex-col items-center">
          {userData?.perfil?.avatar ? (
            <img 
              src={userData.perfil.avatar} 
              alt={userData.nome || 'User'} 
              className="w-24 h-24 rounded-full object-cover mb-3 border-4 border-brand-primary/20" 
            />
          ) : (
            <div className="w-24 h-24 rounded-full bg-brand-primary/10 flex items-center justify-center mb-3 border-4 border-brand-primary/20">
              <UserCircle className="h-16 w-16 text-brand-primary" />
            </div>
          )}
          <div className="font-semibold text-center">{userData?.nome || 'Usuário'}</div>
          <div className="text-xs text-gray-500 mt-1">@{userData?.perfil?.username?.replace('@', '') || 'usuario'}</div>
          
          <div className="mt-2 flex gap-2">
            {userData?.perfil?.verificado && <Badge variant="success" className="text-xs">Verificado</Badge>}
            {isSubscribed && <Badge variant="brand" className="text-xs">Premium</Badge>}
          </div>
        </div>
        
        <nav className="space-y-1 flex-1">
          <button 
            type="button"
            onClick={() => safeHandleTabChange('overview')} 
            className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${activeTab === 'overview' ? 'bg-brand-primary text-white' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <LayoutDashboard className="h-5 w-5" />
            <span>Visão Geral</span>
          </button>
          
          <button 
            type="button"
            onClick={() => safeHandleTabChange('messages')} 
            className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${activeTab === 'messages' ? 'bg-brand-primary text-white' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <MessageSquare className="h-5 w-5" />
            <span>Mensagens</span>
            {unreadMessagesCount > 0 && <Badge className="ml-auto" variant="brand">{unreadMessagesCount}</Badge>}
          </button>
          
          <button 
            type="button"
            onClick={() => safeHandleTabChange('campaigns')} 
            className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${activeTab === 'campaigns' ? 'bg-brand-primary text-white' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <Search className="h-5 w-5" />
            <span>Campanhas</span>
            <Badge className="ml-auto" variant="brand">5</Badge>
          </button>
          
          <button 
            type="button"
            onClick={() => safeHandleTabChange('subscription')} 
            className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${activeTab === 'subscription' ? 'bg-brand-primary text-white' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <CreditCard className="h-5 w-5" />
            <span>Meu Plano</span>
            {isSubscribed && <Badge className="ml-auto" variant="success">Ativo</Badge>}
          </button>

          <button 
            type="button"
            onClick={() => safeHandleTabChange('affiliate')} 
            className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${activeTab === 'affiliate' ? 'bg-brand-primary text-white' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <LinkIcon className="h-5 w-5" />
            <span>Afiliado</span>
          </button>
          
          <button 
            type="button"
            onClick={() => safeHandleTabChange('ratings')} 
            className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${activeTab === 'ratings' ? 'bg-brand-primary text-white' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <Star className="h-5 w-5" />
            <span>Avaliações</span>
            <Badge className="ml-auto" variant="brand">{userData?.perfil?.avaliacoes?.length || 0}</Badge>
          </button>
          
          <button 
            type="button"
            onClick={() => safeHandleTabChange('favorites')} 
            className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${activeTab === 'favorites' ? 'bg-brand-primary text-white' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <Heart className="h-5 w-5" />
            <span>Favoritos</span>
            <Badge className="ml-auto" variant="brand">8</Badge>
          </button>
          
          <button 
            type="button"
            onClick={() => safeHandleTabChange('settings')} 
            className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${activeTab === 'settings' ? 'bg-brand-primary text-white' : 'text-gray-700 hover:bg-gray-100'}`}
          >
            <Settings className="h-5 w-5" />
            <span>Configurações</span>
          </button>
        </nav>
        
        <div className="pt-4 mt-4 border-t border-gray-200">
          <button 
            type="button"
            onClick={safeHandleLogout}
            className="flex items-center space-x-3 w-full px-4 py-3 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
          >
            <LogOut className="h-5 w-5" />
            <span>Sair</span>
          </button>
        </div>
      </div>
    </div>
  );
}
