
import React, { useCallback } from 'react';
import { Menu } from 'lucide-react';

interface DashboardMobileHeaderProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

export function DashboardMobileHeader({
  sidebarOpen,
  setSidebarOpen,
}: DashboardMobileHeaderProps) {
  // Use useCallback para evitar re-renders desnecessários
  const toggleSidebar = useCallback(() => {
    setSidebarOpen(!sidebarOpen);
  }, [sidebarOpen, setSidebarOpen]);

  return (
    <div className="md:hidden bg-white py-3 px-4 border-b border-gray-200 flex items-center">
      <button
        onClick={toggleSidebar}
        className="p-2 rounded-md text-gray-600 hover:bg-gray-100"
        type="button"
      >
        <Menu className="h-6 w-6" />
      </button>
      <div className="ml-4">
        <img 
          src="/lovable-uploads/2bf57e0e-db5c-40de-99ba-8d1bfd2dcbc5.png" 
          alt="CreatorMatch" 
          className="h-8" 
        />
      </div>
    </div>
  );
}
