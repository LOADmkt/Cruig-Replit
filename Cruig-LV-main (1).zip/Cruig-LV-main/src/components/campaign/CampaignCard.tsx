
import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Check, ExternalLink, Bookmark, CalendarDays, MapPin } from "lucide-react";
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';

interface CampaignProps {
  id: string;
  title: string;
  company: {
    name: string;
    avatar?: string;
    verified: boolean;
  };
  description: string;
  nicho: string[];
  tipoConteudo: string[];
  valorMinimo: number;
  localizacao: string[];
  prazoMaximo: string;
  createdAt: Date;
  status: 'ativa' | 'pausada' | 'encerrada' | 'rascunho';
}

interface CampaignCardProps {
  campaign: CampaignProps;
}

export function CampaignCard({ campaign }: CampaignCardProps) {
  const { toast } = useToast();
  const [isSaved, setIsSaved] = React.useState(false);

  const getStatusBadgeProps = (status: string) => {
    switch (status) {
      case 'ativa':
        return { variant: 'success' as const, label: 'Ativa' };
      case 'pausada':
        return { variant: 'warning' as const, label: 'Pausada' };
      case 'encerrada':
        return { variant: 'destructive' as const, label: 'Encerrada' };
      case 'rascunho':
        return { variant: 'outline' as const, label: 'Rascunho' };
      default:
        return { variant: 'outline' as const, label: status };
    }
  };

  const prazoLabel = (prazo: string) => {
    switch (prazo) {
      case '7d': return '7 dias';
      case '15d': return '15 dias';
      case '30d': return '30 dias';
      case '60d': return '60 dias';
      case '90d': return '90 dias';
      case '180d': return '6 meses';
      default: return prazo;
    }
  };

  const locationLabel = (loc: string) => {
    const locations: Record<string, string> = {
      'sp': 'São Paulo',
      'rj': 'Rio de Janeiro',
      'mg': 'Minas Gerais',
      'ba': 'Bahia',
      'pr': 'Paraná',
      'rs': 'Rio Grande do Sul',
      'pe': 'Pernambuco',
      'ce': 'Ceará',
      'df': 'Distrito Federal',
      'go': 'Goiás',
      'sc': 'Santa Catarina',
      'pa': 'Pará'
    };
    return locations[loc] || loc;
  };

  const handleSaveCampaign = () => {
    setIsSaved(!isSaved);
    toast({
      title: isSaved ? 'Campanha removida' : 'Campanha salva',
      description: isSaved 
        ? 'A campanha foi removida dos seus favoritos.' 
        : 'A campanha foi adicionada aos seus favoritos.'
    });
  };

  const statusInfo = getStatusBadgeProps(campaign.status);
  
  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow duration-200">
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarImage src={campaign.company.avatar} alt={campaign.company.name} />
              <AvatarFallback>{campaign.company.name.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-1">
                <h3 className="font-medium text-gray-900">{campaign.company.name}</h3>
                {campaign.company.verified && (
                  <span className="text-brand-primary" title="Empresa verificada">
                    <Check className="h-4 w-4" />
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-500">
                {formatDistanceToNow(campaign.createdAt, {
                  addSuffix: true,
                  locale: ptBR
                })}
              </p>
            </div>
          </div>
          <Badge variant={statusInfo.variant}>
            {statusInfo.label}
          </Badge>
        </div>

        <h2 className="mt-3 font-semibold text-lg text-gray-900 line-clamp-1">{campaign.title}</h2>
        <p className="mt-1 text-sm text-gray-600 line-clamp-2">{campaign.description}</p>

        <div className="mt-3 flex flex-wrap gap-2">
          {campaign.nicho.slice(0, 3).map(nicho => (
            <Badge key={nicho} variant="outline" className="bg-brand-accent text-gray-800 hover:bg-brand-accent/80">
              {nicho}
            </Badge>
          ))}
        </div>

        <div className="mt-3 text-sm text-gray-700 flex flex-col gap-2">
          <div className="flex items-center gap-1">
            <CalendarDays className="h-4 w-4 text-gray-400" />
            <span>Prazo: {prazoLabel(campaign.prazoMaximo)}</span>
          </div>
          
          <div className="flex items-center gap-1">
            <MapPin className="h-4 w-4 text-gray-400" />
            <span className="truncate">
              {campaign.localizacao.length > 1 
                ? `${locationLabel(campaign.localizacao[0])} + ${campaign.localizacao.length - 1}` 
                : locationLabel(campaign.localizacao[0])}
            </span>
          </div>
        </div>

        <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between items-center">
          <div className="font-semibold text-gray-900">
            A partir de R$ {campaign.valorMinimo.toLocaleString()}
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={handleSaveCampaign}
              className={isSaved ? 'text-brand-primary' : 'text-gray-400 hover:text-gray-600'}
              title={isSaved ? "Remover dos favoritos" : "Salvar campanha"}
            >
              <Bookmark className="h-5 w-5" fill={isSaved ? "currentColor" : "none"} />
            </Button>
            
            <Button variant="default" className="bg-[#99c00d] hover:bg-[#87ab0c]">
              <span>Ver Detalhes</span>
              <ExternalLink className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
