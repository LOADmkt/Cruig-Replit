
import React from 'react';
import { Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { CampaignFilters } from './filters/CampaignFilters';
import { useFilters } from '@/contexts/FilterContext';

export function CampaignMobileFilter() {
  const { activeFilterCount, resetFilters } = useFilters();
  const [open, setOpen] = React.useState(false);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button 
          variant="outline" 
          className="md:hidden flex gap-2 items-center border-2 border-gray-300 hover:border-gray-400 relative"
        >
          <Filter className="h-4 w-4" />
          <span>Filtros</span>
          {activeFilterCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-brand-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
              {activeFilterCount}
            </span>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-md p-0">
        <SheetHeader className="p-4 border-b">
          <SheetTitle>Filtrar Campanhas</SheetTitle>
        </SheetHeader>
        <div className="p-4 overflow-y-auto max-h-[calc(100vh-10rem)]">
          <CampaignFilters />
        </div>
        <div className="border-t p-4 flex justify-between">
          <Button 
            variant="outline"
            onClick={() => {
              resetFilters();
              setOpen(false);
            }}
          >
            Limpar Filtros
          </Button>
          <Button
            onClick={() => setOpen(false)}
            className="bg-[#99c00d] hover:bg-[#99c00d]/90"
          >
            Aplicar Filtros
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
