
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { ArrowLeft, Calendar, DollarSign, MapPin, FileText, Clock, CheckCircle2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useSubscriptionStatus } from '@/hooks/useSubscriptionStatus';

interface Campaign {
  id: string;
  title: string;
  company: {
    name: string;
    avatar?: string;
    verified: boolean;
  };
  description: string;
  nicho: string[];
  tipoConteudo: string[];
  valorMinimo: number;
  localizacao: string[];
  prazoMaximo: string;
  createdAt: Date;
  status: 'ativa' | 'pausada' | 'encerrada' | 'rascunho';
  detailedDescription?: string;
  requirements?: string[];
  deliverables?: string[];
  timeline?: {
    start?: Date;
    end?: Date;
    milestones?: {
      title: string;
      date: Date;
    }[];
  };
}

interface CampaignDetailViewProps {
  campaign: Campaign | null;
  onBack: () => void;
}

export function CampaignDetailView({ campaign, onBack }: CampaignDetailViewProps) {
  const { toast } = useToast();
  const { isSubscribed } = useSubscriptionStatus();
  const [showApplyDialog, setShowApplyDialog] = useState(false);
  const [proposalText, setProposalText] = useState('');

  if (!campaign) {
    return (
      <Card className="border border-gray-200 shadow-lg">
        <CardContent className="p-6 text-center">
          <div className="animate-pulse flex flex-col items-center">
            <div className="h-24 w-24 rounded-full bg-gray-300 mb-4"></div>
            <div className="h-6 w-48 bg-gray-300 rounded mb-2"></div>
            <div className="h-4 w-64 bg-gray-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const handleApply = () => {
    if (!proposalText.trim()) return;
    
    toast({
      title: "Proposta enviada",
      description: `Sua proposta para a campanha "${campaign.title}" foi enviada com sucesso.`,
    });
    
    setProposalText('');
    setShowApplyDialog(false);
  };

  // Format date
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('pt-BR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(date);
  };

  // Convert prazo to readable text
  const getPrazoText = (prazo: string) => {
    switch(prazo) {
      case '7d': return '7 dias';
      case '15d': return '15 dias';
      case '30d': return '30 dias';
      case '60d': return '60 dias';
      default: return prazo;
    }
  };

  return (
    <>
      <Card className="border border-gray-200 shadow-lg">
        <CardHeader className="border-b pb-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" size="sm" onClick={onBack} className="flex items-center gap-1">
              <ArrowLeft className="h-4 w-4" />
              <span>Voltar</span>
            </Button>
            <div className="flex gap-2">
              <Button 
                variant="default"
                disabled={!isSubscribed || campaign.status !== 'ativa'}
                className="bg-[#99c00d] hover:bg-[#87ab0c] text-white"
                onClick={() => setShowApplyDialog(true)}
              >
                Candidatar-se
              </Button>
            </div>
          </div>
          
          <div className="mt-4">
            <div className="flex items-center gap-3 mb-2">
              <Avatar className="h-12 w-12 border">
                {campaign.company.avatar ? (
                  <AvatarImage src={campaign.company.avatar} alt={campaign.company.name} />
                ) : (
                  <AvatarFallback>{campaign.company.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                )}
              </Avatar>
              <div>
                <div className="flex items-center gap-1">
                  <h3 className="font-medium">{campaign.company.name}</h3>
                  {campaign.company.verified && (
                    <Badge variant="secondary" className="bg-blue-100 text-blue-800 text-xs ml-1">
                      Verificado
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-gray-500">
                  Publicado em {formatDate(campaign.createdAt)}
                </p>
              </div>
            </div>
            
            <h2 className="text-xl font-bold mt-3">{campaign.title}</h2>
            <Badge 
              variant="outline" 
              className={`mt-2 ${
                campaign.status === 'ativa' ? 'bg-green-50 text-green-700 border-green-200' : 
                campaign.status === 'pausada' ? 'bg-orange-50 text-orange-700 border-orange-200' : 
                'bg-red-50 text-red-700 border-red-200'
              }`}
            >
              {campaign.status === 'ativa' ? 'Campanha ativa' : 
               campaign.status === 'pausada' ? 'Campanha pausada' : 
               'Campanha encerrada'}
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Tabs defaultValue="detalhes" className="w-full">
                <TabsList className="mb-4">
                  <TabsTrigger value="detalhes">Detalhes</TabsTrigger>
                  <TabsTrigger value="requisitos">Requisitos</TabsTrigger>
                  <TabsTrigger value="cronograma">Cronograma</TabsTrigger>
                </TabsList>
                
                <TabsContent value="detalhes" className="space-y-4">
                  <div className="prose max-w-none">
                    <h3 className="text-lg font-medium mb-2">Descrição da campanha</h3>
                    <p className="text-gray-700">{campaign.description}</p>
                    {campaign.detailedDescription && (
                      <div className="mt-4">
                        <p className="text-gray-700">{campaign.detailedDescription}</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="mt-6">
                    <h3 className="text-lg font-medium mb-3">Entregáveis</h3>
                    {campaign.deliverables ? (
                      <ul className="space-y-2">
                        {campaign.deliverables.map((item, idx) => (
                          <li key={idx} className="flex items-start">
                            <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 mr-2 flex-shrink-0" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-gray-500">Os entregáveis serão discutidos após a aprovação.</p>
                    )}
                  </div>
                </TabsContent>
                
                <TabsContent value="requisitos" className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium mb-3">Requisitos para participação</h3>
                    {campaign.requirements ? (
                      <ul className="space-y-2">
                        {campaign.requirements.map((req, idx) => (
                          <li key={idx} className="flex items-start">
                            <CheckCircle2 className="h-5 w-5 text-[#99c00d] mt-0.5 mr-2 flex-shrink-0" />
                            <span>{req}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-gray-500">Não há requisitos específicos definidos para esta campanha.</p>
                    )}
                  </div>
                </TabsContent>
                
                <TabsContent value="cronograma" className="space-y-4">
                  <div>
                    <h3 className="text-lg font-medium mb-3">Cronograma da campanha</h3>
                    {campaign.timeline?.start && campaign.timeline.end ? (
                      <div className="space-y-4">
                        <div className="flex items-center text-gray-700">
                          <Calendar className="h-5 w-5 mr-2 text-blue-600" />
                          <span>
                            <strong>Período da campanha:</strong> {formatDate(campaign.timeline.start)} até {formatDate(campaign.timeline.end)}
                          </span>
                        </div>
                        
                        {campaign.timeline.milestones && campaign.timeline.milestones.length > 0 && (
                          <div className="mt-4">
                            <h4 className="font-medium mb-2">Marcos importantes:</h4>
                            <ul className="space-y-2">
                              {campaign.timeline.milestones.map((milestone, idx) => (
                                <li key={idx} className="flex items-center">
                                  <span className="h-2 w-2 rounded-full bg-blue-600 mr-2"></span>
                                  <span className="font-medium">{milestone.title}:</span>
                                  <span className="ml-1">{formatDate(milestone.date)}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center text-gray-700">
                        <Clock className="h-5 w-5 mr-2 text-orange-600" />
                        <span>Prazo máximo: {getPrazoText(campaign.prazoMaximo)}</span>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
            
            <div className="space-y-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Detalhes da Oportunidade</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 pt-0">
                  <div className="flex items-center text-gray-700">
                    <DollarSign className="h-5 w-5 mr-2 text-green-600" />
                    <span>
                      <strong>Valor mínimo:</strong> R$ {campaign.valorMinimo.toLocaleString('pt-BR')}
                    </span>
                  </div>
                  
                  <div className="flex items-center text-gray-700">
                    <Clock className="h-5 w-5 mr-2 text-orange-600" />
                    <span>
                      <strong>Prazo:</strong> {getPrazoText(campaign.prazoMaximo)}
                    </span>
                  </div>
                  
                  <div className="flex items-start text-gray-700">
                    <MapPin className="h-5 w-5 mr-2 text-red-600 mt-0.5" />
                    <div>
                      <strong>Localização:</strong>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {campaign.localizacao.map((loc, idx) => (
                          <Badge key={idx} variant="outline" className="bg-red-50">
                            {loc.toUpperCase()}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-start text-gray-700">
                    <FileText className="h-5 w-5 mr-2 text-purple-600 mt-0.5" />
                    <div>
                      <strong>Tipo de conteúdo:</strong>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {campaign.tipoConteudo.map((tipo, idx) => (
                          <Badge key={idx} variant="outline" className="bg-purple-50">
                            {tipo}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-start text-gray-700">
                    <FileText className="h-5 w-5 mr-2 text-blue-600 mt-0.5" />
                    <div>
                      <strong>Nicho:</strong>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {campaign.nicho.map((n, idx) => (
                          <Badge key={idx} variant="outline" className="bg-blue-50">
                            {n}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Button 
                className="w-full bg-[#99c00d] hover:bg-[#87ab0c] text-white"
                disabled={!isSubscribed || campaign.status !== 'ativa'}
                onClick={() => setShowApplyDialog(true)}
              >
                Candidatar-se para esta campanha
              </Button>
              
              {!isSubscribed && (
                <p className="text-sm text-center text-amber-600">
                  Você precisa de uma assinatura ativa para se candidatar às campanhas.
                </p>
              )}
              {campaign.status !== 'ativa' && (
                <p className="text-sm text-center text-red-600">
                  Esta campanha não está aceitando candidaturas no momento.
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Dialog open={showApplyDialog} onOpenChange={setShowApplyDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Candidatar-se à campanha</DialogTitle>
            <DialogDescription>
              Envie uma proposta para participar da campanha "{campaign.title}".
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Sua proposta</label>
              <Textarea
                placeholder="Descreva por que você seria um bom criador para esta campanha, suas ideias e expectativas..."
                value={proposalText}
                onChange={(e) => setProposalText(e.target.value)}
                rows={6}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApplyDialog(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleApply}
              className="bg-[#99c00d] hover:bg-[#87ab0c] text-white"
              disabled={!proposalText.trim()}
            >
              Enviar proposta
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
