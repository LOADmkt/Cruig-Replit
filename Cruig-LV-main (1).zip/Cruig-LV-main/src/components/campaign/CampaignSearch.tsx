
import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { FileText, Search, Filter } from 'lucide-react';
import { FilterProvider, useFilters } from '@/contexts/FilterContext';
import { CampaignFilters } from './filters/CampaignFilters';
import { ActiveFilterBadges } from '@/components/filters/ActiveFilterBadges';
import { campaignFilterConfig } from './filters/CampaignFilterConfig';
import { CampaignCard } from './CampaignCard';
import { CampaignMobileFilter } from './CampaignMobileFilter';
import { CampaignDetailView } from './CampaignDetailView';

// Campaign type
interface Campaign {
  id: string;
  title: string;
  company: {
    name: string;
    avatar?: string;
    verified: boolean;
  };
  description: string;
  nicho: string[];
  tipoConteudo: string[];
  valorMinimo: number;
  localizacao: string[];
  prazoMaximo: string;
  createdAt: Date;
  status: 'ativa' | 'pausada' | 'encerrada' | 'rascunho';
  detailedDescription?: string;
  requirements?: string[];
  deliverables?: string[];
  timeline?: {
    start?: Date;
    end?: Date;
    milestones?: {
      title: string;
      date: Date;
    }[];
  };
}

// CampaignSearchContent component - Uses the filter context
function CampaignSearchContent() {
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [filteredCampaigns, setFilteredCampaigns] = useState<Campaign[]>([]);
  const [activeTab, setActiveTab] = useState<string>('todas');
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  
  const { filters } = useFilters();
  
  // Mock campaigns data
  const mockCampaigns: Campaign[] = [
    {
      id: '1',
      title: 'Campanha de Marketing para Produto de Beleza',
      company: {
        name: 'BeautyCo',
        avatar: 'https://source.unsplash.com/photo-1581582202218-b4565e8d6699',
        verified: true,
      },
      description: 'Procuramos criadores de conteúdo para promover nossa nova linha de produtos para cuidados com a pele.',
      nicho: ['beleza', 'lifestyle'],
      tipoConteudo: ['foto', 'reels'],
      valorMinimo: 1500,
      localizacao: ['sp'],
      prazoMaximo: '30d',
      createdAt: new Date('2025-04-10'),
      status: 'ativa',
      detailedDescription: 'Nossa empresa está lançando uma nova linha de produtos para cuidados com a pele focada em ingredientes naturais e sustentabilidade. Buscamos criadores que possam mostrar a eficácia dos produtos através de antes e depois, demonstração de uso e compartilhamento da experiência pessoal com a linha. Os produtos são veganos, cruelty-free e com embalagens recicláveis.',
      requirements: [
        'Ter experiência com conteúdo de beleza e skincare',
        'Boa iluminação para mostrar os resultados dos produtos',
        'Audiência interessada em beleza e produtos naturais',
        'Comprometimento com o cronograma estabelecido'
      ],
      deliverables: [
        '2 Reels mostrando a rotina de skincare com os produtos',
        '3 Fotos para feed com antes e depois de 15 dias de uso',
        '5 Stories durante o período de 30 dias compartilhando a experiência'
      ],
      timeline: {
        start: new Date('2025-05-15'),
        end: new Date('2025-06-15'),
        milestones: [
          { title: 'Recebimento dos produtos', date: new Date('2025-05-15') },
          { title: 'Primeiro conteúdo', date: new Date('2025-05-20') },
          { title: 'Conteúdo final', date: new Date('2025-06-10') }
        ]
      }
    },
    {
      id: '2',
      title: 'Divulgação de Restaurante Japonês',
      company: {
        name: 'Sushi Express',
        avatar: 'https://source.unsplash.com/photo-1576403794206-51c2788d9c69',
        verified: true,
      },
      description: 'Buscamos criadores para divulgar nosso restaurante. Oferecemos refeição completa + remuneração.',
      nicho: ['gastronomia'],
      tipoConteudo: ['foto', 'reels'],
      valorMinimo: 800,
      localizacao: ['sp', 'rj'],
      prazoMaximo: '15d',
      createdAt: new Date('2025-04-15'),
      status: 'ativa',
      detailedDescription: 'Nosso restaurante de comida japonesa está inaugurando duas novas unidades em São Paulo e Rio de Janeiro. Buscamos criadores de conteúdo para divulgar nossa experiência gastronômica única e ajudar a atrair novos clientes. O criador terá uma experiência completa no restaurante, com direito a degustação do menu completo e bebidas, além de remuneração pela criação de conteúdo.',
      requirements: [
        'Experiência com conteúdo gastronômico',
        'Boa qualidade de imagem para fotografar os pratos',
        'Presença na cidade onde o restaurante está localizado',
        'Disponibilidade para visitar o restaurante no período noturno'
      ],
      deliverables: [
        '1 Reels mostrando a experiência completa no restaurante',
        '5 Fotos de alta qualidade dos pratos para uso em nosso Instagram',
        '3 Stories durante a visita ao restaurante'
      ]
    },
    {
      id: '3',
      title: 'Divulgação de Pousada em Destino Turístico',
      company: {
        name: 'Pousada Serenidade',
        avatar: 'https://source.unsplash.com/photo-1572120360610-d971b9d7767c',
        verified: false,
      },
      description: 'Procuramos criadores para divulgar nossa pousada. Oferecemos 3 diárias + café da manhã + remuneração.',
      nicho: ['viagem', 'lifestyle'],
      tipoConteudo: ['foto', 'reels', 'video'],
      valorMinimo: 2000,
      localizacao: ['ba'],
      prazoMaximo: '60d',
      createdAt: new Date('2025-04-18'),
      status: 'ativa',
      requirements: [
        'Experiência com conteúdo de viagens e hospedagem',
        'Equipamento para fotos e vídeos de qualidade',
        'Disponibilidade para viajar para a Bahia'
      ],
      deliverables: [
        'Vídeo de 3-5 minutos mostrando a experiência completa',
        'Mínimo de 10 fotos profissionais das instalações',
        'Conteúdo para Stories durante toda a estadia'
      ],
      timeline: {
        start: new Date('2025-06-01'),
        end: new Date('2025-08-30')
      }
    },
    {
      id: '4',
      title: 'Review de Notebook Gamer',
      company: {
        name: 'TechMax',
        avatar: 'https://source.unsplash.com/photo-1560179707-f14e90ef3623',
        verified: true,
      },
      description: 'Precisamos de review detalhado do nosso novo notebook gamer com foco em performance.',
      nicho: ['tecnologia', 'games'],
      tipoConteudo: ['video', 'texto'],
      valorMinimo: 3000,
      localizacao: ['sp', 'mg'],
      prazoMaximo: '30d',
      createdAt: new Date('2025-04-20'),
      status: 'ativa',
      detailedDescription: 'Estamos lançando nosso novo notebook gamer com processador de última geração e placa de vídeo dedicada. Buscamos criadores que possam realizar um review completo do produto, testando sua performance em diferentes jogos, analisando recursos exclusivos e comparando com produtos similares no mercado.',
      requirements: [
        'Conhecimento técnico em hardware',
        'Experiência com benchmarks e testes de performance',
        'Canal ou perfil com foco em tecnologia ou games',
        'Capacidade de análise crítica e imparcial'
      ],
      deliverables: [
        'Vídeo review completo de 10-15 minutos',
        'Artigo escrito com especificações técnicas e testes realizados',
        'Compartilhamento em redes sociais'
      ]
    },
    {
      id: '5',
      title: 'Campanha de Roupas Fitness',
      company: {
        name: 'FitWear',
        avatar: 'https://source.unsplash.com/photo-1533750704377-3fda1906eebd',
        verified: true,
      },
      description: 'Buscamos influenciadores fitness para apresentar nossa nova coleção esportiva.',
      nicho: ['fitness', 'moda'],
      tipoConteudo: ['foto', 'reels'],
      valorMinimo: 1200,
      localizacao: ['rj', 'sp', 'mg'],
      prazoMaximo: '30d',
      createdAt: new Date('2025-04-22'),
      status: 'pausada',
    },
  ];

  // Debounce search term
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);
    
    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Filter campaigns whenever filters or search term change
  useEffect(() => {
    setIsLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      let results = [...mockCampaigns];
      
      // Filter by search term
      if (debouncedSearchTerm) {
        results = results.filter(campaign => 
          campaign.title.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
          campaign.description.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
          campaign.company.name.toLowerCase().includes(debouncedSearchTerm.toLowerCase())
        );
      }
      
      // Filter by active tab
      if (activeTab !== 'todas') {
        results = results.filter(campaign => campaign.status === activeTab);
      }
      
      // Apply filters from context
      if (filters) {
        // Nicho filter
        if (Array.isArray(filters.nicho) && filters.nicho.length > 0) {
          results = results.filter(campaign => 
            filters.nicho.some(nicho => campaign.nicho.includes(nicho))
          );
        }
        
        // Tipo de conteúdo filter
        if (Array.isArray(filters.tipoConteudo) && filters.tipoConteudo.length > 0) {
          results = results.filter(campaign => 
            filters.tipoConteudo.some(tipo => campaign.tipoConteudo.includes(tipo))
          );
        }
        
        // Localização filter
        if (Array.isArray(filters.localizacao) && filters.localizacao.length > 0) {
          results = results.filter(campaign => 
            filters.localizacao.some(local => campaign.localizacao.includes(local))
          );
        }
        
        // Valor mínimo filter
        if (typeof filters.valorMinimo === 'number' && filters.valorMinimo > 0) {
          results = results.filter(campaign => campaign.valorMinimo >= filters.valorMinimo);
        }
        
        // Prazo máximo filter
        if (filters.prazoMaximo) {
          results = results.filter(campaign => campaign.prazoMaximo === filters.prazoMaximo);
        }
      }
      
      setFilteredCampaigns(results);
      setIsLoading(false);
    }, 500);
  }, [debouncedSearchTerm, filters, activeTab]);

  const handleViewCampaign = (campaignId: string) => {
    const campaign = mockCampaigns.find(c => c.id === campaignId);
    if (campaign) {
      setSelectedCampaign(campaign);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  if (selectedCampaign) {
    return (
      <div className="container mx-auto py-6 px-4 md:px-6 space-y-6">
        <CampaignDetailView 
          campaign={selectedCampaign}
          onBack={() => setSelectedCampaign(null)}
        />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 px-4 md:px-6 space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Campanhas Disponíveis</h1>
        <p className="text-gray-500">Encontre oportunidades de parcerias com marcas.</p>
      </header>

      <Card>
        <CardHeader className="border-b pb-3">
          <CardTitle className="flex items-center text-lg font-medium">
            <FileText className="mr-2 h-5 w-5 text-brand-primary" />
            Campanhas
            <span className="ml-2 text-sm text-gray-500">({filteredCampaigns.length})</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Buscar campanhas por título, descrição ou empresa..."
                className="pl-10 border-2 border-gray-300 focus:border-[#99c00d] focus:ring-2 focus:ring-[#99c00d] text-gray-800"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                className="hidden md:flex gap-2 items-center border-2 border-gray-300 hover:border-gray-400"
                onClick={() => document.getElementById('filtersSection')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <Filter className="h-4 w-4" />
                <span>Filtros</span>
              </Button>
              
              <CampaignMobileFilter />
            </div>
          </div>

          <Tabs defaultValue="todas" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-4 bg-gray-100 p-1 justify-start w-full md:w-auto">
              <TabsTrigger value="todas" className="data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-brand-primary px-4">
                Todas
              </TabsTrigger>
              <TabsTrigger value="ativa" className="data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-brand-primary px-4">
                Ativas
              </TabsTrigger>
              <TabsTrigger value="pausada" className="data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-brand-primary px-4">
                Pausadas
              </TabsTrigger>
              <TabsTrigger value="encerrada" className="data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-brand-primary px-4">
                Encerradas
              </TabsTrigger>
            </TabsList>

            <ActiveFilterBadges filterConfig={campaignFilterConfig} className="mb-4" />
            
            <TabsContent value="todas" className="mt-0">
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="bg-white border border-gray-200 rounded-lg p-4 h-64 animate-pulse">
                      <div className="flex items-center space-x-4 mb-4">
                        <div className="h-12 w-12 bg-gray-300 rounded-full"></div>
                        <div className="space-y-2">
                          <div className="h-4 bg-gray-300 rounded w-32"></div>
                          <div className="h-3 bg-gray-200 rounded w-24"></div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                        <div className="h-3 bg-gray-200 rounded w-full"></div>
                        <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                      </div>
                      <div className="mt-6 flex gap-2">
                        <div className="h-6 bg-gray-300 rounded w-16"></div>
                        <div className="h-6 bg-gray-300 rounded w-16"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredCampaigns.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredCampaigns.map(campaign => (
                    <div key={campaign.id} onClick={() => handleViewCampaign(campaign.id)} className="cursor-pointer">
                      <CampaignCard campaign={campaign} />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-10">
                  <FileText className="mx-auto h-12 w-12 text-gray-300 mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">Nenhuma campanha encontrada</h3>
                  <p className="text-gray-500 mt-1">
                    Tente ajustar seus filtros ou faça uma nova busca.
                  </p>
                </div>
              )}
            </TabsContent>
            
            {/* The other tabs will show the same content based on the filter applied in the useEffect */}
            <TabsContent value="ativa" className="mt-0">
              {/* Content is filtered by the same component logic */}
            </TabsContent>
            <TabsContent value="pausada" className="mt-0">
              {/* Content is filtered by the same component logic */}
            </TabsContent>
            <TabsContent value="encerrada" className="mt-0">
              {/* Content is filtered by the same component logic */}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card id="filtersSection">
        <CardHeader className="border-b pb-3">
          <CardTitle className="text-lg font-medium">Filtros de Busca</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <CampaignFilters />
        </CardContent>
      </Card>
    </div>
  );
}

// Main CampaignSearch component that provides the filter context
export function CampaignSearch() {
  return (
    <FilterProvider>
      <CampaignSearchContent />
    </FilterProvider>
  );
}
