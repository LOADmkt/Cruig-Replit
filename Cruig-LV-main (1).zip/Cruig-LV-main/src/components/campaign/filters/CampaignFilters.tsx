import React from 'react';
import { FilterSection } from '@/components/filters/FilterSection';
import { MultiSelect } from '@/components/multi-select';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { DatePickerWithRange } from '@/components/ui/date-range-picker';
import { addDays } from 'date-fns';
import { useFilters } from '@/contexts/FilterContext';
import { campaignFilterConfig } from './CampaignFilterConfig';
import { Grid } from '@/components/ui/grid';
import { DateRange } from 'react-day-picker';
import { FilterOption } from '@/types/filters';
import { getMultiSelectOptions } from '@/lib/filterUtils';

export function CampaignFilters() {
  const { filters, setFilter } = useFilters();

  // Get filter config objects
  const nichoConfig = campaignFilterConfig.nicho;
  const tipoConteudoConfig = campaignFilterConfig.tipoConteudo;
  const localizacaoConfig = campaignFilterConfig.localizacao;
  const prazoMaximoConfig = campaignFilterConfig.prazoMaximo;
  const faixaEtariaConfig = campaignFilterConfig.faixaEtaria;
  const generoAlvoConfig = campaignFilterConfig.generoAlvo;
  const statusCampanhaConfig = campaignFilterConfig.statusCampanha;
  const minSeguidoresConfig = campaignFilterConfig.minSeguidores;
  
  // Get typed filter values with safety checks
  const nichoFilters = Array.isArray(filters.nicho) ? filters.nicho as string[] : [];
  const tipoConteudoFilters = Array.isArray(filters.tipoConteudo) ? filters.tipoConteudo as string[] : [];
  const localizacaoFilters = Array.isArray(filters.localizacao) ? filters.localizacao as string[] : [];
  const prazoMaximoValue = typeof filters.prazoMaximo === 'string' ? filters.prazoMaximo as string : '';
  const faixaEtariaFilters = Array.isArray(filters.faixaEtaria) ? filters.faixaEtaria as string[] : [];
  const generoAlvoValue = typeof filters.generoAlvo === 'string' ? filters.generoAlvo as string : '';
  const statusCampanhaValue = typeof filters.statusCampanha === 'string' ? filters.statusCampanha as string : '';
  const minSeguidoresValue = typeof filters.minSeguidores === 'string' ? filters.minSeguidores as string : '';
  const valorMinimoFilter = typeof filters.valorMinimo === 'number' ? filters.valorMinimo as number : 0;
  const dateRange = filters.dateRange as DateRange | undefined;

  return (
    <div className="space-y-6">
      <Grid className="gap-6" cols={1} sm={1} md={2} lg={3}>
        <FilterSection title="Nicho da campanha">
          <MultiSelect
            options={getMultiSelectOptions(nichoConfig?.options)}
            selected={nichoFilters}
            onChange={(value) => setFilter('nicho', value)}
            placeholder="Selecionar nichos..."
          />
        </FilterSection>
        
        <FilterSection title="Tipo de conteúdo">
          <MultiSelect
            options={getMultiSelectOptions(tipoConteudoConfig?.options)}
            selected={tipoConteudoFilters}
            onChange={(value) => setFilter('tipoConteudo', value)}
            placeholder="Selecionar tipos..."
          />
        </FilterSection>

        <FilterSection title="Valor mínimo">
          <div className="pt-5 px-2">
            <Slider 
              min={0} 
              max={10000} 
              step={100} 
              value={[valorMinimoFilter]} 
              onValueChange={(value) => setFilter('valorMinimo', value[0])}
              className="[&_[role=slider]]:bg-[#99c00d] [&_[role=slider]]:border-2 [&_[role=slider]]:border-white"
            />
            <div className="flex justify-between mt-1 text-sm text-gray-600">
              <span>R$ {valorMinimoFilter}</span>
              <span>R$ 10.000</span>
            </div>
          </div>
        </FilterSection>
        
        <FilterSection title="Localização">
          <MultiSelect
            options={getMultiSelectOptions(localizacaoConfig?.options)}
            selected={localizacaoFilters}
            onChange={(value) => setFilter('localizacao', value)}
            placeholder="Selecionar locais..."
          />
        </FilterSection>

        <FilterSection title="Prazo máximo">
          <Select 
            value={prazoMaximoValue} 
            onValueChange={(value) => setFilter('prazoMaximo', value)}
          >
            <SelectTrigger className="border-2 border-gray-300 focus:border-[#99c00d] focus:ring-2 focus:ring-[#99c00d] text-gray-800">
              <SelectValue placeholder="Selecione o prazo" />
            </SelectTrigger>
            <SelectContent className="bg-white text-gray-800">
              {prazoMaximoConfig?.options && prazoMaximoConfig.options.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </FilterSection>
        
        <FilterSection title="Faixa etária do público">
          <MultiSelect
            options={getMultiSelectOptions(faixaEtariaConfig?.options)}
            selected={faixaEtariaFilters}
            onChange={(value) => setFilter('faixaEtaria', value)}
            placeholder="Selecionar faixas..."
          />
        </FilterSection>
        
        <FilterSection title="Gênero alvo">
          <Select 
            value={generoAlvoValue} 
            onValueChange={(value) => setFilter('generoAlvo', value)}
          >
            <SelectTrigger className="border-2 border-gray-300 focus:border-[#99c00d] focus:ring-2 focus:ring-[#99c00d] text-gray-800">
              <SelectValue placeholder="Selecione o gênero" />
            </SelectTrigger>
            <SelectContent className="bg-white text-gray-800">
              {generoAlvoConfig?.options && generoAlvoConfig.options.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </FilterSection>
        
        <FilterSection title="Status da campanha">
          <Select 
            value={statusCampanhaValue} 
            onValueChange={(value) => setFilter('statusCampanha', value)}
          >
            <SelectTrigger className="border-2 border-gray-300 focus:border-[#99c00d] focus:ring-2 focus:ring-[#99c00d] text-gray-800">
              <SelectValue placeholder="Selecione o status" />
            </SelectTrigger>
            <SelectContent className="bg-white text-gray-800">
              {statusCampanhaConfig?.options && statusCampanhaConfig.options.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </FilterSection>
        
        <FilterSection title="Mínimo de seguidores">
          <Select 
            value={minSeguidoresValue} 
            onValueChange={(value) => setFilter('minSeguidores', value)}
          >
            <SelectTrigger className="border-2 border-gray-300 focus:border-[#99c00d] focus:ring-2 focus:ring-[#99c00d] text-gray-800">
              <SelectValue placeholder="Selecione o mínimo" />
            </SelectTrigger>
            <SelectContent className="bg-white text-gray-800">
              {minSeguidoresConfig?.options && minSeguidoresConfig.options.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </FilterSection>
        
        <FilterSection title="Período">
          <DatePickerWithRange 
            date={dateRange} 
            onSelect={(range) => setFilter('dateRange', range)} 
            initialDateFrom={addDays(new Date(), 0)}
            initialDateTo={addDays(new Date(), 7)}
          />
        </FilterSection>
      </Grid>
    </div>
  );
}
