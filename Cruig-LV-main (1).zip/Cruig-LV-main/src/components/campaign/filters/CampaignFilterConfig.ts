
import { FilterConfig } from '@/types/filters';

// Creating a campaign filter configuration that matches the format expected by ActiveFilterBadges
export const campaignFilterConfig: Record<string, FilterConfig> = {
  nicho: {
    field: 'nicho',
    label: 'Nicho',
    type: 'multi-select',
    options: [
      { value: 'moda', label: 'Moda' },
      { value: 'beleza', label: 'Beleza' },
      { value: 'lifestyle', label: 'Lifestyle' },
      { value: 'viagem', label: 'Viagem' },
      { value: 'gastronomia', label: 'Gastronomia' },
      { value: 'fitness', label: 'Fitness' },
      { value: 'tecnologia', label: 'Tecnologia' },
      { value: 'games', label: 'Games' },
      { value: 'esportes', label: 'Esportes' },
      { value: 'educacao', label: 'Educação' },
      { value: 'negocios', label: 'Negócios' },
      { value: 'sustentabilidade', label: 'Sustentabilidade' }
    ],
    defaultValue: [],
    clearable: true
  },
  tipoConteudo: {
    field: 'tipoConteudo',
    label: 'Tipo de Conteúdo',
    type: 'multi-select',
    options: [
      { value: 'foto', label: 'Fotos' },
      { value: 'video', label: 'Vídeos' },
      { value: 'reels', label: 'Reels/Shorts' },
      { value: 'texto', label: 'Texto/Blog' },
      { value: 'audio', label: 'Áudio/Podcast' },
      { value: 'live', label: 'Lives' }
    ],
    defaultValue: [],
    clearable: true
  },
  valorMinimo: {
    field: 'valorMinimo',
    label: 'Valor Mínimo',
    type: 'number',
    defaultValue: 0,
    clearable: true,
    formatter: (value: number) => `R$ ${value}`
  },
  localizacao: {
    field: 'localizacao',
    label: 'Localização',
    type: 'multi-select',
    options: [
      { value: 'sp', label: 'São Paulo' },
      { value: 'rj', label: 'Rio de Janeiro' },
      { value: 'mg', label: 'Minas Gerais' },
      { value: 'ba', label: 'Bahia' },
      { value: 'pr', label: 'Paraná' },
      { value: 'rs', label: 'Rio Grande do Sul' },
      { value: 'pe', label: 'Pernambuco' },
      { value: 'ce', label: 'Ceará' },
      { value: 'df', label: 'Distrito Federal' },
      { value: 'go', label: 'Goiás' },
      { value: 'sc', label: 'Santa Catarina' },
      { value: 'pa', label: 'Pará' },
    ],
    defaultValue: [],
    clearable: true
  },
  prazoMaximo: {
    field: 'prazoMaximo',
    label: 'Prazo Máximo',
    type: 'select',
    options: [
      { value: '7d', label: '7 dias' },
      { value: '15d', label: '15 dias' },
      { value: '30d', label: '30 dias' },
      { value: '60d', label: '60 dias' },
      { value: '90d', label: '90 dias' },
      { value: '180d', label: '6 meses' }
    ],
    defaultValue: '',
    clearable: true
  },
  faixaEtaria: {
    field: 'faixaEtaria',
    label: 'Faixa Etária do Público',
    type: 'multi-select',
    options: [
      { value: '13-17', label: '13 a 17 anos' },
      { value: '18-24', label: '18 a 24 anos' },
      { value: '25-34', label: '25 a 34 anos' },
      { value: '35-44', label: '35 a 44 anos' },
      { value: '45-54', label: '45 a 54 anos' },
      { value: '55+', label: 'Acima de 55 anos' }
    ],
    defaultValue: [],
    clearable: true
  },
  generoAlvo: {
    field: 'generoAlvo',
    label: 'Gênero Alvo',
    type: 'select',
    options: [
      { value: 'feminino', label: 'Feminino' },
      { value: 'masculino', label: 'Masculino' },
      { value: 'todos', label: 'Todos' }
    ],
    defaultValue: '',
    clearable: true
  },
  statusCampanha: {
    field: 'statusCampanha',
    label: 'Status da Campanha',
    type: 'select',
    options: [
      { value: 'ativa', label: 'Ativa' },
      { value: 'pausada', label: 'Pausada' },
      { value: 'encerrada', label: 'Encerrada' },
      { value: 'rascunho', label: 'Rascunho' }
    ],
    defaultValue: '',
    clearable: true
  },
  minSeguidores: {
    field: 'minSeguidores',
    label: 'Mínimo de Seguidores',
    type: 'select',
    options: [
      { value: '0', label: 'Sem mínimo' },
      { value: '5k', label: 'Pelo menos 5 mil' },
      { value: '10k', label: 'Pelo menos 10 mil' },
      { value: '25k', label: 'Pelo menos 25 mil' },
      { value: '50k', label: 'Pelo menos 50 mil' },
      { value: '100k', label: 'Pelo menos 100 mil' },
      { value: '500k', label: 'Pelo menos 500 mil' }
    ],
    defaultValue: '',
    clearable: true
  },
  dateRange: {
    field: 'dateRange',
    label: 'Período',
    type: 'dateRange',
    defaultValue: null,
    clearable: true
  }
};

// For backward compatibility, also export as array
export const campaignFilterConfigArray = Object.entries(campaignFilterConfig).map(
  ([field, config]) => ({
    ...config,
    field
  })
);
