
import React, { ReactNode, useEffect } from 'react';
import { AuthContext } from '@/contexts/AuthContext';
import { useAuthState } from '@/hooks/useAuthState';
import { useAuthOperations } from '@/hooks/useAuthOperations';
import { usePasswordManagement } from '@/hooks/usePasswordManagement';
import { useSessionManagement } from '@/hooks/useSessionManagement';
import { AuthContextType } from '@/types/auth';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabaseClient';

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const { toast } = useToast();
  
  // Utilizando os hooks criados
  const {
    user,
    session,
    isLoading: stateLoading,
    isAuthenticated,
    isAdmin,
    isCreator,
    isCompany,
    handleSessionUpdate,
    clearAuthState
  } = useAuthState();

  const {
    signIn,
    signUp,
    signOut,
    isLoading: operationsLoading,
  } = useAuthOperations();

  const {
    resetPassword,
    updatePassword,
    isLoading: passwordLoading,
  } = usePasswordManagement();

  const {
    refreshSession,
    updateUserData,
    isLoading: sessionLoading,
  } = useSessionManagement();

  // Debug para verificar o estado de autenticação
  useEffect(() => {
    if (isAuthenticated) {
      console.info('Usuário autenticado:', user?.email);
      console.info('Tipo de usuário:', user?.user_metadata?.userType);
    } else if (!stateLoading) {
      console.info('Usuário não autenticado');
    }
  }, [isAuthenticated, user, stateLoading]);

  // Verificar e atualizar a sessão periodicamente
  useEffect(() => {
    if (!isAuthenticated) return;

    const checkSession = async () => {
      try {
        const { data } = await supabase.auth.getSession();
        if (!data.session) {
          console.warn('Sessão expirada, realizando logout');
          clearAuthState();
          toast({
            title: "Sessão expirada",
            description: "Sua sessão expirou. Por favor, faça login novamente.",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error('Erro ao verificar sessão:', error);
      }
    };

    // Verificar a cada 5 minutos
    const interval = setInterval(checkSession, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [isAuthenticated, clearAuthState, toast]);

  // Combinar o estado de carregamento de todos os hooks
  const isLoading = stateLoading || operationsLoading || passwordLoading || sessionLoading;

  // Context value
  const authContextValue: AuthContextType = {
    user,
    session,
    isLoading,
    isAuthenticated,
    isAdmin,
    isCreator,
    isCompany,
    signIn,
    signUp,
    signOut,
    resetPassword,
    updatePassword,
    updateUserData,
    refreshSession
  };
  
  return (
    <AuthContext.Provider value={authContextValue}>
      {children}
    </AuthContext.Provider>
  );
};
