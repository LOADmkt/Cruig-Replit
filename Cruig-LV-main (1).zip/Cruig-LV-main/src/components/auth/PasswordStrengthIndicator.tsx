
import React from 'react';

interface PasswordStrengthIndicatorProps {
  password: string;
}

export const PasswordStrengthIndicator: React.FC<PasswordStrengthIndicatorProps> = ({ password }) => {
  // Calcular a força da senha baseado no seu comprimento e complexidade
  const getStrength = () => {
    if (!password) return 0;
    
    let strength = 0;
    
    // Comprimento
    if (password.length >= 8) strength += 1;
    if (password.length >= 12) strength += 1;
    
    // Números
    if (/\d/.test(password)) strength += 1;
    
    // Letras maiúsculas e minúsculas
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength += 1;
    
    // Caracteres especiais
    if (/[^a-zA-Z0-9]/.test(password)) strength += 1;
    
    return Math.min(strength, 4);
  };
  
  const strength = getStrength();
  
  // Definir as classes CSS baseadas na força da senha
  const getSegmentClasses = (segmentIndex: number) => {
    if (!password) {
      return "h-2 w-full bg-gray-200";
    }
    
    const baseClasses = "h-2 w-full transition-colors duration-300";
    
    if (segmentIndex < strength) {
      if (strength === 1) return `${baseClasses} bg-red-500`;
      if (strength === 2) return `${baseClasses} bg-orange-400`;
      if (strength === 3) return `${baseClasses} bg-yellow-400`;
      if (strength === 4) return `${baseClasses} bg-green-500`;
    }
    
    return `${baseClasses} bg-gray-200`;
  };
  
  // Definir o texto de feedback
  const getFeedbackText = () => {
    if (!password) return "Digite uma senha";
    
    if (strength === 1) return "Muito fraca";
    if (strength === 2) return "Fraca";
    if (strength === 3) return "Média";
    if (strength === 4) return "Forte";
    
    return "";
  };
  
  // Definir a cor do texto de feedback
  const getFeedbackTextColor = () => {
    if (!password) return "text-gray-500";
    
    if (strength === 1) return "text-red-500";
    if (strength === 2) return "text-orange-400";
    if (strength === 3) return "text-yellow-500";
    if (strength === 4) return "text-green-500";
    
    return "text-gray-500";
  };

  return (
    <div className="space-y-1">
      <div className="flex gap-1">
        <div className={getSegmentClasses(0)} />
        <div className={getSegmentClasses(1)} />
        <div className={getSegmentClasses(2)} />
        <div className={getSegmentClasses(3)} />
      </div>
      <p className={`text-xs ${getFeedbackTextColor()}`}>
        {getFeedbackText()}
      </p>
    </div>
  );
};
