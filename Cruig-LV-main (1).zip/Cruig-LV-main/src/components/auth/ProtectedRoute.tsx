
import React, { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from "lucide-react";
import { checkSession } from '@/services/authService';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRole?: string;
  allowedUserType?: 'criador' | 'empresa' | 'admin';
  redirectTo?: string;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  allowedRole,
  allowedUserType,
  redirectTo = '/auth'
}) => {
  const location = useLocation();
  const { toast } = useToast();
  const [sessionChecked, setSessionChecked] = useState(false);
  const [hasShownToast, setHasShownToast] = useState(false);
  
  // Usar try/catch para garantir que erros no Auth não quebrem a aplicação
  let authContext;
  try {
    authContext = useAuth();
  } catch (error) {
    console.error("Erro ao usar contexto de autenticação:", error);
    return <Navigate to={redirectTo} state={{ from: location }} replace />;
  }
  
  const { isAuthenticated, user, isLoading, isAdmin, isCompany, isCreator } = authContext;

  // Verificar validade do token ao montar (uma única vez)
  useEffect(() => {
    if (isAuthenticated && !sessionChecked) {
      const verifySession = async () => {
        try {
          await checkSession();
        } catch (error) {
          console.error('Erro ao verificar sessão:', error);
        } finally {
          setSessionChecked(true);
        }
      };
      
      verifySession();
    } else if (!isAuthenticated) {
      setSessionChecked(true);
    }
  }, [isAuthenticated, sessionChecked]);

  // Exibir estado de carregamento
  if (isLoading || !sessionChecked) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="flex flex-col items-center">
          <Loader2 className="h-12 w-12 text-brand-primary animate-spin mb-4" />
          <p className="text-lg font-medium">Carregando...</p>
        </div>
      </div>
    );
  }

  // Verificar autenticação
  if (!isAuthenticated) {
    console.log("Não autenticado, redirecionando para:", redirectTo);
    return <Navigate to={redirectTo} state={{ from: location }} replace />;
  }

  // Verificar role se especificada (evitando manipulação do DOM direta)
  if (allowedRole && user?.user_metadata?.role !== allowedRole) {
    console.log("Role inválida, redirecionando para home");
    
    // Mostrar toast apenas uma vez para evitar loops
    if (!hasShownToast) {
      setHasShownToast(true);
      // Use setTimeout para evitar erros de renderização durante navegação
      setTimeout(() => {
        toast({
          title: "Acesso negado",
          description: `Você não tem permissão para acessar esta página.`,
          variant: "destructive",
        });
      }, 100);
    }
    
    return <Navigate to="/" replace />;
  }

  // Verificar userType se especificado
  if (allowedUserType) {
    let hasAccess = false;
    
    if (allowedUserType === 'admin' && isAdmin) {
      hasAccess = true;
    } else if (allowedUserType === 'empresa' && isCompany) {
      hasAccess = true;
    } else if (allowedUserType === 'criador' && isCreator) {
      hasAccess = true;
    }
    
    if (!hasAccess) {
      console.log(`Tipo de usuário inválido: esperado=${allowedUserType}, redirecionando para dashboard apropriado`);
      
      // Determine o redirect path
      let redirectPath = '/';
      if (isCompany) {
        redirectPath = '/dashboard/empresa';
      } else if (isAdmin) {
        redirectPath = '/dashboard/admin';
      } else if (isCreator) {
        redirectPath = '/dashboard/criador';
      }
      
      // Mostrar toast apenas uma vez
      if (!hasShownToast) {
        setHasShownToast(true);
        // Use setTimeout para evitar erros de renderização durante navegação
        setTimeout(() => {
          toast({
            title: "Acesso negado",
            description: `Esta página é exclusiva para ${allowedUserType === 'empresa' ? 'empresas' : allowedUserType === 'criador' ? 'criadores' : 'administradores'}.`,
            variant: "destructive",
          });
        }, 100);
      }
      
      return <Navigate to={redirectPath} replace />;
    }
  }

  // Se autenticado e tem a role/userType correto, mostrar o conteúdo protegido
  return <>{children}</>;
};
