import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { AlignRight, X } from 'lucide-react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { NotificationsPopover } from '@/components/notifications/NotificationsPopover';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  
  // Check if we're on the home page
  const isHomePage = location.pathname === "/";

  const handleLogin = () => {
    navigate('/auth');
  };

  const handleSignUp = () => {
    navigate('/auth?tab=cadastro');
  };
  
  const scrollToSection = (sectionId: string, event?: React.MouseEvent) => {
    if (event) {
      event.preventDefault();
    }
    
    // If not on home page, navigate to home page first
    if (!isHomePage) {
      navigate('/', { state: { scrollTo: sectionId } });
      return;
    }
    
    const section = document.getElementById(sectionId);
    if (section) {
      // Close mobile menu if it's open
      if (isMenuOpen) {
        setIsMenuOpen(false);
      }
      
      // Smooth scroll to the section
      section.scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
      });
    }
  };
  
  // Handle scrolling when navigating back to home page
  useEffect(() => {
    if (isHomePage && location.state && location.state.scrollTo) {
      const sectionId = location.state.scrollTo;
      setTimeout(() => {
        scrollToSection(sectionId);
      }, 100);
      
      // Clear the state
      window.history.replaceState({}, document.title);
    }
  }, [isHomePage, location.state]);

  return (
    <nav className="bg-white shadow-md py-4 sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex-shrink-0">
            <Link to="/" className="flex items-center">
              <img 
                src="/lovable-uploads/ee626d52-bec1-43dd-9884-b6016b098e04.png" 
                alt="Cruig" 
                className="h-10 sm:h-12"
              />
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              to="/" 
              className="text-gray-800 hover:text-brand-primary font-medium transition-colors"
            >
              Início
            </Link>
            <a 
              href="#recursos" 
              onClick={(e) => scrollToSection('recursos', e)}
              className="text-gray-800 hover:text-brand-primary font-medium transition-colors"
            >
              Recursos
            </a>
            <a 
              href="#planos" 
              onClick={(e) => scrollToSection('planos', e)}
              className="text-gray-800 hover:text-brand-primary font-medium transition-colors"
            >
              Planos
            </a>
            <NotificationsPopover />
            <Button 
              variant="brand-outline" 
              className="shadow-sm hover:shadow-md transition-all"
              onClick={handleLogin}
            >
              Entrar
            </Button>
            <Button 
              variant="brand"
              className="shadow-md hover:shadow-lg transition-all"
              onClick={handleSignUp}
            >
              Cadastre-se
            </Button>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-800 hover:text-brand-primary hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-brand-primary"
            >
              <span className="sr-only">Abrir menu</span>
              {isMenuOpen ? <X className="block h-6 w-6" /> : <AlignRight className="block h-6 w-6" />}
            </button>
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 py-2 border-t border-gray-200">
            <div className="flex flex-col space-y-3 px-2 pt-2 pb-3">
              <Link to="/" className="text-gray-800 hover:text-brand-primary font-medium transition-colors px-3 py-2 rounded-md hover:bg-gray-50">
                Início
              </Link>
              <a 
                href="#recursos" 
                onClick={(e) => scrollToSection('recursos', e)}
                className="text-gray-800 hover:text-brand-primary font-medium transition-colors px-3 py-2 rounded-md hover:bg-gray-50"
              >
                Recursos
              </a>
              <a 
                href="#planos" 
                onClick={(e) => scrollToSection('planos', e)}
                className="text-gray-800 hover:text-brand-primary font-medium transition-colors px-3 py-2 rounded-md hover:bg-gray-50"
              >
                Planos
              </a>
              <Button 
                variant="brand-outline" 
                className="w-full justify-center font-medium"
                onClick={handleLogin}
              >
                Entrar
              </Button>
              <Button 
                variant="brand" 
                className="w-full justify-center font-medium"
                onClick={handleSignUp}
              >
                Cadastre-se
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
