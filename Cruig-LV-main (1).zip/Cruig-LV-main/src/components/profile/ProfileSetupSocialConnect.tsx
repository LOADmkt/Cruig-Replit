
import React, { useState, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { SocialConnection } from "@/components/social/SocialConnection";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { MultiSelect } from "@/components/ui/multi-select";
import { Check } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface ProfileSetupSocialConnectProps {
  onNext: () => void;
  onBack: () => void;
}

// Mock data for dropdowns
const nichos = [
  { value: "moda", label: "Moda" },
  { value: "beleza", label: "Beleza" },
  { value: "lifestyle", label: "Lifestyle" },
  { value: "tecnologia", label: "Tecnologia" },
  { value: "games", label: "Games" },
  { value: "fitness", label: "Fitness" },
  { value: "culinaria", label: "Culinária" },
  { value: "viagem", label: "Viagem" },
  { value: "financas", label: "Finanças" },
  { value: "educacao", label: "Educação" },
  { value: "humor", label: "Humor" },
  { value: "saude", label: "Saúde" }
];

const cidades = [
  { value: "sao-paulo", label: "São Paulo" },
  { value: "rio-de-janeiro", label: "Rio de Janeiro" },
  { value: "belo-horizonte", label: "Belo Horizonte" },
  { value: "brasilia", label: "Brasília" },
  { value: "curitiba", label: "Curitiba" },
  { value: "salvador", label: "Salvador" },
  { value: "recife", label: "Recife" },
  { value: "fortaleza", label: "Fortaleza" },
  { value: "porto-alegre", label: "Porto Alegre" }
];

export function ProfileSetupSocialConnect({ onNext, onBack }: ProfileSetupSocialConnectProps) {
  const [selectedNicho, setSelectedNicho] = useState("");
  const [selectedCidades, setSelectedCidades] = useState<string[]>([]);
  const [selectedSecondaryNichos, setSelectedSecondaryNichos] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Handle nicho toggle with visual feedback
  const handleNichoToggle = useCallback((value: string) => {
    setSelectedSecondaryNichos(prev => {
      if (prev.includes(value)) {
        return prev.filter(n => n !== value);
      } else {
        return [...prev, value];
      }
    });
  }, []);

  // Form validation and submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Validate required fields
    if (!selectedNicho) {
      toast({
        title: "Campo obrigatório",
        description: "Por favor, selecione um nicho principal",
        variant: "destructive"
      });
      setIsSubmitting(false);
      return;
    }

    if (selectedCidades.length === 0) {
      toast({
        title: "Campo obrigatório",
        description: "Por favor, selecione pelo menos uma cidade",
        variant: "destructive"
      });
      setIsSubmitting(false);
      return;
    }

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Success feedback
      toast({
        title: "Perfil atualizado",
        description: "Suas informações foram salvas com sucesso",
      });
      
      // Process form data here
      onNext();
    } catch (error) {
      toast({
        title: "Erro ao salvar",
        description: "Ocorreu um erro ao salvar suas informações",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>Complete seu perfil</CardTitle>
          <CardDescription>
            Preencha as informações abaixo para personalizar sua experiência
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Cidade field */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Sua cidade</label>
              <MultiSelect
                options={cidades}
                selected={selectedCidades}
                onChange={setSelectedCidades}
                placeholder="Selecione suas cidades"
                className="w-full"
              />
              {selectedCidades.length === 0 && (
                <p className="text-xs text-gray-500">Selecione pelo menos uma cidade</p>
              )}
            </div>

            {/* Nicho principal field */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Nicho principal</label>
              <Select value={selectedNicho} onValueChange={setSelectedNicho}>
                <SelectTrigger className="w-full border-2 border-gray-300">
                  <SelectValue placeholder="Selecione seu nicho principal" />
                </SelectTrigger>
                <SelectContent className="bg-white border border-gray-200 shadow-md">
                  {nichos.map((nicho) => (
                    <SelectItem key={nicho.value} value={nicho.value}>
                      {nicho.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {!selectedNicho && (
                <p className="text-xs text-gray-500">O nicho principal é obrigatório</p>
              )}
            </div>

            {/* Nichos secundários field */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Nichos secundários (opcional)</label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {nichos.map((nicho) => (
                  <div 
                    key={nicho.value}
                    className={`flex items-center gap-2 border rounded-md px-3 py-2 cursor-pointer transition-colors ${
                      selectedSecondaryNichos.includes(nicho.value) 
                        ? 'border-[#99c00d] bg-[#99c00d]/10' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                    onClick={() => handleNichoToggle(nicho.value)}
                  >
                    <div className={`w-5 h-5 flex-shrink-0 rounded-full border transition-colors ${
                      selectedSecondaryNichos.includes(nicho.value) 
                        ? 'border-[#99c00d] bg-[#99c00d]' 
                        : 'border-gray-300'
                    } flex items-center justify-center`}>
                      {selectedSecondaryNichos.includes(nicho.value) && (
                        <Check className="h-3 w-3 text-white" />
                      )}
                    </div>
                    <span>{nicho.label}</span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Social Connections */}
            <div className="space-y-4 pt-6 border-t border-gray-200">
              <h3 className="text-lg font-medium">Conecte suas redes sociais</h3>
              <p className="text-sm text-gray-500">
                Conecte suas contas para importar métricas e aumentar suas chances de parcerias
              </p>
              <SocialConnection />
            </div>
            
            <div className="flex justify-between mt-8">
              <Button 
                type="button"
                variant="outline" 
                onClick={onBack} 
                disabled={isSubmitting}
                className="border-2 border-gray-300"
              >
                Voltar
              </Button>
              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="bg-[#99c00d] hover:bg-[#99c00d]/90 text-white"
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Salvando...
                  </>
                ) : (
                  'Continuar'
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
      
      <div className="text-center text-sm text-gray-500">
        <p>Você pode pular esta etapa e conectar suas redes sociais mais tarde.</p>
      </div>
    </div>
  );
}
