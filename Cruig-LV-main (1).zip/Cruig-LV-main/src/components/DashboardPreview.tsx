import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { ArrowUpRight, Users, BarChart3, PieChart as PieChartIcon } from 'lucide-react';
const growthData = [{
  name: 'Jan',
  valor: 4000
}, {
  name: 'Fev',
  valor: 4600
}, {
  name: 'Mar',
  valor: 5400
}, {
  name: 'Abr',
  valor: 5800
}, {
  name: 'Mai',
  valor: 6800
}, {
  name: 'Jun',
  valor: 7600
}];
const engagementData = [{
  name: 'Instagram',
  valor: 65
}, {
  name: 'TikTok',
  valor: 75
}, {
  name: 'YouTube',
  valor: 42
}, {
  name: 'Twitter',
  valor: 35
}, {
  name: 'Facebook',
  valor: 28
}];
const marketDistribution = [{
  name: 'Moda',
  value: 35
}, {
  name: 'Tecnologia',
  value: 25
}, {
  name: 'Alimentação',
  value: 20
}, {
  name: 'Esportes',
  value: 15
}, {
  name: 'Outros',
  value: 5
}];
const COLORS = ['#99c00d', '#333333', '#ffeee2', '#6A5797', '#c2d5a0'];
interface ChartCardProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  delay: number;
}
const ChartCard = ({
  title,
  icon,
  children,
  delay
}: ChartCardProps) => {
  return <motion.div initial={{
    opacity: 0,
    y: 20
  }} animate={{
    opacity: 1,
    y: 0
  }} transition={{
    duration: 0.5,
    delay
  }} className="flex-1 min-w-[280px] bg-white rounded-xl overflow-hidden shadow-lg border border-gray-100">
      <div className="p-4 border-b border-gray-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {icon}
          <h3 className="font-semibold text-gray-800">{title}</h3>
        </div>
        <ArrowUpRight className="text-brand-primary h-4 w-4" />
      </div>
      <div className="p-4 h-[220px]">
        {children}
      </div>
    </motion.div>;
};
const DashboardPreview = () => {
  return <div className="py-16 bg-gray-50 md:py-[26px]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Visualize Dados e Cresça com Nossas Ferramentas</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Dashboards intuitivos que oferecem insights valiosos para 
            otimizar suas campanhas e maximizar os resultados da sua marca.
          </p>
        </div>
        
        <div className="flex flex-wrap gap-6 justify-center">
          <ChartCard title="Crescimento de Mercado" icon={<LineChart className="h-5 w-5 text-brand-primary" />} delay={0.1}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={growthData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" stroke="#888" fontSize={12} />
                <YAxis stroke="#888" fontSize={12} />
                <Tooltip />
                <Line type="monotone" dataKey="valor" stroke="#99c00d" strokeWidth={2} dot={{
                r: 4,
                strokeWidth: 2
              }} activeDot={{
                r: 6
              }} />
              </LineChart>
            </ResponsiveContainer>
          </ChartCard>
          
          <ChartCard title="Engajamento por Plataforma" icon={<BarChart3 className="h-5 w-5 text-brand-primary" />} delay={0.2}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" stroke="#888" fontSize={12} />
                <YAxis stroke="#888" fontSize={12} />
                <Tooltip />
                <Bar dataKey="valor" fill="#99c00d" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
          
          <ChartCard title="Distribuição de Mercado" icon={<PieChartIcon className="h-5 w-5 text-brand-primary" />} delay={0.3}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={marketDistribution} cx="50%" cy="50%" innerRadius={50} outerRadius={80} fill="#8884d8" dataKey="value" label={({
                name,
                percent
              }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                  {marketDistribution.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>
        
        <div className="mt-12 text-center">
          <a href="/auth" className="inline-flex items-center gap-2 px-6 py-3 bg-white text-brand-primary border-2 border-brand-primary rounded-lg font-medium hover:bg-brand-primary hover:text-white transition-all">
            Acesse os dashboards completos
            <ArrowUpRight className="h-5 w-5" />
          </a>
        </div>
      </div>
    </div>;
};
export default DashboardPreview;