
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { WithdrawalRequestModal } from './WithdrawalRequestModal';
import { Skeleton } from '@/components/ui/skeleton';
import { Link, Copy, CheckCircle, AlertCircle, TrendingUp } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { formatPrice } from '@/lib/subscriptionPlans';
import { useAuth } from '@/hooks/useAuth';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export function CreatorAffiliatePanel() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [copied, setCopied] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Mock data - in a real application, this would come from an API
  const affiliateData = {
    balance: 427.50,
    pendingBalance: 350.00,
    totalEarned: 1275.00,
    conversionRate: 12.4,
    clickCount: 432,
    signupCount: 54,
    referralCode: 'CREATOR123',
    referralLink: `https://creatormatch.com.br/ref/${user?.id || 'CREATOR123'}`,
    recentTransactions: [
      { id: 1, date: '12/04/2023', amount: 125.00, status: 'completed', type: 'commission' },
      { id: 2, date: '05/04/2023', amount: 175.00, status: 'completed', type: 'commission' },
      { id: 3, date: '28/03/2023', amount: 150.00, status: 'completed', type: 'bonus' }
    ]
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(affiliateData.referralLink)
      .then(() => {
        setCopied(true);
        toast({
          title: "Link copiado!",
          description: "Link de afiliado copiado para a área de transferência.",
        });
        setTimeout(() => setCopied(false), 3000);
      })
      .catch(() => {
        toast({
          title: "Erro ao copiar",
          description: "Não foi possível copiar o link para a área de transferência.",
          variant: "destructive",
        });
      });
  };

  const handleWithdrawal = async (amount: number, pixKey: string) => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsLoading(false);
    setIsModalOpen(false);
    
    toast({
      title: "Solicitação enviada",
      description: `Solicitação de saque de ${formatPrice(amount)} enviada com sucesso.`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-6">
        <Card className="flex-1">
          <CardHeader>
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <Link className="h-5 w-5 text-[#99c00d]" />
              Seu Link de Afiliado
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3 mt-2">
              <Input
                value={affiliateData.referralLink}
                readOnly
                className="flex-1 bg-gray-50"
              />
              <Button
                variant="outline"
                size="icon"
                className="flex-shrink-0 border-2 border-gray-300 hover:bg-gray-100"
                onClick={copyToClipboard}
              >
                {copied ? <CheckCircle className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
            <p className="text-sm text-gray-500 mt-4">
              Compartilhe este link com outros criadores e ganhe R$ 30,00 para cada assinante que se cadastrar através dele.
            </p>
          </CardContent>
        </Card>

        <Card className="flex-1 border-[#99c00d]/20 bg-[#99c00d]/5">
          <CardHeader>
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-[#99c00d]" />
              Seu Saldo de Afiliado
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2">
              <div>
                <span className="text-gray-600 text-sm">Saldo disponível:</span>
                <p className="text-2xl font-bold text-[#99c00d]">{formatPrice(affiliateData.balance)}</p>
              </div>
              <div>
                <span className="text-gray-600 text-sm">Saldo pendente:</span>
                <p className="text-lg font-medium text-gray-700">{formatPrice(affiliateData.pendingBalance)}</p>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full bg-[#99c00d] hover:bg-[#84a80c] text-white" 
              disabled={affiliateData.balance < 30}
              onClick={() => setIsModalOpen(true)}
            >
              Solicitar Saque
            </Button>
          </CardFooter>
        </Card>
      </div>

      {isModalOpen && (
        <WithdrawalRequestModal
          open={isModalOpen}
          onOpenChange={setIsModalOpen}
          onConfirm={handleWithdrawal}
          availableBalance={affiliateData.balance}
          isLoading={isLoading}
        />
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold">Indicações</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Criador</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {affiliateData.recentTransactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell className="font-medium">{transaction.type}</TableCell>
                    <TableCell>{new Date(transaction.date).toLocaleDateString('pt-BR')}</TableCell>
                    <TableCell className="flex items-center gap-1">
                      {transaction.status === 'completed' ? (
                        <>
                          <CheckCircle className="h-4 w-4 text-green-600" />
                          <span className="text-green-600">Concluído</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="h-4 w-4 text-amber-600" />
                          <span className="text-amber-600">Pendente</span>
                        </>
                      )}
                    </TableCell>
                    <TableCell className="text-right">{formatPrice(transaction.amount)}</TableCell>
                  </TableRow>
                ))}
                {affiliateData.recentTransactions.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-4 text-gray-500">
                      Você ainda não tem indicações ativas
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold">Estatísticas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-500 text-sm">Cliques no link</p>
              <p className="text-2xl font-bold">{affiliateData.clickCount}</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-500 text-sm">Conversões</p>
              <p className="text-2xl font-bold">{affiliateData.signupCount}</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-500 text-sm">Taxa de conversão</p>
              <p className="text-2xl font-bold">{affiliateData.conversionRate}%</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold">Histórico de Saques</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {affiliateData.recentTransactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell>{new Date(transaction.date).toLocaleDateString('pt-BR')}</TableCell>
                    <TableCell className="text-right">{formatPrice(transaction.amount)}</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        Concluído
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
                {affiliateData.recentTransactions.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center py-4 text-gray-500">
                      Nenhum saque realizado até o momento
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
