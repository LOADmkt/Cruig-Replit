
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

interface WithdrawalRequestModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: (amount: number, pixKey: string) => void;
  availableBalance: number;
  isLoading?: boolean;
}

export function WithdrawalRequestModal({ open, onOpenChange, onConfirm, availableBalance, isLoading = false }: WithdrawalRequestModalProps) {
  const { toast } = useToast();
  const [amount, setAmount] = useState('');
  const [pixKey, setPixKey] = useState('');
  const [pixType, setPixType] = useState('cpf');
  const [localLoading, setLocalLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const amountValue = parseFloat(amount.replace(',', '.'));
    
    if (isNaN(amountValue) || amountValue <= 0) {
      toast({
        title: "Valor inválido",
        description: "Por favor, insira um valor válido.",
        variant: "destructive",
      });
      return;
    }
    
    if (amountValue < 100) {
      toast({
        title: "Valor mínimo não atingido",
        description: "O valor mínimo para saque é R$ 100,00.",
        variant: "destructive",
      });
      return;
    }
    
    if (amountValue > availableBalance) {
      toast({
        title: "Saldo insuficiente",
        description: "O valor solicitado é maior que seu saldo disponível.",
        variant: "destructive",
      });
      return;
    }
    
    if (!pixKey.trim()) {
      toast({
        title: "Chave PIX obrigatória",
        description: "Por favor, insira sua chave PIX para recebimento.",
        variant: "destructive",
      });
      return;
    }
    
    setLocalLoading(true);
    
    try {
      await onConfirm(amountValue, pixKey);
      resetForm();
    } catch (error) {
      console.error("Erro ao confirmar saque:", error);
    } finally {
      setLocalLoading(false);
    }
  };
  
  const resetForm = () => {
    setAmount('');
    setPixKey('');
    setPixType('cpf');
  };

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Permitir apenas números e vírgula/ponto
    if (/^[\d.,]*$/.test(value)) {
      setAmount(value);
    }
  };

  const effectiveLoading = isLoading || localLoading;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Solicitar Saque</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="amount">Valor a sacar</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">R$</span>
              <Input
                id="amount"
                value={amount}
                onChange={handleAmountChange}
                placeholder="0,00"
                className="pl-9"
                required
              />
            </div>
            <p className="text-xs text-gray-500">
              Saldo disponível: R$ {availableBalance.toFixed(2)} • Valor mínimo: R$ 100,00
            </p>
          </div>
          
          <div className="space-y-2">
            <Label>Tipo de chave PIX</Label>
            <div className="flex gap-2">
              <Button
                type="button"
                variant={pixType === 'cpf' ? "default" : "outline"}
                className={pixType === 'cpf' ? "bg-[#99c00d] hover:bg-[#88aa0b]" : ""}
                onClick={() => setPixType('cpf')}
              >
                CPF
              </Button>
              <Button
                type="button"
                variant={pixType === 'email' ? "default" : "outline"}
                className={pixType === 'email' ? "bg-[#99c00d] hover:bg-[#88aa0b]" : ""}
                onClick={() => setPixType('email')}
              >
                E-mail
              </Button>
              <Button
                type="button"
                variant={pixType === 'telefone' ? "default" : "outline"}
                className={pixType === 'telefone' ? "bg-[#99c00d] hover:bg-[#88aa0b]" : ""}
                onClick={() => setPixType('telefone')}
              >
                Telefone
              </Button>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="pixKey">Chave PIX para recebimento</Label>
            <Input
              id="pixKey"
              value={pixKey}
              onChange={(e) => setPixKey(e.target.value)}
              placeholder={
                pixType === 'cpf' ? '123.456.789-10' : 
                pixType === 'email' ? 'seu@email.com' : 
                '(11) 98765-4321'
              }
              required
            />
          </div>
          
          <DialogFooter className="pt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={effectiveLoading}
            >
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="bg-[#99c00d] hover:bg-[#88aa0b]"
              disabled={effectiveLoading}
            >
              {effectiveLoading ? "Processando..." : "Confirmar Saque"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
