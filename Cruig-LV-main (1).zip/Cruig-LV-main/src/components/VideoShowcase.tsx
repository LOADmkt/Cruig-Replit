
import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX } from 'lucide-react';
import { motion } from 'framer-motion';
import './video.css';

interface VideoShowcaseProps {
  title: string;
  description: string;
  videoUrl: string;
  posterImage: string;
}

const VideoShowcase = ({
  title,
  description,
  videoUrl,
  posterImage
}: VideoShowcaseProps) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [progress, setProgress] = useState(0);
  const [showControls, setShowControls] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);

  const handleVideoToggle = () => {
    if (!videoRef.current) return;
    
    if (videoRef.current.paused) {
      videoRef.current.play()
        .then(() => setIsPlaying(true))
        .catch(error => {
          console.error("Error playing video:", error);
          setIsPlaying(false);
        });
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const handleMuteToggle = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  const updateProgress = () => {
    if (!videoRef.current) return;
    const percentage = videoRef.current.currentTime / videoRef.current.duration * 100;
    setProgress(isNaN(percentage) ? 0 : percentage);
  };
  
  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!videoRef.current || !progressBarRef.current) return;
    
    const rect = progressBarRef.current.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / progressBarRef.current.offsetWidth;
    videoRef.current.currentTime = pos * videoRef.current.duration;
  };

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const events = [
      {
        name: 'timeupdate',
        handler: updateProgress
      }, 
      {
        name: 'ended',
        handler: () => setIsPlaying(false)
      }, 
      {
        name: 'pause',
        handler: () => setIsPlaying(false)
      }, 
      {
        name: 'play',
        handler: () => setIsPlaying(true)
      }
    ];

    events.forEach(event => {
      video.addEventListener(event.name, event.handler);
    });

    return () => {
      if (!video) return;
      events.forEach(event => {
        video.removeEventListener(event.name, event.handler);
      });
    };
  }, []);

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold mb-4">{title}</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">{description}</p>
        </div>
        
        <div 
          className="max-w-4xl mx-auto relative rounded-xl overflow-hidden shadow-2xl video-container"
          onMouseEnter={() => setShowControls(true)}
          onMouseLeave={() => setShowControls(false)}
        >
          <video
            ref={videoRef}
            className="w-full h-auto"
            poster={posterImage}
            muted={isMuted}
            onClick={handleVideoToggle}
          >
            <source src={videoUrl} type="video/mp4" />
            Seu navegador não suporta vídeos HTML5.
          </video>
          
          {/* Overlay controls */}
          <div className="absolute inset-0 flex items-center justify-center">
            {!isPlaying && (
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={handleVideoToggle}
                className="bg-[#99c00d]/90 text-white rounded-full p-5 shadow-lg"
              >
                <Play size={30} />
              </motion.button>
            )}
          </div>
          
          {/* Bottom controls */}
          <div 
            className={`absolute bottom-0 left-0 right-0 bg-black/50 text-white px-4 py-3 flex flex-col transition-opacity duration-300 video-controls ${showControls || isPlaying ? 'opacity-100' : 'opacity-0'}`}
          >
            <div 
              ref={progressBarRef}
              className="video-progress mb-2 cursor-pointer" 
              onClick={handleProgressClick}
            >
              <div 
                className="video-progress-filled" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <button onClick={handleVideoToggle} className="video-btn mr-4">
                  {isPlaying ? <Pause size={20} /> : <Play size={20} />}
                </button>
                
                <button onClick={handleMuteToggle} className="video-btn">
                  {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
                </button>
              </div>
              
              <div className="text-sm">
                {videoRef.current && !isNaN(videoRef.current.duration) ? (
                  `${Math.floor(videoRef.current.currentTime / 60)}:${String(Math.floor(videoRef.current.currentTime % 60)).padStart(2, '0')} / 
                   ${Math.floor(videoRef.current.duration / 60)}:${String(Math.floor(videoRef.current.duration % 60)).padStart(2, '0')}`
                ) : '0:00 / 0:00'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VideoShowcase;
