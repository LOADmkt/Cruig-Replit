
import React, { useState, useEffect } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Filter } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface FilterPanelTab {
  id: string;
  label: string;
}

interface FilterPanelProps {
  title: string;
  children: React.ReactNode;
  isOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
  onApplyFilters?: () => void;
  tabs?: FilterPanelTab[];
}

export function FilterPanel({ 
  title, 
  children, 
  isOpen, 
  onOpenChange,
  onApplyFilters,
  tabs
}: FilterPanelProps) {
  const [open, setOpen] = useState(isOpen || false);
  const [activeTab, setActiveTab] = useState(tabs && tabs.length > 0 ? tabs[0].id : '');

  useEffect(() => {
    if (isOpen !== undefined) {
      setOpen(isOpen);
    }
  }, [isOpen]);

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
    if (onOpenChange) {
      onOpenChange(newOpen);
    }
  };

  const handleApplyFilters = () => {
    handleOpenChange(false);
    if (onApplyFilters) {
      onApplyFilters();
    }
  };

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    
    // Encontrar todos os elementos com data-tab
    const tabPanels = document.querySelectorAll('[data-tab]');
    
    // Esconder todos os painéis de abas
    tabPanels.forEach(panel => {
      (panel as HTMLElement).classList.add('hidden');
    });
    
    // Mostrar apenas o painel da aba ativa
    const activePanel = document.querySelector(`[data-tab="${tabId}"]`);
    if (activePanel) {
      (activePanel as HTMLElement).classList.remove('hidden');
    }
  };
  
  return (
    <Sheet open={open} onOpenChange={handleOpenChange}>
      <SheetTrigger asChild>
        <Button variant="outline" className="flex gap-2 items-center border-2 border-gray-300 hover:border-gray-400">
          <Filter className="h-4 w-4" />
          <span>Filtros</span>
        </Button>
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-md">
        <SheetHeader>
          <SheetTitle>{title}</SheetTitle>
        </SheetHeader>
        
        {tabs && tabs.length > 1 && (
          <Tabs defaultValue={activeTab} className="mt-4" onValueChange={handleTabChange}>
            <TabsList className="grid grid-cols-2">
              {tabs.map(tab => (
                <TabsTrigger key={tab.id} value={tab.id}>
                  {tab.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        )}
        
        <div className="py-4">{children}</div>
        
        <div className="flex justify-end mt-4">
          <Button onClick={handleApplyFilters} className="bg-[#99c00d] hover:bg-[#99c00d]/90">
            Aplicar Filtros
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
