
import React from 'react';
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";
import { useFilters } from '@/contexts/FilterContext';
import { FilterConfig, FilterOption } from '@/types/filters';
import { cn } from '@/lib/utils';
import { convertFilterConfigToArray, normalizeFilterOptions } from '@/lib/filterUtils';

interface ActiveFilterBadgesProps {
  filterConfig: Record<string, FilterConfig>;
  className?: string;
}

export function ActiveFilterBadges({ filterConfig, className }: ActiveFilterBadgesProps) {
  const { filters, removeFilter } = useFilters();
  const filterConfigArray = convertFilterConfigToArray(filterConfig);
  
  // Function to get the label for a filter value
  const getValueLabel = (field: string, value: any): string => {
    const config = filterConfigArray.find(c => c.field === field);
    
    if (!config) return String(value);
    
    // Handle range filters
    if (config.type === 'range' && Array.isArray(value)) {
      return `${value[0]} - ${value[1]}`;
    }
    
    // Handle dateRange filter
    if (config.type === 'dateRange' && value && typeof value === 'object') {
      if (value.from && value.to) {
        return `${value.from.toLocaleDateString()} - ${value.to.toLocaleDateString()}`;
      } else if (value.from) {
        return `A partir de ${value.from.toLocaleDateString()}`;
      } else if (value.to) {
        return `Até ${value.to.toLocaleDateString()}`;
      }
    }
    
    // Handle multi-select filters
    if (Array.isArray(value) && config.options) {
      const options = normalizeFilterOptions(config.options);
      if (value.length === 0) return '';
      if (value.length === 1) {
        const option = options.find(o => o.value === value[0]);
        return option ? option.label : String(value[0]);
      }
      return `${value.length} selecionados`;
    }
    
    // Handle single value with options
    if (config.options) {
      const options = normalizeFilterOptions(config.options);
      const option = options.find(o => o.value === value);
      return option ? option.label : String(value);
    }
    
    return String(value);
  };
  
  // Format filter values for display
  const formatFilterValue = (field: string, value: any): string => {
    const config = filterConfigArray.find(c => c.field === field);
    
    if (!config) return String(value);
    
    // Use custom formatter if provided
    if (config.formatValue || config.formatter) {
      const formatter = config.formatValue || config.formatter;
      if (formatter && typeof formatter === 'function') return formatter(value);
    }
    
    // Handle range filters
    if (config.type === 'range' && Array.isArray(value)) {
      return `${value[0]} - ${value[1]}`;
    }
    
    // Handle dateRange filter
    if (config.type === 'dateRange' && value && typeof value === 'object') {
      if (value.from && value.to) {
        return `${value.from.toLocaleDateString()} - ${value.to.toLocaleDateString()}`;
      } else if (value.from) {
        return `A partir de ${value.from.toLocaleDateString()}`;
      } else if (value.to) {
        return `Até ${value.to.toLocaleDateString()}`;
      }
    }
    
    // Handle array values (multi-select)
    if (Array.isArray(value)) {
      if (value.length === 0) return '';
      if (value.length === 1) return getValueLabel(field, value[0]);
      return `${value.length} selecionados`;
    }
    
    return getValueLabel(field, value);
  };

  const activeFilters = Object.entries(filters).filter(([field, value]) => {
    if (Array.isArray(value) && value.length === 0) return false;
    if (value === null || value === undefined) return false;
    if (value === '') return false;
    if (typeof value === 'object' && value !== null && !Object.keys(value).length) return false;
    return true;
  });
  
  if (activeFilters.length === 0) return null;
  
  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      {activeFilters.map(([field, value]) => {
        const config = filterConfigArray.find(c => c.field === field);
        if (!config) return null;
        
        const formattedValue = formatFilterValue(field, value);
        if (!formattedValue) return null;
        
        return (
          <Badge 
            key={field}
            variant="outline" 
            className="bg-gray-100 border-gray-200 text-gray-700 hover:bg-gray-200 px-3 py-1 rounded-md flex items-center gap-1 cursor-default"
            onClick={() => removeFilter(field)}
          >
            <span className="font-medium">{config.label}:</span>
            <span>{formattedValue}</span>
            <X className="h-3 w-3 ml-1 cursor-pointer" onClick={(e) => {
              e.stopPropagation();
              removeFilter(field);
            }} />
          </Badge>
        );
      })}
    </div>
  );
}
