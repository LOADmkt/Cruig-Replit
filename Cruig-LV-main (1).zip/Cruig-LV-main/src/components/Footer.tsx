
import React from 'react';
import { Facebook, Instagram, Twitter, Linkedin, Mail, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-gray-50 pt-16 pb-8 border-t border-gray-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <h3 className="font-display text-2xl font-bold mb-6 text-brand-primary">cruig</h3>
            <p className="text-gray-700 mb-6">
              Conectando criadores de conteúdo e marcas para parcerias de sucesso no mercado brasileiro.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-600 hover:text-brand-primary transition-colors p-2 rounded-full hover:bg-gray-100">
                <Instagram size={22} />
              </a>
              <a href="#" className="text-gray-600 hover:text-brand-primary transition-colors p-2 rounded-full hover:bg-gray-100">
                <Facebook size={22} />
              </a>
              <a href="#" className="text-gray-600 hover:text-brand-primary transition-colors p-2 rounded-full hover:bg-gray-100">
                <Twitter size={22} />
              </a>
              <a href="#" className="text-gray-600 hover:text-brand-primary transition-colors p-2 rounded-full hover:bg-gray-100">
                <Linkedin size={22} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-6 text-gray-800">Links Rápidos</h4>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Início
                </Link>
              </li>
              <li>
                <Link to="/#recursos" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Recursos
                </Link>
              </li>
              <li>
                <Link to="/#planos" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Planos
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Perguntas Frequentes
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Blog
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-6 text-gray-800">Para Criadores</h4>
            <ul className="space-y-3">
              <li>
                <Link to="/criadores" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Como Funciona
                </Link>
              </li>
              <li>
                <Link to="/recursos-criadores" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Recursos para Criadores
                </Link>
              </li>
              <li>
                <Link to="/depoimentos-criadores" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Histórias de Sucesso
                </Link>
              </li>
              <li>
                <Link to="/assinatura-criadores" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Plano para Criadores
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium text-lg mb-6 text-gray-800">Para Empresas</h4>
            <ul className="space-y-3">
              <li>
                <Link to="/empresas" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Como Funciona
                </Link>
              </li>
              <li>
                <Link to="/recursos-empresas" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Recursos para Empresas
                </Link>
              </li>
              <li>
                <Link to="/casos-sucesso" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Casos de Sucesso
                </Link>
              </li>
              <li>
                <Link to="/assinatura-empresas" className="text-gray-700 hover:text-brand-primary transition-colors font-medium hover:underline">
                  Plano para Empresas
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-700 text-sm mb-4 md:mb-0 font-medium">
              &copy; {new Date().getFullYear()} cruig. Todos os direitos reservados.
            </p>
            <div className="flex space-x-6">
              <Link to="/termos" className="text-gray-700 hover:text-brand-primary text-sm font-medium hover:underline">
                Termos de Uso
              </Link>
              <Link to="/privacidade" className="text-gray-700 hover:text-brand-primary text-sm font-medium hover:underline">
                Política de Privacidade
              </Link>
              <Link to="/cookies" className="text-gray-700 hover:text-brand-primary text-sm font-medium hover:underline">
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
