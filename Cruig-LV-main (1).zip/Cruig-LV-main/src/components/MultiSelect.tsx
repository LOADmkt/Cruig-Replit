
/**
 * This is an alias file that re-exports the MultiSelect component from its new location
 * to maintain backward compatibility with existing imports.
 */

export { MultiSelect } from '@/components/multi-select';
export type { MultiSelectProps, MultiSelectOption } from '@/components/multi-select/types';
