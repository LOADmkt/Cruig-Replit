
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { DollarSign, CreditCard, Download, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Dados de exemplo
const transacoesIniciais = [
  { id: 1, tipo: "entrada", descricao: "Assinatura Premium - Ana Silva", valor: 49.90, data: "2024-04-15", status: "pago", metodo: "cartão", idTransacao: "ch_1NkjL2KL3KL3KL3KL3KL3KL3" },
  { id: 2, tipo: "entrada", descricao: "Assinatura Enterprise - MídiaTech", valor: 99.90, data: "2024-04-10", status: "pago", metodo: "cartão", idTransacao: "ch_1NkjL2KL3KL3KL3KL3KL3KL4" },
  { id: 3, tipo: "saida", descricao: "Hospedagem de Servidor", valor: 150.00, data: "2024-04-05", status: "pago", metodo: "transferência", idTransacao: null },
  { id: 4, tipo: "entrada", descricao: "Assinatura Básica - João Almeida", valor: 29.90, data: "2024-04-20", status: "pago", metodo: "cartão", idTransacao: "ch_1NkjL2KL3KL3KL3KL3KL3KL5" },
  { id: 5, tipo: "entrada", descricao: "Assinatura Premium - Paula Ferreira", valor: 49.90, data: "2024-02-10", status: "falhou", metodo: "cartão", idTransacao: "ch_1NkjL2KL3KL3KL3KL3KL3KL6" },
  { id: 6, tipo: "saida", descricao: "Serviços de Marketing", valor: 300.00, data: "2024-03-28", status: "pago", metodo: "transferência", idTransacao: null },
  { id: 7, tipo: "entrada", descricao: "Assinatura Enterprise - Marketing Express", valor: 99.90, data: "2024-02-15", status: "pendente", metodo: "cartão", idTransacao: "ch_1NkjL2KL3KL3KL3KL3KL3KL7" },
];

const AdminFinanceiro = () => {
  const [transacoes, setTransacoes] = useState(transacoesIniciais);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [novaTransacao, setNovaTransacao] = useState({
    tipo: "saida",
    descricao: "",
    valor: "",
    data: new Date().toISOString().split("T")[0]
  });
  const { toast } = useToast();

  // Cálculos financeiros
  const totalEntradas = transacoes
    .filter(t => t.tipo === "entrada" && t.status === "pago")
    .reduce((acc, curr) => acc + curr.valor, 0);
  
  const totalSaidas = transacoes
    .filter(t => t.tipo === "saida" && t.status === "pago")
    .reduce((acc, curr) => acc + curr.valor, 0);
  
  const saldoAtual = totalEntradas - totalSaidas;

  const handleAdicionarTransacao = () => {
    if (!novaTransacao.descricao || !novaTransacao.valor) {
      toast({
        title: "Erro ao adicionar transação",
        description: "Preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }

    const novaId = Math.max(...transacoes.map(t => t.id)) + 1;
    
    const transacaoFormatada = {
      id: novaId,
      tipo: novaTransacao.tipo,
      descricao: novaTransacao.descricao,
      valor: parseFloat(novaTransacao.valor),
      data: novaTransacao.data,
      status: "pago",
      metodo: "manual",
      idTransacao: null
    };
    
    setTransacoes([transacaoFormatada, ...transacoes]);
    setDialogOpen(false);
    
    // Resetar o formulário
    setNovaTransacao({
      tipo: "saida",
      descricao: "",
      valor: "",
      data: new Date().toISOString().split("T")[0]
    });
    
    toast({
      title: "Transação adicionada",
      description: `${transacaoFormatada.tipo === "entrada" ? "Receita" : "Despesa"} registrada com sucesso.`
    });
  };

  const exportarCSV = () => {
    // Cabeçalho do CSV
    let csvContent = "ID,Tipo,Descrição,Valor,Data,Status,Método,ID Transação\n";
    
    // Adicionar dados
    transacoes.forEach(t => {
      const row = [
        t.id,
        t.tipo === "entrada" ? "Receita" : "Despesa",
        `"${t.descricao}"`,  // Aspas para evitar problemas com vírgulas na descrição
        t.valor.toFixed(2).replace(".", ","),
        new Date(t.data).toLocaleDateString("pt-BR"),
        t.status,
        t.metodo,
        t.idTransacao || ""
      ].join(",");
      
      csvContent += row + "\n";
    });
    
    // Criar arquivo e fazer download
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    
    link.setAttribute("href", url);
    link.setAttribute("download", `financeiro_${new Date().toISOString().split("T")[0]}.csv`);
    link.style.visibility = "hidden";
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Relatório exportado",
      description: "O arquivo CSV foi gerado com sucesso."
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-800">Financeiro</h2>
        <div className="flex gap-2">
          <Button 
            variant="outline"
            onClick={exportarCSV}
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            Exportar CSV
          </Button>
          <Button 
            variant="brand"
            onClick={() => setDialogOpen(true)}
            className="flex items-center gap-2"
          >
            <Plus className="h-4 w-4" />
            Registrar Despesa
          </Button>
        </div>
      </div>

      {/* Resumo financeiro */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total de Receitas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">R$ {totalEntradas.toFixed(2)}</div>
              <div className="rounded-full bg-green-100 p-2 text-green-600">
                <DollarSign className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total de Despesas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">R$ {totalSaidas.toFixed(2)}</div>
              <div className="rounded-full bg-red-100 p-2 text-red-600">
                <CreditCard className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Saldo Atual
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className={`text-2xl font-bold ${saldoAtual >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                R$ {saldoAtual.toFixed(2)}
              </div>
              <div className={`rounded-full p-2 ${saldoAtual >= 0 ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                <DollarSign className="h-4 w-4" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Transações */}
      <Tabs defaultValue="todas">
        <TabsList className="mb-4">
          <TabsTrigger value="todas">Todas Transações</TabsTrigger>
          <TabsTrigger value="receitas">Receitas</TabsTrigger>
          <TabsTrigger value="despesas">Despesas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="todas">
          <div className="border rounded-md overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Método</TableHead>
                  <TableHead>ID Transação</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transacoes.map(transacao => (
                  <TableRow key={transacao.id}>
                    <TableCell>
                      {transacao.tipo === "entrada" ? (
                        <Badge variant="brand">Receita</Badge>
                      ) : (
                        <Badge variant="secondary">Despesa</Badge>
                      )}
                    </TableCell>
                    <TableCell>{transacao.descricao}</TableCell>
                    <TableCell className={`font-medium ${transacao.tipo === "entrada" ? "text-green-600" : "text-red-600"}`}>
                      {transacao.tipo === "entrada" ? "+" : "-"} R$ {transacao.valor.toFixed(2)}
                    </TableCell>
                    <TableCell>{new Date(transacao.data).toLocaleDateString("pt-BR")}</TableCell>
                    <TableCell>
                      {transacao.status === "pago" && <Badge variant="outline" className="bg-green-100 text-green-700">Pago</Badge>}
                      {transacao.status === "pendente" && <Badge variant="outline" className="bg-yellow-100 text-yellow-700">Pendente</Badge>}
                      {transacao.status === "falhou" && <Badge variant="outline" className="bg-red-100 text-red-700">Falhou</Badge>}
                    </TableCell>
                    <TableCell>{transacao.metodo}</TableCell>
                    <TableCell className="font-mono text-xs">
                      {transacao.idTransacao || "-"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
        
        <TabsContent value="receitas">
          <div className="border rounded-md overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Método</TableHead>
                  <TableHead>ID Transação</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transacoes
                  .filter(t => t.tipo === "entrada")
                  .map(transacao => (
                    <TableRow key={transacao.id}>
                      <TableCell>{transacao.descricao}</TableCell>
                      <TableCell className="font-medium text-green-600">
                        + R$ {transacao.valor.toFixed(2)}
                      </TableCell>
                      <TableCell>{new Date(transacao.data).toLocaleDateString("pt-BR")}</TableCell>
                      <TableCell>
                        {transacao.status === "pago" && <Badge variant="outline" className="bg-green-100 text-green-700">Pago</Badge>}
                        {transacao.status === "pendente" && <Badge variant="outline" className="bg-yellow-100 text-yellow-700">Pendente</Badge>}
                        {transacao.status === "falhou" && <Badge variant="outline" className="bg-red-100 text-red-700">Falhou</Badge>}
                      </TableCell>
                      <TableCell>{transacao.metodo}</TableCell>
                      <TableCell className="font-mono text-xs">
                        {transacao.idTransacao || "-"}
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
        
        <TabsContent value="despesas">
          <div className="border rounded-md overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Método</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transacoes
                  .filter(t => t.tipo === "saida")
                  .map(transacao => (
                    <TableRow key={transacao.id}>
                      <TableCell>{transacao.descricao}</TableCell>
                      <TableCell className="font-medium text-red-600">
                        - R$ {transacao.valor.toFixed(2)}
                      </TableCell>
                      <TableCell>{new Date(transacao.data).toLocaleDateString("pt-BR")}</TableCell>
                      <TableCell>
                        {transacao.status === "pago" && <Badge variant="outline" className="bg-green-100 text-green-700">Pago</Badge>}
                        {transacao.status === "pendente" && <Badge variant="outline" className="bg-yellow-100 text-yellow-700">Pendente</Badge>}
                      </TableCell>
                      <TableCell>{transacao.metodo}</TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      {/* Dialog para adicionar despesa */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Registrar Nova Transação</DialogTitle>
            <DialogDescription>
              Adicione uma nova transação financeira ao sistema.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="tipo" className="text-right">
                Tipo
              </Label>
              <select
                id="tipo"
                value={novaTransacao.tipo}
                onChange={(e) => setNovaTransacao({...novaTransacao, tipo: e.target.value})}
                className="col-span-3 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <option value="entrada">Receita</option>
                <option value="saida">Despesa</option>
              </select>
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="descricao" className="text-right">
                Descrição
              </Label>
              <Textarea
                id="descricao"
                value={novaTransacao.descricao}
                onChange={(e) => setNovaTransacao({...novaTransacao, descricao: e.target.value})}
                className="col-span-3 resize-none"
                rows={2}
                placeholder="Descreva a transação"
              />
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="valor" className="text-right">
                Valor (R$)
              </Label>
              <Input
                id="valor"
                type="number"
                step="0.01"
                min="0"
                value={novaTransacao.valor}
                onChange={(e) => setNovaTransacao({...novaTransacao, valor: e.target.value})}
                className="col-span-3"
                placeholder="0,00"
              />
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="data" className="text-right">
                Data
              </Label>
              <Input
                id="data"
                type="date"
                value={novaTransacao.data}
                onChange={(e) => setNovaTransacao({...novaTransacao, data: e.target.value})}
                className="col-span-3"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button 
              variant="brand"
              onClick={handleAdicionarTransacao}
            >
              {novaTransacao.tipo === "entrada" ? "Adicionar Receita" : "Registrar Despesa"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminFinanceiro;
