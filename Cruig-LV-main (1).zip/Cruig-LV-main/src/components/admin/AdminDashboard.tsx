
import React, { useState, useEffect } from "react";
import { useDashboardData } from "@/hooks/useDashboardData";
import { AdminMetricsCards } from "./AdminMetricsCards";
import { AdminUserTable } from "./AdminUserTable";
import { AdminCampaignTable } from "./AdminCampaignTable";
import DashboardHeader from "./DashboardHeader";
import DashboardCharts from "./DashboardCharts";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";

const AdminDashboard: React.FC = () => {
  const [timeRange, setTimeRange] = useState("monthly");
  const { isLoading, error, data } = useDashboardData('admin/dashboard');

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <Loader2 className="h-12 w-12 animate-spin text-brand-primary mb-4" />
        <p className="text-lg text-gray-600">Carregando dashboard administrativo...</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center">
        <h3 className="text-lg font-medium text-red-800">Erro ao carregar dados</h3>
        <p className="mt-2 text-red-600">{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 px-4 py-2 bg-brand-tertiary text-white rounded-lg hover:bg-brand-tertiary/80"
        >
          Tentar Novamente
        </button>
      </div>
    );
  }

  // Prepare stats data for the metrics cards
  const dashboardStats = [
    {
      title: "Empresas",
      value: data?.companies?.toString() || "0",
      description: "Total registrado",
      icon: "Users",
      iconBg: "bg-brand-tertiary/10",
      iconColor: "text-brand-tertiary"
    },
    {
      title: "Criadores",
      value: data?.creators?.toString() || "0",
      description: "Total registrado",
      icon: "Users",
      iconBg: "bg-brand-primary/10",
      iconColor: "text-brand-primary"
    },
    {
      title: "Campanhas",
      value: data?.campaigns?.toString() || "0",
      description: "Total criado",
      icon: "TrendingUp",
      iconBg: "bg-green-100",
      iconColor: "text-green-600"
    },
    {
      title: "Usuários Ativos",
      value: data?.activeUsers?.toString() || "0",
      description: "Últimas 24h",
      icon: "CheckCircle",
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600"
    },
    {
      title: "Taxa de Conversão",
      value: "24%",
      description: "Últimos 30 dias",
      icon: "TrendingUp",
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600"
    },
    {
      title: "Receita Mensal",
      value: "R$ 18.500",
      description: "Este mês",
      icon: "DollarSign",
      iconBg: "bg-brand-dark/10",
      iconColor: "text-brand-dark"
    }
  ];

  return (
    <div className="space-y-8">
      <DashboardHeader timeRange={timeRange} setTimeRange={setTimeRange} />
      
      {/* Cartões de métricas */}
      <AdminMetricsCards stats={dashboardStats} />
      
      {/* Gráficos */}
      <DashboardCharts />
      
      {/* Tabs para Usuários e Campanhas */}
      <Tabs defaultValue="users" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="users">Usuários Recentes</TabsTrigger>
          <TabsTrigger value="campaigns">Campanhas Recentes</TabsTrigger>
        </TabsList>
        
        <TabsContent value="users" className="mt-0">
          <div className="rounded-lg bg-white p-6">
            <h3 className="text-lg font-medium mb-4">Usuários Recentes</h3>
            <AdminUserTable users={data?.recentUsers || []} />
          </div>
        </TabsContent>
        
        <TabsContent value="campaigns" className="mt-0">
          <div className="rounded-lg bg-white p-6">
            <h3 className="text-lg font-medium mb-4">Campanhas Recentes</h3>
            <AdminCampaignTable campaigns={data?.recentCampaigns || []} />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;
