
import React, { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Edit, Trash2 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

// Tipo para representar um nicho
interface Nicho {
  id: string;
  nome: string;
  descricao?: string;
  ativo: boolean;
}

export const AdminNichosGerenciamento = () => {
  const { toast } = useToast();
  const [nichos, setNichos] = useState<Nicho[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingNicho, setEditingNicho] = useState<Nicho | null>(null);
  const [newNicho, setNewNicho] = useState({ nome: "", descricao: "" });

  // Buscar nichos do Supabase
  useEffect(() => {
    const fetchNichos = async () => {
      try {
        // Simulando dados para demonstração
        // Em produção, isso seria uma chamada para o Supabase
        const mockData = [
          { id: '1', nome: 'Moda', descricao: 'Conteúdo sobre moda e tendências', ativo: true },
          { id: '2', nome: 'Tecnologia', descricao: 'Conteúdo sobre tecnologia e inovação', ativo: true },
          { id: '3', nome: 'Saúde', descricao: 'Conteúdo sobre saúde e bem-estar', ativo: true },
          { id: '4', nome: 'Gastronomia', descricao: 'Conteúdo sobre culinária e gastronomia', ativo: true }
        ];
        
        // Simular um atraso na resposta para mostrar o loading
        setTimeout(() => {
          setNichos(mockData);
          setLoading(false);
        }, 500);
        
        // NOTA: Quando integrado ao Supabase, usaríamos algo como:
        // const { data, error } = await supabase.from('nichos').select('*');
        // if (error) throw error;
        // setNichos(data);
      } catch (error) {
        console.error("Erro ao buscar nichos:", error);
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Não foi possível carregar os nichos. Tente novamente mais tarde.",
        });
        setLoading(false);
      }
    };

    fetchNichos();
  }, [toast]);

  const handleAddNicho = async () => {
    try {
      if (!newNicho.nome.trim()) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "O nome do nicho é obrigatório.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando adição de um novo nicho
      // Em produção, isso seria uma chamada para o Supabase
      const novoNicho: Nicho = {
        id: `${Date.now()}`,
        nome: newNicho.nome,
        descricao: newNicho.descricao,
        ativo: true
      };
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { data, error } = await supabase
      //   .from('nichos')
      //   .insert([{ nome: newNicho.nome, descricao: newNicho.descricao, ativo: true }])
      //   .select();
      // if (error) throw error;
      
      setNichos([...nichos, novoNicho]);
      setDialogOpen(false);
      setNewNicho({ nome: "", descricao: "" });
      
      toast({
        title: "Sucesso",
        description: "Nicho adicionado com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao adicionar nicho:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível adicionar o nicho. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateNicho = async () => {
    try {
      if (!editingNicho || !editingNicho.nome.trim()) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "O nome do nicho é obrigatório.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando atualização de um nicho
      // Em produção, isso seria uma chamada para o Supabase
      const updatedNichos = nichos.map(nicho => 
        nicho.id === editingNicho.id ? editingNicho : nicho
      );
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('nichos')
      //   .update({ nome: editingNicho.nome, descricao: editingNicho.descricao })
      //   .eq('id', editingNicho.id);
      // if (error) throw error;
      
      setNichos(updatedNichos);
      setDialogOpen(false);
      setEditingNicho(null);
      
      toast({
        title: "Sucesso",
        description: "Nicho atualizado com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao atualizar nicho:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível atualizar o nicho. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteNicho = async () => {
    try {
      if (!editingNicho) return;
      
      setLoading(true);
      
      // Simulando exclusão de um nicho
      // Em produção, isso seria uma chamada para o Supabase
      const updatedNichos = nichos.filter(nicho => nicho.id !== editingNicho.id);
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('nichos')
      //   .delete()
      //   .eq('id', editingNicho.id);
      // if (error) throw error;
      
      setNichos(updatedNichos);
      setDeleteDialogOpen(false);
      setEditingNicho(null);
      
      toast({
        title: "Sucesso",
        description: "Nicho excluído com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao excluir nicho:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível excluir o nicho. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const openAddDialog = () => {
    setEditingNicho(null);
    setNewNicho({ nome: "", descricao: "" });
    setDialogOpen(true);
  };

  const openEditDialog = (nicho: Nicho) => {
    setEditingNicho(nicho);
    setDialogOpen(true);
  };

  const openDeleteDialog = (nicho: Nicho) => {
    setEditingNicho(nicho);
    setDeleteDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-bold text-gray-800">Gestão de Nichos</h3>
        <Button 
          onClick={openAddDialog} 
          variant="brand" 
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Adicionar Nicho
        </Button>
      </div>
      
      {loading ? (
        <div className="flex justify-center p-8">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-brand-primary border-t-transparent"></div>
        </div>
      ) : nichos.length === 0 ? (
        <div className="text-center p-8 bg-gray-50 rounded-lg border border-gray-200">
          <p className="text-gray-600">Nenhum nicho cadastrado.</p>
          <Button onClick={openAddDialog} variant="link" className="mt-2">
            Adicionar o primeiro nicho
          </Button>
        </div>
      ) : (
        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-[100px]">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {nichos.map((nicho) => (
                <TableRow key={nicho.id}>
                  <TableCell className="font-medium">{nicho.nome}</TableCell>
                  <TableCell>{nicho.descricao || "-"}</TableCell>
                  <TableCell>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      nicho.ativo ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                    }`}>
                      {nicho.ativo ? "Ativo" : "Inativo"}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditDialog(nicho)}
                        title="Editar"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openDeleteDialog(nicho)}
                        title="Excluir"
                      >
                        <Trash2 className="h-4 w-4 text-red-600" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
      
      {/* Dialog para adicionar ou editar nicho */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingNicho ? "Editar Nicho" : "Adicionar Nicho"}
            </DialogTitle>
            <DialogDescription>
              {editingNicho
                ? "Faça as alterações necessárias e salve."
                : "Preencha os campos para adicionar um novo nicho."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label htmlFor="nome" className="text-sm font-medium">
                Nome do nicho *
              </label>
              <Input
                id="nome"
                placeholder="Ex: Moda, Tecnologia, Finanças..."
                value={editingNicho ? editingNicho.nome : newNicho.nome}
                onChange={(e) => {
                  if (editingNicho) {
                    setEditingNicho({ ...editingNicho, nome: e.target.value });
                  } else {
                    setNewNicho({ ...newNicho, nome: e.target.value });
                  }
                }}
                className="focus:border-brand-primary"
              />
            </div>
            <div className="grid gap-2">
              <label htmlFor="descricao" className="text-sm font-medium">
                Descrição
              </label>
              <Input
                id="descricao"
                placeholder="Descreva o nicho (opcional)"
                value={editingNicho ? editingNicho.descricao || "" : newNicho.descricao}
                onChange={(e) => {
                  if (editingNicho) {
                    setEditingNicho({ ...editingNicho, descricao: e.target.value });
                  } else {
                    setNewNicho({ ...newNicho, descricao: e.target.value });
                  }
                }}
                className="focus:border-brand-primary"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={editingNicho ? handleUpdateNicho : handleAddNicho}
              disabled={loading}
              variant="brand"
            >
              {loading ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2"></span>
                  Processando...
                </>
              ) : editingNicho ? (
                "Salvar alterações"
              ) : (
                "Adicionar nicho"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog para confirmar exclusão */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir nicho</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir o nicho "{editingNicho?.nome}"?
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteNicho}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {loading ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2"></span>
                  Excluindo...
                </>
              ) : (
                "Excluir"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
