
import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, ThumbsUp, ThumbsDown } from "lucide-react";

interface Campaign {
  id: string;
  name: string;
  company: string;
  status: 'ativa' | 'pausada' | 'finalizada' | 'revisão';
  creators: number;
  createdAt: string;
}

interface AdminCampaignTableProps {
  campaigns: Campaign[];
}

export function AdminCampaignTable({ campaigns }: AdminCampaignTableProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };
  
  const getCampaignStatusBadge = (status: string) => {
    switch(status) {
      case 'ativa':
        return <Badge className="bg-green-500">Ativa</Badge>;
      case 'pausada':
        return <Badge className="bg-amber-500">Pausada</Badge>;
      case 'finalizada':
        return <Badge className="bg-gray-500">Finalizada</Badge>;
      case 'revisão':
        return <Badge className="bg-purple-500">Em Revisão</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };
  
  const handleViewCampaign = (id: string) => {
    console.log('Ver campanha:', id);
    // Navigate to campaign details
  };
  
  const handleApproveCampaign = (id: string) => {
    console.log('Aprovar campanha:', id);
    // API call to approve campaign
  };
  
  const handleRejectCampaign = (id: string) => {
    console.log('Rejeitar campanha:', id);
    // API call to reject campaign
  };
  
  if (!campaigns || campaigns.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Nenhuma campanha encontrada.</p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border shadow-sm overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Empresa</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Criadores</TableHead>
            <TableHead>Data Criação</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {campaigns.map((campaign) => (
            <TableRow key={campaign.id}>
              <TableCell className="font-medium">{campaign.name}</TableCell>
              <TableCell>{campaign.company}</TableCell>
              <TableCell>{getCampaignStatusBadge(campaign.status)}</TableCell>
              <TableCell>{campaign.creators}</TableCell>
              <TableCell>{formatDate(campaign.createdAt)}</TableCell>
              <TableCell className="text-right space-x-2">
                <Button variant="ghost" size="sm" onClick={() => handleViewCampaign(campaign.id)}>
                  <Eye className="h-4 w-4" />
                </Button>
                {campaign.status === 'revisão' && (
                  <>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleApproveCampaign(campaign.id)}
                      className="text-green-500 hover:text-green-700"
                    >
                      <ThumbsUp className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleRejectCampaign(campaign.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <ThumbsDown className="h-4 w-4" />
                    </Button>
                  </>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
