
import React from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AdminNichosGerenciamento } from "./AdminNichosGerenciamento";
import { AdminLocalizacoesGerenciamento } from "./AdminLocalizacoesGerenciamento";
import { AdminConfiguracoesExtras } from "./AdminConfiguracoesExtras";

const AdminConfiguracao = () => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Configurações do Sistema</h2>
        <p className="text-gray-600">
          Gerencie todas as configurações e parâmetros do sistema para manter o aplicativo atualizado.
        </p>
      </div>
      
      <Tabs defaultValue="nichos" className="w-full">
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="nichos" className="text-base">Nichos</TabsTrigger>
          <TabsTrigger value="localizacoes" className="text-base">Localizações</TabsTrigger>
          <TabsTrigger value="configuracoes" className="text-base">Parâmetros Extras</TabsTrigger>
        </TabsList>
        
        <Card>
          <CardContent className="pt-6">
            <TabsContent value="nichos">
              <AdminNichosGerenciamento />
            </TabsContent>
            
            <TabsContent value="localizacoes">
              <AdminLocalizacoesGerenciamento />
            </TabsContent>
            
            <TabsContent value="configuracoes">
              <AdminConfiguracoesExtras />
            </TabsContent>
          </CardContent>
        </Card>
      </Tabs>
      
      <Card>
        <CardHeader>
          <CardTitle>Instruções</CardTitle>
          <CardDescription>
            Dicas importantes sobre como gerenciar o sistema
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-semibold text-gray-800 mb-1">Nichos</h4>
            <p className="text-gray-600 text-sm">
              Os nichos são categorias que classificam os criadores de conteúdo e campanhas. 
              Todas as alterações feitas aqui serão refletidas nos filtros de busca, cadastros de criadores e 
              formulários de criação de campanhas.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold text-gray-800 mb-1">Localizações</h4>
            <p className="text-gray-600 text-sm">
              As localizações permitem segmentar criadores e campanhas por região geográfica.
              Mantenha uma estrutura hierárquica de País &gt; Estado &gt; Cidade para facilitar a navegação e busca.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold text-gray-800 mb-1">Configurações do Sistema</h4>
            <p className="text-gray-600 text-sm">
              Os parâmetros do sistema controlam limites, valores padrão e comportamentos em todo o aplicativo.
              As plataformas sociais definem quais serviços os criadores podem conectar aos seus perfis.
            </p>
          </div>
          
          <div className="bg-amber-50 border border-amber-200 rounded-md p-3">
            <h4 className="font-semibold text-amber-800 flex items-center mb-1">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Lembre-se
            </h4>
            <p className="text-amber-800 text-sm">
              As alterações feitas no painel administrativo têm efeito imediato em todo o sistema.
              Verifique todas as informações antes de salvar para garantir a consistência dos dados.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminConfiguracao;
