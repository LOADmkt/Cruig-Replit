
import React, { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Edit, Trash2, Settings } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

// Tipos para configurações extras
interface ConfiguracaoExtra {
  id: string;
  chave: string;
  valor: string;
  descricao?: string;
  ativo: boolean;
}

interface PlataformaSocial {
  id: string;
  nome: string;
  icon: string;
  cor: string;
  ativo: boolean;
}

export const AdminConfiguracoesExtras = () => {
  const { toast } = useToast();
  const [configuracoes, setConfiguracoes] = useState<ConfiguracaoExtra[]>([]);
  const [plataformas, setPlataformas] = useState<PlataformaSocial[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState<"config" | "plataforma">("config");
  
  const [editingConfig, setEditingConfig] = useState<ConfiguracaoExtra | null>(null);
  const [editingPlataforma, setEditingPlataforma] = useState<PlataformaSocial | null>(null);
  
  const [newConfig, setNewConfig] = useState<{ chave: string; valor: string; descricao: string }>({ 
    chave: "", valor: "", descricao: "" 
  });
  const [newPlataforma, setNewPlataforma] = useState<{ nome: string; icon: string; cor: string }>({ 
    nome: "", icon: "", cor: "#000000" 
  });

  // Buscar configurações do Supabase
  useEffect(() => {
    const fetchConfiguracoes = async () => {
      try {
        // Simulando dados para demonstração
        // Em produção, isso seria uma chamada para o Supabase
        const mockConfiguracoes = [
          { 
            id: '1', 
            chave: 'limiteUsuariosGratuitos', 
            valor: '100', 
            descricao: 'Limite de usuários para contas gratuitas', 
            ativo: true 
          },
          { 
            id: '2', 
            chave: 'comissaoPadrao', 
            valor: '10', 
            descricao: 'Percentual de comissão padrão para campanhas', 
            ativo: true 
          },
          { 
            id: '3', 
            chave: 'diasLimiteTrial', 
            valor: '14', 
            descricao: 'Dias disponíveis para período de avaliação', 
            ativo: true 
          }
        ];
        
        const mockPlataformas = [
          { 
            id: '1', 
            nome: 'Instagram', 
            icon: 'instagram', 
            cor: '#E1306C', 
            ativo: true 
          },
          { 
            id: '2', 
            nome: 'TikTok', 
            icon: 'tiktok', 
            cor: '#000000', 
            ativo: true 
          },
          { 
            id: '3', 
            nome: 'YouTube', 
            icon: 'youtube', 
            cor: '#FF0000', 
            ativo: true 
          },
          { 
            id: '4', 
            nome: 'Twitter', 
            icon: 'twitter', 
            cor: '#1DA1F2', 
            ativo: true 
          }
        ];
        
        // Simular um atraso na resposta para mostrar o loading
        setTimeout(() => {
          setConfiguracoes(mockConfiguracoes);
          setPlataformas(mockPlataformas);
          setLoading(false);
        }, 500);
        
        // NOTA: Quando integrado ao Supabase, usaríamos algo como:
        // const { data: configData, error: configError } = await supabase.from('configuracoes_sistema').select('*');
        // if (configError) throw configError;
        // setConfiguracoes(configData);
        
        // const { data: plataformasData, error: plataformasError } = await supabase.from('plataformas_sociais').select('*');
        // if (plataformasError) throw plataformasError;
        // setPlataformas(plataformasData);
      } catch (error) {
        console.error("Erro ao buscar configurações:", error);
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Não foi possível carregar as configurações. Tente novamente mais tarde.",
        });
        setLoading(false);
      }
    };

    fetchConfiguracoes();
  }, [toast]);

  // ======== Funções para gerenciar configurações ========
  const handleAddConfig = async () => {
    try {
      if (!newConfig.chave.trim() || !newConfig.valor.trim()) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Chave e valor são campos obrigatórios.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando adição de uma nova configuração
      // Em produção, isso seria uma chamada para o Supabase
      const novaConfig: ConfiguracaoExtra = {
        id: `cfg-${Date.now()}`,
        chave: newConfig.chave,
        valor: newConfig.valor,
        descricao: newConfig.descricao,
        ativo: true
      };
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { data, error } = await supabase
      //   .from('configuracoes_sistema')
      //   .insert([{ 
      //     chave: newConfig.chave, 
      //     valor: newConfig.valor, 
      //     descricao: newConfig.descricao,
      //     ativo: true 
      //   }])
      //   .select();
      // if (error) throw error;
      
      setConfiguracoes([...configuracoes, novaConfig]);
      setDialogOpen(false);
      setNewConfig({ chave: "", valor: "", descricao: "" });
      
      toast({
        title: "Sucesso",
        description: "Configuração adicionada com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao adicionar configuração:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível adicionar a configuração. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateConfig = async () => {
    try {
      if (!editingConfig || !editingConfig.chave.trim() || !editingConfig.valor.trim()) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Chave e valor são campos obrigatórios.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando atualização de uma configuração
      // Em produção, isso seria uma chamada para o Supabase
      const updatedConfigs = configuracoes.map(config => 
        config.id === editingConfig.id ? editingConfig : config
      );
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('configuracoes_sistema')
      //   .update({ 
      //     chave: editingConfig.chave, 
      //     valor: editingConfig.valor, 
      //     descricao: editingConfig.descricao 
      //   })
      //   .eq('id', editingConfig.id);
      // if (error) throw error;
      
      setConfiguracoes(updatedConfigs);
      setDialogOpen(false);
      setEditingConfig(null);
      
      toast({
        title: "Sucesso",
        description: "Configuração atualizada com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao atualizar configuração:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível atualizar a configuração. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteConfig = async () => {
    try {
      if (!editingConfig) return;
      
      setLoading(true);
      
      // Simulando exclusão de uma configuração
      // Em produção, isso seria uma chamada para o Supabase
      const updatedConfigs = configuracoes.filter(config => config.id !== editingConfig.id);
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('configuracoes_sistema')
      //   .delete()
      //   .eq('id', editingConfig.id);
      // if (error) throw error;
      
      setConfiguracoes(updatedConfigs);
      setDeleteDialogOpen(false);
      setEditingConfig(null);
      
      toast({
        title: "Sucesso",
        description: "Configuração excluída com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao excluir configuração:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível excluir a configuração. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  // ======== Funções para gerenciar plataformas sociais ========
  const handleAddPlataforma = async () => {
    try {
      if (!newPlataforma.nome.trim() || !newPlataforma.icon.trim() || !newPlataforma.cor.trim()) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Todos os campos são obrigatórios.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando adição de uma nova plataforma
      // Em produção, isso seria uma chamada para o Supabase
      const novaPlataforma: PlataformaSocial = {
        id: `plat-${Date.now()}`,
        nome: newPlataforma.nome,
        icon: newPlataforma.icon,
        cor: newPlataforma.cor,
        ativo: true
      };
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { data, error } = await supabase
      //   .from('plataformas_sociais')
      //   .insert([{ 
      //     nome: newPlataforma.nome, 
      //     icon: newPlataforma.icon, 
      //     cor: newPlataforma.cor,
      //     ativo: true 
      //   }])
      //   .select();
      // if (error) throw error;
      
      setPlataformas([...plataformas, novaPlataforma]);
      setDialogOpen(false);
      setNewPlataforma({ nome: "", icon: "", cor: "#000000" });
      
      toast({
        title: "Sucesso",
        description: "Plataforma adicionada com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao adicionar plataforma:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível adicionar a plataforma. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePlataforma = async () => {
    try {
      if (!editingPlataforma || !editingPlataforma.nome.trim() || !editingPlataforma.icon.trim() || !editingPlataforma.cor.trim()) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Todos os campos são obrigatórios.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando atualização de uma plataforma
      // Em produção, isso seria uma chamada para o Supabase
      const updatedPlataformas = plataformas.map(plataforma => 
        plataforma.id === editingPlataforma.id ? editingPlataforma : plataforma
      );
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('plataformas_sociais')
      //   .update({ 
      //     nome: editingPlataforma.nome, 
      //     icon: editingPlataforma.icon, 
      //     cor: editingPlataforma.cor 
      //   })
      //   .eq('id', editingPlataforma.id);
      // if (error) throw error;
      
      setPlataformas(updatedPlataformas);
      setDialogOpen(false);
      setEditingPlataforma(null);
      
      toast({
        title: "Sucesso",
        description: "Plataforma atualizada com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao atualizar plataforma:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível atualizar a plataforma. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeletePlataforma = async () => {
    try {
      if (!editingPlataforma) return;
      
      setLoading(true);
      
      // Simulando exclusão de uma plataforma
      // Em produção, isso seria uma chamada para o Supabase
      const updatedPlataformas = plataformas.filter(plataforma => plataforma.id !== editingPlataforma.id);
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('plataformas_sociais')
      //   .delete()
      //   .eq('id', editingPlataforma.id);
      // if (error) throw error;
      
      setPlataformas(updatedPlataformas);
      setDeleteDialogOpen(false);
      setEditingPlataforma(null);
      
      toast({
        title: "Sucesso",
        description: "Plataforma excluída com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao excluir plataforma:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível excluir a plataforma. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  // ======== Funções para abrir diálogos ========
  const openAddDialog = (tipo: "config" | "plataforma") => {
    setDialogType(tipo);
    
    if (tipo === "config") {
      setEditingConfig(null);
      setNewConfig({ chave: "", valor: "", descricao: "" });
    } else {
      setEditingPlataforma(null);
      setNewPlataforma({ nome: "", icon: "", cor: "#000000" });
    }
    
    setDialogOpen(true);
  };

  const openEditDialog = (tipo: "config" | "plataforma", item: ConfiguracaoExtra | PlataformaSocial) => {
    setDialogType(tipo);
    
    if (tipo === "config") {
      setEditingConfig(item as ConfiguracaoExtra);
    } else {
      setEditingPlataforma(item as PlataformaSocial);
    }
    
    setDialogOpen(true);
  };

  const openDeleteDialog = (tipo: "config" | "plataforma", item: ConfiguracaoExtra | PlataformaSocial) => {
    setDialogType(tipo);
    
    if (tipo === "config") {
      setEditingConfig(item as ConfiguracaoExtra);
    } else {
      setEditingPlataforma(item as PlataformaSocial);
    }
    
    setDeleteDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <h3 className="text-2xl font-bold text-gray-800">Configurações do Sistema</h3>
      
      <Tabs defaultValue="config" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="config" className="text-base">
            Parâmetros do Sistema
          </TabsTrigger>
          <TabsTrigger value="plataformas" className="text-base">
            Plataformas Sociais
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="config" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-gray-600">
              Gerencie parâmetros globais do sistema que afetam o funcionamento do aplicativo.
            </p>
            <Button 
              onClick={() => openAddDialog("config")} 
              variant="brand" 
              className="flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Adicionar Configuração
            </Button>
          </div>
          
          {loading ? (
            <div className="flex justify-center p-8">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-brand-primary border-t-transparent"></div>
            </div>
          ) : configuracoes.length === 0 ? (
            <div className="text-center p-8 bg-gray-50 rounded-lg border border-gray-200">
              <p className="text-gray-600">Nenhuma configuração cadastrada.</p>
              <Button onClick={() => openAddDialog("config")} variant="link" className="mt-2">
                Adicionar a primeira configuração
              </Button>
            </div>
          ) : (
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Chave</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[100px]">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {configuracoes.map((config) => (
                    <TableRow key={config.id}>
                      <TableCell className="font-medium">{config.chave}</TableCell>
                      <TableCell>{config.valor}</TableCell>
                      <TableCell>{config.descricao || "-"}</TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          config.ativo ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                        }`}>
                          {config.ativo ? "Ativo" : "Inativo"}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog("config", config)}
                            title="Editar"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openDeleteDialog("config", config)}
                            title="Excluir"
                          >
                            <Trash2 className="h-4 w-4 text-red-600" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="plataformas" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-gray-600">
              Gerencie as plataformas sociais que os criadores podem conectar ao sistema.
            </p>
            <Button 
              onClick={() => openAddDialog("plataforma")} 
              variant="brand" 
              className="flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Adicionar Plataforma
            </Button>
          </div>
          
          {loading ? (
            <div className="flex justify-center p-8">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-brand-primary border-t-transparent"></div>
            </div>
          ) : plataformas.length === 0 ? (
            <div className="text-center p-8 bg-gray-50 rounded-lg border border-gray-200">
              <p className="text-gray-600">Nenhuma plataforma social cadastrada.</p>
              <Button onClick={() => openAddDialog("plataforma")} variant="link" className="mt-2">
                Adicionar a primeira plataforma
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {plataformas.map((plataforma) => (
                <div 
                  key={plataforma.id} 
                  className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                  style={{
                    borderLeft: `4px solid ${plataforma.cor}`
                  }}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-3">
                      <div 
                        className="h-10 w-10 rounded-full flex items-center justify-center text-white"
                        style={{ backgroundColor: plataforma.cor }}
                      >
                        {/* Placeholder para ícone - em produção usaríamos lucide-react ou outro sistema de ícones */}
                        <span className="font-bold text-sm">
                          {plataforma.nome.substring(0, 1).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{plataforma.nome}</h4>
                        <p className="text-xs text-gray-500">Icon: {plataforma.icon}</p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditDialog("plataforma", plataforma)}
                        title="Editar"
                        className="h-8 w-8"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openDeleteDialog("plataforma", plataforma)}
                        title="Excluir"
                        className="h-8 w-8"
                      >
                        <Trash2 className="h-4 w-4 text-red-600" />
                      </Button>
                    </div>
                  </div>
                  <div className="mt-2 flex items-center">
                    <span 
                      className="inline-block w-4 h-4 rounded-full mr-2"
                      style={{ backgroundColor: plataforma.cor }}
                    ></span>
                    <span className="text-xs font-mono">{plataforma.cor}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Dialog para adicionar ou editar configuração/plataforma */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {dialogType === "config"
                ? editingConfig ? "Editar Configuração" : "Adicionar Configuração"
                : editingPlataforma ? "Editar Plataforma" : "Adicionar Plataforma"
              }
            </DialogTitle>
            <DialogDescription>
              {dialogType === "config"
                ? editingConfig ? "Faça as alterações necessárias e salve." : "Preencha os campos para adicionar uma nova configuração."
                : editingPlataforma ? "Faça as alterações necessárias e salve." : "Preencha os campos para adicionar uma nova plataforma."
              }
            </DialogDescription>
          </DialogHeader>
          
          {dialogType === "config" && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="chave" className="text-sm font-medium">
                  Chave *
                </label>
                <Input
                  id="chave"
                  placeholder="Ex: limiteUsuariosGratuitos, comissaoPadrao..."
                  value={editingConfig ? editingConfig.chave : newConfig.chave}
                  onChange={(e) => {
                    if (editingConfig) {
                      setEditingConfig({ ...editingConfig, chave: e.target.value });
                    } else {
                      setNewConfig({ ...newConfig, chave: e.target.value });
                    }
                  }}
                  className="focus:border-brand-primary"
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="valor" className="text-sm font-medium">
                  Valor *
                </label>
                <Input
                  id="valor"
                  placeholder="Ex: 100, 10%, true..."
                  value={editingConfig ? editingConfig.valor : newConfig.valor}
                  onChange={(e) => {
                    if (editingConfig) {
                      setEditingConfig({ ...editingConfig, valor: e.target.value });
                    } else {
                      setNewConfig({ ...newConfig, valor: e.target.value });
                    }
                  }}
                  className="focus:border-brand-primary"
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="descricao" className="text-sm font-medium">
                  Descrição
                </label>
                <Input
                  id="descricao"
                  placeholder="Explique o propósito desta configuração"
                  value={editingConfig ? editingConfig.descricao || "" : newConfig.descricao}
                  onChange={(e) => {
                    if (editingConfig) {
                      setEditingConfig({ ...editingConfig, descricao: e.target.value });
                    } else {
                      setNewConfig({ ...newConfig, descricao: e.target.value });
                    }
                  }}
                  className="focus:border-brand-primary"
                />
              </div>
            </div>
          )}
          
          {dialogType === "plataforma" && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="nome" className="text-sm font-medium">
                  Nome da Plataforma *
                </label>
                <Input
                  id="nome"
                  placeholder="Ex: Instagram, TikTok, YouTube..."
                  value={editingPlataforma ? editingPlataforma.nome : newPlataforma.nome}
                  onChange={(e) => {
                    if (editingPlataforma) {
                      setEditingPlataforma({ ...editingPlataforma, nome: e.target.value });
                    } else {
                      setNewPlataforma({ ...newPlataforma, nome: e.target.value });
                    }
                  }}
                  className="focus:border-brand-primary"
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="icon" className="text-sm font-medium">
                  Identificador do Ícone *
                </label>
                <Input
                  id="icon"
                  placeholder="Ex: instagram, tiktok, youtube..."
                  value={editingPlataforma ? editingPlataforma.icon : newPlataforma.icon}
                  onChange={(e) => {
                    if (editingPlataforma) {
                      setEditingPlataforma({ ...editingPlataforma, icon: e.target.value });
                    } else {
                      setNewPlataforma({ ...newPlataforma, icon: e.target.value });
                    }
                  }}
                  className="focus:border-brand-primary"
                />
                <p className="text-xs text-gray-500">Identificador usado para mostrar o ícone da plataforma</p>
              </div>
              <div className="grid gap-2">
                <label htmlFor="cor" className="text-sm font-medium">
                  Cor da Marca *
                </label>
                <div className="flex gap-3">
                  <Input
                    id="cor"
                    type="color"
                    value={editingPlataforma ? editingPlataforma.cor : newPlataforma.cor}
                    onChange={(e) => {
                      if (editingPlataforma) {
                        setEditingPlataforma({ ...editingPlataforma, cor: e.target.value });
                      } else {
                        setNewPlataforma({ ...newPlataforma, cor: e.target.value });
                      }
                    }}
                    className="w-14 p-1 h-10"
                  />
                  <Input
                    value={editingPlataforma ? editingPlataforma.cor : newPlataforma.cor}
                    onChange={(e) => {
                      if (editingPlataforma) {
                        setEditingPlataforma({ ...editingPlataforma, cor: e.target.value });
                      } else {
                        setNewPlataforma({ ...newPlataforma, cor: e.target.value });
                      }
                    }}
                    placeholder="#000000"
                    className="flex-1 focus:border-brand-primary"
                  />
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={() => {
                if (dialogType === "config") {
                  editingConfig ? handleUpdateConfig() : handleAddConfig();
                } else {
                  editingPlataforma ? handleUpdatePlataforma() : handleAddPlataforma();
                }
              }}
              disabled={loading}
              variant="brand"
            >
              {loading ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2"></span>
                  Processando...
                </>
              ) : dialogType === "config" ? (
                editingConfig ? "Salvar alterações" : "Adicionar configuração"
              ) : (
                editingPlataforma ? "Salvar alterações" : "Adicionar plataforma"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog para confirmar exclusão */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {dialogType === "config" 
                ? "Excluir configuração"
                : "Excluir plataforma"
              }
            </AlertDialogTitle>
            <AlertDialogDescription>
              {dialogType === "config" && editingConfig && (
                <>Tem certeza que deseja excluir a configuração "{editingConfig.chave}"?</>
              )}
              {dialogType === "plataforma" && editingPlataforma && (
                <>Tem certeza que deseja excluir a plataforma "{editingPlataforma.nome}"?</>
              )}
              <br />
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => {
                if (dialogType === "config") {
                  handleDeleteConfig();
                } else {
                  handleDeletePlataforma();
                }
              }}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {loading ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2"></span>
                  Excluindo...
                </>
              ) : (
                "Excluir"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
