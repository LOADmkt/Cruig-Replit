
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export function AdminNotificationSystem() {
  const { toast } = useToast();
  const [emailEnabled, setEmailEnabled] = useState(true);
  const [whatsappEnabled, setWhatsappEnabled] = useState(true);
  const [inAppEnabled, setInAppEnabled] = useState(true);
  
  const [reminderDays, setReminderDays] = useState("7");
  const [emailSubject, setEmailSubject] = useState("Sua assinatura está prestes a expirar");
  const [emailTemplate, setEmailTemplate] = useState(
    "Olá {nome},\n\nSua assinatura do plano {plano} está prestes a expirar em {dias} dias.\n\nRenove agora para continuar aproveitando todos os benefícios.\n\nAtenciosamente,\nEquipe de Suporte"
  );
  const [whatsappTemplate, setWhatsappTemplate] = useState(
    "Olá {nome}! Sua assinatura do plano {plano} expira em {dias} dias. Renove agora para continuar aproveitando todos os benefícios."
  );
  
  const handleSaveSettings = () => {
    toast({
      title: "Configurações salvas",
      description: "As configurações de notificação foram atualizadas com sucesso.",
    });
  };
  
  const handleSendTestNotification = () => {
    toast({
      title: "Notificação de teste enviada",
      description: "Uma notificação de teste foi enviada para você.",
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Sistema de Notificações</h2>
        <p className="text-gray-600">
          Configure as notificações automáticas para renovação de assinatura e outros eventos importantes.
        </p>
      </div>
      
      <Tabs defaultValue="subscription">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="subscription">Renovação de Assinatura</TabsTrigger>
          <TabsTrigger value="campaign">Campanhas</TabsTrigger>
          <TabsTrigger value="system">Sistema</TabsTrigger>
        </TabsList>
        
        <TabsContent value="subscription" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Notificação de Assinatura</CardTitle>
              <CardDescription>
                Configure quando e como os usuários serão notificados sobre a renovação de suas assinaturas.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Canais de Notificação</h4>
                    <p className="text-sm text-gray-500">Selecione os canais que deseja utilizar</p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <Switch 
                        id="email-notifications" 
                        checked={emailEnabled}
                        onCheckedChange={setEmailEnabled}
                      />
                      <Label htmlFor="email-notifications">Email</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch 
                        id="whatsapp-notifications" 
                        checked={whatsappEnabled}
                        onCheckedChange={setWhatsappEnabled}
                      />
                      <Label htmlFor="whatsapp-notifications">WhatsApp</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch 
                        id="inapp-notifications" 
                        checked={inAppEnabled}
                        onCheckedChange={setInAppEnabled}
                      />
                      <Label htmlFor="inapp-notifications">No Aplicativo</Label>
                    </div>
                  </div>
                </div>
                
                <div className="border-t pt-4">
                  <h4 className="font-medium mb-2">Período de Lembretes</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="reminder-days">Dias antes do vencimento</Label>
                      <Select value={reminderDays} onValueChange={setReminderDays}>
                        <SelectTrigger id="reminder-days">
                          <SelectValue placeholder="Selecione os dias" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 dia</SelectItem>
                          <SelectItem value="3">3 dias</SelectItem>
                          <SelectItem value="5">5 dias</SelectItem>
                          <SelectItem value="7">7 dias</SelectItem>
                          <SelectItem value="14">14 dias</SelectItem>
                          <SelectItem value="30">30 dias</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </div>
              
              {emailEnabled && (
                <div className="border-t pt-4">
                  <h4 className="font-medium mb-4">Template de Email</h4>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email-subject">Assunto</Label>
                      <Input
                        id="email-subject"
                        value={emailSubject}
                        onChange={(e) => setEmailSubject(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email-template">Conteúdo do Email</Label>
                      <Textarea
                        id="email-template"
                        value={emailTemplate}
                        onChange={(e) => setEmailTemplate(e.target.value)}
                        rows={6}
                      />
                      <p className="text-xs text-gray-500">
                        Use as variáveis <code>{"{nome}"}</code>, <code>{"{plano}"}</code>, <code>{"{dias}"}</code>, etc. para personalização.
                      </p>
                    </div>
                  </div>
                </div>
              )}
              
              {whatsappEnabled && (
                <div className="border-t pt-4">
                  <h4 className="font-medium mb-4">Template de WhatsApp</h4>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="whatsapp-template">Mensagem</Label>
                      <Textarea
                        id="whatsapp-template"
                        value={whatsappTemplate}
                        onChange={(e) => setWhatsappTemplate(e.target.value)}
                        rows={4}
                      />
                      <p className="text-xs text-gray-500">
                        Use as variáveis <code>{"{nome}"}</code>, <code>{"{plano}"}</code>, <code>{"{dias}"}</code>, etc. para personalização.
                      </p>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="flex space-x-4 pt-2">
                <Button onClick={handleSaveSettings}>Salvar Configurações</Button>
                <Button variant="outline" onClick={handleSendTestNotification}>Enviar Notificação de Teste</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="campaign" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Notificações de Campanhas</CardTitle>
              <CardDescription>
                Configure notificações relacionadas a campanhas e interações.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-40">
                <p className="text-gray-500">Configurações de notificação de campanhas estarão disponíveis em breve.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="system" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Notificações do Sistema</CardTitle>
              <CardDescription>
                Configure notificações sobre manutenção, atualizações e outros eventos do sistema.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-40">
                <p className="text-gray-500">Configurações de notificação do sistema estarão disponíveis em breve.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
