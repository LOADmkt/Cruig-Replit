
import React from 'react';
import MRRChart from './charts/MRRChart';
import RetentionChart from './charts/RetentionChart';
import UserGrowthChart from './charts/UserGrowthChart';
import ConversionChart from './charts/ConversionChart';
import PlanDistributionChart from './charts/PlanDistributionChart';
import { 
  mrrData, 
  userData, 
  conversaoData, 
  retencaoData, 
  planosData,
  COLORS,
  CONVERSION_COLORS
} from './data/dashboardData';

const DashboardCharts: React.FC = () => {
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <MRRChart data={mrrData} />
      <RetentionChart data={retencaoData} />
      <UserGrowthChart data={userData} />
      <ConversionChart data={conversaoData} colors={CONVERSION_COLORS} />
      <PlanDistributionChart data={planosData} colors={COLORS} />
    </div>
  );
};

export default DashboardCharts;
