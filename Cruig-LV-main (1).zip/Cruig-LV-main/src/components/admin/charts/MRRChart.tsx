
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer } from "@/components/ui/chart";
import { AreaChart, XAxis, YAxis, Tooltip, Legend, Area } from "recharts";

interface MRRChartProps {
  data: Array<{ month: string; valor: number }>;
}

const MRRChart: React.FC<MRRChartProps> = ({ data }) => {
  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle>MRR (Receita Mensal Recorrente)</CardTitle>
        <CardDescription>Crescimento nos últimos 12 meses</CardDescription>
      </CardHeader>
      <CardContent className="pl-2">
        <ChartContainer 
          config={{ 
            area: { label: "Receita", color: "#99c00d" },
            line: { label: "Tendência", color: "#333333" }
          }} 
          className="h-[300px]"
        >
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorMrr" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#99c00d" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#99c00d" stopOpacity={0.1}/>
              </linearGradient>
            </defs>
            <XAxis dataKey="month" />
            <YAxis 
              tickFormatter={(value) => `R$ ${value / 1000}k`}
            />
            <Tooltip 
              formatter={(value) => [`R$ ${value}`, "Receita"]}
              labelFormatter={(label) => `Mês: ${label}`}
            />
            <Legend />
            <Area 
              type="monotone" 
              dataKey="valor" 
              stroke="#99c00d" 
              fillOpacity={1} 
              fill="url(#colorMrr)" 
            />
          </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
};

export default MRRChart;
