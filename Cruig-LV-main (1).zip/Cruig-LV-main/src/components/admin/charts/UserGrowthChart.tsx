
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer } from "@/components/ui/chart";
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend } from "recharts";

interface UserGrowthChartProps {
  data: Array<{ name: string; usuarios: number }>;
}

const UserGrowthChart: React.FC<UserGrowthChartProps> = ({ data }) => {
  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle>Crescimento de Usuários</CardTitle>
        <CardDescription>Usuários ativos por mês</CardDescription>
      </CardHeader>
      <CardContent className="pl-2">
        <ChartContainer config={{ line: { label: "Usuários", color: "#99c00d" } }} className="h-[300px]">
          <LineChart data={data}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="usuarios" stroke="#99c00d" strokeWidth={2} />
          </LineChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
};

export default UserGrowthChart;
