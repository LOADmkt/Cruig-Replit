
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from "recharts";

interface RetentionChartProps {
  data: Array<{ name: string; taxa: number }>;
}

const RetentionChart: React.FC<RetentionChartProps> = ({ data }) => {
  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle>Retenção de Clientes</CardTitle>
        <CardDescription>Taxa de retenção por mês de assinatura</CardDescription>
      </CardHeader>
      <CardContent className="pl-2">
        <ChartContainer config={{ bar: { label: "Taxa", color: "#333333" } }} className="h-[300px]">
          <BarChart data={data}>
            <XAxis dataKey="name" />
            <YAxis domain={[0, 100]} tickFormatter={(value) => `${value}%`} />
            <Tooltip formatter={(value) => [`${value}%`, "Taxa de Retenção"]} />
            <Legend />
            <Bar dataKey="taxa" fill="#333333" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
};

export default RetentionChart;
