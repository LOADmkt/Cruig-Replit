
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, Cell } from "recharts";

interface ConversionChartProps {
  data: Array<{ name: string; count: number }>;
  colors: string[];
}

const ConversionChart: React.FC<ConversionChartProps> = ({ data, colors }) => {
  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle>Conversão de Campanhas</CardTitle>
        <CardDescription>Funil de conversão de campanhas</CardDescription>
      </CardHeader>
      <CardContent className="pl-2">
        <ChartContainer config={{ bar: { label: "Quantidade", color: "#333333" } }} className="h-[300px]">
          <BarChart data={data}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="count" fill="#333333">
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
              ))}
            </Bar>
          </BarChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
};

export default ConversionChart;
