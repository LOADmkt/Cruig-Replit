
// Enhanced data for MRR tracking over the past year
export const mrrData = [
  { month: "Jul", valor: 14000 },
  { month: "Ago", valor: 15500 },
  { month: "Set", valor: 17000 },
  { month: "Out", valor: 18500 },
  { month: "Nov", valor: 20000 },
  { month: "Dez", valor: 21500 },
  { month: "Jan", valor: 23000 },
  { month: "Fev", valor: 24500 },
  { month: "Mar", valor: 24950 },
  { month: "Abr", valor: 27000 },
  { month: "Mai", valor: 29000 },
  { month: "Jun", valor: 30500 }
];

export const userData = [
  { name: "Jan", usuarios: 40 },
  { name: "Fev", usuarios: 45 },
  { name: "Mar", usuarios: 55 },
  { name: "Abr", usuarios: 60 },
  { name: "Mai", usuarios: 75 },
  { name: "Jun", usuarios: 85 }
];

export const receitaData = [
  { name: "Jan", valor: 4000 },
  { name: "Fev", valor: 4500 },
  { name: "Mar", valor: 5500 },
  { name: "Abr", valor: 6000 },
  { name: "Mai", valor: 7500 },
  { name: "Jun", valor: 8500 }
];

export const planosData = [
  { name: "Básico", value: 45 },
  { name: "Premium", value: 30 },
  { name: "Enterprise", value: 25 }
];

export const conversaoData = [
  { name: "Visualizações", count: 1240 },
  { name: "Inscrições", count: 420 },
  { name: "Contratações", count: 98 },
];

export const retencaoData = [
  { name: "1º Mês", taxa: 95 },
  { name: "2º Mês", taxa: 88 },
  { name: "3º Mês", taxa: 82 },
  { name: "4º Mês", taxa: 78 },
  { name: "5º Mês", taxa: 75 },
  { name: "6º Mês", taxa: 72 },
];

export const COLORS = ["#99c00d", "#333333", "#6A5797"];
export const CONVERSION_COLORS = ["#e0e0e0", "#a5d6a7", "#66bb6a"];

export const dashboardStats = [
  {
    title: "Total de Usuários",
    value: "358",
    description: "+14% desde o último mês",
    icon: "Users",
    iconBg: "bg-brand-primary/20",
    iconColor: "text-brand-primary"
  },
  {
    title: "Receita Mensal (MRR)",
    value: "R$ 24.950",
    description: "+8% desde o último mês",
    icon: "DollarSign",
    iconBg: "bg-green-100",
    iconColor: "text-green-600"
  },
  {
    title: "Taxa de Crescimento",
    value: "12%",
    description: "2% maior que o mês anterior",
    icon: "TrendingUp",
    iconBg: "bg-blue-100",
    iconColor: "text-blue-600"
  },
  {
    title: "Contas Inadimplentes",
    value: "7",
    description: "2 novas desde a semana passada",
    icon: "AlertCircle",
    iconBg: "bg-red-100",
    iconColor: "text-red-500"
  },
  {
    title: "Taxa de Renovação",
    value: "92%",
    description: "3% maior que o mês anterior",
    icon: "Repeat",
    iconBg: "bg-purple-100",
    iconColor: "text-purple-600"
  },
  {
    title: "Conversão de Campanhas",
    value: "7.9%",
    description: "1.2% maior que a média",
    icon: "CheckCircle",
    iconBg: "bg-amber-100",
    iconColor: "text-amber-600"
  }
];
