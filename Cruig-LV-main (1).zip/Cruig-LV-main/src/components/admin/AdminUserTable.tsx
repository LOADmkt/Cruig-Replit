
import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, Eye, Ban, CheckCircle } from "lucide-react";

interface User {
  id: string;
  name: string;
  email: string;
  type: 'empresa' | 'criador' | 'admin';
  status: 'ativo' | 'inativo' | 'banido';
  registeredAt: string;
}

interface AdminUserTableProps {
  users: User[];
}

export function AdminUserTable({ users }: AdminUserTableProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
  };
  
  const getUserTypeBadge = (type: 'empresa' | 'criador' | 'admin') => {
    switch(type) {
      case 'empresa':
        return <Badge className="bg-brand-tertiary">Empresa</Badge>;
      case 'criador':
        return <Badge className="bg-brand-primary">Criador</Badge>;
      case 'admin':
        return <Badge className="bg-brand-darkGray">Admin</Badge>;
      default:
        return <Badge>{type}</Badge>;
    }
  };
  
  const handleViewUser = (id: string) => {
    console.log('Ver usuário:', id);
    // Navigate to user profile
  };
  
  const handleEditUser = (id: string) => {
    console.log('Editar usuário:', id);
    // Open edit modal
  };
  
  const handleToggleUserStatus = (id: string, currentStatus: string) => {
    console.log(`Alternar status do usuário ${id} de ${currentStatus}`);
    // API call to toggle user status
  };
  
  if (!users || users.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Nenhum usuário encontrado.</p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border shadow-sm overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Tipo</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Registro</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.map((user) => (
            <TableRow key={user.id}>
              <TableCell className="font-medium">{user.name}</TableCell>
              <TableCell>{user.email}</TableCell>
              <TableCell>{getUserTypeBadge(user.type)}</TableCell>
              <TableCell>
                {user.status === 'ativo' ? (
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    Ativo
                  </Badge>
                ) : user.status === 'banido' ? (
                  <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                    Banido
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                    Inativo
                  </Badge>
                )}
              </TableCell>
              <TableCell>{formatDate(user.registeredAt)}</TableCell>
              <TableCell className="text-right space-x-2">
                <Button variant="ghost" size="sm" onClick={() => handleViewUser(user.id)}>
                  <Eye className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={() => handleEditUser(user.id)}>
                  <Edit className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => handleToggleUserStatus(user.id, user.status)}
                  className={user.status === 'ativo' ? 'text-red-500 hover:text-red-700' : 'text-green-500 hover:text-green-700'}
                >
                  {user.status === 'ativo' ? <Ban className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
