
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, AlertCircle, User, DollarSign, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabaseClient';

interface WithdrawalRequest {
  id: string;
  creatorId: string;
  creatorName: string;
  email: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
  processedAt?: string;
}

export function AdminAffiliateManagement() {
  const { toast } = useToast();
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>([]);
  const [loading, setLoading] = useState<{[id: string]: boolean}>({});
  
  // Load withdrawal requests
  useEffect(() => {
    const fetchWithdrawalRequests = async () => {
      try {
        // In a real implementation, this would fetch from Supabase
        const { data, error } = await supabase
          .from('withdrawal_requests')
          .select(`
            id,
            amount,
            status,
            created_at,
            processed_at,
            creator_id,
            profiles(name, email)
          `)
          .order('created_at', { ascending: false });
          
        if (error) throw error;
        
        const formattedRequests: WithdrawalRequest[] = data ? data.map((item: any) => ({
          id: item.id,
          creatorId: item.creator_id,
          creatorName: item.profiles?.name || 'Unknown Creator',
          email: item.profiles?.email || 'unknown@email.com',
          amount: item.amount,
          status: item.status || 'pending',
          requestedAt: item.created_at,
          processedAt: item.processed_at,
        })) : [];
        
        setWithdrawalRequests(formattedRequests);
      } catch (error) {
        console.error('Error fetching withdrawal requests:', error);
        
        // For demo purposes, load mock data if fetching fails
        const mockWithdrawalRequests: WithdrawalRequest[] = [
          {
            id: '1',
            creatorId: '101',
            creatorName: 'Ana Carolina Silva',
            email: 'ana@email.com',
            amount: 175.00,
            status: 'pending',
            requestedAt: '2024-04-15T14:30:00Z'
          },
          {
            id: '2',
            creatorId: '102',
            creatorName: 'Bruno Almeida',
            email: 'bruno@email.com',
            amount: 125.00,
            status: 'pending',
            requestedAt: '2024-04-17T09:15:00Z'
          },
          {
            id: '3',
            creatorId: '103',
            creatorName: 'Carla Mendonça',
            email: 'carla@email.com',
            amount: 250.00,
            status: 'approved',
            requestedAt: '2024-04-10T16:45:00Z',
            processedAt: '2024-04-12T11:20:00Z'
          },
          {
            id: '4',
            creatorId: '104',
            creatorName: 'Daniel Oliveira',
            email: 'daniel@email.com',
            amount: 100.00,
            status: 'rejected',
            requestedAt: '2024-04-09T13:10:00Z',
            processedAt: '2024-04-11T10:30:00Z'
          },
          {
            id: '5',
            creatorId: '105',
            creatorName: 'Eduarda Santos',
            email: 'eduarda@email.com',
            amount: 350.00,
            status: 'approved',
            requestedAt: '2024-04-05T15:25:00Z',
            processedAt: '2024-04-07T14:15:00Z'
          }
        ];
        
        setWithdrawalRequests(mockWithdrawalRequests);
      }
    };
    
    fetchWithdrawalRequests();
  }, []);
  
  const handleApprove = async (requestId: string) => {
    setLoading(prev => ({ ...prev, [requestId]: true }));
    
    try {
      // In a real implementation, this would update the withdrawal request in Supabase
      await supabase
        .from('withdrawal_requests')
        .update({
          status: 'approved',
          processed_at: new Date().toISOString()
        })
        .eq('id', requestId);
      
      // Update local state
      setWithdrawalRequests(prev => 
        prev.map(request => 
          request.id === requestId 
            ? { 
                ...request, 
                status: 'approved', 
                processedAt: new Date().toISOString() 
              } 
            : request
        )
      );
      
      toast({
        title: "Solicitação aprovada",
        description: "A solicitação de saque foi aprovada com sucesso.",
      });
    } catch (error) {
      console.error('Error approving withdrawal:', error);
      toast({
        title: "Erro ao aprovar solicitação",
        description: "Ocorreu um erro ao processar a ação. Por favor, tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(prev => ({ ...prev, [requestId]: false }));
    }
  };
  
  const handleReject = async (requestId: string) => {
    setLoading(prev => ({ ...prev, [requestId]: true }));
    
    try {
      // In a real implementation, this would update the withdrawal request in Supabase
      await supabase
        .from('withdrawal_requests')
        .update({
          status: 'rejected',
          processed_at: new Date().toISOString()
        })
        .eq('id', requestId);
      
      // Update local state
      setWithdrawalRequests(prev => 
        prev.map(request => 
          request.id === requestId 
            ? { 
                ...request, 
                status: 'rejected', 
                processedAt: new Date().toISOString() 
              } 
            : request
        )
      );
      
      toast({
        title: "Solicitação rejeitada",
        description: "A solicitação de saque foi rejeitada.",
      });
    } catch (error) {
      console.error('Error rejecting withdrawal:', error);
      toast({
        title: "Erro ao rejeitar solicitação",
        description: "Ocorreu um erro ao processar a ação. Por favor, tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(prev => ({ ...prev, [requestId]: false }));
    }
  };
  
  // Filter requests by status
  const pendingRequests = withdrawalRequests.filter(req => req.status === 'pending');
  const processedRequests = withdrawalRequests.filter(req => req.status !== 'pending');
  
  // Calculate total amounts
  const totalPendingAmount = pendingRequests.reduce((sum, req) => sum + req.amount, 0);
  const totalApprovedAmount = processedRequests
    .filter(req => req.status === 'approved')
    .reduce((sum, req) => sum + req.amount, 0);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Gerenciamento de Afiliados</h2>
        <p className="text-gray-600">
          Gerencie todas as solicitações de saque do programa de afiliados
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl font-bold text-amber-600">
              {pendingRequests.length}
            </CardTitle>
            <CardDescription>Solicitações pendentes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-2 text-amber-600" />
              <span className="text-sm text-gray-600">Aguardando aprovação</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl font-bold text-green-600">
              R$ {totalPendingAmount.toFixed(2)}
            </CardTitle>
            <CardDescription>Valor pendente total</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <DollarSign className="h-4 w-4 mr-2 text-green-600" />
              <span className="text-sm text-gray-600">A ser pago</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl font-bold text-brand-primary">
              R$ {totalApprovedAmount.toFixed(2)}
            </CardTitle>
            <CardDescription>Total aprovado (histórico)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <User className="h-4 w-4 mr-2 text-brand-primary" />
              <span className="text-sm text-gray-600">{processedRequests.filter(req => req.status === 'approved').length} afiliados pagos</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <AlertCircle className="h-5 w-5 mr-2 text-amber-500" />
            Solicitações pendentes
          </CardTitle>
          <CardDescription>
            Revise e aprove ou rejeite as solicitações de saque dos afiliados
          </CardDescription>
        </CardHeader>
        <CardContent>
          {pendingRequests.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              Não há solicitações pendentes no momento
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Criador</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Data solicitada</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingRequests.map((request) => (
                    <TableRow key={request.id}>
                      <TableCell className="font-medium">{request.creatorName}</TableCell>
                      <TableCell>{request.email}</TableCell>
                      <TableCell>{new Date(request.requestedAt).toLocaleDateString('pt-BR')}</TableCell>
                      <TableCell>R$ {request.amount.toFixed(2)}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                          Pendente
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 border-green-200 text-green-700 hover:bg-green-50 hover:text-green-800"
                            onClick={() => handleApprove(request.id)}
                            disabled={loading[request.id]}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" /> 
                            {loading[request.id] ? 'Aprovando...' : 'Aprovar'}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 border-red-200 text-red-700 hover:bg-red-50 hover:text-red-800"
                            onClick={() => handleReject(request.id)}
                            disabled={loading[request.id]}
                          >
                            <XCircle className="h-4 w-4 mr-1" /> 
                            {loading[request.id] ? 'Rejeitando...' : 'Rejeitar'}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Histórico de solicitações</CardTitle>
          <CardDescription>
            Solicitações de saque já processadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          {processedRequests.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              Não há histórico de solicitações processadas
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Criador</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Solicitado em</TableHead>
                    <TableHead>Processado em</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {processedRequests.map((request) => (
                    <TableRow key={request.id}>
                      <TableCell className="font-medium">{request.creatorName}</TableCell>
                      <TableCell>{request.email}</TableCell>
                      <TableCell>{new Date(request.requestedAt).toLocaleDateString('pt-BR')}</TableCell>
                      <TableCell>{request.processedAt ? new Date(request.processedAt).toLocaleDateString('pt-BR') : '-'}</TableCell>
                      <TableCell>R$ {request.amount.toFixed(2)}</TableCell>
                      <TableCell>
                        {request.status === 'approved' ? (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Aprovado
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                            Rejeitado
                          </Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
