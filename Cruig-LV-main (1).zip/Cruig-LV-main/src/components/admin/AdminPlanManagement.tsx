
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { PlusCircle, Edit2, History, Save, X, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getCreatorPlans, getCompanyPlans } from "@/lib/subscriptionPlans";

export function AdminPlanManagement() {
  const { toast } = useToast();
  const [currentTab, setCurrentTab] = useState("creator");
  const [creatorPlans, setCreatorPlans] = useState(getCreatorPlans());
  const [companyPlans, setCompanyPlans] = useState(getCompanyPlans());
  const [editingPlan, setEditingPlan] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  const [planHistory] = useState([
    { 
      id: 1, 
      date: "15/05/2023", 
      action: "Alteração de preço", 
      details: "Plano Semestral (Criador) alterado de R$137 para R$127", 
      user: "Admin" 
    },
    { 
      id: 2, 
      date: "10/04/2023", 
      action: "Nova funcionalidade", 
      details: "Adicionado 'Destaque no resultado de buscas' ao plano Mensal (Criador)", 
      user: "Admin" 
    },
    { 
      id: 3, 
      date: "28/03/2023", 
      action: "Alteração de preço", 
      details: "Plano Anual (Empresa) alterado de R$1.600 para R$1.524", 
      user: "Admin" 
    },
  ]);
  
  const handleEditPlan = (plan: any) => {
    setEditingPlan({...plan});
    setIsDialogOpen(true);
  };
  
  const handleSavePlan = () => {
    if (currentTab === "creator") {
      setCreatorPlans(prevPlans => 
        prevPlans.map(plan => 
          plan.id === editingPlan.id ? editingPlan : plan
        )
      );
    } else {
      setCompanyPlans(prevPlans => 
        prevPlans.map(plan => 
          plan.id === editingPlan.id ? editingPlan : plan
        )
      );
    }
    
    setIsDialogOpen(false);
    toast({
      title: "Plano atualizado",
      description: `As alterações no plano ${editingPlan.name} foram salvas com sucesso.`,
    });
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Gestão de Planos</h2>
        <p className="text-gray-600">
          Configure os planos de assinatura disponíveis para criadores e empresas.
        </p>
      </div>
      
      <Tabs value={currentTab} onValueChange={setCurrentTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="creator">Planos para Criadores</TabsTrigger>
          <TabsTrigger value="company">Planos para Empresas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="creator" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <div>
                  <CardTitle>Planos para Criadores</CardTitle>
                  <CardDescription>Configure os planos disponíveis para criadores de conteúdo</CardDescription>
                </div>
                <Button className="w-full sm:w-auto">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Adicionar Plano
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Preço</TableHead>
                      <TableHead>Período</TableHead>
                      <TableHead>Popular</TableHead>
                      <TableHead>Benefícios</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {creatorPlans.map((plan) => (
                      <TableRow key={plan.id}>
                        <TableCell className="font-medium">{plan.name}</TableCell>
                        <TableCell>{plan.price}</TableCell>
                        <TableCell>{plan.period}</TableCell>
                        <TableCell>
                          {plan.popular ? 
                            <Check className="h-5 w-5 text-green-600" /> : 
                            <X className="h-5 w-5 text-gray-400" />
                          }
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <span className="truncate max-w-[200px]">
                              {plan.features.length} benefícios
                            </span>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="link" className="h-auto p-0 ml-2">Ver</Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Benefícios do plano {plan.name}</DialogTitle>
                                </DialogHeader>
                                <div className="py-4">
                                  <ul className="list-disc pl-5 space-y-2">
                                    {plan.features.map((feature, i) => (
                                      <li key={i}>{feature}</li>
                                    ))}
                                  </ul>
                                </div>
                              </DialogContent>
                            </Dialog>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm" onClick={() => handleEditPlan(plan)}>
                            <Edit2 className="h-4 w-4" />
                            <span className="sr-only">Editar</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="company" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <div>
                  <CardTitle>Planos para Empresas</CardTitle>
                  <CardDescription>Configure os planos disponíveis para empresas</CardDescription>
                </div>
                <Button className="w-full sm:w-auto">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Adicionar Plano
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Preço</TableHead>
                      <TableHead>Período</TableHead>
                      <TableHead>Popular</TableHead>
                      <TableHead>Benefícios</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {companyPlans.map((plan) => (
                      <TableRow key={plan.id}>
                        <TableCell className="font-medium">{plan.name}</TableCell>
                        <TableCell>{plan.price}</TableCell>
                        <TableCell>{plan.period}</TableCell>
                        <TableCell>
                          {plan.popular ? 
                            <Check className="h-5 w-5 text-green-600" /> : 
                            <X className="h-5 w-5 text-gray-400" />
                          }
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <span className="truncate max-w-[200px]">
                              {plan.features.length} benefícios
                            </span>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="link" className="h-auto p-0 ml-2">Ver</Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Benefícios do plano {plan.name}</DialogTitle>
                                </DialogHeader>
                                <div className="py-4">
                                  <ul className="list-disc pl-5 space-y-2">
                                    {plan.features.map((feature, i) => (
                                      <li key={i}>{feature}</li>
                                    ))}
                                  </ul>
                                </div>
                              </DialogContent>
                            </Dialog>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm" onClick={() => handleEditPlan(plan)}>
                            <Edit2 className="h-4 w-4" />
                            <span className="sr-only">Editar</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <Card>
        <CardHeader>
          <CardTitle>Histórico de Alterações</CardTitle>
          <CardDescription>
            Registro de todas as modificações realizadas nos planos
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Ação</TableHead>
                  <TableHead>Detalhes</TableHead>
                  <TableHead>Usuário</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {planHistory.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{item.date}</TableCell>
                    <TableCell>{item.action}</TableCell>
                    <TableCell>{item.details}</TableCell>
                    <TableCell>{item.user}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          <div className="mt-4 flex justify-between">
            <Button variant="outline" className="gap-1">
              <History className="h-4 w-4" /> Ver histórico completo
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* Dialog para edição de plano */}
      {editingPlan && (
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Editar Plano {editingPlan.name}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="plan-name">Nome do Plano</Label>
                <Input 
                  id="plan-name" 
                  value={editingPlan.name}
                  onChange={(e) => setEditingPlan({...editingPlan, name: e.target.value})}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="plan-price">Preço</Label>
                  <Input 
                    id="plan-price" 
                    value={editingPlan.price}
                    onChange={(e) => setEditingPlan({...editingPlan, price: e.target.value})}
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="plan-period">Período</Label>
                  <Input 
                    id="plan-period" 
                    value={editingPlan.period}
                    onChange={(e) => setEditingPlan({...editingPlan, period: e.target.value})}
                  />
                </div>
              </div>
              
              <Separator />
              
              <div>
                <Label className="mb-2 block">Benefícios (um por linha)</Label>
                <textarea
                  className="w-full min-h-[100px] p-2 border rounded-md"
                  value={editingPlan.features.join('\n')}
                  onChange={(e) => setEditingPlan({
                    ...editingPlan, 
                    features: e.target.value.split('\n').filter(line => line.trim() !== '')
                  })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancelar</Button>
              <Button onClick={handleSavePlan} className="gap-1">
                <Save className="h-4 w-4" /> Salvar Alterações
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
