
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableHead, TableRow, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Check, X, Search, ArrowUpDown } from "lucide-react";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Dados de exemplo para afiliados
const affiliatesData = [
  { 
    id: 1, 
    name: "Ana Silva", 
    email: "ana.silva@example.com", 
    balance: 150, 
    pendingWithdrawal: 0, 
    totalEarned: 300, 
    referralsCount: 10,
    status: "active",
    lastWithdrawal: "10/06/2023",
  },
  { 
    id: 2, 
    name: "Carlos Mendes", 
    email: "carlos.mendes@example.com", 
    balance: 75, 
    pendingWithdrawal: 75, 
    totalEarned: 225, 
    referralsCount: 7,
    status: "active",
    lastWithdrawal: "05/05/2023",
  },
  { 
    id: 3, 
    name: "Juliana Costa", 
    email: "juliana.costa@example.com", 
    balance: 30, 
    pendingWithdrawal: 0, 
    totalEarned: 120, 
    referralsCount: 4,
    status: "inactive",
    lastWithdrawal: "20/04/2023",
  },
  { 
    id: 4, 
    name: "Pedro Santos", 
    email: "pedro.santos@example.com", 
    balance: 210, 
    pendingWithdrawal: 210, 
    totalEarned: 390, 
    referralsCount: 13,
    status: "active",
    lastWithdrawal: "15/06/2023",
  },
  { 
    id: 5, 
    name: "Mariana Oliveira", 
    email: "mariana.oliveira@example.com", 
    balance: 0, 
    pendingWithdrawal: 0, 
    totalEarned: 90, 
    referralsCount: 3,
    status: "active",
    lastWithdrawal: "28/03/2023",
  },
];

// Dados de exemplo para solicitações de saque
const withdrawalRequestsData = [
  {
    id: 1,
    affiliateId: 2,
    affiliateName: "Carlos Mendes",
    email: "carlos.mendes@example.com",
    amount: 75,
    requestDate: "15/06/2023",
    status: "pending",
    paymentMethod: "pix",
    pixKey: "carlos.mendes@example.com"
  },
  {
    id: 2,
    affiliateId: 4,
    affiliateName: "Pedro Santos",
    email: "pedro.santos@example.com",
    amount: 210,
    requestDate: "16/06/2023",
    status: "pending",
    paymentMethod: "bank_transfer",
    bankInfo: {
      bank: "Itaú",
      agency: "1234",
      account: "56789-0"
    }
  },
];

export function AdminAffiliateDashboard() {
  const [activeTab, setActiveTab] = useState("affiliates");
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  
  // Filtrar afiliados com base na busca e status
  const filteredAffiliates = affiliatesData.filter(affiliate => {
    const matchesSearch = 
      affiliate.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      affiliate.email.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = 
      statusFilter === "all" || 
      affiliate.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Aprovar solicitação de saque
  const approveWithdrawal = (id: number) => {
    console.log(`Aprovando solicitação de saque #${id}`);
    // Aqui seria implementada a lógica real para aprovar o saque
  };

  // Rejeitar solicitação de saque
  const rejectWithdrawal = (id: number) => {
    console.log(`Rejeitando solicitação de saque #${id}`);
    // Aqui seria implementada a lógica real para rejeitar o saque
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Gestão de Afiliados</h2>
        <p className="text-gray-600">
          Acompanhe o desempenho dos afiliados e gerencie solicitações de saque.
        </p>
      </div>
      
      <div className="flex space-x-4 border-b mb-6">
        <Button
          variant={activeTab === "affiliates" ? "default" : "ghost"}
          onClick={() => setActiveTab("affiliates")}
          className="rounded-none border-b-2 border-transparent data-[state=active]:border-brand-primary px-4 py-2"
          data-state={activeTab === "affiliates" ? "active" : "inactive"}
        >
          Afiliados
        </Button>
        <Button
          variant={activeTab === "withdrawals" ? "default" : "ghost"}
          onClick={() => setActiveTab("withdrawals")}
          className="rounded-none border-b-2 border-transparent data-[state=active]:border-brand-primary px-4 py-2"
          data-state={activeTab === "withdrawals" ? "active" : "inactive"}
        >
          Solicitações de Saque
        </Button>
        <Button
          variant={activeTab === "reports" ? "default" : "ghost"}
          onClick={() => setActiveTab("reports")}
          className="rounded-none border-b-2 border-transparent data-[state=active]:border-brand-primary px-4 py-2"
          data-state={activeTab === "reports" ? "active" : "inactive"}
        >
          Relatórios
        </Button>
      </div>
      
      {activeTab === "affiliates" && (
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Resumo do Programa de Afiliados</CardTitle>
              <CardDescription>Visão geral do desempenho do programa de afiliados</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-500">Total de Afiliados</p>
                  <p className="text-2xl font-bold">{affiliatesData.length}</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-500">Afiliados Ativos</p>
                  <p className="text-2xl font-bold">
                    {affiliatesData.filter(a => a.status === "active").length}
                  </p>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-500">Total Pago</p>
                  <p className="text-2xl font-bold">
                    R$ {affiliatesData.reduce((sum, a) => sum + (a.totalEarned - a.balance - a.pendingWithdrawal), 0)}
                  </p>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-500">Saldo Pendente</p>
                  <p className="text-2xl font-bold">
                    R$ {affiliatesData.reduce((sum, a) => sum + a.balance + a.pendingWithdrawal, 0)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Afiliados</CardTitle>
              <CardDescription>Gerenciar afiliados cadastrados no sistema</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4 mb-6">
                <div className="relative flex-grow">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    placeholder="Buscar por nome ou email..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <div className="w-full md:w-64">
                  <Select 
                    value={statusFilter} 
                    onValueChange={setStatusFilter}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Filtrar por status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectLabel>Status</SelectLabel>
                        <SelectItem value="all">Todos</SelectItem>
                        <SelectItem value="active">Ativos</SelectItem>
                        <SelectItem value="inactive">Inativos</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Nome</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Saldo</TableHead>
                      <TableHead>
                        <div className="flex items-center">
                          Indicações <ArrowUpDown className="ml-2 h-4 w-4" />
                        </div>
                      </TableHead>
                      <TableHead>Último Saque</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAffiliates.map((affiliate) => (
                      <TableRow key={affiliate.id}>
                        <TableCell className="font-medium">{affiliate.id}</TableCell>
                        <TableCell>{affiliate.name}</TableCell>
                        <TableCell>{affiliate.email}</TableCell>
                        <TableCell>
                          <Badge
                            variant={affiliate.status === "active" ? "default" : "secondary"}
                            className={
                              affiliate.status === "active" 
                              ? "bg-green-100 text-green-800 hover:bg-green-100"
                              : "bg-gray-100 text-gray-800 hover:bg-gray-100"
                            }
                          >
                            {affiliate.status === "active" ? "Ativo" : "Inativo"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          R$ {affiliate.balance}
                          {affiliate.pendingWithdrawal > 0 && (
                            <span className="ml-2 text-xs text-amber-600">
                              (R$ {affiliate.pendingWithdrawal} pendente)
                            </span>
                          )}
                        </TableCell>
                        <TableCell>{affiliate.referralsCount}</TableCell>
                        <TableCell>{affiliate.lastWithdrawal}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      {activeTab === "withdrawals" && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Solicitações de Saque</CardTitle>
            <CardDescription>Aprovar ou rejeitar solicitações de saque de afiliados</CardDescription>
          </CardHeader>
          <CardContent>
            {withdrawalRequestsData.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-gray-500">Não há solicitações de saque pendentes.</p>
              </div>
            ) : (
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Afiliado</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Data da Solicitação</TableHead>
                      <TableHead>Método de Pagamento</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {withdrawalRequestsData.map((request) => (
                      <TableRow key={request.id}>
                        <TableCell className="font-medium">{request.id}</TableCell>
                        <TableCell>{request.affiliateName}</TableCell>
                        <TableCell>{request.email}</TableCell>
                        <TableCell>R$ {request.amount}</TableCell>
                        <TableCell>{request.requestDate}</TableCell>
                        <TableCell className="capitalize">
                          {request.paymentMethod === "pix" ? "PIX" : "Transferência Bancária"}
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-8 w-8 p-0 text-green-600 hover:text-green-700 hover:bg-green-50"
                              onClick={() => approveWithdrawal(request.id)}
                            >
                              <Check className="h-4 w-4" />
                              <span className="sr-only">Aprovar</span>
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                              onClick={() => rejectWithdrawal(request.id)}
                            >
                              <X className="h-4 w-4" />
                              <span className="sr-only">Rejeitar</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      )}
      
      {activeTab === "reports" && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Relatórios de Desempenho</CardTitle>
            <CardDescription>Análise detalhada do desempenho dos afiliados</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-10">
              <p className="text-gray-500">Funcionalidade de relatórios em desenvolvimento.</p>
              <p className="text-gray-500 mt-2">Disponível em breve.</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
