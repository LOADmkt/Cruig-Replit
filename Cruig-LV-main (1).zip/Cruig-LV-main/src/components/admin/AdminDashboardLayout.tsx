
import React, { useState } from 'react';
import { AdminHeader } from './layout/AdminHeader';
import { AdminSidebar } from './layout/AdminSidebar';
import { AdminMobileNav } from './layout/AdminMobileNav';
import { AdminMainContent } from './layout/AdminMainContent';

export function AdminDashboardLayout() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="flex h-screen w-full flex-col overflow-hidden bg-brand-secondary/30">
      <AdminHeader />

      <div className="flex flex-1 overflow-hidden">
        <AdminSidebar activeTab={activeTab} setActiveTab={setActiveTab} />
        <div className="flex flex-1 flex-col overflow-hidden">
          <AdminMobileNav activeTab={activeTab} setActiveTab={setActiveTab} />
          <AdminMainContent activeTab={activeTab} setActiveTab={setActiveTab} />
        </div>
      </div>
    </div>
  );
}
