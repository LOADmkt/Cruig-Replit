
import React, { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Edit, Trash2, ChevronDown } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

// Tipos para representar localizações
interface Pais {
  id: string;
  nome: string;
  codigo: string;
}

interface Estado {
  id: string;
  nome: string;
  sigla: string;
  pais_id: string;
}

interface Cidade {
  id: string;
  nome: string;
  estado_id: string;
}

export const AdminLocalizacoesGerenciamento = () => {
  const { toast } = useToast();
  const [paises, setPaises] = useState<Pais[]>([]);
  const [estados, setEstados] = useState<Estado[]>([]);
  const [cidades, setCidades] = useState<Cidade[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [tipoLocalizacao, setTipoLocalizacao] = useState<"pais" | "estado" | "cidade">("pais");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  
  const [editingPais, setEditingPais] = useState<Pais | null>(null);
  const [editingEstado, setEditingEstado] = useState<Estado | null>(null);
  const [editingCidade, setEditingCidade] = useState<Cidade | null>(null);
  
  const [newPais, setNewPais] = useState({ nome: "", codigo: "" });
  const [newEstado, setNewEstado] = useState({ nome: "", sigla: "", pais_id: "" });
  const [newCidade, setNewCidade] = useState({ nome: "", estado_id: "" });
  
  const [openPaisId, setOpenPaisId] = useState<string | null>(null);
  const [openEstadoId, setOpenEstadoId] = useState<string | null>(null);

  // Buscar localizações do Supabase
  useEffect(() => {
    const fetchLocalizacoes = async () => {
      try {
        // Simulando dados para demonstração
        // Em produção, isso seria uma chamada para o Supabase
        const mockPaises = [
          { id: '1', nome: 'Brasil', codigo: 'BR' },
          { id: '2', nome: 'Estados Unidos', codigo: 'US' },
        ];
        
        const mockEstados = [
          { id: '1', nome: 'São Paulo', sigla: 'SP', pais_id: '1' },
          { id: '2', nome: 'Rio de Janeiro', sigla: 'RJ', pais_id: '1' },
          { id: '3', nome: 'California', sigla: 'CA', pais_id: '2' },
          { id: '4', nome: 'Texas', sigla: 'TX', pais_id: '2' },
        ];
        
        const mockCidades = [
          { id: '1', nome: 'São Paulo', estado_id: '1' },
          { id: '2', nome: 'Campinas', estado_id: '1' },
          { id: '3', nome: 'Rio de Janeiro', estado_id: '2' },
          { id: '4', nome: 'Los Angeles', estado_id: '3' },
          { id: '5', nome: 'Houston', estado_id: '4' },
        ];
        
        // Simular um atraso na resposta para mostrar o loading
        setTimeout(() => {
          setPaises(mockPaises);
          setEstados(mockEstados);
          setCidades(mockCidades);
          setLoading(false);
        }, 500);
        
        // NOTA: Quando integrado ao Supabase, usaríamos algo como:
        // const { data: paisesData, error: paisesError } = await supabase.from('paises').select('*');
        // if (paisesError) throw paisesError;
        // setPaises(paisesData);
        
        // const { data: estadosData, error: estadosError } = await supabase.from('estados').select('*');
        // if (estadosError) throw estadosError;
        // setEstados(estadosData);
        
        // const { data: cidadesData, error: cidadesError } = await supabase.from('cidades').select('*');
        // if (cidadesError) throw cidadesError;
        // setCidades(cidadesData);
      } catch (error) {
        console.error("Erro ao buscar localizações:", error);
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Não foi possível carregar as localizações. Tente novamente mais tarde.",
        });
        setLoading(false);
      }
    };

    fetchLocalizacoes();
  }, [toast]);

  // ======== Funções para gerenciar países ========
  const handleAddPais = async () => {
    try {
      if (!newPais.nome.trim() || !newPais.codigo.trim()) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Todos os campos são obrigatórios.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando adição de um novo país
      // Em produção, isso seria uma chamada para o Supabase
      const novoPais: Pais = {
        id: `p-${Date.now()}`,
        nome: newPais.nome,
        codigo: newPais.codigo.toUpperCase()
      };
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { data, error } = await supabase
      //   .from('paises')
      //   .insert([{ nome: newPais.nome, codigo: newPais.codigo.toUpperCase() }])
      //   .select();
      // if (error) throw error;
      
      setPaises([...paises, novoPais]);
      setDialogOpen(false);
      setNewPais({ nome: "", codigo: "" });
      
      toast({
        title: "Sucesso",
        description: "País adicionado com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao adicionar país:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível adicionar o país. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePais = async () => {
    try {
      if (!editingPais || !editingPais.nome.trim() || !editingPais.codigo.trim()) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Todos os campos são obrigatórios.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando atualização de um país
      // Em produção, isso seria uma chamada para o Supabase
      const updatedPaises = paises.map(pais => 
        pais.id === editingPais.id ? {
          ...editingPais,
          codigo: editingPais.codigo.toUpperCase()
        } : pais
      );
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('paises')
      //   .update({ nome: editingPais.nome, codigo: editingPais.codigo.toUpperCase() })
      //   .eq('id', editingPais.id);
      // if (error) throw error;
      
      setPaises(updatedPaises);
      setDialogOpen(false);
      setEditingPais(null);
      
      toast({
        title: "Sucesso",
        description: "País atualizado com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao atualizar país:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível atualizar o país. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeletePais = async () => {
    try {
      if (!editingPais) return;
      
      // Verificar se existem estados relacionados
      const estadosRelacionados = estados.filter(estado => estado.pais_id === editingPais.id);
      
      if (estadosRelacionados.length > 0) {
        toast({
          variant: "destructive",
          title: "Ação não permitida",
          description: `Existem ${estadosRelacionados.length} estados vinculados a este país. Remova os estados primeiro.`,
        });
        setDeleteDialogOpen(false);
        return;
      }
      
      setLoading(true);
      
      // Simulando exclusão de um país
      // Em produção, isso seria uma chamada para o Supabase
      const updatedPaises = paises.filter(pais => pais.id !== editingPais.id);
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('paises')
      //   .delete()
      //   .eq('id', editingPais.id);
      // if (error) throw error;
      
      setPaises(updatedPaises);
      setDeleteDialogOpen(false);
      setEditingPais(null);
      
      toast({
        title: "Sucesso",
        description: "País excluído com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao excluir país:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível excluir o país. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  // ======== Funções para gerenciar estados ========
  const handleAddEstado = async () => {
    try {
      if (!newEstado.nome.trim() || !newEstado.sigla.trim() || !newEstado.pais_id) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Todos os campos são obrigatórios.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando adição de um novo estado
      // Em produção, isso seria uma chamada para o Supabase
      const novoEstado: Estado = {
        id: `e-${Date.now()}`,
        nome: newEstado.nome,
        sigla: newEstado.sigla.toUpperCase(),
        pais_id: newEstado.pais_id
      };
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { data, error } = await supabase
      //   .from('estados')
      //   .insert([{ nome: newEstado.nome, sigla: newEstado.sigla.toUpperCase(), pais_id: newEstado.pais_id }])
      //   .select();
      // if (error) throw error;
      
      setEstados([...estados, novoEstado]);
      setDialogOpen(false);
      setNewEstado({ nome: "", sigla: "", pais_id: "" });
      
      toast({
        title: "Sucesso",
        description: "Estado adicionado com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao adicionar estado:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível adicionar o estado. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateEstado = async () => {
    try {
      if (!editingEstado || !editingEstado.nome.trim() || !editingEstado.sigla.trim() || !editingEstado.pais_id) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Todos os campos são obrigatórios.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando atualização de um estado
      // Em produção, isso seria uma chamada para o Supabase
      const updatedEstados = estados.map(estado => 
        estado.id === editingEstado.id ? {
          ...editingEstado,
          sigla: editingEstado.sigla.toUpperCase()
        } : estado
      );
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('estados')
      //   .update({ 
      //     nome: editingEstado.nome, 
      //     sigla: editingEstado.sigla.toUpperCase(), 
      //     pais_id: editingEstado.pais_id 
      //   })
      //   .eq('id', editingEstado.id);
      // if (error) throw error;
      
      setEstados(updatedEstados);
      setDialogOpen(false);
      setEditingEstado(null);
      
      toast({
        title: "Sucesso",
        description: "Estado atualizado com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao atualizar estado:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível atualizar o estado. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteEstado = async () => {
    try {
      if (!editingEstado) return;
      
      // Verificar se existem cidades relacionadas
      const cidadesRelacionadas = cidades.filter(cidade => cidade.estado_id === editingEstado.id);
      
      if (cidadesRelacionadas.length > 0) {
        toast({
          variant: "destructive",
          title: "Ação não permitida",
          description: `Existem ${cidadesRelacionadas.length} cidades vinculadas a este estado. Remova as cidades primeiro.`,
        });
        setDeleteDialogOpen(false);
        return;
      }
      
      setLoading(true);
      
      // Simulando exclusão de um estado
      // Em produção, isso seria uma chamada para o Supabase
      const updatedEstados = estados.filter(estado => estado.id !== editingEstado.id);
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('estados')
      //   .delete()
      //   .eq('id', editingEstado.id);
      // if (error) throw error;
      
      setEstados(updatedEstados);
      setDeleteDialogOpen(false);
      setEditingEstado(null);
      
      toast({
        title: "Sucesso",
        description: "Estado excluído com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao excluir estado:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível excluir o estado. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  // ======== Funções para gerenciar cidades ========
  const handleAddCidade = async () => {
    try {
      if (!newCidade.nome.trim() || !newCidade.estado_id) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Todos os campos são obrigatórios.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando adição de uma nova cidade
      // Em produção, isso seria uma chamada para o Supabase
      const novaCidade: Cidade = {
        id: `c-${Date.now()}`,
        nome: newCidade.nome,
        estado_id: newCidade.estado_id
      };
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { data, error } = await supabase
      //   .from('cidades')
      //   .insert([{ nome: newCidade.nome, estado_id: newCidade.estado_id }])
      //   .select();
      // if (error) throw error;
      
      setCidades([...cidades, novaCidade]);
      setDialogOpen(false);
      setNewCidade({ nome: "", estado_id: "" });
      
      toast({
        title: "Sucesso",
        description: "Cidade adicionada com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao adicionar cidade:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível adicionar a cidade. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateCidade = async () => {
    try {
      if (!editingCidade || !editingCidade.nome.trim() || !editingCidade.estado_id) {
        toast({
          variant: "destructive",
          title: "Erro",
          description: "Todos os campos são obrigatórios.",
        });
        return;
      }

      setLoading(true);
      
      // Simulando atualização de uma cidade
      // Em produção, isso seria uma chamada para o Supabase
      const updatedCidades = cidades.map(cidade => 
        cidade.id === editingCidade.id ? editingCidade : cidade
      );
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('cidades')
      //   .update({ nome: editingCidade.nome, estado_id: editingCidade.estado_id })
      //   .eq('id', editingCidade.id);
      // if (error) throw error;
      
      setCidades(updatedCidades);
      setDialogOpen(false);
      setEditingCidade(null);
      
      toast({
        title: "Sucesso",
        description: "Cidade atualizada com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao atualizar cidade:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível atualizar a cidade. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCidade = async () => {
    try {
      if (!editingCidade) return;
      
      setLoading(true);
      
      // Simulando exclusão de uma cidade
      // Em produção, isso seria uma chamada para o Supabase
      const updatedCidades = cidades.filter(cidade => cidade.id !== editingCidade.id);
      
      // NOTA: Quando integrado ao Supabase, usaríamos algo como:
      // const { error } = await supabase
      //   .from('cidades')
      //   .delete()
      //   .eq('id', editingCidade.id);
      // if (error) throw error;
      
      setCidades(updatedCidades);
      setDeleteDialogOpen(false);
      setEditingCidade(null);
      
      toast({
        title: "Sucesso",
        description: "Cidade excluída com sucesso!",
      });
    } catch (error) {
      console.error("Erro ao excluir cidade:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível excluir a cidade. Tente novamente mais tarde.",
      });
    } finally {
      setLoading(false);
    }
  };

  // ======== Funções para abrir diálogos ========
  const openAddDialog = (tipo: "pais" | "estado" | "cidade") => {
    setTipoLocalizacao(tipo);
    
    if (tipo === "pais") {
      setEditingPais(null);
      setNewPais({ nome: "", codigo: "" });
    } else if (tipo === "estado") {
      setEditingEstado(null);
      setNewEstado({ nome: "", sigla: "", pais_id: "" });
    } else if (tipo === "cidade") {
      setEditingCidade(null);
      setNewCidade({ nome: "", estado_id: "" });
    }
    
    setDialogOpen(true);
  };

  const openEditDialog = (tipo: "pais" | "estado" | "cidade", item: Pais | Estado | Cidade) => {
    setTipoLocalizacao(tipo);
    
    if (tipo === "pais") {
      setEditingPais(item as Pais);
    } else if (tipo === "estado") {
      setEditingEstado(item as Estado);
    } else if (tipo === "cidade") {
      setEditingCidade(item as Cidade);
    }
    
    setDialogOpen(true);
  };

  const openDeleteDialog = (tipo: "pais" | "estado" | "cidade", item: Pais | Estado | Cidade) => {
    setTipoLocalizacao(tipo);
    
    if (tipo === "pais") {
      setEditingPais(item as Pais);
    } else if (tipo === "estado") {
      setEditingEstado(item as Estado);
    } else if (tipo === "cidade") {
      setEditingCidade(item as Cidade);
    }
    
    setDeleteDialogOpen(true);
  };

  // Funções para buscar dados relacionados
  const getPaisById = (id: string) => {
    return paises.find(pais => pais.id === id);
  };

  const getEstadoById = (id: string) => {
    return estados.find(estado => estado.id === id);
  };

  const getEstadosPorPais = (paisId: string) => {
    return estados.filter(estado => estado.pais_id === paisId);
  };

  const getCidadesPorEstado = (estadoId: string) => {
    return cidades.filter(cidade => cidade.estado_id === estadoId);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-bold text-gray-800">Gestão de Localizações</h3>
        <div className="flex gap-2">
          <Button 
            onClick={() => openAddDialog("pais")} 
            variant="brand" 
            className="flex items-center gap-2"
          >
            <Plus className="h-4 w-4" />
            Adicionar País
          </Button>
          <Button 
            onClick={() => openAddDialog("estado")} 
            variant="outline"
            className="flex items-center gap-2 border-2 border-brand-primary text-brand-primary hover:bg-brand-primary hover:text-white"
          >
            <Plus className="h-4 w-4" />
            Adicionar Estado
          </Button>
          <Button 
            onClick={() => openAddDialog("cidade")} 
            variant="outline"
            className="flex items-center gap-2 border-2 border-gray-300 text-gray-700 hover:bg-gray-100"
          >
            <Plus className="h-4 w-4" />
            Adicionar Cidade
          </Button>
        </div>
      </div>
      
      {loading ? (
        <div className="flex justify-center p-8">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-brand-primary border-t-transparent"></div>
        </div>
      ) : paises.length === 0 ? (
        <div className="text-center p-8 bg-gray-50 rounded-lg border border-gray-200">
          <p className="text-gray-600">Nenhuma localização cadastrada.</p>
          <Button onClick={() => openAddDialog("pais")} variant="link" className="mt-2">
            Adicionar o primeiro país
          </Button>
        </div>
      ) : (
        <div className="border rounded-lg overflow-hidden">
          {paises.map((pais) => (
            <Collapsible 
              key={pais.id} 
              open={openPaisId === pais.id} 
              onOpenChange={() => setOpenPaisId(openPaisId === pais.id ? null : pais.id)}
              className="border-b last:border-b-0"
            >
              <div className="flex items-center justify-between bg-gray-50 p-4">
                <div className="flex items-center gap-4">
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <ChevronDown className={`h-4 w-4 transition-transform ${openPaisId === pais.id ? "transform rotate-180" : ""}`} />
                    </Button>
                  </CollapsibleTrigger>
                  <div>
                    <h4 className="font-medium text-gray-800">{pais.nome}</h4>
                    <p className="text-sm text-gray-500">Código: {pais.codigo}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      openEditDialog("pais", pais);
                    }}
                    title="Editar"
                    className="h-8 w-8"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      openDeleteDialog("pais", pais);
                    }}
                    title="Excluir"
                    className="h-8 w-8"
                  >
                    <Trash2 className="h-4 w-4 text-red-600" />
                  </Button>
                </div>
              </div>
              <CollapsibleContent>
                <div className="p-4 bg-white">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="text-lg font-medium">Estados</h4>
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex items-center gap-1 text-sm border-brand-primary text-brand-primary hover:bg-brand-primary hover:text-white"
                      onClick={() => {
                        setNewEstado({ ...newEstado, pais_id: pais.id });
                        openAddDialog("estado");
                      }}
                    >
                      <Plus className="h-3 w-3" />
                      Adicionar Estado
                    </Button>
                  </div>
                  
                  {getEstadosPorPais(pais.id).length === 0 ? (
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <p className="text-gray-600 text-sm">Nenhum estado cadastrado para este país.</p>
                    </div>
                  ) : (
                    <div>
                      {getEstadosPorPais(pais.id).map((estado) => (
                        <Collapsible 
                          key={estado.id} 
                          open={openEstadoId === estado.id} 
                          onOpenChange={() => setOpenEstadoId(openEstadoId === estado.id ? null : estado.id)}
                          className="border rounded-lg mb-2 last:mb-0 overflow-hidden"
                        >
                          <div className="flex items-center justify-between bg-gray-50 p-3">
                            <div className="flex items-center gap-3">
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-6 w-6">
                                  <ChevronDown className={`h-3 w-3 transition-transform ${openEstadoId === estado.id ? "transform rotate-180" : ""}`} />
                                </Button>
                              </CollapsibleTrigger>
                              <div>
                                <h5 className="font-medium text-gray-800">{estado.nome}</h5>
                                <p className="text-xs text-gray-500">Sigla: {estado.sigla}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openEditDialog("estado", estado);
                                }}
                                title="Editar"
                                className="h-6 w-6"
                              >
                                <Edit className="h-3 w-3" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openDeleteDialog("estado", estado);
                                }}
                                title="Excluir"
                                className="h-6 w-6"
                              >
                                <Trash2 className="h-3 w-3 text-red-600" />
                              </Button>
                            </div>
                          </div>
                          <CollapsibleContent>
                            <div className="p-3 bg-white">
                              <div className="flex justify-between items-center mb-3">
                                <h6 className="font-medium">Cidades</h6>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="flex items-center gap-1 text-xs h-7 border-gray-300 text-gray-700 hover:bg-gray-100"
                                  onClick={() => {
                                    setNewCidade({ ...newCidade, estado_id: estado.id });
                                    openAddDialog("cidade");
                                  }}
                                >
                                  <Plus className="h-2 w-2" />
                                  Adicionar Cidade
                                </Button>
                              </div>
                              
                              {getCidadesPorEstado(estado.id).length === 0 ? (
                                <div className="text-center p-3 bg-gray-50 rounded-lg">
                                  <p className="text-gray-600 text-xs">Nenhuma cidade cadastrada para este estado.</p>
                                </div>
                              ) : (
                                <div className="border rounded-lg overflow-hidden">
                                  <Table>
                                    <TableHeader>
                                      <TableRow>
                                        <TableHead className="text-xs">Nome</TableHead>
                                        <TableHead className="text-xs w-[80px]">Ações</TableHead>
                                      </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                      {getCidadesPorEstado(estado.id).map((cidade) => (
                                        <TableRow key={cidade.id}>
                                          <TableCell className="text-sm py-2">{cidade.nome}</TableCell>
                                          <TableCell className="py-2">
                                            <div className="flex items-center gap-1">
                                              <Button
                                                variant="ghost"
                                                size="icon"
                                                onClick={() => openEditDialog("cidade", cidade)}
                                                title="Editar"
                                                className="h-6 w-6"
                                              >
                                                <Edit className="h-3 w-3" />
                                              </Button>
                                              <Button
                                                variant="ghost"
                                                size="icon"
                                                onClick={() => openDeleteDialog("cidade", cidade)}
                                                title="Excluir"
                                                className="h-6 w-6"
                                              >
                                                <Trash2 className="h-3 w-3 text-red-600" />
                                              </Button>
                                            </div>
                                          </TableCell>
                                        </TableRow>
                                      ))}
                                    </TableBody>
                                  </Table>
                                </div>
                              )}
                            </div>
                          </CollapsibleContent>
                        </Collapsible>
                      ))}
                    </div>
                  )}
                </div>
              </CollapsibleContent>
            </Collapsible>
          ))}
        </div>
      )}
      
      {/* Dialog para adicionar ou editar localização */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {tipoLocalizacao === "pais" 
                ? editingPais ? "Editar País" : "Adicionar País"
                : tipoLocalizacao === "estado"
                ? editingEstado ? "Editar Estado" : "Adicionar Estado"
                : editingCidade ? "Editar Cidade" : "Adicionar Cidade"
              }
            </DialogTitle>
            <DialogDescription>
              {tipoLocalizacao === "pais" 
                ? editingPais ? "Faça as alterações necessárias e salve." : "Preencha os campos para adicionar um novo país."
                : tipoLocalizacao === "estado"
                ? editingEstado ? "Faça as alterações necessárias e salve." : "Preencha os campos para adicionar um novo estado."
                : editingCidade ? "Faça as alterações necessárias e salve." : "Preencha os campos para adicionar uma nova cidade."
              }
            </DialogDescription>
          </DialogHeader>
          
          {tipoLocalizacao === "pais" && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="nome" className="text-sm font-medium">
                  Nome *
                </label>
                <Input
                  id="nome"
                  placeholder="Ex: Brasil, Estados Unidos..."
                  value={editingPais ? editingPais.nome : newPais.nome}
                  onChange={(e) => {
                    if (editingPais) {
                      setEditingPais({ ...editingPais, nome: e.target.value });
                    } else {
                      setNewPais({ ...newPais, nome: e.target.value });
                    }
                  }}
                  className="focus:border-brand-primary"
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="codigo" className="text-sm font-medium">
                  Código *
                </label>
                <Input
                  id="codigo"
                  placeholder="Ex: BR, US..."
                  value={editingPais ? editingPais.codigo : newPais.codigo}
                  maxLength={2}
                  onChange={(e) => {
                    const value = e.target.value.toUpperCase();
                    if (editingPais) {
                      setEditingPais({ ...editingPais, codigo: value });
                    } else {
                      setNewPais({ ...newPais, codigo: value });
                    }
                  }}
                  className="focus:border-brand-primary"
                />
                <p className="text-xs text-gray-500">Código de 2 letras do país (ISO 3166-1 alpha-2)</p>
              </div>
            </div>
          )}
          
          {tipoLocalizacao === "estado" && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="nome" className="text-sm font-medium">
                  Nome *
                </label>
                <Input
                  id="nome"
                  placeholder="Ex: São Paulo, California..."
                  value={editingEstado ? editingEstado.nome : newEstado.nome}
                  onChange={(e) => {
                    if (editingEstado) {
                      setEditingEstado({ ...editingEstado, nome: e.target.value });
                    } else {
                      setNewEstado({ ...newEstado, nome: e.target.value });
                    }
                  }}
                  className="focus:border-brand-primary"
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="sigla" className="text-sm font-medium">
                  Sigla *
                </label>
                <Input
                  id="sigla"
                  placeholder="Ex: SP, CA..."
                  value={editingEstado ? editingEstado.sigla : newEstado.sigla}
                  maxLength={2}
                  onChange={(e) => {
                    const value = e.target.value.toUpperCase();
                    if (editingEstado) {
                      setEditingEstado({ ...editingEstado, sigla: value });
                    } else {
                      setNewEstado({ ...newEstado, sigla: value });
                    }
                  }}
                  className="focus:border-brand-primary"
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="pais" className="text-sm font-medium">
                  País *
                </label>
                <Select
                  value={editingEstado ? editingEstado.pais_id : newEstado.pais_id}
                  onValueChange={(value) => {
                    if (editingEstado) {
                      setEditingEstado({ ...editingEstado, pais_id: value });
                    } else {
                      setNewEstado({ ...newEstado, pais_id: value });
                    }
                  }}
                >
                  <SelectTrigger className="focus:border-brand-primary">
                    <SelectValue placeholder="Selecione um país" />
                  </SelectTrigger>
                  <SelectContent>
                    {paises.map((pais) => (
                      <SelectItem key={pais.id} value={pais.id}>
                        {pais.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          
          {tipoLocalizacao === "cidade" && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="nome" className="text-sm font-medium">
                  Nome *
                </label>
                <Input
                  id="nome"
                  placeholder="Ex: São Paulo, Rio de Janeiro..."
                  value={editingCidade ? editingCidade.nome : newCidade.nome}
                  onChange={(e) => {
                    if (editingCidade) {
                      setEditingCidade({ ...editingCidade, nome: e.target.value });
                    } else {
                      setNewCidade({ ...newCidade, nome: e.target.value });
                    }
                  }}
                  className="focus:border-brand-primary"
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="estado" className="text-sm font-medium">
                  Estado *
                </label>
                <Select
                  value={editingCidade ? editingCidade.estado_id : newCidade.estado_id}
                  onValueChange={(value) => {
                    if (editingCidade) {
                      setEditingCidade({ ...editingCidade, estado_id: value });
                    } else {
                      setNewCidade({ ...newCidade, estado_id: value });
                    }
                  }}
                >
                  <SelectTrigger className="focus:border-brand-primary">
                    <SelectValue placeholder="Selecione um estado" />
                  </SelectTrigger>
                  <SelectContent>
                    {estados.map((estado) => {
                      const pais = getPaisById(estado.pais_id);
                      return (
                        <SelectItem key={estado.id} value={estado.id}>
                          {estado.nome} - {estado.sigla} ({pais?.nome})
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={() => {
                if (tipoLocalizacao === "pais") {
                  editingPais ? handleUpdatePais() : handleAddPais();
                } else if (tipoLocalizacao === "estado") {
                  editingEstado ? handleUpdateEstado() : handleAddEstado();
                } else if (tipoLocalizacao === "cidade") {
                  editingCidade ? handleUpdateCidade() : handleAddCidade();
                }
              }}
              disabled={loading}
              variant="brand"
            >
              {loading ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2"></span>
                  Processando...
                </>
              ) : tipoLocalizacao === "pais" ? (
                editingPais ? "Salvar alterações" : "Adicionar país"
              ) : tipoLocalizacao === "estado" ? (
                editingEstado ? "Salvar alterações" : "Adicionar estado"
              ) : (
                editingCidade ? "Salvar alterações" : "Adicionar cidade"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog para confirmar exclusão */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {tipoLocalizacao === "pais" 
                ? "Excluir país" 
                : tipoLocalizacao === "estado" 
                ? "Excluir estado" 
                : "Excluir cidade"
              }
            </AlertDialogTitle>
            <AlertDialogDescription>
              {tipoLocalizacao === "pais" && editingPais && (
                <>Tem certeza que deseja excluir o país "{editingPais.nome}"?</>
              )}
              {tipoLocalizacao === "estado" && editingEstado && (
                <>Tem certeza que deseja excluir o estado "{editingEstado.nome}"?</>
              )}
              {tipoLocalizacao === "cidade" && editingCidade && (
                <>Tem certeza que deseja excluir a cidade "{editingCidade.nome}"?</>
              )}
              <br />
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => {
                if (tipoLocalizacao === "pais") {
                  handleDeletePais();
                } else if (tipoLocalizacao === "estado") {
                  handleDeleteEstado();
                } else if (tipoLocalizacao === "cidade") {
                  handleDeleteCidade();
                }
              }}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {loading ? (
                <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2"></span>
                  Excluindo...
                </>
              ) : (
                "Excluir"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
