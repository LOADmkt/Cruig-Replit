
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Users, DollarSign, TrendingUp, AlertCircle, Repeat, CheckCircle, LucideIcon } from "lucide-react";

interface Stat {
  title: string;
  value: string;
  description: string;
  icon: string;
  iconBg: string;
  iconColor: string;
}

interface AdminMetricsCardsProps {
  stats: Stat[];
}

export const AdminMetricsCards = ({ stats }: AdminMetricsCardsProps) => {
  // Map string icon names to actual Lucide icons
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Users': return <Users className="h-5 w-5" />;
      case 'DollarSign': return <DollarSign className="h-5 w-5" />;
      case 'TrendingUp': return <TrendingUp className="h-5 w-5" />;
      case 'AlertCircle': return <AlertCircle className="h-5 w-5" />;
      case 'Repeat': return <Repeat className="h-5 w-5" />;
      case 'CheckCircle': return <CheckCircle className="h-5 w-5" />;
      default: return <Users className="h-5 w-5" />;
    }
  };

  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
      {stats.map((stat, index) => (
        <Card key={index} className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-x-4">
              <div>
                <p className="text-sm font-medium text-gray-500">{stat.title}</p>
                <h3 className="text-2xl font-bold">{stat.value}</h3>
                <p className="text-xs text-gray-500">{stat.description}</p>
              </div>
              <div className={`rounded-full p-2.5 ${stat.iconBg} ${stat.iconColor}`}>
                {getIcon(stat.icon)}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
