
import React from 'react';
import AdminDashboard from '@/components/admin/AdminDashboard';
import { AdminAffiliateDashboard } from '@/components/admin/AdminAffiliateDashboard';
import AdminClientes from '@/components/admin/AdminClientes';
import AdminFinanceiro from '@/components/admin/AdminFinanceiro';
import { AdminPlanManagement } from '@/components/admin/AdminPlanManagement';
import { AdminNotificationSystem } from '@/components/admin/AdminNotificationSystem';
import AdminConfiguracao from '@/components/admin/AdminConfiguracao';

interface AdminMainContentProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function AdminMainContent({ activeTab }: AdminMainContentProps) {
  return (
    <main className="flex-1 overflow-y-auto bg-brand-secondary/20 p-6">
      {activeTab === 'dashboard' && <AdminDashboard />}
      {activeTab === 'customers' && <AdminClientes />}
      {activeTab === 'financial' && <AdminFinanceiro />}
      {activeTab === 'affiliate' && <AdminAffiliateDashboard />}
      {activeTab === 'plans' && <AdminPlanManagement />}
      {activeTab === 'notifications' && <AdminNotificationSystem />}
      {activeTab === 'settings' && <AdminConfiguracao />}
    </main>
  );
}
