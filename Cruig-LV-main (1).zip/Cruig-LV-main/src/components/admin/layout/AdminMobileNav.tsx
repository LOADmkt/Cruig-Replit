
import React from 'react';
import { Home, Users, DollarSign, Activity, Settings } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface AdminMobileNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function AdminMobileNav({ activeTab, setActiveTab }: AdminMobileNavProps) {
  return (
    <div className="md:hidden flex-none bg-white border-b w-full p-2">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full">
          <TabsTrigger value="dashboard">
            <Home className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="clientes">
            <Users className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="financeiro">
            <DollarSign className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="afiliados">
            <Activity className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="configuracao">
            <Settings className="h-4 w-4" />
          </TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  );
}
