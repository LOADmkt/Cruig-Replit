
import React from 'react';
import { Info, LogOut, ChevronDown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export function AdminHeader() {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogout = () => {
    localStorage.removeItem('admin_auth');
    toast({
      title: 'Logout bem-sucedido',
      description: 'Você foi desconectado do painel administrativo.'
    });
    navigate('/admin');
  };

  return (
    <header className="flex h-16 items-center justify-between border-b bg-white px-4 sm:px-6">
      <div className="flex items-center gap-2">
        <img
          src="/lovable-uploads/2bf57e0e-db5c-40de-99ba-8d1bfd2dcbc5.png"
          alt="Logo"
          className="h-8 w-auto"
        />
        <span className="font-semibold text-lg hidden sm:inline">Admin Panel</span>
      </div>
      
      <div className="flex items-center gap-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="flex items-center gap-1">
              <Info className="h-4 w-4" />
              <span className="hidden sm:inline">Ajuda</span>
              <ChevronDown className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Recursos</DropdownMenuLabel>
            <DropdownMenuItem>Documentação</DropdownMenuItem>
            <DropdownMenuItem>Tutoriais</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Suporte técnico</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        
        <Button variant="outline" size="sm" onClick={handleLogout} className="flex items-center gap-1">
          <LogOut className="h-4 w-4" />
          <span className="hidden sm:inline">Sair</span>
        </Button>
      </div>
    </header>
  );
}
