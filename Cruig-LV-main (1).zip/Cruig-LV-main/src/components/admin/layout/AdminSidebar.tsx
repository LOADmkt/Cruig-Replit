
import React from 'react';
import { Home, Users, DollarSign, Activity, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AdminSidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function AdminSidebar({ activeTab, setActiveTab }: AdminSidebarProps) {
  return (
    <aside className="hidden md:flex w-64 flex-col border-r bg-white">
      <div className="flex flex-col gap-1 p-4">
        <Button
          variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
          className="justify-start"
          onClick={() => setActiveTab('dashboard')}
        >
          <Home className="mr-2 h-4 w-4" />
          Dashboard
        </Button>
        <Button
          variant={activeTab === 'clientes' ? 'default' : 'ghost'}
          className="justify-start"
          onClick={() => setActiveTab('clientes')}
        >
          <Users className="mr-2 h-4 w-4" />
          Clientes
        </Button>
        <Button
          variant={activeTab === 'financeiro' ? 'default' : 'ghost'}
          className="justify-start"
          onClick={() => setActiveTab('financeiro')}
        >
          <DollarSign className="mr-2 h-4 w-4" />
          Financeiro
        </Button>
        <Button
          variant={activeTab === 'afiliados' ? 'default' : 'ghost'}
          className="justify-start"
          onClick={() => setActiveTab('afiliados')}
        >
          <Activity className="mr-2 h-4 w-4" />
          Afiliados
        </Button>
        <Button
          variant={activeTab === 'configuracao' ? 'default' : 'ghost'}
          className="justify-start"
          onClick={() => setActiveTab('configuracao')}
        >
          <Settings className="mr-2 h-4 w-4" />
          Configuração
        </Button>
      </div>
    </aside>
  );
}
