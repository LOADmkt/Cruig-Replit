
import { useState } from "react";
import { Search, Filter, Edit, Trash, CheckCircle, XCircle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

// Dados de exemplo
const clientesIniciais = [
  { id: 1, nome: "Ana Silva", email: "ana.silva@email.com", tipo: "criador", status: "ativo", plano: "Premium", dataCadastro: "2023-12-01", ultimoPagamento: "2024-04-15" },
  { id: 2, nome: "MídiaTech Ltda.", email: "contato@midiatech.com.br", tipo: "empresa", status: "ativo", plano: "Enterprise", dataCadastro: "2023-11-15", ultimoPagamento: "2024-04-10" },
  { id: 3, nome: "Carlos Mendes", email: "carlos@exemplo.com", tipo: "criador", status: "inativo", plano: "Básico", dataCadastro: "2024-01-05", ultimoPagamento: "2024-03-05" },
  { id: 4, nome: "AgênciaDigital S.A.", email: "contato@agenciadigital.com", tipo: "empresa", status: "teste", plano: "Premium", dataCadastro: "2024-04-01", ultimoPagamento: null },
  { id: 5, nome: "Paula Ferreira", email: "paula@criativos.com", tipo: "criador", status: "inadimplente", plano: "Premium", dataCadastro: "2023-10-10", ultimoPagamento: "2024-02-10" },
  { id: 6, nome: "João Almeida", email: "joao@email.com", tipo: "criador", status: "ativo", plano: "Básico", dataCadastro: "2024-02-20", ultimoPagamento: "2024-04-20" },
  { id: 7, nome: "Marketing Express", email: "contato@marketingexpress.com.br", tipo: "empresa", status: "inadimplente", plano: "Enterprise", dataCadastro: "2023-09-15", ultimoPagamento: "2024-02-15" }
];

const AdminClientes = () => {
  const [clientes, setClientes] = useState(clientesIniciais);
  const [filteredClientes, setFilteredClientes] = useState(clientesIniciais);
  const [searchTerm, setSearchTerm] = useState("");
  const [filtroStatus, setFiltroStatus] = useState("todos");
  const [clienteSelecionado, setClienteSelecionado] = useState<any>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const { toast } = useToast();

  const aplicarFiltros = (termo: string, filtro: string) => {
    let resultado = clientes;
    
    // Aplicar filtro de texto
    if (termo) {
      resultado = resultado.filter(cliente => 
        cliente.nome.toLowerCase().includes(termo.toLowerCase()) || 
        cliente.email.toLowerCase().includes(termo.toLowerCase())
      );
    }
    
    // Aplicar filtro de status
    if (filtro !== "todos") {
      resultado = resultado.filter(cliente => cliente.status === filtro);
    }
    
    setFilteredClientes(resultado);
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const termo = e.target.value;
    setSearchTerm(termo);
    aplicarFiltros(termo, filtroStatus);
  };

  const handleFiltroStatus = (status: string) => {
    setFiltroStatus(status);
    aplicarFiltros(searchTerm, status);
  };

  const handleEditarCliente = (cliente: any) => {
    setClienteSelecionado(cliente);
    setDialogOpen(true);
  };

  const handleSalvarCliente = () => {
    // Atualizar o cliente no array
    const index = clientes.findIndex(c => c.id === clienteSelecionado.id);
    const novosClientes = [...clientes];
    novosClientes[index] = clienteSelecionado;
    
    setClientes(novosClientes);
    aplicarFiltros(searchTerm, filtroStatus);
    setDialogOpen(false);
    
    toast({
      title: "Cliente atualizado",
      description: `As informações de ${clienteSelecionado.nome} foram atualizadas com sucesso.`
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "ativo":
        return <Badge variant="brand">Ativo</Badge>;
      case "inativo":
        return <Badge variant="secondary">Inativo</Badge>;
      case "inadimplente":
        return <Badge variant="destructive">Inadimplente</Badge>;
      case "teste":
        return <Badge variant="outline">Em Teste</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-gray-800">Gestão de Clientes</h2>
        <Button variant="brand">Adicionar Cliente</Button>
      </div>

      {/* Filtros e busca */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            type="text"
            placeholder="Buscar por nome ou e-mail..."
            className="pl-9 w-full"
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>
        
        <div className="flex gap-2 flex-wrap">
          <Button 
            variant={filtroStatus === "todos" ? "brand" : "outline"}
            size="sm"
            onClick={() => handleFiltroStatus("todos")}
          >
            Todos
          </Button>
          <Button 
            variant={filtroStatus === "ativo" ? "brand" : "outline"}
            size="sm"
            onClick={() => handleFiltroStatus("ativo")}
            className="flex items-center gap-1"
          >
            <CheckCircle className="h-4 w-4" /> Ativos
          </Button>
          <Button 
            variant={filtroStatus === "inativo" ? "brand" : "outline"}
            size="sm"
            onClick={() => handleFiltroStatus("inativo")}
            className="flex items-center gap-1"
          >
            <XCircle className="h-4 w-4" /> Inativos
          </Button>
          <Button 
            variant={filtroStatus === "teste" ? "brand" : "outline"}
            size="sm"
            onClick={() => handleFiltroStatus("teste")}
            className="flex items-center gap-1"
          >
            <Clock className="h-4 w-4" /> Em Teste
          </Button>
          <Button 
            variant={filtroStatus === "inadimplente" ? "brand" : "outline"}
            size="sm"
            onClick={() => handleFiltroStatus("inadimplente")}
            className="flex items-center gap-1"
          >
            <Filter className="h-4 w-4" /> Inadimplentes
          </Button>
        </div>
      </div>

      {/* Tabela de clientes */}
      <div className="border rounded-md overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>E-mail</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Plano</TableHead>
              <TableHead>Data Cadastro</TableHead>
              <TableHead>Último Pagamento</TableHead>
              <TableHead>Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredClientes.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-4 text-gray-500">
                  Nenhum cliente encontrado com os filtros aplicados.
                </TableCell>
              </TableRow>
            ) : (
              filteredClientes.map((cliente) => (
                <TableRow key={cliente.id}>
                  <TableCell className="font-medium">{cliente.nome}</TableCell>
                  <TableCell>{cliente.email}</TableCell>
                  <TableCell>
                    {cliente.tipo === "criador" ? "Criador" : "Empresa"}
                  </TableCell>
                  <TableCell>{getStatusBadge(cliente.status)}</TableCell>
                  <TableCell>{cliente.plano}</TableCell>
                  <TableCell>{new Date(cliente.dataCadastro).toLocaleDateString("pt-BR")}</TableCell>
                  <TableCell>
                    {cliente.ultimoPagamento 
                      ? new Date(cliente.ultimoPagamento).toLocaleDateString("pt-BR")
                      : "-"}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="icon"
                        onClick={() => handleEditarCliente(cliente)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="icon">
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Dialog de edição */}
      {clienteSelecionado && (
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar Cliente</DialogTitle>
              <DialogDescription>
                Atualize as informações do cliente abaixo.
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="nome" className="text-right">
                  Nome
                </label>
                <Input
                  id="nome"
                  value={clienteSelecionado.nome}
                  onChange={(e) => setClienteSelecionado({...clienteSelecionado, nome: e.target.value})}
                  className="col-span-3"
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="email" className="text-right">
                  E-mail
                </label>
                <Input
                  id="email"
                  value={clienteSelecionado.email}
                  onChange={(e) => setClienteSelecionado({...clienteSelecionado, email: e.target.value})}
                  className="col-span-3"
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="status" className="text-right">
                  Status
                </label>
                <select
                  id="status"
                  value={clienteSelecionado.status}
                  onChange={(e) => setClienteSelecionado({...clienteSelecionado, status: e.target.value})}
                  className="col-span-3 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <option value="ativo">Ativo</option>
                  <option value="inativo">Inativo</option>
                  <option value="teste">Em Teste</option>
                  <option value="inadimplente">Inadimplente</option>
                </select>
              </div>
              
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="plano" className="text-right">
                  Plano
                </label>
                <select
                  id="plano"
                  value={clienteSelecionado.plano}
                  onChange={(e) => setClienteSelecionado({...clienteSelecionado, plano: e.target.value})}
                  className="col-span-3 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <option value="Básico">Básico</option>
                  <option value="Premium">Premium</option>
                  <option value="Enterprise">Enterprise</option>
                </select>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              <Button variant="brand" onClick={handleSalvarCliente}>Salvar Alterações</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default AdminClientes;
