
import React from 'react';
import { Button } from "@/components/ui/button";

interface DashboardHeaderProps {
  timeRange: string;
  setTimeRange: (range: string) => void;
}

const DashboardHeader: React.FC<DashboardHeaderProps> = ({ timeRange, setTimeRange }) => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
      <h2 className="text-3xl font-bold text-gray-800">Visão Geral</h2>
      
      <div className="flex space-x-2 mt-4 md:mt-0">
        <Button
          variant={timeRange === "weekly" ? "default" : "outline"}
          size="sm"
          onClick={() => setTimeRange("weekly")}
        >
          Semanal
        </Button>
        <Button
          variant={timeRange === "monthly" ? "default" : "outline"}
          size="sm"
          onClick={() => setTimeRange("monthly")}
        >
          Mensal
        </Button>
        <Button
          variant={timeRange === "yearly" ? "default" : "outline"}
          size="sm"
          onClick={() => setTimeRange("yearly")}
        >
          Anual
        </Button>
      </div>
    </div>
  );
};

export default DashboardHeader;
