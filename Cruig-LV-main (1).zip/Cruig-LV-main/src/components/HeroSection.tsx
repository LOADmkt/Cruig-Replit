import React from 'react';
import { Button } from '@/components/ui/button';
import { BadgeCheck, ArrowRight, MessageSquare, Users, Activity } from 'lucide-react';
import { motion } from 'framer-motion';
import VideoPlayer from './VideoPlayer';
const HeroSection = () => {
  return <div className="bg-gradient-to-b from-white via-brand-accent/10 to-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Hero Section */}
        <div className="py-20 md:py-28 lg:py-32">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6
          }} className="lg:w-1/2 text-center lg:text-left">
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
                <span className="bg-gradient-to-r from-brand-primary to-brand-primary/80 bg-clip-text text-transparent">Conectando Criadores e Marcas!</span>
              </h1>
              <p className="text-lg md:text-xl text-gray-700 mb-8 font-medium leading-relaxed">
                A plataforma que conecta criadores de conteúdo com as marcas ideais para seu nicho, 
                e ajuda empresas a encontrarem os parceiros perfeitos para suas campanhas.
              </p>
              <div className="flex flex-col sm:flex-row gap-5 justify-center lg:justify-start">
                <Button size="lg" className="bg-brand-primary hover:bg-brand-primary/90 text-white font-semibold shadow-lg hover:shadow-xl transition-all text-lg px-8 py-6" onClick={() => window.location.href = '/auth'}>
                  Sou Criador de Conteúdo <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button size="lg" variant="outline" className="border-2 border-brand-primary text-brand-dark hover:bg-brand-primary hover:text-white font-semibold shadow-md hover:shadow-lg transition-all text-lg px-8 py-6" onClick={() => window.location.href = '/auth'}>
                  Sou uma Empresa <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>
              
              <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-8">
                <div className="flex flex-col items-center sm:items-start gap-2">
                  <div className="bg-brand-primary/10 p-3 rounded-full">
                    <Users className="h-6 w-6 text-brand-primary" />
                  </div>
                  <div className="text-center sm:text-left">
                    <p className="text-brand-primary font-bold text-2xl">+5.000</p>
                    <p className="text-gray-700 font-medium">Criadores ativos</p>
                  </div>
                </div>
                
                <div className="flex flex-col items-center sm:items-start gap-2">
                  <div className="bg-brand-primary/10 p-3 rounded-full">
                    <MessageSquare className="h-6 w-6 text-brand-primary" />
                  </div>
                  <div className="text-center sm:text-left">
                    <p className="text-brand-primary font-bold text-2xl">+15.000</p>
                    <p className="text-gray-700 font-medium">Mensagens trocadas</p>
                  </div>
                </div>
                
                <div className="flex flex-col items-center sm:items-start gap-2">
                  <div className="bg-brand-primary/10 p-3 rounded-full">
                    <Activity className="h-6 w-6 text-brand-primary" />
                  </div>
                  <div className="text-center sm:text-left">
                    <p className="text-brand-primary font-bold text-2xl">+2.000</p>
                    <p className="text-gray-700 font-medium">Campanhas realizadas</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div initial={{
            opacity: 0,
            x: 20
          }} animate={{
            opacity: 1,
            x: 0
          }} transition={{
            duration: 0.6,
            delay: 0.2
          }} className="lg:w-1/2 relative mt-8 lg:mt-0">
              <div className="relative mx-auto">
                {/* Video demonstration section */}
                <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
                  <div className="relative">
                    <VideoPlayer posterUrl="public/lovable-uploads/0e13ccbc-84ac-4284-9215-34f34cd587c9.png" videoUrl="https://player.vimeo.com/external/373302913.sd.mp4?s=72fd4102f0aea0f1777ca59483520a654c8583a0&profile_id=164&oauth2_token_id=57447761" className="aspect-video w-full rounded-2xl overflow-hidden" />
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10 pointer-events-none">
                      <div className="bg-white/90 backdrop-blur-sm px-6 py-3 rounded-lg shadow-lg">
                        <h3 className="text-brand-primary font-bold text-xl text-center">
                          Veja como funciona
                        </h3>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Animated Detective Frog */}
                <motion.div initial={{
                y: 0
              }} animate={{
                y: [0, -8, 0],
                rotate: [-2, 2, -2]
              }} transition={{
                repeat: Infinity,
                duration: 6,
                ease: "easeInOut"
              }} className="absolute -bottom-16 -right-8 w-40 md:w-48 lg:w-56">
                  
                </motion.div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute top-1/3 -left-8 -z-10 w-24 h-24 bg-brand-primary/20 rounded-full blur-2xl"></div>
              <div className="absolute bottom-1/3 -right-8 -z-10 w-32 h-32 bg-brand-dark/10 rounded-full blur-2xl"></div>
            </motion.div>
          </div>
        </div>
        
        {/* How It Works Section with improved spacing */}
        <div className="py-24 bg-white rounded-2xl shadow-sm mt-28">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <span className="inline-block px-4 py-2 rounded-full bg-brand-primary/10 text-brand-primary font-semibold text-sm mb-4">
                Processo simples e eficiente
              </span>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Como Funciona</h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto">
                Conectar criadores e marcas nunca foi tão fácil. Um processo simples que 
                gera resultados extraordinários para todos os envolvidos.
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-10 mt-16">
              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5
            }} className="bg-white p-8 rounded-xl shadow-md border border-gray-100 relative">
                <div className="bg-brand-primary text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-xl absolute -top-6 left-8">
                  1
                </div>
                <div className="pt-6">
                  <h3 className="text-xl font-semibold mb-4 text-brand-dark">Cadastre-se na plataforma</h3>
                  <p className="text-gray-600">
                    Crie seu perfil como criador de conteúdo ou empresa, 
                    adicionando suas informações e preferências de trabalho.
                  </p>
                </div>
              </motion.div>
              
              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5,
              delay: 0.2
            }} className="bg-white p-8 rounded-xl shadow-md border border-gray-100 relative">
                <div className="bg-brand-primary text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-xl absolute -top-6 left-8">
                  2
                </div>
                <div className="pt-6">
                  <h3 className="text-xl font-semibold mb-4 text-brand-dark">Encontre parcerias ideais</h3>
                  <p className="text-gray-600">
                    Use nossos filtros avançados para encontrar o parceiro 
                    perfeito para seus objetivos de marketing ou conteúdo.
                  </p>
                </div>
              </motion.div>
              
              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5,
              delay: 0.4
            }} className="bg-white p-8 rounded-xl shadow-md border border-gray-100 relative">
                <div className="bg-brand-primary text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-xl absolute -top-6 left-8">
                  3
                </div>
                <div className="pt-6">
                  <h3 className="text-xl font-semibold mb-4 text-brand-dark">Conecte e cresça</h3>
                  <p className="text-gray-600">
                    Negocie diretamente, estabeleça parcerias e acompanhe 
                    resultados em tempo real através da nossa plataforma.
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
        
        {/* Partners Section with improved spacing */}
        <div className="py-24 text-center">
          <p className="text-gray-700 font-medium mb-10 text-xl">Empresas que confiam na nossa plataforma</p>
          <div className="flex flex-wrap justify-center gap-12 md:gap-20">
            <motion.img initial={{
            opacity: 0,
            y: 10
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.5,
            delay: 0.1
          }} src="https://upload.wikimedia.org/wikipedia/commons/2/2f/Google_2015_logo.svg" alt="Google" className="h-8 md:h-10 object-contain grayscale hover:grayscale-0 transition-all" />
            <motion.img initial={{
            opacity: 0,
            y: 10
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.5,
            delay: 0.2
          }} src="https://upload.wikimedia.org/wikipedia/commons/0/08/Netflix_2015_logo.svg" alt="Netflix" className="h-8 md:h-10 object-contain grayscale hover:grayscale-0 transition-all" />
            <motion.img initial={{
            opacity: 0,
            y: 10
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.5,
            delay: 0.3
          }} src="https://upload.wikimedia.org/wikipedia/commons/4/4a/Amazon_icon.svg" alt="Amazon" className="h-8 md:h-10 object-contain grayscale hover:grayscale-0 transition-all" />
            <motion.img initial={{
            opacity: 0,
            y: 10
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.5,
            delay: 0.4
          }} src="https://upload.wikimedia.org/wikipedia/commons/c/ce/Coca-Cola_logo.svg" alt="Coca-Cola" className="h-8 md:h-10 object-contain grayscale hover:grayscale-0 transition-all" />
            <motion.img initial={{
            opacity: 0,
            y: 10
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.5,
            delay: 0.5
          }} src="https://upload.wikimedia.org/wikipedia/commons/8/89/Facebook_Logo_%282019%29.svg" alt="Meta" className="h-8 md:h-10 object-contain grayscale hover:grayscale-0 transition-all" />
          </div>
        </div>
      </div>
    </div>;
};
export default HeroSection;