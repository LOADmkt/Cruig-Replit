
import React from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShieldCheck } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { formatPrice } from '@/lib/subscriptionPlans';

interface ActiveSubscriptionCardProps {
  subscription: {
    plan: string | null;
    expiresAt: string | null;
  };
  loading: boolean;
  onCancel: () => void;
  onChangePlan?: () => void;
  showChangePlan?: boolean;
}

export function ActiveSubscriptionCard({ 
  subscription, 
  loading,
  onCancel,
  onChangePlan,
  showChangePlan = false
}: ActiveSubscriptionCardProps) {
  const getPlanName = (planId: string | null) => {
    if (!planId) return 'Premium';
    
    switch(planId) {
      case 'basic':
        return 'Básico';
      case 'pro':
      case 'business':
        return 'Pro';
      case 'enterprise':
        return 'Enterprise';
      default:
        return planId.charAt(0).toUpperCase() + planId.slice(1);
    }
  };

  const getPlanPrice = (planId: string | null) => {
    if (!planId) return formatPrice(99.97);
    
    switch(planId) {
      case 'basic':
        return formatPrice(47);
      case 'pro':
      case 'business':
        return formatPrice(97);
      case 'enterprise':
        return formatPrice(247);
      default:
        return formatPrice(99.97);
    }
  };

  const formattedExpiryDate = subscription.expiresAt
    ? new Date(subscription.expiresAt).toLocaleDateString('pt-BR')
    : 'N/A';

  return (
    <Card className="border-2 border-green-500 bg-green-50 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-16 -translate-y-16">
        <div className="absolute top-0 right-0 w-full h-full bg-green-200 rounded-full opacity-50"></div>
      </div>
      
      <CardHeader className="relative z-10">
        <CardTitle className="flex items-center text-green-800">
          <ShieldCheck className="mr-2 h-5 w-5 text-green-700" />
          <span>Plano {getPlanName(subscription.plan)} Ativo</span>
          <Badge variant="success" className="ml-3">Ativo</Badge>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="relative z-10">
        <div className="space-y-4">
          <div>
            <p className="text-2xl font-bold text-brand-dark">{getPlanPrice(subscription.plan)}</p>
            <p className="text-sm text-gray-600">por mês</p>
          </div>
          
          <div className="space-y-2">
            <div>
              <span className="text-sm text-gray-600">Status:</span>
              <span className="ml-2 text-sm font-medium text-green-600">Ativo</span>
            </div>
            <div>
              <span className="text-sm text-gray-600">Válido até:</span>
              <span className="ml-2 text-sm font-medium">{formattedExpiryDate}</span>
            </div>
          </div>
          
          <div className="pt-2">
            <h4 className="font-medium text-green-800 mb-2">Benefícios inclusos:</h4>
            <div className="grid grid-cols-2 gap-2">
              <Badge variant="success" className="bg-green-500 justify-center py-1">Recursos premium</Badge>
              <Badge variant="success" className="bg-green-500 justify-center py-1">Acesso ilimitado</Badge>
              <Badge variant="success" className="bg-green-500 justify-center py-1">Suporte prioritário</Badge>
              <Badge variant="success" className="bg-green-500 justify-center py-1">Campanhas avançadas</Badge>
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="flex gap-3 relative z-10">
        {showChangePlan && onChangePlan && (
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={onChangePlan}
            disabled={loading}
          >
            Mudar plano
          </Button>
        )}
        <Button 
          variant="outline" 
          className="flex-1 border-red-300 text-red-600 hover:bg-red-50"
          onClick={onCancel}
          disabled={loading}
        >
          {loading ? "Processando..." : "Cancelar assinatura"}
        </Button>
      </CardFooter>
    </Card>
  );
}
