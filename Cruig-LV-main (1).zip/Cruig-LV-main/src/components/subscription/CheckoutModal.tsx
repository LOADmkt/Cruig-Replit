
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { formatPrice } from '@/lib/subscriptionPlans';
import { useSubscription } from '@/hooks/useSubscription';
import { useToast } from '@/hooks/use-toast';

interface CheckoutModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  planId: string;
  planName: string;
  planPrice: string;
  userType: 'creator' | 'company';
}

export function CheckoutModal({ 
  open, 
  onOpenChange,
  planId,
  planName,
  planPrice,
  userType
}: CheckoutModalProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const { subscribeToPlan } = useSubscription();
  const { toast } = useToast();

  const handleCheckout = async () => {
    try {
      setIsProcessing(true);
      
      // In a real application, we would redirect to Stripe using createCheckoutSession
      // For now, we'll simulate this with our local subscribeToPlan function
      const result = await subscribeToPlan(planId);
      
      if (result.success) {
        toast({
          title: "Assinatura realizada",
          description: `Você assinou o plano ${planName} com sucesso!`
        });
        onOpenChange(false);
      } else {
        throw new Error(result.error || "Erro desconhecido");
      }
    } catch (error: any) {
      console.error("Erro ao processar pagamento:", error);
      toast({
        title: "Erro ao processar pagamento",
        description: error.message || "Ocorreu um erro ao processar seu pagamento. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Finalizar assinatura</DialogTitle>
          <DialogDescription>
            Você está prestes a assinar o plano {planName}.
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="border rounded-lg p-4">
            <h3 className="font-medium mb-2">Detalhes do plano</h3>
            
            <div className="flex justify-between items-center mb-2">
              <span>Plano:</span>
              <span className="font-medium">{planName}</span>
            </div>
            
            <div className="flex justify-between items-center">
              <span>Preço:</span>
              <span className="font-bold text-lg">{planPrice}</span>
            </div>
            
            <div className="text-xs text-gray-500 mt-2">
              Cobrado mensalmente. Cancele a qualquer momento.
            </div>
          </div>
          
          <div className="text-sm text-gray-500">
            Ao clicar em "Prosseguir para pagamento", você será redirecionado para finalizar 
            seu pagamento com segurança.
          </div>
        </div>
        
        <div className="flex justify-between">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isProcessing}>
            Cancelar
          </Button>
          <Button onClick={handleCheckout} disabled={isProcessing}>
            {isProcessing ? "Processando..." : "Prosseguir para pagamento"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
