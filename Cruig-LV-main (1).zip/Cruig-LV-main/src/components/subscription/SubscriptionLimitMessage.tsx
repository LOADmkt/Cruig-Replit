
import React from 'react';
import { AlertCircle, CheckCircle, InfoIcon } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Link } from 'react-router-dom';

interface SubscriptionLimitMessageProps {
  message: string;
  actionText?: string;
  actionHref?: string;
  variant?: 'warning' | 'success' | 'info';
  className?: string;
}

export function SubscriptionLimitMessage({
  message,
  actionText,
  actionHref,
  variant = 'warning',
  className = ''
}: SubscriptionLimitMessageProps) {
  const getVariantStyles = () => {
    switch (variant) {
      case 'warning':
        return {
          bg: 'bg-amber-50',
          border: 'border-amber-200',
          text: 'text-amber-700',
          icon: <AlertCircle className="h-4 w-4 text-amber-600" />
        };
      case 'success':
        return {
          bg: 'bg-green-50',
          border: 'border-green-200',
          text: 'text-green-700',
          icon: <CheckCircle className="h-4 w-4 text-green-600" />
        };
      case 'info':
        return {
          bg: 'bg-blue-50',
          border: 'border-blue-200',
          text: 'text-blue-700',
          icon: <InfoIcon className="h-4 w-4 text-blue-600" />
        };
      default:
        return {
          bg: 'bg-amber-50',
          border: 'border-amber-200',
          text: 'text-amber-700',
          icon: <AlertCircle className="h-4 w-4 text-amber-600" />
        };
    }
  };
  
  const styles = getVariantStyles();
  
  return (
    <Alert className={`${styles.bg} ${styles.border} ${className}`}>
      {styles.icon}
      <AlertDescription className={`flex justify-between items-center ${styles.text}`}>
        <span>{message}</span>
        {actionText && actionHref && (
          <Link 
            to={actionHref}
            className="ml-4 text-sm font-medium underline hover:text-opacity-80"
          >
            {actionText}
          </Link>
        )}
      </AlertDescription>
    </Alert>
  );
}
