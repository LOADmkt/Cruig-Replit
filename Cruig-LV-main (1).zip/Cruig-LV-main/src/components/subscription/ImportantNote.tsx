
import React from 'react';
import { AlertCircle } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";

interface ImportantNoteProps {
  userType: 'creator' | 'company';
}

export function ImportantNote({ userType }: ImportantNoteProps) {
  return (
    <Card className="bg-blue-50 border-blue-200">
      <CardContent className="pt-6">
        <div className="flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-800 space-y-2">
            <p className="font-medium">Importante sobre nossos planos:</p>
            <ul className="list-disc pl-5 space-y-1">
              {userType === 'creator' ? (
                <>
                  <li>Todos os planos são renovados automaticamente após o período contratado.</li>
                  <li>Você pode cancelar a qualquer momento e continuará com acesso até o final do período pago.</li>
                  <li>Com um plano Premium, você terá visibilidade destacada para empresas.</li>
                  <li>O pagamento é processado com segurança através do Stripe.</li>
                </>
              ) : (
                <>
                  <li>Todos os planos são renovados automaticamente após o período contratado.</li>
                  <li>Você pode cancelar a qualquer momento e continuará com acesso até o final do período pago.</li>
                  <li>Com um plano Business ou Enterprise, você terá acesso a campanhas e recursos exclusivos.</li>
                  <li>O pagamento é processado com segurança através do Stripe.</li>
                </>
              )}
            </ul>
            <p>Precisa de ajuda? Entre em contato com nosso suporte.</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
