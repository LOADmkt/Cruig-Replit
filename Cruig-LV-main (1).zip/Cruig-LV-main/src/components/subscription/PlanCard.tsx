
import React from 'react';
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Check, PiggyBank } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { formatPrice } from '@/lib/subscriptionPlans';

export interface Plan {
  id: string;
  name: string;
  price: number;
  priceRaw: number;
  period: string;
  billingCycle: 'monthly' | 'yearly';
  monthlyPrice?: number;
  totalPrice?: number;
  popular?: boolean;
  color?: string;
  features: string[];
  buttonText: string;
  description: string;
}

interface PlanCardProps {
  plan: Plan;
  isActive: boolean;
  isSelected: boolean;
  onSelect: (id: string) => void;
  subscription: {
    active: boolean;
    plan: string | null;
  };
}

export function PlanCard({ plan, isActive, isSelected, onSelect, subscription }: PlanCardProps) {
  const isYearly = plan.billingCycle === 'yearly';
  
  const getBorderColor = () => {
    if (isActive) return 'border-green-500';
    if (isSelected) return 'border-brand-primary';
    return 'border-gray-200';
  };
  
  const getBackgroundColor = () => {
    if (isActive) return 'bg-green-50';
    if (isSelected) return 'bg-brand-secondary/10';
    return '';
  };
  
  const getPlanColor = () => {
    switch (plan.color) {
      case 'blue':
        return 'bg-blue-500';
      case 'green':
        return 'bg-green-500';
      case 'purple':
        return 'bg-purple-500';
      default:
        return 'bg-brand-primary';
    }
  };

  return (
    <Card 
      className={`relative transition-all ${getBorderColor()} ${getBackgroundColor()} hover:shadow-md h-full flex flex-col`}
      onClick={() => !subscription.active && onSelect(plan.id)}
    >
      {plan.popular && (
        <Badge 
          className="absolute top-0 right-4 -translate-y-1/2 bg-amber-500 text-white border-2 border-white" 
          variant="default"
        >
          Popular
        </Badge>
      )}

      {isActive && (
        <Badge 
          className="absolute top-0 left-4 -translate-y-1/2 bg-green-500 text-white border-2 border-white" 
          variant="default"
        >
          Seu Plano
        </Badge>
      )}
      
      <CardHeader className={`p-4 border-b ${isActive ? 'border-green-200' : 'border-gray-100'}`}>
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold text-brand-dark">{plan.name}</h3>
          <div 
            className={`rounded-full w-4 h-4 ${getPlanColor()}`}
          />
        </div>
        <p className="text-sm text-gray-600">{plan.description}</p>
      </CardHeader>
      
      <CardContent className="p-4 flex-grow">
        <div className="mb-5">
          <div className="flex items-baseline">
            <span className="text-2xl font-bold">
              {isYearly ? formatPrice(plan.price / 12) : formatPrice(plan.price)}
            </span>
            <span className="text-gray-600 ml-1">
              /mês
            </span>
          </div>
          
          {isYearly && (
            <div className="flex items-center mt-1 text-green-600 text-sm">
              <PiggyBank className="mr-1 h-4 w-4" />
              <span>Economia de 20% no plano anual</span>
            </div>
          )}
          
          {isYearly && (
            <div className="text-xs text-gray-500 mt-1">
              Pagamento único de {formatPrice(plan.price)}
            </div>
          )}
        </div>
        
        <div className="space-y-3">
          {plan.features.map((feature, index) => (
            <div key={index} className="flex items-start">
              <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm">{feature}</span>
            </div>
          ))}
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button 
          className={`w-full ${isActive ? 'bg-green-500 hover:bg-green-600' : isSelected ? 'bg-brand-primary' : 'bg-brand-primary/80'}`}
          disabled={isActive || subscription.active}
          variant={isSelected ? 'default' : 'outline'}
          onClick={() => onSelect(plan.id)}
        >
          {isActive ? 'Plano atual' : subscription.active ? 'Indisponível' : plan.buttonText}
        </Button>
      </CardFooter>
    </Card>
  );
}
