
import React from 'react';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface SubscriptionLimitAlertProps {
  userType: 'creator' | 'company';
  showActions?: boolean;
}

export function SubscriptionLimitAlert({ userType, showActions = true }: SubscriptionLimitAlertProps) {
  const navigate = useNavigate();
  
  const alertTitle = userType === 'creator' 
    ? 'Límites da conta gratuita' 
    : 'Acesso limitado para empresas';
    
  const alertDescription = userType === 'creator'
    ? 'Sua conta gratuita tem limites de mensagens e campanhas. Assine um plano para recursos ilimitados.'
    : 'Para desbloquear acesso completo a todos os criadores, mensagens ilimitadas e recursos exclusivos, assine um de nossos planos premium.';
    
  const buttonText = 'Ver planos de assinatura';
  
  const handleButtonClick = () => {
    if (userType === 'creator') {
      navigate('/dashboard?tab=subscription');
    } else {
      navigate('/empresa-dashboard?tab=subscription');
    }
  };
  
  return (
    <Alert variant="warning" className="border-amber-300 bg-amber-50">
      <AlertCircle className="h-4 w-4 text-amber-600" />
      <AlertTitle className="text-amber-800">{alertTitle}</AlertTitle>
      <AlertDescription className="text-amber-700">
        {alertDescription}
        {showActions && (
          <Button
            variant="outline"
            className="mt-3 bg-white border-amber-400 hover:bg-amber-100 text-amber-800"
            onClick={handleButtonClick}
          >
            {buttonText}
          </Button>
        )}
      </AlertDescription>
    </Alert>
  );
}
