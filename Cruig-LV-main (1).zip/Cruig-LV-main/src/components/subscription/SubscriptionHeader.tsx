
import React from 'react';
import { RefreshCw, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SubscriptionHeaderProps {
  userType: 'creator' | 'company';
  isLoadingStatus: boolean;
  onRefresh: () => void;
}

export function SubscriptionHeader({ userType, isLoadingStatus, onRefresh }: SubscriptionHeaderProps) {
  const title = userType === 'creator'
    ? 'Planos para Criadores'
    : 'Planos para Empresas';
    
  const subtitle = userType === 'creator'
    ? 'Amplie seu alcance e receba mais oportunidades com nossos planos premium.'
    : 'Acesso completo a criadores de conteúdo e ferramentas exclusivas para suas campanhas.';
    
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold flex items-center text-brand-dark">
          <CreditCard className="mr-2 h-6 w-6 text-brand-primary" />
          {title}
        </h1>
        <Button
          variant="outline"
          size="sm"
          onClick={onRefresh}
          disabled={isLoadingStatus}
          className="flex items-center gap-1"
        >
          <RefreshCw className={`h-4 w-4 ${isLoadingStatus ? 'animate-spin' : ''}`} />
          <span>Atualizar</span>
        </Button>
      </div>
      <p className="text-gray-600">{subtitle}</p>
    </div>
  );
}
