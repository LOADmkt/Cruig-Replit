
import React from 'react';
import { PlanCard } from './PlanCard';
import { SubscriptionPlan } from '@/lib/subscriptionPlans';

interface SubscriptionPlansProps {
  plans: SubscriptionPlan[];
  selectedPlan: string | null;
  subscription: {
    active: boolean;
    plan: string | null;
  };
  onSelectPlan: (planId: string) => void;
}

export function SubscriptionPlans({ plans, selectedPlan, subscription, onSelectPlan }: SubscriptionPlansProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {plans.map((plan) => (
        <PlanCard
          key={plan.id}
          plan={{
            ...plan,
            priceRaw: plan.priceRaw || plan.price,
            period: plan.period || 'mensal',
            popular: plan.popular || false,
            color: plan.color || 'blue',
            billingCycle: plan.billingCycle || 'monthly',
            monthlyPrice: plan.monthlyPrice || plan.price,
            totalPrice: plan.totalPrice || plan.price
          }}
          isActive={subscription.active && subscription.plan === plan.id}
          isSelected={selectedPlan === plan.id}
          onSelect={onSelectPlan}
          subscription={subscription}
        />
      ))}
    </div>
  );
}
