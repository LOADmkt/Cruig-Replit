
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useSubscription } from '@/hooks/useSubscription';
import { CheckoutModal } from '@/components/subscription/CheckoutModal';
import { formatPrice } from '@/lib/subscriptionPlans';

interface SubscriptionCheckoutProps {
  userType: 'creator' | 'company';
  className?: string;
}

interface PlanType {
  id: string;
  name: string;
  price: number;
  period: string;
}

export function SubscriptionCheckout({ userType, className = '' }: SubscriptionCheckoutProps) {
  const { toast } = useToast();
  const { subscription } = useSubscription();
  const [selectedPlan, setSelectedPlan] = useState<PlanType | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  
  // Define plans based on user type
  const getPlans = () => {
    if (userType === 'creator') {
      return [
        {
          id: 'mensal',
          name: 'Mensal',
          price: 147,
          period: 'por mês'
        },
        {
          id: 'semestral',
          name: 'Semestral',
          price: 127,
          period: 'por mês'
        },
        {
          id: 'anual',
          name: 'Anual',
          price: 997,
          period: 'por ano'
        }
      ];
    } else {
      return [
        {
          id: 'mensal',
          name: 'Mensal',
          price: 197,
          period: 'por mês'
        },
        {
          id: 'semestral',
          name: 'Semestral',
          price: 170,
          period: 'por mês'
        },
        {
          id: 'anual',
          name: 'Anual',
          price: 1524,
          period: 'por ano'
        }
      ];
    }
  };
  
  const plans = getPlans();
  
  const handleSelectPlan = (plan: PlanType) => {
    setSelectedPlan(plan);
    
    if (subscription.active) {
      toast({
        title: "Você já possui uma assinatura ativa",
        description: "Para alterar seu plano, acesse a seção de gerenciamento de assinatura.",
        variant: "destructive",
      });
      return;
    }
    
    setIsCheckoutOpen(true);
  };
  
  return (
    <div className={className}>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Button
            key={plan.id}
            variant="outline"
            className="p-6 h-auto flex flex-col items-start text-left"
            onClick={() => handleSelectPlan(plan)}
          >
            <div className="font-bold text-lg mb-1">{plan.name}</div>
            <div className="flex items-baseline mb-2">
              <span className="text-2xl font-bold">{formatPrice(plan.price)}</span>
              <span className="text-sm text-gray-500 ml-1">{plan.period}</span>
            </div>
            <div className="text-sm text-gray-600">
              {plan.id === 'mensal' && 'Flexibilidade mensal sem compromisso'}
              {plan.id === 'semestral' && 'Economia e benefícios exclusivos'}
              {plan.id === 'anual' && 'Melhor custo-benefício'}
            </div>
          </Button>
        ))}
      </div>

      {selectedPlan && (
        <CheckoutModal
          open={isCheckoutOpen}
          onOpenChange={setIsCheckoutOpen}
          planId={selectedPlan.id}
          planName={selectedPlan.name}
          planPrice={formatPrice(selectedPlan.price)}
          userType={userType}
        />
      )}
    </div>
  );
}
