
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabaseClient';
import { Loader2 } from 'lucide-react';

interface ManageSubscriptionButtonProps {
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 
           'ghost' | 'link' | 'brand';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  className?: string;
  children?: React.ReactNode;
}

export function ManageSubscriptionButton({ 
  variant = 'outline',
  size = 'default',
  className = '',
  children = 'Gerenciar assinatura'
}: ManageSubscriptionButtonProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  const handleOpenCustomerPortal = async () => {
    setLoading(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('customer-portal');
      
      if (error) throw new Error(`Error accessing customer portal: ${error.message}`);
      
      if (data?.url) {
        window.location.href = data.url;
      } else {
        throw new Error('No portal URL received');
      }
    } catch (err) {
      console.error('Error opening customer portal:', err);
      
      toast({
        title: 'Erro ao acessar portal',
        description: err instanceof Error ? err.message : 'Não foi possível abrir o portal de gerenciamento',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      variant={variant}
      size={size}
      className={className}
      onClick={handleOpenCustomerPortal}
      disabled={loading}
    >
      {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
      {children}
    </Button>
  );
}
