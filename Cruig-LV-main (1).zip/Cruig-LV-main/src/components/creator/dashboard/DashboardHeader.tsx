
import React from 'react';
import { Button } from '@/components/ui/button';

interface DashboardHeaderProps {
  userName: string;
  onCampaignSearch: () => void;
}

export function DashboardHeader({ userName, onCampaignSearch }: DashboardHeaderProps) {
  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-brand-secondary/30 p-6 rounded-xl border border-brand-primary/20">
      <div>
        <h1 className="text-2xl font-bold text-brand-dark">Bem-vindo, {userName}</h1>
        <p className="text-gray-600 mt-1">Aqui está o resumo da sua conta</p>
      </div>
      <Button variant="brand" onClick={onCampaignSearch}>Buscar Campanhas</Button>
    </div>
  );
}
