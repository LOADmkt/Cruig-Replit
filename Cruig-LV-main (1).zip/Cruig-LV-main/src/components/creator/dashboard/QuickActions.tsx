
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { User, FileText, MessageSquare, ChevronRight } from 'lucide-react';

interface QuickActionsProps {
  pendingCampaigns: number;
  unreadMessages: number;
  hasReachedCampaignLimit: boolean;
  isSubscriptionActive: boolean;
  onViewProfile: () => void;
  onCampaignSearch: () => void;
  onViewCampaigns: () => void;
  onViewMessages: () => void;
}

export function QuickActions({
  pendingCampaigns,
  unreadMessages,
  hasReachedCampaignLimit,
  isSubscriptionActive,
  onViewProfile,
  onCampaignSearch,
  onViewCampaigns,
  onViewMessages
}: QuickActionsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-brand-dark">Ações rápidas</CardTitle>
        <CardDescription>
          Acesse as principais funcionalidades
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <Button 
            variant="outline" 
            className="w-full justify-between"
            onClick={onViewProfile}
          >
            <div className="flex items-center">
              <User className="mr-2 h-4 w-4 text-brand-primary" />
              <span>Ver meu perfil</span>
            </div>
            <ChevronRight className="h-4 w-4" />
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full justify-between"
            onClick={onCampaignSearch}
            disabled={hasReachedCampaignLimit && !isSubscriptionActive}
          >
            <div className="flex items-center">
              <FileText className="mr-2 h-4 w-4 text-brand-primary" />
              <span>Buscar Campanhas</span>
            </div>
            <ChevronRight className="h-4 w-4" />
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full justify-between"
            onClick={onViewCampaigns}
          >
            <div className="flex items-center">
              <FileText className="mr-2 h-4 w-4 text-brand-primary" />
              <span>Minhas Candidaturas</span>
              {pendingCampaigns > 0 && (
                <Badge variant="brand" className="ml-2">
                  {pendingCampaigns}
                </Badge>
              )}
            </div>
            <ChevronRight className="h-4 w-4" />
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full justify-between"
            onClick={onViewMessages}
          >
            <div className="flex items-center">
              <MessageSquare className="mr-2 h-4 w-4 text-brand-primary" />
              <span>Mensagens</span>
              {unreadMessages > 0 && (
                <Badge variant="brand" className="ml-2">
                  {unreadMessages}
                </Badge>
              )}
            </div>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
