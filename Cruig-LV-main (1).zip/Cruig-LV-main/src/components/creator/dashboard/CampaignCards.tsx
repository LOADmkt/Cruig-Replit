
import React from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, DollarSign, Building, Check, X } from 'lucide-react';

interface CreatorCampaign {
  id: string;
  companyName: string;
  campaignName: string;
  status: string;
  payment: string;
  deadline: string;
}

interface OpenCampaign {
  id: string;
  companyName: string;
  campaignName: string;
  budget: string;
  deadline: string;
  requirements: string;
}

interface CampaignCardsProps {
  campaigns: CreatorCampaign[];
  openCampaigns: OpenCampaign[];
}

export function CampaignCards({ campaigns, openCampaigns }: CampaignCardsProps) {
  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'ativa':
        return <Badge className="bg-green-500">Ativa</Badge>;
      case 'convite':
        return <Badge className="bg-brand-tertiary">Convite</Badge>;
      case 'finalizada':
        return <Badge className="bg-gray-500">Finalizada</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const handleAcceptInvite = (id: string) => {
    console.log('Aceitar convite:', id);
    // API call to accept invite
  };

  const handleRejectInvite = (id: string) => {
    console.log('Rejeitar convite:', id);
    // API call to reject invite
  };

  const handleApplyCampaign = (id: string) => {
    console.log('Aplicar para campanha:', id);
    // API call to apply for campaign
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-brand-darkGray">Suas Campanhas e Convites</h2>
        
        {campaigns.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {campaigns.map(campaign => (
              <Card key={campaign.id} className="overflow-hidden shadow-card hover:shadow-card-hover transition-shadow">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center mb-2">
                        <Building className="h-4 w-4 mr-2 text-gray-500" />
                        <span className="text-sm text-gray-600">{campaign.companyName}</span>
                      </div>
                      <h3 className="font-semibold text-lg">{campaign.campaignName}</h3>
                      <div className="mt-2">
                        {getStatusBadge(campaign.status)}
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-sm font-medium text-gray-500">Pagamento</span>
                      <span className="text-lg font-semibold text-brand-dark">{campaign.payment}</span>
                    </div>
                  </div>
                  
                  <div className="mt-4 flex items-center text-sm text-gray-500">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>Prazo: {campaign.deadline}</span>
                  </div>
                </CardContent>
                
                {campaign.status === 'convite' && (
                  <CardFooter className="bg-gray-50 px-6 py-3 flex justify-end space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      onClick={() => handleRejectInvite(campaign.id)}
                    >
                      <X className="h-4 w-4 mr-1" /> Recusar
                    </Button>
                    <Button
                      size="sm"
                      className="bg-brand-primary hover:bg-brand-dark text-white"
                      onClick={() => handleAcceptInvite(campaign.id)}
                    >
                      <Check className="h-4 w-4 mr-1" /> Aceitar
                    </Button>
                  </CardFooter>
                )}
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-dashed border-2 border-gray-200">
            <CardContent className="p-8">
              <div className="text-center">
                <Calendar className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">
                  Sem campanhas ou convites
                </h3>
                <p className="mt-1 text-sm text-gray-500">
                  Você não possui campanhas ativas ou convites pendentes no momento.
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-brand-darkGray">Campanhas Disponíveis</h2>
        
        {openCampaigns.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {openCampaigns.map(campaign => (
              <Card key={campaign.id} className="overflow-hidden shadow-card hover:shadow-card-hover transition-shadow">
                <CardContent className="p-6">
                  <div>
                    <div className="flex items-center mb-2">
                      <Building className="h-4 w-4 mr-2 text-gray-500" />
                      <span className="text-sm text-gray-600">{campaign.companyName}</span>
                    </div>
                    <h3 className="font-semibold text-lg">{campaign.campaignName}</h3>
                    
                    <div className="mt-3 flex items-center text-sm">
                      <DollarSign className="h-4 w-4 mr-1 text-gray-500" />
                      <span>Orçamento: {campaign.budget}</span>
                    </div>
                    
                    <div className="mt-1 flex items-center text-sm text-gray-500">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>Prazo: {campaign.deadline}</span>
                    </div>
                    
                    <div className="mt-2 text-sm text-gray-600">
                      <span>Requisitos: {campaign.requirements}</span>
                    </div>
                  </div>
                </CardContent>
                
                <CardFooter className="bg-gray-50 px-6 py-3">
                  <Button
                    className="ml-auto bg-brand-primary hover:bg-brand-dark text-white"
                    onClick={() => handleApplyCampaign(campaign.id)}
                  >
                    Aplicar
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-dashed border-2 border-gray-200">
            <CardContent className="p-8">
              <div className="text-center">
                <Calendar className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">
                  Sem campanhas disponíveis
                </h3>
                <p className="mt-1 text-sm text-gray-500">
                  Não há campanhas disponíveis para aplicação no momento.
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
