
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { MessageSquare, Calendar, AlertCircle } from 'lucide-react';

interface MetricsGridProps {
  data: any;
}

export function MetricsGrid({ data }: MetricsGridProps) {
  const metrics = [
    {
      title: 'Convites Recebidos',
      value: data.invites,
      icon: <MessageSquare className="h-5 w-5" />,
      color: 'bg-brand-tertiary/10 text-brand-tertiary'
    },
    {
      title: 'Campanhas em Andamento',
      value: data.activeCampaigns,
      icon: <Calendar className="h-5 w-5" />,
      color: 'bg-brand-primary/10 text-brand-primary'
    },
    {
      title: 'Ganhos Estimados',
      value: data.estimatedEarnings,
      icon: <AlertCircle className="h-5 w-5" />,
      color: 'bg-brand-dark/10 text-brand-dark'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {metrics.map((metric, index) => (
        <Card key={index} className="shadow-card hover:shadow-card-hover transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">{metric.title}</p>
                <h3 className="text-3xl font-bold mt-2">{metric.value}</h3>
              </div>
              <div className={`rounded-full p-3 ${metric.color}`}>
                {metric.icon}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
