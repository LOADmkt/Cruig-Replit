
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface PremiumAccountCardProps {
  subscription: {
    active: boolean;
    planName?: string;
    expiresAt?: string;
  };
}

export function PremiumAccountCard({ subscription }: PremiumAccountCardProps) {
  return (
    <Card className="border-2 border-green-500 bg-green-50">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-green-800">
          <Badge variant="success" className="mr-2">Premium</Badge>
          Plano {subscription.planName || 'Premium'} Ativo
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p>Você tem acesso a todas as funcionalidades premium da plataforma até {new Date(subscription.expiresAt || "").toLocaleDateString('pt-BR')}.</p>
        <div className="flex gap-2 mt-3">
          <Badge variant="success" className="bg-green-500">Candidaturas ilimitadas</Badge>
          <Badge variant="success" className="bg-green-500">Mensagens ilimitadas</Badge>
          <Badge variant="success" className="bg-green-500">Perfil destacado</Badge>
        </div>
      </CardContent>
    </Card>
  );
}
