
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { User, Instagram, Youtube, Twitter, ExternalLink } from 'lucide-react';
import { BrandTiktok } from '@/components/icons/BrandTiktok';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface SocialStats {
  followers: number;
  engagement?: number;
}

interface SocialNetworks {
  instagram?: { username: string; followers?: string; engagement?: string; connected?: boolean; stats?: SocialStats };
  youtube?: { username: string; followers?: string; engagement?: string; connected?: boolean; stats?: SocialStats };
  tiktok?: { username: string; followers?: string; engagement?: string; connected?: boolean; stats?: SocialStats };
  twitter?: { username: string; followers?: string; engagement?: string; connected?: boolean; stats?: SocialStats };
}

interface ProfileSummaryProps {
  userData: any;
  onConnectSocial?: () => void;
}

export function ProfileSummary({ userData, onConnectSocial }: ProfileSummaryProps) {
  const navigate = useNavigate();
  
  const handleSettingsClick = () => {
    navigate('/dashboard?tab=settings');
  };
  
  const handleConnectSocial = () => {
    if (onConnectSocial) {
      onConnectSocial();
    } else {
      navigate('/dashboard?tab=social');
    }
  };
  
  // Get profile data or default values
  const profile = userData?.perfil || {};
  const socialNetworks: SocialNetworks = profile?.redeSocial || {};
  const hasSocialNetworks = Object.keys(socialNetworks).length > 0;
  const anyConnected = Object.values(socialNetworks).some(network => network?.connected);
  
  // Format follower counts for display
  const formatFollowers = (count: string | undefined) => {
    if (!count) return 'N/A';
    
    // If it's already formatted like "10k", return as is
    if (typeof count === 'string' && count.includes('k')) return count;
    
    // Try to convert to number
    const num = parseInt(count, 10);
    if (isNaN(num)) return count;
    
    // Format number
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}k`;
    }
    return num.toString();
  };

  return (
    <Card className="shadow-sm border border-gray-200">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
          {/* Profile Image */}
          <div className="flex-shrink-0">
            {profile?.avatar ? (
              <Avatar className="h-24 w-24 md:h-32 md:w-32 border-2 border-brand-primary/20">
                <AvatarImage src={profile.avatar} alt={profile.nome || userData?.nome || 'Perfil'} />
                <AvatarFallback className="bg-brand-primary/10">
                  <User className="h-12 w-12 text-brand-primary" />
                </AvatarFallback>
              </Avatar>
            ) : (
              <div className="h-24 w-24 md:h-32 md:w-32 rounded-full bg-brand-primary/10 flex items-center justify-center border-2 border-brand-primary/20">
                <User className="h-12 w-12 text-brand-primary" />
              </div>
            )}
          </div>
          
          {/* Profile Info */}
          <div className="flex-grow text-center md:text-left">
            <div className="space-y-1">
              <h2 className="text-xl font-bold">{profile.nome || userData?.nome || 'Nome não disponível'}</h2>
              
              {profile.username && (
                <p className="text-gray-600">@{profile.username.replace('@', '')}</p>
              )}
              
              {profile.bio && (
                <p className="text-gray-700 mt-2">{profile.bio}</p>
              )}
              
              {!profile.bio && (
                <p className="text-gray-500 italic mt-2">Adicione uma biografia para seu perfil</p>
              )}
              
              {/* Badges */}
              <div className="flex flex-wrap gap-2 mt-2 justify-center md:justify-start">
                {profile?.verificado && (
                  <Badge variant="success">Verificado</Badge>
                )}
                {profile?.nicho?.map((n: string, i: number) => (
                  <Badge key={i} variant="secondary">{n}</Badge>
                ))}
                {(!profile?.nicho || profile.nicho.length === 0) && (
                  <Badge variant="outline" className="text-gray-600">Adicione seus nichos</Badge>
                )}
              </div>
            </div>
          </div>
          
          {/* Actions */}
          <div className="flex-shrink-0 mt-4 md:mt-0 flex flex-col gap-3 w-full md:w-auto">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleSettingsClick}
              className="w-full md:w-auto"
            >
              Editar Perfil
            </Button>
            <Button 
              variant={anyConnected ? "outline" : "default"} 
              size="sm"
              onClick={handleConnectSocial}
              className="w-full md:w-auto"
            >
              {anyConnected ? 'Gerenciar Redes Sociais' : 'Conectar Redes Sociais'}
            </Button>
          </div>
        </div>
        
        {/* Social Networks Section */}
        <div className="mt-6 pt-4 border-t border-gray-200">
          <h3 className="text-lg font-semibold mb-3">Redes Sociais</h3>
          
          {hasSocialNetworks ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {socialNetworks.instagram && (
                <div className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg p-4 text-white">
                  <div className="flex items-center mb-2">
                    <Instagram className="h-5 w-5 mr-2" />
                    <span className="font-medium">Instagram</span>
                    {socialNetworks.instagram.connected && (
                      <span className="ml-2 bg-green-400 rounded-full h-2 w-2"></span>
                    )}
                  </div>
                  <div className="font-bold text-lg">
                    {socialNetworks.instagram.username || '@username'}
                  </div>
                  <div className="flex justify-between mt-2 text-sm">
                    <span>{formatFollowers(socialNetworks.instagram.followers)} seguidores</span>
                    {socialNetworks.instagram.engagement && (
                      <span>{socialNetworks.instagram.engagement} eng.</span>
                    )}
                  </div>
                </div>
              )}
              
              {socialNetworks.youtube && (
                <div className="bg-red-600 rounded-lg p-4 text-white">
                  <div className="flex items-center mb-2">
                    <Youtube className="h-5 w-5 mr-2" />
                    <span className="font-medium">YouTube</span>
                    {socialNetworks.youtube.connected && (
                      <span className="ml-2 bg-green-400 rounded-full h-2 w-2"></span>
                    )}
                  </div>
                  <div className="font-bold text-lg">
                    {socialNetworks.youtube.username || 'Canal'}
                  </div>
                  <div className="flex justify-between mt-2 text-sm">
                    <span>{formatFollowers(socialNetworks.youtube.followers)} inscritos</span>
                    {socialNetworks.youtube.engagement && (
                      <span>{socialNetworks.youtube.engagement} eng.</span>
                    )}
                  </div>
                </div>
              )}
              
              {socialNetworks.tiktok && (
                <div className="bg-black rounded-lg p-4 text-white">
                  <div className="flex items-center mb-2">
                    <BrandTiktok className="h-5 w-5 mr-2" />
                    <span className="font-medium">TikTok</span>
                    {socialNetworks.tiktok.connected && (
                      <span className="ml-2 bg-green-400 rounded-full h-2 w-2"></span>
                    )}
                  </div>
                  <div className="font-bold text-lg">
                    {socialNetworks.tiktok.username || '@username'}
                  </div>
                  <div className="flex justify-between mt-2 text-sm">
                    <span>{formatFollowers(socialNetworks.tiktok.followers)} seguidores</span>
                    {socialNetworks.tiktok.engagement && (
                      <span>{socialNetworks.tiktok.engagement} eng.</span>
                    )}
                  </div>
                </div>
              )}
              
              {socialNetworks.twitter && (
                <div className="bg-blue-500 rounded-lg p-4 text-white">
                  <div className="flex items-center mb-2">
                    <Twitter className="h-5 w-5 mr-2" />
                    <span className="font-medium">Twitter (X)</span>
                    {socialNetworks.twitter.connected && (
                      <span className="ml-2 bg-green-400 rounded-full h-2 w-2"></span>
                    )}
                  </div>
                  <div className="font-bold text-lg">
                    {socialNetworks.twitter.username || '@username'}
                  </div>
                  <div className="flex justify-between mt-2 text-sm">
                    <span>{formatFollowers(socialNetworks.twitter.followers)} seguidores</span>
                    {socialNetworks.twitter.engagement && (
                      <span>{socialNetworks.twitter.engagement} eng.</span>
                    )}
                  </div>
                </div>
              )}
              
              {/* Show connect button if no social networks are available */}
              {(!socialNetworks.instagram && !socialNetworks.youtube && !socialNetworks.tiktok && !socialNetworks.twitter) && (
                <div className="col-span-full flex justify-center">
                  <Button onClick={handleConnectSocial}>
                    Conectar Redes Sociais
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center p-6 bg-gray-50 rounded-lg">
              <ExternalLink className="h-12 w-12 mx-auto text-gray-400 mb-2" />
              <h4 className="text-lg font-medium">Nenhuma rede social conectada</h4>
              <p className="text-gray-500 mb-4">Conecte suas redes sociais para aumentar suas chances de parcerias</p>
              <Button onClick={handleConnectSocial}>
                Conectar Redes Sociais
              </Button>
            </div>
          )}
        </div>
        
        {/* Audience Demographics */}
        {anyConnected && (
          <div className="mt-6 pt-4 border-t border-gray-200">
            <h3 className="text-lg font-semibold mb-3">Dados do Público</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-sm text-gray-600 mb-2">Faixa Etária</h4>
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-sm">
                      <span>18-24</span>
                      <span>35%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full">
                      <div className="h-2 bg-brand-primary rounded-full" style={{ width: '35%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm">
                      <span>25-34</span>
                      <span>42%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full">
                      <div className="h-2 bg-brand-primary rounded-full" style={{ width: '42%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm">
                      <span>35-44</span>
                      <span>15%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full">
                      <div className="h-2 bg-brand-primary rounded-full" style={{ width: '15%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm">
                      <span>45+</span>
                      <span>8%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full">
                      <div className="h-2 bg-brand-primary rounded-full" style={{ width: '8%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="text-sm text-gray-600 mb-2">Gênero</h4>
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-gray-100 p-3 rounded-lg text-center">
                    <p className="text-xs text-gray-600">Masculino</p>
                    <p className="font-bold">48%</p>
                  </div>
                  <div className="bg-gray-100 p-3 rounded-lg text-center">
                    <p className="text-xs text-gray-600">Feminino</p>
                    <p className="font-bold">50%</p>
                  </div>
                  <div className="bg-gray-100 p-3 rounded-lg text-center">
                    <p className="text-xs text-gray-600">Outro</p>
                    <p className="font-bold">2%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
