
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface AccountLimitsCardProps {
  usageCount: {
    messages: number;
    maxFreeMessages: number;
    campaigns: number;
    maxFreeCampaigns: number;
  };
}

export function AccountLimitsCard({ usageCount }: AccountLimitsCardProps) {
  const navigate = useNavigate();
  
  return (
    <Card className="border border-amber-200 bg-amber-50">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center text-amber-800">
          <AlertCircle className="mr-2 h-5 w-5" />
          Limites da conta gratuita
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span>Mensagens enviadas:</span>
            <span className="font-medium">{usageCount.messages} de {usageCount.maxFreeMessages} permitidas</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className={`h-2.5 rounded-full ${usageCount.messages >= usageCount.maxFreeMessages ? 'bg-red-500' : 'bg-green-500'}`} 
              style={{ width: `${Math.min(usageCount.messages / usageCount.maxFreeMessages * 100, 100)}%` }}
            ></div>
          </div>
          
          <div className="flex justify-between items-center mt-4">
            <span>Campanhas candidatadas:</span>
            <span className="font-medium">{usageCount.campaigns} de {usageCount.maxFreeCampaigns} permitidas</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className={`h-2.5 rounded-full ${usageCount.campaigns >= usageCount.maxFreeCampaigns ? 'bg-red-500' : 'bg-green-500'}`} 
              style={{ width: `${Math.min(usageCount.campaigns / usageCount.maxFreeCampaigns * 100, 100)}%` }}
            ></div>
          </div>
        </div>
        
        <p className="mt-4 text-sm text-amber-800">
          Para acesso ilimitado, assine um plano premium.
        </p>
        <Button 
          variant="brand"
          className="mt-4"
          onClick={() => navigate('/dashboard?tab=subscription')}
        >
          Ver planos de assinatura
        </Button>
      </CardContent>
    </Card>
  );
}
