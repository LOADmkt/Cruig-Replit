
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface ActivityMetrics {
  pendingCampaigns: number;
  activeCampaigns: number;
  unreadMessages: number;
  totalMessages: number;
  metrics: {
    followers: {
      instagram: string;
      youtube: string;
      tiktok: string;
    };
    engagement: {
      instagram: string;
      youtube: string;
      tiktok: string;
    };
    audience: {
      age: Record<string, string>;
      gender: Record<string, string>;
      topLocations: Array<{ location: string; percentage: string }>;
    };
  };
}

export function ActivitySummary({ data }: { data: ActivityMetrics }) {
  const [showMetrics, setShowMetrics] = useState(false);
  
  return (
    <Card className="lg:col-span-2">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-brand-dark">Resumo da Sua Atividade</CardTitle>
          <CardDescription>
            Visão geral do seu desempenho na plataforma
          </CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={() => setShowMetrics(!showMetrics)}>
          {showMetrics ? "Ocultar Métricas" : "Ver Mais Métricas"}
        </Button>
      </CardHeader>
      <CardContent>
        {!showMetrics ? (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-sm font-medium text-gray-500">Candidaturas Pendentes</div>
                <div className="mt-2 text-2xl font-bold">{data.pendingCampaigns}</div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-sm font-medium text-gray-500">Campanhas Ativas</div>
                <div className="mt-2 text-2xl font-bold">{data.activeCampaigns}</div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-sm font-medium text-gray-500">Mensagens</div>
                <div className="mt-2 text-2xl font-bold">{data.unreadMessages} <span className="text-sm font-normal text-gray-500">não lidas</span></div>
              </div>
            </div>
            
            <div className="space-y-2">
              <h3 className="font-medium">Resumo de Seguidores</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="p-3 bg-gray-50 rounded-lg text-center">
                  <div className="text-sm font-medium text-gray-500">Instagram</div>
                  <div className="font-bold">{data.metrics.followers.instagram}</div>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg text-center">
                  <div className="text-sm font-medium text-gray-500">YouTube</div>
                  <div className="font-bold">{data.metrics.followers.youtube}</div>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg text-center">
                  <div className="text-sm font-medium text-gray-500">TikTok</div>
                  <div className="font-bold">{data.metrics.followers.tiktok}</div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="space-y-2">
              <h3 className="font-medium">Estatísticas de Seguidores</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-sm font-medium text-gray-500">Instagram</div>
                  <div className="font-bold">{data.metrics.followers.instagram}</div>
                  <div className="text-xs text-gray-500">Engajamento: {data.metrics.engagement.instagram}</div>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-sm font-medium text-gray-500">YouTube</div>
                  <div className="font-bold">{data.metrics.followers.youtube}</div>
                  <div className="text-xs text-gray-500">Engajamento: {data.metrics.engagement.youtube}</div>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-sm font-medium text-gray-500">TikTok</div>
                  <div className="font-bold">{data.metrics.followers.tiktok}</div>
                  <div className="text-xs text-gray-500">Engajamento: {data.metrics.engagement.tiktok}</div>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium mb-2">Distribuição de Idade</h3>
                <div className="space-y-2">
                  {Object.entries(data.metrics.audience.age).map(([ageRange, percentage]) => (
                    <div key={ageRange} className="flex justify-between items-center">
                      <span>{ageRange}</span>
                      <div className="flex items-center">
                        <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                          <div 
                            className="bg-brand-primary h-2 rounded-full" 
                            style={{ width: percentage }}
                          ></div>
                        </div>
                        <span className="text-sm">{percentage}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Distribuição de Gênero</h3>
                <div className="space-y-2">
                  {Object.entries(data.metrics.audience.gender).map(([gender, percentage]) => (
                    <div key={gender} className="flex justify-between items-center">
                      <span>{gender}</span>
                      <div className="flex items-center">
                        <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                          <div 
                            className="bg-brand-primary h-2 rounded-full" 
                            style={{ width: percentage }}
                          ></div>
                        </div>
                        <span className="text-sm">{percentage}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-medium mb-2">Principais Localizações</h3>
              <div className="space-y-2">
                {data.metrics.audience.topLocations.map((loc, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span>{loc.location}</span>
                    <div className="flex items-center">
                      <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                        <div 
                          className="bg-brand-primary h-2 rounded-full" 
                          style={{ width: loc.percentage }}
                        ></div>
                      </div>
                      <span className="text-sm">{loc.percentage}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
