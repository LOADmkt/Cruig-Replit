
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, ThumbsUp, MessageCircle, AlertTriangle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

export function CreatorRatings() {
  // Mock de avaliações (em produção viria do backend)
  const [ratings, setRatings] = useState([
    {
      id: 1,
      empresa: {
        nome: "TechBrasil",
        logo: null,
      },
      nota: 5,
      comentario: "Excelente criador! Entregou o conteúdo dentro do prazo e com qualidade excepcional. A campanha teve resultados muito acima do esperado.",
      data: "2023-11-15T14:30:00",
      respondido: true,
      resposta: "Obrigado pela oportunidade! Foi um prazer trabalhar com a equipe da TechBrasil.",
      dataResposta: "2023-11-15T16:45:00"
    },
    {
      id: 2,
      empresa: {
        nome: "ModaStyle",
        logo: null,
      },
      nota: 4,
      comentario: "Ótimo trabalho! O conteúdo ficou muito bom e trouxe bons resultados para nossa marca. Apenas um pequeno atraso na entrega.",
      data: "2023-10-22T09:15:00",
      respondido: false,
      resposta: null,
      dataResposta: null
    },
    {
      id: 3,
      empresa: {
        nome: "EcoVida",
        logo: null,
      },
      nota: 5,
      comentario: "Adoramos a parceria! Criador muito profissional e alinhado com os valores da nossa marca. Já estamos planejando novas campanhas.",
      data: "2023-09-05T11:30:00",
      respondido: true,
      resposta: "Foi um prazer trabalhar com produtos tão alinhados com meus valores! Aguardo ansiosamente os próximos projetos.",
      dataResposta: "2023-09-05T14:20:00"
    }
  ]);

  // Cálculo da média das avaliações
  const averageRating = ratings.length > 0
    ? (ratings.reduce((acc, rating) => acc + rating.nota, 0) / ratings.length).toFixed(1)
    : "0.0";

  // Contagem de avaliações por nota
  const ratingCounts = {
    5: ratings.filter(r => r.nota === 5).length,
    4: ratings.filter(r => r.nota === 4).length,
    3: ratings.filter(r => r.nota === 3).length,
    2: ratings.filter(r => r.nota === 2).length,
    1: ratings.filter(r => r.nota === 1).length,
  };

  // Calcular percentuais para a barra de progresso
  const calculatePercentage = (count: number) => {
    return ratings.length > 0 ? (count / ratings.length) * 100 : 0;
  };

  // Estado para controlar a abertura/fechamento do formulário de resposta
  const [respondingTo, setRespondingTo] = useState<number | null>(null);
  const [responseText, setResponseText] = useState("");

  const handleRespond = (ratingId: number) => {
    setRespondingTo(ratingId);
    setResponseText("");
  };

  const handleCancelResponse = () => {
    setRespondingTo(null);
    setResponseText("");
  };

  const handleSubmitResponse = (ratingId: number) => {
    // Em produção, enviaria para o backend
    const updatedRatings = ratings.map(rating => {
      if (rating.id === ratingId) {
        return {
          ...rating,
          respondido: true,
          resposta: responseText,
          dataResposta: new Date().toISOString()
        };
      }
      return rating;
    });
    
    setRatings(updatedRatings);
    setRespondingTo(null);
    setResponseText("");
  };

  // Função para renderizar as estrelas
  const renderStars = (rating: number) => {
    return Array(5).fill(0).map((_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
      />
    ));
  };

  // Função para formatar a data
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const isSuperCreator = ratings.length >= 10;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Avaliações</h2>
        <p className="text-gray-600">Veja o que as empresas estão dizendo sobre seu trabalho</p>
      </div>

      {/* Resumo das avaliações */}
      <Card>
        <CardHeader>
          <CardTitle>Resumo das avaliações</CardTitle>
          <CardDescription>
            Baseado em {ratings.length} {ratings.length === 1 ? 'avaliação' : 'avaliações'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex flex-col items-center justify-center">
              <div className="text-5xl font-bold text-brand-primary">{averageRating}</div>
              <div className="flex mt-2">
                {renderStars(parseFloat(averageRating))}
              </div>
              <div className="mt-2 text-sm text-gray-500">{ratings.length} {ratings.length === 1 ? 'avaliação' : 'avaliações'} no total</div>
              
              {isSuperCreator && (
                <Badge className="mt-4 bg-amber-100 text-amber-800 border border-amber-200 hover:bg-amber-200">
                  Super Criador
                </Badge>
              )}
              
              {!isSuperCreator && ratings.length > 0 && (
                <div className="mt-4 text-sm text-gray-500">
                  Faltam {10 - ratings.length} avaliações para se tornar um Super Criador
                </div>
              )}
            </div>
            
            <div className="space-y-2">
              {[5, 4, 3, 2, 1].map((star) => (
                <div key={star} className="flex items-center">
                  <div className="flex items-center w-12">
                    {star} <Star className="h-3 w-3 text-yellow-500 fill-yellow-500 ml-1" />
                  </div>
                  <div className="w-full ml-2">
                    <Progress value={calculatePercentage(ratingCounts[star as keyof typeof ratingCounts])} className="h-2" />
                  </div>
                  <div className="w-12 text-right text-sm text-gray-500">
                    {ratingCounts[star as keyof typeof ratingCounts]}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de avaliações */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Todas as avaliações</h3>
        
        {ratings.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <AlertTriangle className="h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-gray-700">Nenhuma avaliação ainda</h3>
              <p className="text-gray-500 text-center mt-2">
                Quando empresas avaliarem seu trabalho, as avaliações aparecerão aqui.
              </p>
            </CardContent>
          </Card>
        ) : (
          ratings.map((rating) => (
            <Card key={rating.id} className="overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-start">
                  <Avatar className="h-10 w-10">
                    {rating.empresa.logo ? (
                      <AvatarImage src={rating.empresa.logo} alt={rating.empresa.nome} />
                    ) : null}
                    <AvatarFallback className="bg-brand-primary/10 text-brand-primary">
                      {rating.empresa.nome.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="ml-4 flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold">{rating.empresa.nome}</h4>
                      <div className="flex items-center">
                        {renderStars(rating.nota)}
                      </div>
                    </div>
                    <div className="text-sm text-gray-500 mb-2">
                      {formatDate(rating.data)}
                    </div>
                    <p className="text-gray-700 mb-4">{rating.comentario}</p>
                    
                    {!rating.respondido && (
                      <div className="flex justify-end">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="flex items-center"
                          onClick={() => handleRespond(rating.id)}
                        >
                          <MessageCircle className="h-4 w-4 mr-2" />
                          Responder
                        </Button>
                      </div>
                    )}
                    
                    {respondingTo === rating.id && (
                      <div className="mt-4">
                        <textarea
                          className="w-full p-3 border rounded-md min-h-[100px]"
                          placeholder="Escreva sua resposta..."
                          value={responseText}
                          onChange={(e) => setResponseText(e.target.value)}
                        ></textarea>
                        <div className="flex justify-end space-x-2 mt-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={handleCancelResponse}
                          >
                            Cancelar
                          </Button>
                          <Button 
                            size="sm"
                            onClick={() => handleSubmitResponse(rating.id)}
                            disabled={!responseText.trim()}
                          >
                            Enviar resposta
                          </Button>
                        </div>
                      </div>
                    )}
                    
                    {rating.respondido && rating.resposta && (
                      <div className="mt-4 bg-gray-50 rounded-lg p-4 border border-gray-200">
                        <div className="flex items-start">
                          <ThumbsUp className="h-4 w-4 text-brand-primary mt-1 mr-2" />
                          <div>
                            <div className="flex items-center">
                              <h5 className="text-sm font-medium">Sua resposta</h5>
                              <span className="text-xs text-gray-500 ml-2">
                                {rating.dataResposta ? formatDate(rating.dataResposta) : ''}
                              </span>
                            </div>
                            <p className="text-gray-700 text-sm mt-1">{rating.resposta}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
