
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Send, Search, MessageCircle } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';

// Exemplo de tipo de mensagem
interface Message {
  id: string;
  senderId: string;
  recipientId: string;
  content: string;
  timestamp: Date;
  read: boolean;
  senderName: string;
  senderAvatar?: string;
}

interface Chat {
  id: string;
  participantId: string;
  participantName: string;
  participantAvatar?: string;
  lastMessage: string;
  lastMessageDate: Date;
  unreadCount: number;
}

export function CreatorMessages() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('inbox');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [messageText, setMessageText] = useState('');

  // Dados de exemplo para chats
  const mockChats: Chat[] = [
    {
      id: '1',
      participantId: '101',
      participantName: 'Beauty Brand',
      participantAvatar: 'https://source.unsplash.com/photo-1567477463859-26c3b1c16cf3',
      lastMessage: 'Gostaríamos de te convidar para uma campanha de produto capilar.',
      lastMessageDate: new Date('2025-04-28'),
      unreadCount: 2
    },
    {
      id: '2',
      participantId: '102',
      participantName: 'Fashion Style Co.',
      participantAvatar: 'https://source.unsplash.com/photo-1603400521630-9f2de124b33b',
      lastMessage: 'Confirmamos o pagamento da campanha #4523.',
      lastMessageDate: new Date('2025-04-25'),
      unreadCount: 0
    },
    {
      id: '3',
      participantId: '103',
      participantName: 'Travel Agency',
      participantAvatar: 'https://source.unsplash.com/photo-1563013544-824ae1b704d3',
      lastMessage: 'Adoramos o conteúdo que você criou para nossa campanha!',
      lastMessageDate: new Date('2025-04-20'),
      unreadCount: 0
    }
  ];

  // Dados de exemplo para mensagens
  const mockMessages: Record<string, Message[]> = {
    '1': [
      {
        id: 'm1',
        senderId: '101',
        recipientId: 'creator-1',
        content: 'Olá! Gostaríamos de te convidar para uma campanha de produto capilar. Temos interesse em trabalhar com criadores do seu nicho.',
        timestamp: new Date('2025-04-27T14:30:00'),
        read: true,
        senderName: 'Beauty Brand'
      },
      {
        id: 'm2',
        senderId: 'creator-1',
        recipientId: '101',
        content: 'Olá! Obrigada pelo convite. Tenho interesse sim, podem me contar mais sobre a campanha?',
        timestamp: new Date('2025-04-27T15:45:00'),
        read: true,
        senderName: 'Você'
      },
      {
        id: 'm3',
        senderId: '101',
        recipientId: 'creator-1',
        content: 'Claro! Estamos lançando uma nova linha de produtos para cabelos cacheados e crespos. Gostaríamos de um reels mostrando sua rotina de cuidados usando nossos produtos. O orçamento é de R$1.500,00 e enviaríamos os produtos para você testar.',
        timestamp: new Date('2025-04-28T09:15:00'),
        read: false,
        senderName: 'Beauty Brand'
      },
      {
        id: 'm4',
        senderId: '101',
        recipientId: 'creator-1',
        content: 'Seria para o final de maio. Você tem interesse?',
        timestamp: new Date('2025-04-28T09:16:00'),
        read: false,
        senderName: 'Beauty Brand'
      }
    ],
    '2': [
      {
        id: 'm5',
        senderId: '102',
        recipientId: 'creator-1',
        content: 'Olá! Confirmamos o recebimento do seu conteúdo para a campanha #4523.',
        timestamp: new Date('2025-04-24T10:00:00'),
        read: true,
        senderName: 'Fashion Style Co.'
      },
      {
        id: 'm6',
        senderId: '102',
        recipientId: 'creator-1',
        content: 'O pagamento já foi realizado e deve cair na sua conta em até 2 dias úteis.',
        timestamp: new Date('2025-04-25T11:30:00'),
        read: true,
        senderName: 'Fashion Style Co.'
      }
    ],
    '3': [
      {
        id: 'm7',
        senderId: '103',
        recipientId: 'creator-1',
        content: 'Olá! Adoramos o conteúdo que você criou para nossa campanha de destinos nacionais!',
        timestamp: new Date('2025-04-20T16:45:00'),
        read: true,
        senderName: 'Travel Agency'
      },
      {
        id: 'm8',
        senderId: 'creator-1',
        recipientId: '103',
        content: 'Que bom que gostaram! Foi um prazer trabalhar com vocês. Estou à disposição para futuros projetos.',
        timestamp: new Date('2025-04-20T17:30:00'),
        read: true,
        senderName: 'Você'
      }
    ]
  };

  const filteredChats = mockChats.filter(chat => 
    chat.participantName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (date: Date): string => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date.toDateString() === today.toDateString()) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Ontem';
    } else {
      return date.toLocaleDateString();
    }
  };

  const handleSendMessage = () => {
    if (!messageText.trim() || !selectedChat) return;
    
    // Em um app real, enviaríamos a mensagem para a API
    toast({
      title: 'Mensagem enviada',
      description: 'Sua mensagem foi enviada com sucesso.',
    });
    
    // Limpar o campo de mensagem
    setMessageText('');
  };

  const renderChatList = () => {
    if (filteredChats.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center h-64 text-center">
          <MessageCircle className="h-16 w-16 text-gray-300 mb-4" />
          <h3 className="font-medium text-gray-700">Nenhuma conversa encontrada</h3>
          <p className="text-gray-500 text-sm mt-1">
            {searchTerm ? 'Tente outro termo de busca' : 'Suas conversas aparecerão aqui'}
          </p>
        </div>
      );
    }
    
    return filteredChats.map(chat => (
      <div 
        key={chat.id}
        onClick={() => setSelectedChat(chat.id)}
        className={`
          flex items-start gap-3 p-3 rounded-lg cursor-pointer transition-colors
          ${selectedChat === chat.id ? 'bg-brand-accent' : 'hover:bg-gray-100'}
        `}
      >
        <Avatar className="h-12 w-12">
          <AvatarImage src={chat.participantAvatar} alt={chat.participantName} />
          <AvatarFallback>{chat.participantName.substring(0, 2)}</AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-center">
            <h4 className="font-medium text-gray-900 truncate">{chat.participantName}</h4>
            <span className="text-xs text-gray-500">{formatDate(chat.lastMessageDate)}</span>
          </div>
          <p className="text-sm text-gray-500 truncate">{chat.lastMessage}</p>
        </div>
        {chat.unreadCount > 0 && (
          <Badge variant="brand" className="rounded-full h-5 w-5 flex items-center justify-center p-0">
            {chat.unreadCount}
          </Badge>
        )}
      </div>
    ));
  };

  const renderMessages = () => {
    if (!selectedChat || !mockMessages[selectedChat]) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center">
          <MessageCircle className="h-16 w-16 text-gray-300 mb-4" />
          <h3 className="font-medium text-gray-700">Selecione uma conversa</h3>
          <p className="text-gray-500 text-sm mt-1">Escolha uma conversa para ver as mensagens</p>
        </div>
      );
    }
    
    const messages = mockMessages[selectedChat];
    const selectedChatDetails = mockChats.find(chat => chat.id === selectedChat);
    
    return (
      <>
        <div className="border-b p-3">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={selectedChatDetails?.participantAvatar} />
              <AvatarFallback>{selectedChatDetails?.participantName.substring(0, 2)}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-medium">{selectedChatDetails?.participantName}</h3>
            </div>
          </div>
        </div>
        
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map(message => (
              <div 
                key={message.id} 
                className={`flex ${message.senderId === 'creator-1' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`
                    max-w-[80%] rounded-lg p-3
                    ${message.senderId === 'creator-1' 
                      ? 'bg-brand-primary text-white rounded-tr-none' 
                      : 'bg-gray-100 text-gray-800 rounded-tl-none'}
                  `}
                >
                  <p>{message.content}</p>
                  <div 
                    className={`
                      text-xs mt-1 text-right
                      ${message.senderId === 'creator-1' ? 'text-white/80' : 'text-gray-500'}
                    `}
                  >
                    {formatDate(message.timestamp)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
        
        <div className="border-t p-3">
          <div className="flex gap-2">
            <Textarea 
              placeholder="Digite sua mensagem..." 
              value={messageText}
              onChange={e => setMessageText(e.target.value)}
              className="resize-none"
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
            />
            <Button 
              onClick={handleSendMessage} 
              className="bg-brand-primary hover:bg-brand-primary/90"
              disabled={!messageText.trim()}
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </>
    );
  };

  return (
    <div className="space-y-4">
      <Card className="border-gray-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-xl font-semibold text-gray-800">Mensagens</CardTitle>
          <CardDescription>
            Gerencie suas conversas com marcas e outros criadores.
          </CardDescription>
        </CardHeader>
        
        <CardContent className="p-0">
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="border-b px-6">
              <TabsList className="bg-transparent border-b-0">
                <TabsTrigger value="inbox" className="data-[state=active]:border-b-2 data-[state=active]:border-brand-primary data-[state=active]:shadow-none data-[state=active]:bg-transparent data-[state=active]:text-brand-primary rounded-none">
                  Caixa de Entrada
                </TabsTrigger>
                <TabsTrigger value="sent" className="data-[state=active]:border-b-2 data-[state=active]:border-brand-primary data-[state=active]:shadow-none data-[state=active]:bg-transparent data-[state=active]:text-brand-primary rounded-none">
                  Enviadas
                </TabsTrigger>
              </TabsList>
            </div>
            
            <div className="flex h-[600px]">
              <div className="w-1/3 border-r">
                <div className="p-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input 
                      placeholder="Buscar mensagens..." 
                      className="pl-10 bg-gray-50"
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                <ScrollArea className="h-[540px]">
                  <div className="space-y-1 p-2">
                    {renderChatList()}
                  </div>
                </ScrollArea>
              </div>
              
              <div className="flex-1 flex flex-col">
                {renderMessages()}
              </div>
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
