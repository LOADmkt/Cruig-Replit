
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useSubscription } from '@/hooks/useSubscription';
import { useSubscriptionStatus } from '@/hooks/useSubscriptionStatus';
import { CheckoutModal } from '@/components/subscription/CheckoutModal';
import { SubscriptionLimitAlert } from '@/components/subscription/SubscriptionLimitAlert';
import { SubscriptionHeader } from '@/components/subscription/SubscriptionHeader';
import { ActiveSubscriptionCard } from '@/components/subscription/ActiveSubscriptionCard';
import { SubscriptionPlans } from '@/components/subscription/SubscriptionPlans';
import { ImportantNote } from '@/components/subscription/ImportantNote';
import { getCreatorPlans, formatPrice } from '@/lib/subscriptionPlans';

export function CreatorSubscription() {
  const { toast } = useToast();
  const { subscription, usageCount } = useSubscription();
  const { refreshSubscriptionStatus, isLoadingStatus } = useSubscriptionStatus();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const plans = getCreatorPlans();
  const selectedPlanDetails = selectedPlan ? plans.find(p => p.id === selectedPlan) : null;

  const handleSelectPlan = (planId: string) => {
    setSelectedPlan(planId);
  };

  const handleSubscribe = async () => {
    if (!selectedPlan) {
      toast({
        title: "Selecione um plano",
        description: "Por favor, selecione um plano antes de continuar.",
        variant: "destructive",
      });
      return;
    }
    setIsCheckoutOpen(true);
  };

  const handleCancelSubscription = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      const userData = JSON.parse(localStorage.getItem('userData') || '{}');
      userData.subscription = {
        active: false,
        canceledAt: new Date().toISOString()
      };
      localStorage.setItem('userData', JSON.stringify(userData));
      toast({
        title: "Assinatura cancelada",
        description: "Sua assinatura foi cancelada com sucesso. Seus benefícios premium continuarão ativos até o final do período já pago.",
      });
      refreshSubscriptionStatus();
    } catch (error) {
      toast({
        title: "Erro ao cancelar",
        description: "Ocorreu um erro ao cancelar sua assinatura. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <SubscriptionHeader
        userType="creator"
        isLoadingStatus={isLoadingStatus}
        onRefresh={refreshSubscriptionStatus}
      />

      {!subscription.active ? (
        <SubscriptionLimitAlert userType="creator" showActions={false} />
      ) : (
        <ActiveSubscriptionCard
          subscription={{
            plan: subscription.plan,
            expiresAt: subscription.expiresAt || null
          }}
          loading={loading}
          onCancel={handleCancelSubscription}
        />
      )}

      <SubscriptionPlans
        plans={plans}
        selectedPlan={selectedPlan}
        subscription={{
          active: subscription.active,
          plan: subscription.plan
        }}
        onSelectPlan={handleSelectPlan}
      />

      {!subscription.active && (
        <div className="flex justify-center mt-8">
          <Button
            className="bg-brand-primary hover:bg-brand-primary/90 w-full max-w-md"
            size="lg"
            onClick={handleSubscribe}
            disabled={!selectedPlan || loading}
          >
            {loading ? "Processando..." : "Assinar agora"}
          </Button>
        </div>
      )}

      {selectedPlanDetails && (
        <CheckoutModal
          open={isCheckoutOpen}
          onOpenChange={setIsCheckoutOpen}
          planId={selectedPlanDetails.id}
          planName={selectedPlanDetails.name}
          planPrice={formatPrice(selectedPlanDetails.price)}
          userType="creator"
        />
      )}

      <ImportantNote userType="creator" />
    </div>
  );
}
