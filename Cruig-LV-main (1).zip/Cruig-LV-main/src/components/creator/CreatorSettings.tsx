import React, { useState } from 'react';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Upload, X, User, Save, Instagram, Youtube } from "lucide-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { MultiSelect } from "@/components/MultiSelect";
import { BrandTiktok } from "@/components/icons/BrandTiktok";

// Esquema de validação para o perfil
const profileSchema = z.object({
  nome: z.string().min(2, { message: "Nome deve ter pelo menos 2 caracteres" }),
  nomeArtistico: z.string().min(2, { message: "Nome artístico deve ter pelo menos 2 caracteres" }),
  bio: z.string().min(10, { message: "Bio deve ter pelo menos 10 caracteres" }),
  website: z.string().url({ message: "URL inválida" }).optional().or(z.literal("")),
  nicho: z.string().min(1, { message: "Nicho é obrigatório" }),
});

// Esquema de validação para a conta
const accountSchema = z.object({
  nome: z.string().min(3, { message: "Nome deve ter pelo menos 3 caracteres" }),
  email: z.string().email({ message: "Email inválido" }),
  telefone: z.string().optional(),
  cpf: z.string().optional(),
});

// Esquema de validação para a senha
const passwordSchema = z.object({
  senhaAtual: z.string().min(6, { message: "Senha atual é obrigatória" }),
  novaSenha: z.string().min(6, { message: "Nova senha deve ter pelo menos 6 caracteres" }),
  confirmarSenha: z.string(),
}).refine(data => data.novaSenha === data.confirmarSenha, {
  message: "As senhas não coincidem",
  path: ["confirmarSenha"],
});

type ProfileFormValues = z.infer<typeof profileSchema>;
type AccountFormValues = z.infer<typeof accountSchema>;
type PasswordFormValues = z.infer<typeof passwordSchema>;

interface CreatorSettingsProps {
  userData?: any;
}

export function CreatorSettings({ userData }: CreatorSettingsProps) {
  const { toast } = useToast();
  const [avatarPreview, setAvatarPreview] = useState<string | null>(userData?.perfil?.avatar || null);
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
  const [isUpdatingAccount, setIsUpdatingAccount] = useState(false);
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);
  
  // Social media connected states
  const [instagramConnected, setInstagramConnected] = useState(false);
  const [youtubeConnected, setYoutubeConnected] = useState(false);
  const [tiktokConnected, setTiktokConnected] = useState(false);
  
  // Notificações
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [whatsappNotifications, setWhatsappNotifications] = useState(true);
  const [newCampaignNotif, setNewCampaignNotif] = useState(true);
  const [messageNotif, setMessageNotif] = useState(true);
  const [ratingNotif, setRatingNotif] = useState(true);

  // Preparar as cidades para o multiselect
  const cidadesOptions = [
    { value: "São Paulo", label: "São Paulo" }, 
    { value: "Rio de Janeiro", label: "Rio de Janeiro" }, 
    { value: "Belo Horizonte", label: "Belo Horizonte" }, 
    { value: "Brasília", label: "Brasília" }, 
    { value: "Salvador", label: "Salvador" }, 
    { value: "Fortaleza", label: "Fortaleza" }, 
    { value: "Recife", label: "Recife" }, 
    { value: "Porto Alegre", label: "Porto Alegre" }, 
    { value: "Curitiba", label: "Curitiba" }, 
    { value: "Manaus", label: "Manaus" }, 
    { value: "Belém", label: "Belém" },
    { value: "Goiânia", label: "Goiânia" },
    { value: "Campinas", label: "Campinas" },
    { value: "Florianópolis", label: "Florianópolis" },
    { value: "Vitória", label: "Vitória" }
  ];
  
  const [selectedCidades, setSelectedCidades] = useState<string[]>(["São Paulo"]);

  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      nome: userData?.perfil?.nome || "",
      nomeArtistico: userData?.perfil?.nomeArtistico || "",
      bio: userData?.perfil?.bio || "",
      website: userData?.perfil?.website || "",
      nicho: userData?.perfil?.nicho || "",
    }
  });

  const accountForm = useForm<AccountFormValues>({
    resolver: zodResolver(accountSchema),
    defaultValues: {
      nome: userData?.nome || "",
      email: userData?.email || "",
      telefone: userData?.telefone || "",
      cpf: userData?.cpf || "",
    }
  });

  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      senhaAtual: "",
      novaSenha: "",
      confirmarSenha: "",
    }
  });

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeAvatar = () => {
    setAvatarPreview(null);
  };

  const onProfileSubmit = async (data: ProfileFormValues) => {
    setIsUpdatingProfile(true);
    try {
      // Simulando um atraso na requisição
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Atualizar os dados do usuário no localStorage
      const updatedUserData = {
        ...userData,
        perfil: {
          ...userData?.perfil,
          nome: data.nome,
          nomeArtistico: data.nomeArtistico,
          bio: data.bio,
          website: data.website,
          nicho: data.nicho,
          avatar: avatarPreview,
        }
      };
      
      localStorage.setItem('userData', JSON.stringify(updatedUserData));
      
      toast({
        title: "Perfil atualizado",
        description: "Suas informações de perfil foram atualizadas com sucesso.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar perfil",
        description: "Ocorreu um erro ao atualizar seu perfil. Tente novamente.",
      });
    } finally {
      setIsUpdatingProfile(false);
    }
  };

  const onAccountSubmit = async (data: AccountFormValues) => {
    setIsUpdatingAccount(true);
    try {
      // Simulando um atraso na requisição
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Atualizar os dados do usuário no localStorage
      const updatedUserData = {
        ...userData,
        nome: data.nome,
        email: data.email,
        telefone: data.telefone,
        cpf: data.cpf,
      };
      
      localStorage.setItem('userData', JSON.stringify(updatedUserData));
      
      toast({
        title: "Conta atualizada",
        description: "Suas informações de conta foram atualizadas com sucesso.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar conta",
        description: "Ocorreu um erro ao atualizar sua conta. Tente novamente.",
      });
    } finally {
      setIsUpdatingAccount(false);
    }
  };

  const onPasswordSubmit = async (data: PasswordFormValues) => {
    setIsUpdatingPassword(true);
    try {
      // Simulando um atraso na requisição
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast({
        title: "Senha atualizada",
        description: "Sua senha foi atualizada com sucesso.",
      });
      
      // Resetar o formulário de senha
      passwordForm.reset({
        senhaAtual: "",
        novaSenha: "",
        confirmarSenha: "",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar senha",
        description: "Ocorreu um erro ao atualizar sua senha. Tente novamente.",
      });
    } finally {
      setIsUpdatingPassword(false);
    }
  };

  const handleConnectInstagram = () => {
    toast({
      title: "Conectando Instagram",
      description: "Redirecionando para autenticação...",
    });
    
    // Em produção, redirecionaria para OAuth
    setTimeout(() => {
      setInstagramConnected(true);
      toast({
        title: "Instagram conectado",
        description: "Sua conta do Instagram foi conectada com sucesso.",
      });
    }, 2000);
  };

  const handleConnectYoutube = () => {
    toast({
      title: "Conectando YouTube",
      description: "Redirecionando para autenticação...",
    });
    
    // Em produção, redirecionaria para OAuth do Google
    setTimeout(() => {
      setYoutubeConnected(true);
      toast({
        title: "YouTube conectado",
        description: "Sua conta do YouTube foi conectada com sucesso.",
      });
    }, 2000);
  };

  const handleConnectTiktok = () => {
    toast({
      title: "Conectando TikTok",
      description: "Redirecionando para autenticação...",
    });
    
    // Em produção, redirecionaria para OAuth
    setTimeout(() => {
      setTiktokConnected(true);
      toast({
        title: "TikTok conectado",
        description: "Sua conta do TikTok foi conectada com sucesso.",
      });
    }, 2000);
  };

  const handleDisconnectSocial = (platform: string) => {
    switch (platform) {
      case 'instagram':
        setInstagramConnected(false);
        break;
      case 'youtube':
        setYoutubeConnected(false);
        break;
      case 'tiktok':
        setTiktokConnected(false);
        break;
    }
    
    toast({
      title: `${platform} desconectado`,
      description: `Sua conta do ${platform} foi desconectada com sucesso.`,
    });
  };

  // Lista de nichos para o dropdown
  const nichos = [
    "Moda e Beleza", 
    "Tecnologia", 
    "Lifestyle", 
    "Fitness e Saúde", 
    "Culinária", 
    "Viagem", 
    "Games", 
    "Educação", 
    "Finanças", 
    "Entretenimento", 
    "Sustentabilidade",
    "Parentalidade",
    "Pets",
    "Arte e Cultura",
    "Outros"
  ];

  const saveNotificationSettings = () => {
    toast({
      title: "Preferências atualizadas",
      description: "Suas preferências de notificação foram salvas com sucesso.",
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Configurações</h1>
        <p className="text-gray-600 mt-1">Gerencie suas informações e preferências</p>
      </div>

      <Tabs defaultValue="perfil">
        <TabsList className="w-full md:w-auto grid grid-cols-2 md:flex">
          <TabsTrigger value="perfil">Perfil</TabsTrigger>
          <TabsTrigger value="conta">Conta</TabsTrigger>
          <TabsTrigger value="senha">Senha</TabsTrigger>
          <TabsTrigger value="redes">Redes Sociais</TabsTrigger>
          <TabsTrigger value="notificacoes">Notificações</TabsTrigger>
        </TabsList>
        
        {/* Aba de Perfil */}
        <TabsContent value="perfil" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Informações de Perfil</CardTitle>
              <CardDescription>
                Atualize as informações que serão exibidas para as empresas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Foto de perfil</label>
                  <div className="flex justify-start">
                    {avatarPreview ? (
                      <div className="relative">
                        <img 
                          src={avatarPreview} 
                          alt="Avatar preview" 
                          className="w-32 h-32 object-cover rounded-full border border-gray-200"
                        />
                        <button 
                          type="button"
                          onClick={removeAvatar}
                          className="absolute -top-2 -right-2 bg-white rounded-full p-1 shadow-md"
                        >
                          <X size={16} className="text-gray-700" />
                        </button>
                      </div>
                    ) : (
                      <label className="flex flex-col items-center justify-center w-32 h-32 bg-gray-100 rounded-full border-2 border-dashed border-gray-300 cursor-pointer hover:bg-gray-50">
                        <div className="flex flex-col items-center justify-center">
                          <User className="h-8 w-8 text-gray-400" />
                          <span className="mt-2 text-sm text-gray-500">Alterar foto</span>
                        </div>
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={handleAvatarUpload}
                        />
                      </label>
                    )}
                  </div>
                </div>
                
                <Form {...profileForm}>
                  <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                    <FormField
                      control={profileForm.control}
                      name="nome"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome completo</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="nomeArtistico"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome artístico/Nickname</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bio</FormLabel>
                          <FormControl>
                            <Textarea 
                              className="min-h-[120px]"
                              placeholder="Uma breve descrição sobre você, seu trabalho e seus valores..."
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="website"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Site ou blog pessoal (opcional)</FormLabel>
                          <FormControl>
                            <Input placeholder="https://www.seusite.com.br" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="nicho"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nicho principal</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione seu nicho principal" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {nichos.map((nicho) => (
                                <SelectItem key={nicho} value={nicho}>
                                  {nicho}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="space-y-2">
                      <FormLabel>Onde você atua? (opcional)</FormLabel>
                      <MultiSelect
                        options={cidadesOptions}
                        selected={selectedCidades}
                        onChange={setSelectedCidades}
                        placeholder="Selecione as cidades onde você atua"
                      />
                    </div>
                    
                    <div className="pt-4">
                      <Button 
                        type="submit" 
                        className="bg-brand-primary hover:bg-brand-primary/90"
                        disabled={isUpdatingProfile}
                      >
                        <Save className="mr-2 h-4 w-4" />
                        {isUpdatingProfile ? "Salvando..." : "Salvar alterações"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Aba de Conta */}
        <TabsContent value="conta" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Informações da Conta</CardTitle>
              <CardDescription>
                Atualize suas informações pessoais e de contato
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...accountForm}>
                <form onSubmit={accountForm.handleSubmit(onAccountSubmit)} className="space-y-4">
                  <FormField
                    control={accountForm.control}
                    name="nome"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nome completo</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={accountForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={accountForm.control}
                    name="telefone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Telefone (opcional)</FormLabel>
                        <FormControl>
                          <Input placeholder="(00) 00000-0000" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={accountForm.control}
                    name="cpf"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>CPF (opcional)</FormLabel>
                        <FormControl>
                          <Input placeholder="000.000.000-00" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="pt-4">
                    <Button 
                      type="submit" 
                      className="bg-brand-primary hover:bg-brand-primary/90"
                      disabled={isUpdatingAccount}
                    >
                      <Save className="mr-2 h-4 w-4" />
                      {isUpdatingAccount ? "Salvando..." : "Salvar alterações"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Aba de Senha */}
        <TabsContent value="senha" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Alterar Senha</CardTitle>
              <CardDescription>
                Atualize sua senha para manter sua conta segura
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...passwordForm}>
                <form onSubmit={passwordForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
                  <FormField
                    control={passwordForm.control}
                    name="senhaAtual"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Senha atual</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={passwordForm.control}
                    name="novaSenha"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nova senha</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={passwordForm.control}
                    name="confirmarSenha"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Confirmar nova senha</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="pt-4">
                    <Button 
                      type="submit" 
                      className="bg-brand-primary hover:bg-brand-primary/90"
                      disabled={isUpdatingPassword}
                    >
                      <Save className="mr-2 h-4 w-4" />
                      {isUpdatingPassword ? "Atualizando..." : "Atualizar senha"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Aba de Redes Sociais */}
        <TabsContent value="redes" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Conectar Redes Sociais</CardTitle>
              <CardDescription>
                Conecte suas redes sociais para verificação e métricas de desempenho
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                  <h3 className="font-medium mb-2">Por que conectar suas redes sociais?</h3>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start">
                      <span className="text-green-500 mr-2">✓</span>
                      <span>Verificação automática do seu número de seguidores</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-500 mr-2">✓</span>
                      <span>Métricas de engajamento exibidas para as marcas</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-500 mr-2">✓</span>
                      <span>Destaque nos resultados de busca das marcas</span>
                    </li>
                  </ul>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center">
                      <Instagram className="h-6 w-6 text-pink-600 mr-3" />
                      <div>
                        <h4 className="font-medium">Instagram</h4>
                        <p className="text-sm text-gray-500">
                          {instagramConnected 
                            ? "Conectado - @usuarioexemplo" 
                            : "Não conectado"}
                        </p>
                      </div>
                    </div>
                    {instagramConnected ? (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleDisconnectSocial('instagram')}
                      >
                        Desconectar
                      </Button>
                    ) : (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={handleConnectInstagram}
                        className="text-pink-600 border-pink-200 hover:bg-pink-50"
                      >
                        Conectar
                      </Button>
                    )}
                  </div>

                  <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center">
                      <Youtube className="h-6 w-6 text-red-600 mr-3" />
                      <div>
                        <h4 className="font-medium">YouTube</h4>
                        <p className="text-sm text-gray-500">
                          {youtubeConnected 
                            ? "Conectado - Canal Exemplo" 
                            : "Não conectado"}
                        </p>
                      </div>
                    </div>
                    {youtubeConnected ? (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleDisconnectSocial('youtube')}
                      >
                        Desconectar
                      </Button>
                    ) : (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={handleConnectYoutube}
                        className="text-red-600 border-red-200 hover:bg-red-50"
                      >
                        Conectar
                      </Button>
                    )}
                  </div>

                  <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center">
                      <BrandTiktok className="h-6 w-6 text-black mr-3" />
                      <div>
                        <h4 className="font-medium">TikTok</h4>
                        <p className="text-sm text-gray-500">
                          {tiktokConnected 
                            ? "Conectado - @usuariotiktok" 
                            : "Não conectado"}
                        </p>
                      </div>
                    </div>
                    {tiktokConnected ? (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleDisconnectSocial('tiktok')}
                      >
                        Desconectar
                      </Button>
                    ) : (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={handleConnectTiktok}
                      >
                        Conectar
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Aba de Notificações */}
        <TabsContent value="notificacoes" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Preferências de Notificação</CardTitle>
              <CardDescription>
                Escolha como e quando deseja receber notificações
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-3">
                  <h3 className="font-medium">Canais de notificação</h3>
                  <div className="flex items-center justify-between py-2">
                    <div className="space-y-0.5">
                      <div className="font-medium">Email</div>
                      <div className="text-sm text-gray-500">Receba atualizações por email</div>
                    </div>
                    <Switch 
                      checked={emailNotifications}
                      onCheckedChange={setEmailNotifications}
                    />
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <div className="space-y-0.5">
                      <div className="font-medium">WhatsApp</div>
                      <div className="text-sm text-gray-500">Receba atualizações por WhatsApp</div>
                    </div>
                    <Switch 
                      checked={whatsappNotifications}
                      onCheckedChange={setWhatsappNotifications}
                    />
                  </div>
                </div>
                
                <div className="space-y-3 pt-4 border-t">
                  <h3 className="font-medium">Tipos de notificação</h3>
                  <div className="flex items-center justify-between py-2">
                    <div className="space-y-0.5">
                      <div className="font-medium">Novas campanhas</div>
                      <div className="text-sm text-gray-500">Quando surgirem novas campanhas de seu interesse</div>
                    </div>
                    <Switch 
                      checked={newCampaignNotif}
                      onCheckedChange={setNewCampaignNotif}
                    />
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <div className="space-y-0.5">
                      <div className="font-medium">Mensagens</div>
                      <div className="text-sm text-gray-500">Quando receber mensagens de marcas</div>
                    </div>
                    <Switch 
                      checked={messageNotif}
                      onCheckedChange={setMessageNotif}
                    />
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <div className="space-y-0.5">
                      <div className="font-medium">Novas avaliações</div>
                      <div className="text-sm text-gray-500">Quando receber uma nova avaliação</div>
                    </div>
                    <Switch 
                      checked={ratingNotif}
                      onCheckedChange={setRatingNotif}
                    />
                  </div>
                </div>
                
                <div className="pt-4">
                  <Button 
                    className="bg-brand-primary hover:bg-brand-primary/90"
                    onClick={saveNotificationSettings}
                  >
                    <Save className="mr-2 h-4 w-4" />
                    Salvar preferências
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
