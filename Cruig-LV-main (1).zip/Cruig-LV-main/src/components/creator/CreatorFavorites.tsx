
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, Star, MessageSquare, Building, MapPin, AlertTriangle } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from '@/hooks/use-toast';

export function CreatorFavorites() {
  const { toast } = useToast();
  
  // Mock de empresas favoritas (em produção viria do backend)
  const [favorites, setFavorites] = useState([
    {
      id: 1,
      nomeMarca: 'TechGadget Brasil',
      logo: null,
      segmento: 'Tecnologia',
      cidade: 'São Paulo',
      estado: 'SP',
      descricao: 'Empresa líder em produtos tecnológicos com foco em inovação e sustentabilidade.',
      avaliacao: 4.8,
      totalAvaliacoes: 24,
      campanhasAtivas: 3
    },
    {
      id: 2,
      nomeMarca: 'ModaStyle',
      logo: null,
      segmento: 'Moda e Vestuário',
      cidade: 'Rio de Janeiro',
      estado: 'RJ',
      descricao: 'Marca de moda sustentável com peças exclusivas e materiais eco-friendly.',
      avaliacao: 4.5,
      totalAvaliacoes: 18,
      campanhasAtivas: 2
    },
    {
      id: 3,
      nomeMarca: 'EcoVida Produtos Naturais',
      logo: null,
      segmento: 'Saúde e Bem-estar',
      cidade: 'Curitiba',
      estado: 'PR',
      descricao: 'Produtos orgânicos e naturais para um estilo de vida saudável e sustentável.',
      avaliacao: 4.9,
      totalAvaliacoes: 31,
      campanhasAtivas: 1
    }
  ]);

  const handleRemoveFavorite = (id: number) => {
    setFavorites(favorites.filter(fav => fav.id !== id));
    
    toast({
      title: "Removido dos favoritos",
      description: "Empresa removida da sua lista de favoritos com sucesso.",
    });
  };

  const handleSendMessage = (companyName: string) => {
    toast({
      title: "Mensagem iniciada",
      description: `Iniciando conversa com ${companyName}.`,
    });
    // Em produção, redirecionaria para a página de mensagens ou abriria um modal
  };

  const handleViewCampaigns = (companyName: string) => {
    toast({
      title: "Campanhas da empresa",
      description: `Visualizando campanhas de ${companyName}.`,
    });
    // Em produção, redirecionaria para a página de campanhas filtrada por empresa
  };

  // Função para renderizar as estrelas
  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center">
        <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
        <span className="ml-1 text-sm font-medium">{rating.toFixed(1)}</span>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Favoritos</h2>
        <p className="text-gray-600">Empresas que você marcou como favoritas</p>
      </div>

      {favorites.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Heart className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold text-gray-700">Nenhuma empresa favorita</h3>
            <p className="text-gray-500 text-center mt-2">
              Quando você adicionar empresas aos favoritos, elas aparecerão aqui para fácil acesso.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {favorites.map((company) => (
            <Card key={company.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <Avatar className="h-12 w-12">
                    {company.logo ? (
                      <AvatarImage src={company.logo} alt={company.nomeMarca} />
                    ) : null}
                    <AvatarFallback className="bg-brand-primary/10 text-brand-primary">
                      {company.nomeMarca.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-red-500 hover:text-red-600 hover:bg-red-50"
                          onClick={() => handleRemoveFavorite(company.id)}
                        >
                          <Heart className="h-5 w-5 fill-red-500" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Remover dos favoritos</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <CardTitle className="mt-2">{company.nomeMarca}</CardTitle>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge variant="outline" className="bg-gray-50">
                    {company.segmento}
                  </Badge>
                  <div className="flex items-center text-gray-500 text-sm">
                    <MapPin className="h-3 w-3 mr-1" />
                    {company.cidade}, {company.estado}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 text-sm line-clamp-2">{company.descricao}</p>
                
                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center">
                    {renderStars(company.avaliacao)}
                    <span className="text-xs text-gray-500 ml-1">
                      ({company.totalAvaliacoes})
                    </span>
                  </div>
                  
                  <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                    {company.campanhasAtivas} {company.campanhasAtivas === 1 ? 'campanha ativa' : 'campanhas ativas'}
                  </Badge>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between pt-0">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleSendMessage(company.nomeMarca)}
                  className="flex items-center"
                >
                  <MessageSquare className="h-4 w-4 mr-1" />
                  Mensagem
                </Button>
                <Button 
                  size="sm"
                  onClick={() => handleViewCampaigns(company.nomeMarca)}
                  className="flex items-center"
                >
                  <Building className="h-4 w-4 mr-1" />
                  Ver campanhas
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
