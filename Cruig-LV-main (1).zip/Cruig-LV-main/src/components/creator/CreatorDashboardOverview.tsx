
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDashboardData } from '@/hooks/useDashboardData';
import { useSubscription } from '@/hooks/useSubscription';
import { DashboardHeader } from './dashboard/DashboardHeader';
import { AccountLimitsCard } from './dashboard/AccountLimitsCard';
import { PremiumAccountCard } from './dashboard/PremiumAccountCard';
import { MetricsGrid } from './dashboard/MetricsGrid';
import { CampaignCards } from './dashboard/CampaignCards';
import { QuickActions } from './dashboard/QuickActions';
import { Loader2 } from 'lucide-react';
import { ProfileSummary } from './dashboard/ProfileSummary';

interface CreatorDashboardOverviewProps {
  userData: any;
}

export function CreatorDashboardOverview({ userData }: CreatorDashboardOverviewProps) {
  const navigate = useNavigate();
  const { subscription, usageCount, hasReachedCampaignLimit } = useSubscription();
  const { isLoading, error, data } = useDashboardData('creator/dashboard');
  const [showSocialConnect, setShowSocialConnect] = useState(false);
  
  const handleCampaignSearch = () => {
    navigate('/campanhas');
  };
  
  const handleViewMessages = () => {
    navigate('/dashboard?tab=messages');
  };
  
  const handleViewProfile = () => {
    navigate('/dashboard?tab=settings');
  };
  
  const handleViewCampaigns = () => {
    navigate('/dashboard?tab=campaigns');
  };
  
  const handleConnectSocial = () => {
    navigate('/dashboard?tab=social');
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <Loader2 className="h-12 w-12 animate-spin text-brand-primary mb-4" />
        <p className="text-lg text-gray-600">Carregando seu dashboard...</p>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center">
        <h3 className="text-lg font-medium text-red-800">Erro ao carregar dados</h3>
        <p className="mt-2 text-red-600">{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="mt-4 px-4 py-2 bg-brand-tertiary text-white rounded-lg hover:bg-brand-tertiary/80"
        >
          Tentar Novamente
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <DashboardHeader 
        userName={userData?.user_metadata?.name || userData?.nome || 'Criador'}
        onCampaignSearch={handleCampaignSearch}
      />

      <ProfileSummary 
        userData={userData}
        onConnectSocial={handleConnectSocial}
      />

      {!subscription.active && (
        <AccountLimitsCard usageCount={usageCount} />
      )}

      {subscription.active && (
        <PremiumAccountCard subscription={subscription} />
      )}

      <MetricsGrid data={data} />

      <CampaignCards 
        campaigns={data?.campaigns || []} 
        openCampaigns={data?.openCampaigns || []}
      />

      <QuickActions
        pendingCampaigns={data?.invites || 0}
        unreadMessages={3} // Mock value, would come from notifications API
        hasReachedCampaignLimit={hasReachedCampaignLimit}
        isSubscriptionActive={subscription.active}
        onViewProfile={handleViewProfile}
        onCampaignSearch={handleCampaignSearch}
        onViewCampaigns={handleViewCampaigns}
        onViewMessages={handleViewMessages}
      />
    </div>
  );
}
