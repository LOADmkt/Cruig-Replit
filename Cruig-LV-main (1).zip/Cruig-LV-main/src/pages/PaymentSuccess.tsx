
import React, { useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { CheckCircle, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useSubscription } from '@/hooks/useSubscription';

export default function PaymentSuccess() {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const referralCode = searchParams.get('ref');
  
  const { refreshSubscription } = useSubscription();
  
  useEffect(() => {
    // In a real application, verify the session with the Stripe API
    // and update the user's subscription status in the database
    refreshSubscription();
  }, [refreshSubscription]);
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-lg bg-white rounded-lg shadow-lg p-8 text-center">
        <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="h-12 w-12 text-green-500" />
        </div>
        
        <h1 className="text-2xl font-bold text-green-600 mb-2">
          Pagamento realizado com sucesso!
        </h1>
        
        <p className="text-gray-600 mb-6">
          Sua assinatura foi ativada e você já tem acesso a todos os recursos premium.
          {sessionId && (
            <span className="block text-sm mt-1 text-gray-400">
              ID da transação: {sessionId.substring(0, 16)}...
            </span>
          )}
        </p>
        
        <div className="space-y-3">
          <Button asChild className="w-full">
            <Link to="/dashboard">
              Ir para o Dashboard
              <ChevronRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          
          {referralCode && (
            <div className="text-sm text-gray-500 mt-4">
              Código de referência: {referralCode}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
