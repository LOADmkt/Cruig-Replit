
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Camera, CheckCircle2, Instagram, Upload, Youtube } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";

// Lista de nichos disponíveis
const NICHOS = [
  "Beleza",
  "Moda",
  "Lifestyle",
  "Games",
  "Tecnologia",
  "Culinária",
  "Fitness",
  "Viagem",
  "Finanças",
  "Humor",
  "Educação",
  "Saúde"
];

// Lista de estados brasileiros
const ESTADOS = [
  "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", 
  "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"
];

// Esquema para o passo 1 - Informações básicas
const basicInfoSchema = z.object({
  nomeArtistico: z.string().min(3, "Nome artístico deve ter pelo menos 3 caracteres"),
  bio: z.string().min(20, "Descrição deve ter pelo menos 20 caracteres").max(500, "Descrição muito longa (máximo 500 caracteres)"),
  cidade: z.string().min(2, "Informe sua cidade"),
  estado: z.string().min(2, "Selecione seu estado"),
  nichoPrincipal: z.string().min(1, "Selecione seu nicho principal"),
  nichosSecundarios: z.array(z.string()).optional(),
});

// Esquema para o passo 2 - Redes sociais
const socialMediaSchema = z.object({
  instagram: z.string().min(1, "Informe seu usuário do Instagram"),
  youtube: z.string().optional(),
  tiktok: z.string().optional(),
});

// Esquema para o passo 3 - Fotos
const photosSchema = z.object({
  fotoPerfil: z.any().optional(),
  fotoCapa: z.any().optional(),
});

// Esquema para o passo 4 - Verificação
const verificationSchema = z.object({
  documento: z.any().optional(),
  termoVerificacao: z.boolean().refine(val => val === true, {
    message: "Você precisa concordar com os termos de verificação",
  }),
});

// Tipos baseados nos esquemas
type BasicInfoFormValues = z.infer<typeof basicInfoSchema>;
type SocialMediaFormValues = z.infer<typeof socialMediaSchema>;
type PhotosFormValues = z.infer<typeof photosSchema>;
type VerificationFormValues = z.infer<typeof verificationSchema>;

export default function ProfileSetup() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 4;
  const progress = (currentStep / totalSteps) * 100;
  
  // Recuperar dados do localStorage (simulando autenticação)
  const userName = localStorage.getItem('userName') || 'Usuário';
  
  // Form para passo 1 - Informações básicas
  const basicInfoForm = useForm<BasicInfoFormValues>({
    resolver: zodResolver(basicInfoSchema),
    defaultValues: {
      nomeArtistico: userName,
      bio: "",
      cidade: "",
      estado: "",
      nichoPrincipal: "",
      nichosSecundarios: [],
    },
  });

  // Form para passo 2 - Redes sociais
  const socialMediaForm = useForm<SocialMediaFormValues>({
    resolver: zodResolver(socialMediaSchema),
    defaultValues: {
      instagram: "",
      youtube: "",
      tiktok: "",
    },
  });

  // Form para passo 3 - Fotos
  const photosForm = useForm<PhotosFormValues>({
    resolver: zodResolver(photosSchema),
    defaultValues: {
      fotoPerfil: null,
      fotoCapa: null,
    },
  });

  // Form para passo 4 - Verificação
  const verificationForm = useForm<VerificationFormValues>({
    resolver: zodResolver(verificationSchema),
    defaultValues: {
      documento: null,
      termoVerificacao: false,
    },
  });

  // Estado para armazenar as imagens de preview
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(null);
  const [coverImagePreview, setCoverImagePreview] = useState<string | null>(null);
  const [documentPreview, setDocumentPreview] = useState<string | null>(null);
  
  // Estado para armazenar os nichos secundários selecionados
  const [selectedSecondaryNiches, setSelectedSecondaryNiches] = useState<string[]>([]);

  // Função para lidar com o envio do formulário do passo 1
  function onBasicInfoSubmit(data: BasicInfoFormValues) {
    console.log("Passo 1 dados:", data);
    toast({
      title: "Informações básicas salvas!",
      description: "Vamos continuar com suas redes sociais.",
    });
    setCurrentStep(2);
  }

  // Função para lidar com o envio do formulário do passo 2
  function onSocialMediaSubmit(data: SocialMediaFormValues) {
    console.log("Passo 2 dados:", data);
    
    // Simular extração de dados das redes sociais
    toast({
      title: "Redes sociais conectadas!",
      description: "Extração de métricas concluída com sucesso.",
    });
    
    setCurrentStep(3);
  }

  // Função para lidar com o envio do formulário do passo 3
  function onPhotosSubmit(data: PhotosFormValues) {
    console.log("Passo 3 dados:", data);
    toast({
      title: "Fotos adicionadas com sucesso!",
      description: "Vamos para o último passo da verificação.",
    });
    setCurrentStep(4);
  }

  // Função para lidar com o envio do formulário do passo 4
  function onVerificationSubmit(data: VerificationFormValues) {
    console.log("Passo 4 dados:", data);
    
    toast({
      title: "Perfil criado com sucesso!",
      description: "Seu documento será analisado para verificação.",
    });
    
    // Redirecionar para o dashboard após completar o perfil
    setTimeout(() => {
      navigate("/dashboard");
    }, 1500);
  }

  // Função para lidar com o upload de imagem de perfil
  function handleProfileImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      
      reader.onload = (event) => {
        if (event.target) {
          setProfileImagePreview(event.target.result as string);
          photosForm.setValue('fotoPerfil', file);
        }
      };
      
      reader.readAsDataURL(file);
    }
  }

  // Função para lidar com o upload de imagem de capa
  function handleCoverImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      
      reader.onload = (event) => {
        if (event.target) {
          setCoverImagePreview(event.target.result as string);
          photosForm.setValue('fotoCapa', file);
        }
      };
      
      reader.readAsDataURL(file);
    }
  }

  // Função para lidar com o upload de documento
  function handleDocumentUpload(e: React.ChangeEvent<HTMLInputElement>) {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      
      reader.onload = (event) => {
        if (event.target) {
          setDocumentPreview(event.target.result as string);
          verificationForm.setValue('documento', file);
        }
      };
      
      reader.readAsDataURL(file);
    }
  }

  // Função para lidar com a seleção de nichos secundários
  function handleSecondaryNicheToggle(nicho: string) {
    setSelectedSecondaryNiches(prev => {
      if (prev.includes(nicho)) {
        const newNiches = prev.filter(n => n !== nicho);
        basicInfoForm.setValue('nichosSecundarios', newNiches);
        return newNiches;
      } else {
        const newNiches = [...prev, nicho];
        basicInfoForm.setValue('nichosSecundarios', newNiches);
        return newNiches;
      }
    });
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-brand-light to-white pb-12">
      <div className="container mx-auto px-4 pt-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold mb-2">Configuração do seu perfil</h1>
            <p className="text-gray-600">Complete as informações abaixo para configurar seu perfil de criador</p>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
            <div className="mb-6">
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Passo {currentStep} de {totalSteps}</span>
                <span className="text-sm font-medium">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
            
            {/* Passo 1 - Informações Básicas */}
            {currentStep === 1 && (
              <div>
                <h2 className="text-xl font-semibold mb-4">Informações Básicas</h2>
                <Form {...basicInfoForm}>
                  <form onSubmit={basicInfoForm.handleSubmit(onBasicInfoSubmit)} className="space-y-4">
                    <FormField
                      control={basicInfoForm.control}
                      name="nomeArtistico"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome artístico</FormLabel>
                          <FormControl>
                            <Input placeholder="Como você quer ser chamado" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={basicInfoForm.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bio (descrição pessoal)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Conte um pouco sobre você e seu trabalho" 
                              className="resize-none" 
                              rows={4}
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            Entre 20 e 500 caracteres
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={basicInfoForm.control}
                        name="cidade"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Cidade</FormLabel>
                            <FormControl>
                              <Input placeholder="Sua cidade" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={basicInfoForm.control}
                        name="estado"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Estado</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Selecione" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {ESTADOS.map((estado) => (
                                  <SelectItem key={estado} value={estado}>
                                    {estado}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={basicInfoForm.control}
                      name="nichoPrincipal"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nicho principal</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione seu nicho principal" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {NICHOS.map((nicho) => (
                                <SelectItem key={nicho} value={nicho}>
                                  {nicho}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={basicInfoForm.control}
                      name="nichosSecundarios"
                      render={() => (
                        <FormItem>
                          <FormLabel>Nichos secundários (opcional)</FormLabel>
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2">
                            {NICHOS.map((nicho) => (
                              <div 
                                key={nicho}
                                className={`flex items-center space-x-2 border rounded-md p-2 cursor-pointer ${
                                  selectedSecondaryNiches.includes(nicho) 
                                    ? 'border-brand-purple bg-brand-purple/10' 
                                    : 'border-gray-200'
                                }`}
                                onClick={() => handleSecondaryNicheToggle(nicho)}
                              >
                                <Checkbox 
                                  checked={selectedSecondaryNiches.includes(nicho)}
                                  onCheckedChange={() => handleSecondaryNicheToggle(nicho)}
                                  id={`nicho-${nicho}`}
                                />
                                <label 
                                  htmlFor={`nicho-${nicho}`} 
                                  className="text-sm cursor-pointer"
                                >
                                  {nicho}
                                </label>
                              </div>
                            ))}
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full mt-6 bg-brand-purple hover:bg-brand-purple/90">
                      Próximo passo
                    </Button>
                  </form>
                </Form>
              </div>
            )}
            
            {/* Passo 2 - Redes Sociais */}
            {currentStep === 2 && (
              <div>
                <h2 className="text-xl font-semibold mb-4">Redes Sociais</h2>
                <p className="text-sm text-gray-600 mb-6">
                  Conecte suas redes sociais para extrair métricas em tempo real
                </p>
                
                <Form {...socialMediaForm}>
                  <form onSubmit={socialMediaForm.handleSubmit(onSocialMediaSubmit)} className="space-y-4">
                    <FormField
                      control={socialMediaForm.control}
                      name="instagram"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-2">
                            <Instagram className="h-4 w-4" />
                            Instagram
                          </FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">@</span>
                              <Input className="pl-8" placeholder="seu_usuario" {...field} />
                            </div>
                          </FormControl>
                          <FormDescription>
                            Seu nome de usuário sem o @
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={socialMediaForm.control}
                      name="youtube"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-2">
                            <Youtube className="h-4 w-4" />
                            YouTube
                          </FormLabel>
                          <FormControl>
                            <Input placeholder="Link do seu canal (opcional)" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={socialMediaForm.control}
                      name="tiktok"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-2">
                            <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                            </svg>
                            TikTok
                          </FormLabel>
                          <FormControl>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">@</span>
                              <Input className="pl-8" placeholder="seu_usuario (opcional)" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mt-6">
                      <h3 className="font-medium text-gray-800 mb-2">O que extraímos das suas redes</h3>
                      <ul className="space-y-2 text-sm text-gray-600">
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                          Número de seguidores
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                          Engajamento médio
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                          Faixa etária predominante
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                          Distribuição de gênero
                        </li>
                      </ul>
                    </div>
                    
                    <div className="flex gap-3 pt-3">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setCurrentStep(1)}
                      >
                        Voltar
                      </Button>
                      <Button 
                        type="submit" 
                        className="flex-1 bg-brand-purple hover:bg-brand-purple/90"
                      >
                        Conectar e continuar
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            )}
            
            {/* Passo 3 - Fotos de Perfil e Capa */}
            {currentStep === 3 && (
              <div>
                <h2 className="text-xl font-semibold mb-4">Foto de Perfil e Capa</h2>
                <p className="text-sm text-gray-600 mb-6">
                  Adicione sua foto de perfil e imagem de capa para destacar seu perfil
                </p>
                
                <Form {...photosForm}>
                  <form onSubmit={photosForm.handleSubmit(onPhotosSubmit)} className="space-y-6">
                    {/* Upload de Foto de Perfil */}
                    <div className="space-y-4">
                      <FormLabel>Foto de perfil</FormLabel>
                      <div className="flex flex-col items-center justify-center">
                        <div className="relative mb-4">
                          {profileImagePreview ? (
                            <div className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-md">
                              <img 
                                src={profileImagePreview} 
                                alt="Foto de perfil" 
                                className="w-full h-full object-cover" 
                              />
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                className="absolute bottom-0 right-0 bg-white rounded-full shadow-md h-8 w-8"
                                onClick={() => {
                                  document.getElementById('profile-upload')?.click();
                                }}
                              >
                                <Camera className="h-4 w-4" />
                              </Button>
                            </div>
                          ) : (
                            <div 
                              className="w-32 h-32 rounded-full bg-gray-100 border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 transition-colors"
                              onClick={() => {
                                document.getElementById('profile-upload')?.click();
                              }}
                            >
                              <Camera className="h-8 w-8 text-gray-400 mb-2" />
                              <span className="text-xs text-gray-500">Adicionar foto</span>
                            </div>
                          )}
                        </div>
                        <Input
                          id="profile-upload"
                          type="file"
                          className="hidden"
                          accept="image/*"
                          onChange={handleProfileImageUpload}
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          onClick={() => {
                            document.getElementById('profile-upload')?.click();
                          }}
                        >
                          {profileImagePreview ? 'Trocar foto' : 'Fazer upload'}
                        </Button>
                      </div>
                    </div>
                    
                    {/* Upload de Imagem de Capa */}
                    <div className="space-y-4 pt-4">
                      <FormLabel>Imagem de capa</FormLabel>
                      <div>
                        {coverImagePreview ? (
                          <div className="relative rounded-lg overflow-hidden border border-gray-200 h-48">
                            <img 
                              src={coverImagePreview} 
                              alt="Imagem de capa" 
                              className="w-full h-full object-cover" 
                            />
                            <Button
                              type="button"
                              variant="secondary"
                              size="sm"
                              className="absolute bottom-2 right-2 bg-white/80 hover:bg-white/90"
                              onClick={() => {
                                document.getElementById('cover-upload')?.click();
                              }}
                            >
                              <Upload className="h-4 w-4 mr-1" />
                              Trocar capa
                            </Button>
                          </div>
                        ) : (
                          <div 
                            className="w-full h-48 rounded-lg bg-gray-100 border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 transition-colors"
                            onClick={() => {
                              document.getElementById('cover-upload')?.click();
                            }}
                          >
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <span className="text-sm text-gray-500">Clique para fazer upload da imagem de capa</span>
                            <span className="text-xs text-gray-400 mt-1">Recomendado: 1200 x 400 pixels</span>
                          </div>
                        )}
                        <Input
                          id="cover-upload"
                          type="file"
                          className="hidden"
                          accept="image/*"
                          onChange={handleCoverImageUpload}
                        />
                      </div>
                    </div>
                    
                    <div className="flex gap-3 pt-6">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setCurrentStep(2)}
                      >
                        Voltar
                      </Button>
                      <Button 
                        type="submit" 
                        className="flex-1 bg-brand-purple hover:bg-brand-purple/90"
                      >
                        Continuar
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            )}
            
            {/* Passo 4 - Verificação */}
            {currentStep === 4 && (
              <div>
                <h2 className="text-xl font-semibold mb-4">Verificação</h2>
                <p className="text-sm text-gray-600 mb-6">
                  Envie um documento oficial para validação e obtenha o selo de verificação real
                </p>
                
                <Form {...verificationForm}>
                  <form onSubmit={verificationForm.handleSubmit(onVerificationSubmit)} className="space-y-6">
                    {/* Upload de Documento */}
                    <div className="space-y-4">
                      <FormLabel>Upload de documento</FormLabel>
                      <div>
                        {documentPreview ? (
                          <div className="relative rounded-lg overflow-hidden border border-gray-200">
                            <img 
                              src={documentPreview} 
                              alt="Documento" 
                              className="w-full h-48 object-contain bg-gray-50" 
                            />
                            <Button
                              type="button"
                              variant="secondary"
                              size="sm"
                              className="absolute bottom-2 right-2 bg-white/80 hover:bg-white/90"
                              onClick={() => {
                                document.getElementById('document-upload')?.click();
                              }}
                            >
                              <Upload className="h-4 w-4 mr-1" />
                              Trocar documento
                            </Button>
                          </div>
                        ) : (
                          <div 
                            className="w-full h-48 rounded-lg bg-gray-100 border-2 border-dashed border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 transition-colors"
                            onClick={() => {
                              document.getElementById('document-upload')?.click();
                            }}
                          >
                            <Upload className="h-8 w-8 text-gray-400 mb-2" />
                            <span className="text-sm text-gray-500">Clique para fazer upload do seu documento</span>
                            <span className="text-xs text-gray-400 mt-1">RG, CNH ou Passaporte</span>
                          </div>
                        )}
                        <Input
                          id="document-upload"
                          type="file"
                          className="hidden"
                          accept="image/*,.pdf"
                          onChange={handleDocumentUpload}
                        />
                      </div>
                    </div>
                    
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                      <h3 className="font-medium text-amber-800 mb-2">Importante</h3>
                      <p className="text-sm text-amber-700 mb-4">
                        O selo de verificação real é importante para garantir a credibilidade do seu perfil e aumentar suas chances de fechar parcerias com empresas.
                      </p>
                      <ul className="space-y-2 text-sm text-amber-700">
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 mt-0.5 text-amber-500" />
                          <span>Seu documento será analisado manualmente pela nossa equipe.</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 mt-0.5 text-amber-500" />
                          <span>A verificação geralmente leva até 48 horas úteis.</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 mt-0.5 text-amber-500" />
                          <span>Seus dados são criptografados e tratados com segurança.</span>
                        </li>
                      </ul>
                    </div>
                    
                    <FormField
                      control={verificationForm.control}
                      name="termoVerificacao"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-2 space-y-0 mt-4">
                          <FormControl>
                            <Checkbox 
                              checked={field.value} 
                              onCheckedChange={field.onChange} 
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel className="text-sm font-normal">
                              Concordo em fornecer meu documento para verificação de identidade e autorizo o processamento seguro desses dados conforme a política de privacidade
                            </FormLabel>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex gap-3 pt-6">
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setCurrentStep(3)}
                      >
                        Voltar
                      </Button>
                      <Button 
                        type="submit" 
                        className="flex-1 bg-brand-purple hover:bg-brand-purple/90"
                      >
                        Finalizar perfil
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
