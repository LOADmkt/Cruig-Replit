import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  MessageSquare, 
  FileText, 
  Star, 
  Heart, 
  Settings, 
  LogOut,
  Menu,
  X,
  Search,
  UserCircle,
  Bell,
  LinkIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from "@/hooks/use-toast";
import { CreatorDashboardOverview } from '@/components/creator/CreatorDashboardOverview';
import { Badge } from '@/components/ui/badge';
import { CreatorAffiliatePanel } from '@/components/affiliate/CreatorAffiliatePanel';

export default function CreatorDashboard() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [userData, setUserData] = useState<any>(null);

  useEffect(() => {
    const mockUserData = {
      id: 1,
      nome: "Julia Santos",
      email: "julia@creator.com",
      tipoConta: "criador",
      isLoggedIn: true,
      perfil: {
        nome: "Julia Santos",
        avatar: "https://source.unsplash.com/photo-1494790108377-be9c29b29330",
        username: "@juliasantos",
        nicho: ["moda", "lifestyle", "sustentabilidade"],
        location: "São Paulo",
        bio: "Criadora de conteúdo sobre moda sustentável e lifestyle consciente. Transformando o mundo, um post de cada vez. ♻️✨",
        perfilCompleto: true,
        verificado: true,
        redeSocial: {
          instagram: {
            connected: false,
            username: "@juliasantos",
            followers: "156.2k",
            engagement: "5.8%"
          },
          youtube: {
            connected: false,
            username: "Julia Santos",
            followers: "45.3k",
            engagement: "4.2%"
          },
          tiktok: {
            connected: false,
            username: "@juliasantos",
            followers: "232.7k",
            engagement: "7.5%"
          }
        },
        avaliacoes: [
          {
            id: 1,
            empresa: "Empresa XYZ",
            nota: 5,
            comentario: "Ótimo criador, muito profissional e pontual com as entregas."
          },
          {
            id: 2,
            empresa: "Marca ABC",
            nota: 4,
            comentario: "Excelente trabalho! Recomendo fortemente."
          }
        ]
      }
    };
    
    setUserData(mockUserData);

    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) {
        setSidebarOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('userData');
    toast({
      title: "Logout realizado com sucesso",
      description: "Você saiu da sua conta.",
    });
    navigate('/');
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <CreatorDashboardOverview userData={userData} />;
      case 'affiliate':
        return <CreatorAffiliatePanel />;
      default:
        return <CreatorDashboardOverview userData={userData} />;
    }
  };

  if (!userData) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-brand-secondary/30">
        <div className="animate-pulse flex flex-col items-center p-8">
          <div className="h-16 w-16 bg-brand-primary/30 rounded-full mb-4"></div>
          <div className="h-4 w-32 bg-gray-300 rounded mb-3"></div>
          <div className="h-3 w-24 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-brand-secondary/30 flex flex-col">
      <div className="md:hidden bg-white shadow-sm p-4 flex justify-between items-center">
        <div className="flex items-center">
          <img 
            src="/lovable-uploads/2bf57e0e-db5c-40de-99ba-8d1bfd2dcbc5.png" 
            alt="Cruig" 
            className="h-8" 
          />
        </div>
        <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(!sidebarOpen)}>
          {sidebarOpen ? <X /> : <Menu />}
        </Button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <div 
          className={`bg-white shadow-lg z-20 ${
            sidebarOpen 
              ? "fixed inset-y-0 left-0 w-64 transform translate-x-0 transition-transform ease-in-out duration-300 md:relative" 
              : "fixed inset-y-0 left-0 w-64 transform -translate-x-full transition-transform ease-in-out duration-300 md:relative md:translate-x-0 md:w-0"
          }`}
        >
          <div className="h-full flex flex-col p-4">
            <div className="py-4 flex justify-center">
              <img 
                src="/lovable-uploads/2bf57e0e-db5c-40de-99ba-8d1bfd2dcbc5.png" 
                alt="Cruig" 
                className="h-8" 
              />
            </div>
            
            <div className="mb-6 flex flex-col items-center">
              {userData.perfil?.avatar ? (
                <img 
                  src={userData.perfil.avatar} 
                  alt={userData.nome} 
                  className="w-24 h-24 rounded-full object-cover mb-3 border-4 border-brand-primary/20"
                />
              ) : (
                <div className="w-24 h-24 rounded-full bg-brand-primary/10 flex items-center justify-center mb-3 border-4 border-brand-primary/20">
                  <UserCircle className="h-16 w-16 text-brand-primary" />
                </div>
              )}
              <div className="font-semibold text-center">{userData.nome}</div>
              <div className="text-xs text-gray-500 mt-1">@{userData.perfil?.username?.replace('@', '') || 'usuario'}</div>
              
              <div className="mt-2 flex gap-2">
                {userData.perfil?.verificado && (
                  <Badge variant="success" className="text-xs">Verificado</Badge>
                )}
                {(userData.perfil?.avaliacoes?.length >= 10) && (
                  <Badge variant="brand" className="text-xs">Super Criador</Badge>
                )}
              </div>
            </div>
            
            <nav className="space-y-1 flex-1">
              <button 
                onClick={() => setActiveTab('overview')} 
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'overview' 
                    ? 'bg-brand-primary text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <LayoutDashboard className="h-5 w-5" />
                <span>Visão Geral</span>
              </button>
              
              <button 
                onClick={() => setActiveTab('profile')} 
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'profile' 
                    ? 'bg-brand-primary text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <UserCircle className="h-5 w-5" />
                <span>Meu Perfil</span>
              </button>
              
              <button 
                onClick={() => setActiveTab('campaigns')} 
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'campaigns' 
                    ? 'bg-brand-primary text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <FileText className="h-5 w-5" />
                <span>Campanhas</span>
                <Badge className="ml-auto" variant="brand">5</Badge>
              </button>
              
              <button 
                onClick={() => setActiveTab('messages')} 
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'messages' 
                    ? 'bg-brand-primary text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <MessageSquare className="h-5 w-5" />
                <span>Mensagens</span>
                <Badge className="ml-auto" variant="brand">8</Badge>
              </button>
              
              <button 
                onClick={() => setActiveTab('favorites')} 
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'favorites' 
                    ? 'bg-brand-primary text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Heart className="h-5 w-5" />
                <span>Favoritos</span>
              </button>
              
              <button 
                onClick={() => setActiveTab('affiliate')} 
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'affiliate' 
                    ? 'bg-brand-primary text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <LinkIcon className="h-5 w-5" />
                <span>Afiliado</span>
              </button>
              
              <button 
                onClick={() => setActiveTab('ratings')} 
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'ratings' 
                    ? 'bg-brand-primary text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Star className="h-5 w-5" />
                <span>Avaliações</span>
                <Badge className="ml-auto" variant="brand">{userData.perfil?.avaliacoes?.length || 0}</Badge>
              </button>
              
              <button 
                onClick={() => setActiveTab('notifications')} 
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'notifications' 
                    ? 'bg-brand-primary text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Bell className="h-5 w-5" />
                <span>Notificações</span>
                <Badge className="ml-auto" variant="brand">3</Badge>
              </button>
              
              <button 
                onClick={() => setActiveTab('search')} 
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'search' 
                    ? 'bg-brand-primary text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Search className="h-5 w-5" />
                <span>Buscar Campanhas</span>
              </button>
              
              <button 
                onClick={() => setActiveTab('settings')} 
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'settings' 
                    ? 'bg-brand-primary text-white' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Settings className="h-5 w-5" />
                <span>Configurações</span>
              </button>
            </nav>
            
            <button 
              onClick={handleLogout}
              className="mt-auto flex items-center space-x-3 w-full px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
            >
              <LogOut className="h-5 w-5" />
              <span>Sair</span>
            </button>
          </div>
        </div>
        
        <div className="flex-1 overflow-auto p-4 md:p-8">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}
