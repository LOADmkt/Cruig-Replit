
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { KeyRound, Loader2, AlertCircle, Check } from 'lucide-react';
import { resetPassword } from '@/services/authService';
import { supabase } from '@/lib/supabaseClient';
import { isValidPassword, passwordsMatch } from '@/lib/formValidation';
import { PasswordStrengthIndicator } from '@/components/auth/PasswordStrengthIndicator';

export default function ResetarSenha() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState<{ password?: string; confirmPassword?: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [hasResetToken, setHasResetToken] = useState(false);

  useEffect(() => {
    // Check if we have a valid recovery token in the URL
    const checkResetToken = async () => {
      const { data, error } = await supabase.auth.getSession();
      
      // Check if we have a session in recovery mode
      if (data.session?.user && window.location.hash.includes('type=recovery')) {
        setHasResetToken(true);
      } else {
        // If no token, user shouldn't be on this page
        toast({
          title: 'Link inválido ou expirado',
          description: 'O link de redefinição de senha é inválido ou expirou.',
          variant: 'destructive',
        });
        
        // Redirect after a small delay
        setTimeout(() => navigate('/auth'), 3000);
      }
    };
    
    checkResetToken();
  }, [navigate, toast]);

  const validateForm = (): boolean => {
    const newErrors: { password?: string; confirmPassword?: string } = {};
    
    if (!password) {
      newErrors.password = 'A senha é obrigatória';
    } else if (!isValidPassword(password)) {
      newErrors.password = 'A senha deve ter pelo menos 6 caracteres';
    }
    
    if (!passwordsMatch(password, confirmPassword)) {
      newErrors.confirmPassword = 'As senhas não correspondem';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      setIsSubmitting(true);
      const result = await resetPassword(password);
      
      if (result.success) {
        setIsSuccess(true);
        toast({
          title: 'Senha redefinida com sucesso',
          description: 'Sua senha foi alterada. Você já pode fazer login com a nova senha.',
        });
        
        // Redirect to login page after 3 seconds
        setTimeout(() => navigate('/auth'), 3000);
      } else {
        toast({
          title: 'Erro',
          description: result.error || 'Ocorreu um erro ao redefinir sua senha.',
          variant: 'destructive',
        });
      }
    } catch (error: any) {
      toast({
        title: 'Erro',
        description: error.message || 'Ocorreu um erro ao redefinir sua senha.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-brand-secondary/30">
      <header className="w-full p-4 bg-white shadow-sm flex justify-center">
        <Link to="/" className="flex items-center">
          <img 
            src="/lovable-uploads/2bf57e0e-db5c-40de-99ba-8d1bfd2dcbc5.png" 
            alt="CreatorMatch" 
            className="h-8"
          />
        </Link>
      </header>
      
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-lg border-gray-200 animate-fade-in">
          <CardHeader className="space-y-1">
            <CardTitle className="text-xl text-center">Redefinir senha</CardTitle>
            <CardDescription className="text-center">
              {!isSuccess 
                ? 'Crie uma nova senha para sua conta'
                : 'Sua senha foi redefinida com sucesso'}
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {!hasResetToken ? (
              <div className="text-center py-6">
                <Loader2 className="animate-spin h-10 w-10 mx-auto mb-4 text-gray-400" />
                <p>Verificando link de redefinição...</p>
                <p className="text-sm text-gray-500 mt-2">
                  Você será redirecionado em instantes...
                </p>
              </div>
            ) : !isSuccess ? (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <div className="relative">
                    <KeyRound className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                    <Input
                      placeholder="Nova senha"
                      type="password"
                      autoComplete="new-password"
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value);
                        if (errors.password) {
                          setErrors(prev => ({ ...prev, password: undefined }));
                        }
                      }}
                      className={`pl-10 border-2 ${errors.password ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-brand-primary focus:ring-brand-primary'}`}
                      disabled={isSubmitting}
                    />
                    {errors.password && (
                      <div className="flex items-center mt-1 text-red-500 text-sm">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        <span>{errors.password}</span>
                      </div>
                    )}
                    <PasswordStrengthIndicator password={password} />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="relative">
                    <KeyRound className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                    <Input
                      placeholder="Confirmar nova senha"
                      type="password"
                      autoComplete="new-password"
                      value={confirmPassword}
                      onChange={(e) => {
                        setConfirmPassword(e.target.value);
                        if (errors.confirmPassword) {
                          setErrors(prev => ({ ...prev, confirmPassword: undefined }));
                        }
                      }}
                      className={`pl-10 border-2 ${errors.confirmPassword ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-brand-primary focus:ring-brand-primary'}`}
                      disabled={isSubmitting}
                    />
                    {errors.confirmPassword && (
                      <div className="flex items-center mt-1 text-red-500 text-sm">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        <span>{errors.confirmPassword}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-[#87ab0c] hover:bg-[#758f0d] text-white font-medium py-2.5 shadow-md transition-colors"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="animate-spin h-4 w-4 mr-2" />
                      Atualizando senha...
                    </>
                  ) : 'Redefinir senha'}
                </Button>
              </form>
            ) : (
              <div className="text-center py-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Check className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-lg font-medium text-green-700 mb-2">Senha redefinida com sucesso!</h3>
                <p className="text-gray-600">
                  Você será redirecionado para a página de login em instantes.
                </p>
              </div>
            )}
          </CardContent>
          
          <CardFooter className="flex justify-center">
            <Link to="/auth" className="text-[#87ab0c] hover:underline">
              Voltar para o login
            </Link>
          </CardFooter>
        </Card>
      </main>
    </div>
  );
}
