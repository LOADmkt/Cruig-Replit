
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { AtSign, KeyRound, User, AlertCircle, Loader2, Eye, EyeOff } from 'lucide-react';
import { PasswordStrengthIndicator } from '@/components/auth/PasswordStrengthIndicator';
import { validateLoginData, validateRegistrationData, getPasswordStrength } from '@/lib/formValidation';
import { signInWithGoogle } from '@/services/authService';
import { Separator } from '@/components/ui/separator';

interface FormData {
  email: string;
  password: string;
  confirmPassword: string;
  name: string;
  userType: 'empresa' | 'criador' | 'admin' | undefined;
}

export default function Auth() {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const {
    signIn,
    signUp,
    isLoading: authLoading,
    isAuthenticated,
    isCompany,
    isCreator,
    isAdmin
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'login' | 'signup'>('login');
  const [formData, setFormData] = useState<FormData>({
    email: '',
    password: '',
    confirmPassword: '',
    name: '',
    userType: undefined
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);

  // Parse redirect destination from location state
  const from = location.state?.from?.pathname || '/';

  // Update password strength when password changes
  useEffect(() => {
    setPasswordStrength(getPasswordStrength(formData.password));
  }, [formData.password]);

  // Redirect if already authenticated - wrapped in useEffect to avoid render during component mount
  useEffect(() => {
    if (isAuthenticated) {
      console.log("Usuário autenticado, redirecionando para dashboard adequado");
      if (isCompany) {
        navigate('/dashboard/empresa');
      } else if (isCreator) {
        navigate('/dashboard/criador');
      } else if (isAdmin) {
        navigate('/dashboard/admin');
      } else {
        // Fallback para a página que estavam tentando acessar ou homepage
        navigate(from);
      }
    }
  }, [isAuthenticated, isCompany, isCreator, isAdmin, navigate, from]);

  // Memoized handlers to prevent re-renders
  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Limpar erro quando o campo é editado
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  }, [errors]);

  const handleLogin = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateLoginData({
      email: formData.email,
      password: formData.password
    });

    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }

    try {
      setIsSubmitting(true);
      const result = await signIn(formData.email, formData.password);
      
      if (!result.success) {
        // Mostrar erro específico se disponível
        const errorMessage = result.error || 'Ocorreu um erro ao fazer login. Por favor, tente novamente.';
        toast({
          title: 'Erro no login',
          description: errorMessage,
          variant: 'destructive'
        });

        // Log para depuração
        console.error("Erro de login:", result.error);
      } else {
        console.log("Login bem-sucedido, redirecionando em breve");
        // Login bem-sucedido acionará o useEffect acima
        // Mostrar toast de boas-vindas
        toast({
          title: 'Login bem-sucedido',
          description: 'Redirecionando para seu dashboard...',
          variant: 'default'
        });
      }
    } catch (error: any) {
      console.error("Erro de login:", error);
      toast({
        title: 'Erro no login',
        description: error.message || 'Ocorreu um erro ao fazer login. Por favor, tente novamente.',
        variant: 'destructive'
      });
    } finally {
      setIsSubmitting(false);
    }
  }, [formData.email, formData.password, signIn, toast]);

  const handleGoogleLogin = useCallback(async () => {
    try {
      setGoogleLoading(true);
      const result = await signInWithGoogle();
      if (!result.success) {
        toast({
          title: 'Erro no login com Google',
          description: result.error || 'Não foi possível fazer login com o Google. Por favor, tente novamente.',
          variant: 'destructive'
        });
      }
      // Se bem-sucedido, o usuário será redirecionado para o provedor OAuth
    } catch (error: any) {
      console.error("Erro no login com Google:", error);
      toast({
        title: 'Erro no login com Google',
        description: error.message || 'Ocorreu um erro ao fazer login com o Google. Por favor, tente novamente.',
        variant: 'destructive'
      });
    } finally {
      setGoogleLoading(false);
    }
  }, [toast]);

  const handleSignUp = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateRegistrationData({
      name: formData.name,
      email: formData.email,
      password: formData.password,
      confirmPassword: formData.confirmPassword,
      userType: formData.userType
    });

    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }

    try {
      setIsSubmitting(true);
      const userData = {
        name: formData.name,
        userType: formData.userType
      };

      console.log("Tentando cadastro com:", {
        email: formData.email,
        userType: formData.userType,
        name: formData.name
      });

      const result = await signUp(formData.email, formData.password, userData);
      
      if (!result.success) {
        // Mostrar erro específico se disponível
        const errorMessage = result.error || 'Ocorreu um erro ao criar sua conta. Por favor, tente novamente.';
        toast({
          title: 'Erro no cadastro',
          description: errorMessage,
          variant: 'destructive'
        });

        // Log para depuração
        console.error("Erro no cadastro:", result.error);
      } else {
        console.log("Cadastro bem-sucedido");
        // Se chegamos aqui e permanecemos na página, o cadastro foi bem-sucedido mas pode precisar de verificação de email
        if (!isAuthenticated) {
          toast({
            title: "Cadastro realizado!",
            description: "Verifique seu email para ativar sua conta."
          });
        }
        // Se autenticado automaticamente, o useEffect redirecionará
      }
    } catch (error: any) {
      console.error("Erro no cadastro:", error);
      toast({
        title: 'Erro no cadastro',
        description: error.message || 'Ocorreu um erro ao criar sua conta. Por favor, tente novamente.',
        variant: 'destructive'
      });
    } finally {
      setIsSubmitting(false);
    }
  }, [formData, signUp, toast, isAuthenticated]);

  const handleSetUserType = useCallback((type: 'criador' | 'empresa') => {
    setFormData(prev => ({
      ...prev,
      userType: type
    }));
    setErrors(prev => ({
      ...prev,
      userType: ''
    }));
  }, []);

  const handleTabChange = useCallback((value: string) => {
    setActiveTab(value as 'login' | 'signup');
  }, []);

  const handleTogglePassword = useCallback(() => {
    setShowPassword(prev => !prev);
  }, []);

  const handleToggleConfirmPassword = useCallback(() => {
    setShowConfirmPassword(prev => !prev);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#FBF7E1]/30">
      <header className="w-full p-4 bg-white shadow-sm flex justify-center">
        <Link to="/" className="flex items-center">
          <img alt="Cruig" className="h-8" src="/lovable-uploads/90f7e64d-1bab-443e-933c-dbdb769727c7.png" />
        </Link>
      </header>
      
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-lg border-gray-200 animate-fade-in">
          <Tabs defaultValue={activeTab} onValueChange={handleTabChange}>
            <CardHeader className="space-y-1">
              <div className="flex justify-center mb-4">
                <TabsList className="grid grid-cols-2 w-full">
                  <TabsTrigger value="login" className="data-[state=active]:bg-[#94C700] data-[state=active]:text-white font-medium transition-colors">
                    Entrar
                  </TabsTrigger>
                  <TabsTrigger value="signup" className="data-[state=active]:bg-[#94C700] data-[state=active]:text-white font-medium transition-colors">
                    Cadastrar
                  </TabsTrigger>
                </TabsList>
              </div>
              <CardTitle className="text-xl text-center">
                {activeTab === 'login' ? 'Acesse sua conta' : 'Crie sua conta'}
              </CardTitle>
              <CardDescription className="text-center">
                {activeTab === 'login' ? 'Entre com seu e-mail e senha para acessar a plataforma' : 'Preencha os dados abaixo para criar sua conta'}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <TabsContent value="login" className="space-y-4 mt-0 animate-fade-in">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <div className="relative">
                      <AtSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                      <Input placeholder="E-mail" name="email" type="email" autoComplete="email" value={formData.email} onChange={handleChange} className={`pl-10 border-2 ${errors.email ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-[#94C700] focus:ring-[#94C700]'}`} disabled={isSubmitting} />
                      {errors.email && (
                        <div className="flex items-center mt-1 text-red-500 text-sm">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          <span>{errors.email}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="relative">
                      <KeyRound className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                      <Input placeholder="Senha" name="password" type={showPassword ? "text" : "password"} autoComplete="current-password" value={formData.password} onChange={handleChange} className={`pl-10 pr-10 border-2 ${errors.password ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-[#94C700] focus:ring-[#94C700]'}`} disabled={isSubmitting} />
                      <button type="button" className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500" onClick={handleTogglePassword}>
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                      {errors.password && (
                        <div className="flex items-center mt-1 text-red-500 text-sm">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          <span>{errors.password}</span>
                        </div>
                      )}
                    </div>
                    <div className="text-right">
                      <Link to="/auth/recuperar-senha" className="text-sm text-[#94C700] hover:underline font-medium">
                        Esqueceu a senha?
                      </Link>
                    </div>
                  </div>
                  
                  <Button type="submit" disabled={isSubmitting || authLoading} className="w-full bg-[#94C700] hover:bg-[#75a300] text-white font-medium py-2.5 shadow-md transition-colors">
                    {isSubmitting || authLoading ? (
                      <>
                        <Loader2 className="animate-spin h-4 w-4 mr-2" />
                        Entrando...
                      </>
                    ) : 'Entrar'}
                  </Button>

                  <div className="relative my-6">
                    <div className="absolute inset-0 flex items-center">
                      <Separator className="w-full" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-white px-2 text-gray-500">ou</span>
                    </div>
                  </div>

                  <Button type="button" variant="outline" onClick={handleGoogleLogin} disabled={googleLoading || isSubmitting || authLoading} className="w-full border-2 font-medium shadow-sm">
                    {googleLoading ? (
                      <>
                        <Loader2 className="animate-spin h-4 w-4 mr-2" />
                        Conectando...
                      </>
                    ) : (
                      <>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="h-5 w-5 mr-2">
                          <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"></path>
                          <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"></path>
                          <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"></path>
                          <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"></path>
                        </svg>
                        Entrar com Google
                      </>
                    )}
                  </Button>
                </form>
              </TabsContent>
              
              <TabsContent value="signup" className="space-y-4 mt-0 animate-fade-in">
                <form onSubmit={handleSignUp} className="space-y-4">
                  <div className="space-y-2">
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                      <Input placeholder="Nome completo" name="name" autoComplete="name" value={formData.name} onChange={handleChange} className={`pl-10 border-2 ${errors.name ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-[#94C700] focus:ring-[#94C700]'}`} disabled={isSubmitting} />
                      {errors.name && (
                        <div className="flex items-center mt-1 text-red-500 text-sm">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          <span>{errors.name}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="relative">
                      <AtSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                      <Input placeholder="E-mail" name="email" type="email" autoComplete="email" value={formData.email} onChange={handleChange} className={`pl-10 border-2 ${errors.email ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-[#94C700] focus:ring-[#94C700]'}`} disabled={isSubmitting} />
                      {errors.email && (
                        <div className="flex items-center mt-1 text-red-500 text-sm">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          <span>{errors.email}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="relative">
                      <KeyRound className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                      <Input placeholder="Senha" name="password" type={showPassword ? "text" : "password"} autoComplete="new-password" value={formData.password} onChange={handleChange} className={`pl-10 pr-10 border-2 ${errors.password ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-[#94C700] focus:ring-[#94C700]'}`} disabled={isSubmitting} />
                      <button type="button" className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500" onClick={handleTogglePassword}>
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                      {errors.password && (
                        <div className="flex items-center mt-1 text-red-500 text-sm">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          <span>{errors.password}</span>
                        </div>
                      )}
                    </div>
                    
                    <PasswordStrengthIndicator password={formData.password} />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="relative">
                      <KeyRound className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                      <Input placeholder="Confirmar senha" name="confirmPassword" type={showConfirmPassword ? "text" : "password"} autoComplete="new-password" value={formData.confirmPassword} onChange={handleChange} className={`pl-10 pr-10 border-2 ${errors.confirmPassword ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-[#94C700] focus:ring-[#94C700]'}`} disabled={isSubmitting} />
                      <button type="button" className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500" onClick={handleToggleConfirmPassword}>
                        {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                      {errors.confirmPassword && (
                        <div className="flex items-center mt-1 text-red-500 text-sm">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          <span>{errors.confirmPassword}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <Button 
                      type="button" 
                      variant={formData.userType === 'criador' ? 'default' : 'outline'} 
                      className={`w-full ${formData.userType === 'criador' ? 'bg-[#94C700] hover:bg-[#75a300] text-white shadow-md' : 'text-gray-700 border-2 hover:bg-gray-100'} transition-colors`} 
                      onClick={() => handleSetUserType('criador')} 
                      disabled={isSubmitting}
                    >
                      Sou Criador
                    </Button>
                    <Button 
                      type="button" 
                      variant={formData.userType === 'empresa' ? 'default' : 'outline'} 
                      className={`w-full ${formData.userType === 'empresa' ? 'bg-[#94C700] hover:bg-[#75a300] text-white shadow-md' : 'text-gray-700 border-2 hover:bg-gray-100'} transition-colors`} 
                      onClick={() => handleSetUserType('empresa')} 
                      disabled={isSubmitting}
                    >
                      Sou Empresa
                    </Button>
                  </div>
                  {errors.userType && (
                    <div className="flex items-center mt-1 text-red-500 text-sm justify-center">
                      <AlertCircle className="h-3 w-3 mr-1" />
                      <span>{errors.userType}</span>
                    </div>
                  )}
                  
                  <Button type="submit" disabled={isSubmitting || authLoading} className="w-full bg-[#94C700] hover:bg-[#75a300] text-white font-medium py-2.5 shadow-md transition-colors">
                    {isSubmitting || authLoading ? (
                      <>
                        <Loader2 className="animate-spin h-4 w-4 mr-2" />
                        Cadastrando...
                      </>
                    ) : 'Cadastrar'}
                  </Button>

                  <div className="relative my-6">
                    <div className="absolute inset-0 flex items-center">
                      <Separator className="w-full" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-white px-2 text-gray-500">ou</span>
                    </div>
                  </div>

                  <Button type="button" variant="outline" onClick={handleGoogleLogin} disabled={googleLoading || isSubmitting || authLoading} className="w-full border-2 font-medium shadow-sm">
                    {googleLoading ? (
                      <>
                        <Loader2 className="animate-spin h-4 w-4 mr-2" />
                        Conectando...
                      </>
                    ) : (
                      <>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="h-5 w-5 mr-2">
                          <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"></path>
                          <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"></path>
                          <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"></path>
                          <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"></path>
                        </svg>
                        Cadastrar com Google
                      </>
                    )}
                  </Button>
                </form>
              </TabsContent>
            </CardContent>
            
            <CardFooter className="flex flex-col space-y-4">
              <div className="text-center text-sm text-gray-600">
                {activeTab === 'login' ? (
                  <span>
                    Ainda não tem uma conta?{' '}
                    <button onClick={() => handleTabChange('signup')} className="text-[#94C700] hover:underline font-medium" disabled={isSubmitting}>
                      Cadastre-se aqui
                    </button>
                  </span>
                ) : (
                  <span>
                    Já tem uma conta?{' '}
                    <button onClick={() => handleTabChange('login')} className="text-[#94C700] hover:underline font-medium" disabled={isSubmitting}>
                      Faça login
                    </button>
                  </span>
                )}
              </div>
            </CardFooter>
          </Tabs>
        </Card>
      </main>
    </div>
  );
}
