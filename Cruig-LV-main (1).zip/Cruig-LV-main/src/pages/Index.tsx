
import React from 'react';
import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import FeaturesSection from '@/components/FeaturesSection';
import TestimonialsSection from '@/components/TestimonialsSection';
import CTASection from '@/components/CTASection';
import Footer from '@/components/Footer';
import DashboardPreview from '@/components/DashboardPreview';
import VideoShowcase from '@/components/VideoShowcase';

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <HeroSection />
        <FeaturesSection />
        <VideoShowcase 
          title="Descubra Como Nossa Plataforma Funciona"
          description="Assista a este vídeo para entender como conectamos criadores de conteúdo e marcas de forma eficiente e transparente."
          videoUrl="https://player.vimeo.com/external/373302913.sd.mp4?s=72fd4102f0aea0f1777ca59483520a654c8583a0&profile_id=164&oauth2_token_id=57447761"
          posterImage="public/lovable-uploads/0e13ccbc-84ac-4284-9215-34f34cd587c9.png"
        />
        <DashboardPreview />
        <TestimonialsSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
