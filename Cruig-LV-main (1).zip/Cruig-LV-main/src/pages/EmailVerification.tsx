import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Loader2, CheckCircle, AlertTriangle, Lock } from 'lucide-react';
import { verifyEmail } from '@/services/authService';
import { useAuth } from '@/hooks/useAuth';

export default function EmailVerification() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated } = useAuth();
  const [email, setEmail] = useState('');
  const [token, setToken] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isVerifying, setIsVerifying] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Extract token and email from URL params
  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const urlToken = queryParams.get('token');
    const urlEmail = queryParams.get('email');
    
    if (urlToken) setToken(urlToken);
    if (urlEmail) setEmail(urlEmail);
  }, [location]);
  
  // Verify token automatically if present
  useEffect(() => {
    const verifyTokenFromUrl = async () => {
      if (token) {
        try {
          setIsVerifying(true);
          const result = await verifyEmail(token);
          
          if (result.success) {
            setIsSuccess(true);
            toast({
              title: 'Verificação bem-sucedida',
              description: 'Seu e-mail foi verificado com sucesso.',
            });
            
            // Redirect after 3 seconds
            setTimeout(() => {
              navigate('/auth');
            }, 3000);
          } else {
            setError(result.error || 'Erro ao verificar o e-mail.');
            toast({
              title: 'Erro na verificação',
              description: result.error || 'Ocorreu um erro ao verificar seu e-mail.',
              variant: 'destructive',
            });
          }
        } catch (error: any) {
          setError(error.message || 'Erro ao verificar o e-mail.');
          toast({
            title: 'Erro',
            description: error.message || 'Ocorreu um erro ao verificar seu e-mail.',
            variant: 'destructive',
          });
        } finally {
          setIsVerifying(false);
        }
      } else {
        setIsVerifying(false);
      }
    };
    
    if (token) {
      verifyTokenFromUrl();
    } else {
      setIsVerifying(false);
    }
  }, [token, navigate, toast]);
  
  // If already authenticated, redirect to appropriate dashboard
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);
  
  // Handle manual verification
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!token) {
      setError('Código de verificação é obrigatório.');
      return;
    }
    
    try {
      setIsSubmitting(true);
      const result = await verifyEmail(token);
      
      if (result.success) {
        setIsSuccess(true);
        toast({
          title: 'Verificação bem-sucedida',
          description: 'Seu e-mail foi verificado com sucesso.',
        });
        
        // Redirect after 3 seconds
        setTimeout(() => {
          navigate('/auth');
        }, 3000);
      } else {
        setError(result.error || 'Erro ao verificar o e-mail.');
        toast({
          title: 'Erro na verificação',
          description: result.error || 'Ocorreu um erro ao verificar seu e-mail.',
          variant: 'destructive',
        });
      }
    } catch (error: any) {
      setError(error.message || 'Erro ao verificar o e-mail.');
      toast({
        title: 'Erro',
        description: error.message || 'Ocorreu um erro ao verificar seu e-mail.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-brand-secondary/30">
      <header className="w-full p-4 bg-white shadow-sm flex justify-center">
        <Link to="/" className="flex items-center">
          <img 
            src="/lovable-uploads/a62bb1ba-0892-46c2-a3c0-15b74883be21.png" 
            alt="Cruig" 
            className="h-8"
          />
        </Link>
      </header>
      
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-lg border-gray-200 animate-fade-in">
          <CardHeader className="space-y-1">
            <CardTitle className="text-xl text-center">Verificação de E-mail</CardTitle>
            <CardDescription className="text-center">
              {isVerifying 
                ? 'Validando seu e-mail, aguarde...' 
                : isSuccess 
                ? 'Seu e-mail foi verificado com sucesso!'
                : 'Verifique seu e-mail para concluir o cadastro'}
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {isVerifying ? (
              <div className="flex flex-col items-center justify-center p-6">
                <Loader2 className="h-12 w-12 text-[#87ab0c] animate-spin mb-4" />
                <p className="text-center">Verificando seu e-mail, aguarde um momento...</p>
              </div>
            ) : isSuccess ? (
              <div className="text-center py-4">
                <div className="bg-green-50 p-6 rounded-lg">
                  <div className="flex justify-center mb-4">
                    <CheckCircle className="h-16 w-16 text-green-500" />
                  </div>
                  <h3 className="font-medium text-lg text-green-700 mb-2">Verificação concluída!</h3>
                  <p className="text-green-600">
                    Seu e-mail foi verificado com sucesso. Você será redirecionado para a página de login em breve.
                  </p>
                </div>
              </div>
            ) : error ? (
              <div className="text-center py-4">
                <div className="bg-red-50 p-6 rounded-lg">
                  <div className="flex justify-center mb-4">
                    <AlertTriangle className="h-16 w-16 text-red-500" />
                  </div>
                  <h3 className="font-medium text-lg text-red-700 mb-2">Erro na verificação</h3>
                  <p className="text-red-600 mb-4">
                    {error}
                  </p>
                  <p className="text-gray-700">
                    Você pode tentar verificar novamente usando o formulário abaixo.
                  </p>
                </div>
                
                <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="token" className="block text-sm font-medium text-gray-700">Código de verificação</label>
                    <Input
                      id="token"
                      placeholder="Digite o código recebido por e-mail"
                      value={token}
                      onChange={(e) => setToken(e.target.value)}
                      disabled={isSubmitting}
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full bg-[#87ab0c] hover:bg-[#758f0d] text-white font-medium py-2.5 shadow-md transition-colors"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="animate-spin h-4 w-4 mr-2" />
                        Verificando...
                      </>
                    ) : 'Verificar e-mail'}
                  </Button>
                </form>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="bg-blue-50 p-6 rounded-lg">
                  <div className="flex justify-center mb-4">
                    <Lock className="h-12 w-12 text-blue-500" />
                  </div>
                  <h3 className="font-medium text-lg text-blue-700 mb-2">Verifique seu e-mail</h3>
                  <p className="text-blue-600">
                    Enviamos um e-mail para você com um link de verificação. Clique no link para verificar sua conta.
                  </p>
                  <p className="mt-4 text-gray-700 text-sm">
                    Se você não recebeu o e-mail, verifique sua caixa de spam ou use o formulário abaixo para inserir o código de verificação manualmente.
                  </p>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="token" className="block text-sm font-medium text-gray-700">Código de verificação</label>
                    <Input
                      id="token"
                      placeholder="Digite o código recebido por e-mail"
                      value={token}
                      onChange={(e) => setToken(e.target.value)}
                      disabled={isSubmitting}
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full bg-[#87ab0c] hover:bg-[#758f0d] text-white font-medium py-2.5 shadow-md transition-colors"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="animate-spin h-4 w-4 mr-2" />
                        Verificando...
                      </>
                    ) : 'Verificar e-mail'}
                  </Button>
                </form>
              </div>
            )}
          </CardContent>
          
          <CardFooter className="flex justify-center">
            <Link to="/auth" className="flex items-center text-gray-600 hover:text-gray-900 text-sm">
              <ArrowLeft className="h-4 w-4 mr-1" />
              Voltar para o login
            </Link>
          </CardFooter>
        </Card>
      </main>
    </div>
  );
}
