
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { AtSign, ArrowLeft, Loader2, AlertCircle, CheckCircle } from 'lucide-react';
import { requestPasswordReset } from '@/services/authService';
import { isValidEmail } from '@/lib/formValidation';

export default function RecuperarSenha() {
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const validateForm = (): boolean => {
    if (!email) {
      setError('E-mail é obrigatório');
      return false;
    } else if (!isValidEmail(email)) {
      setError('E-mail inválido');
      return false;
    }
    setError(null);
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      setIsSubmitting(true);
      const result = await requestPasswordReset(email);
      
      if (result.success) {
        setIsSuccess(true);
        toast({
          title: 'E-mail enviado',
          description: 'Verifique sua caixa de entrada para redefinir sua senha.',
        });
      } else {
        toast({
          title: 'Erro',
          description: result.error || 'Ocorreu um erro ao enviar o e-mail de recuperação.',
          variant: 'destructive',
        });
      }
    } catch (error: any) {
      toast({
        title: 'Erro',
        description: error.message || 'Ocorreu um erro ao enviar o e-mail de recuperação.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-brand-secondary/30">
      <header className="w-full p-4 bg-white shadow-sm flex justify-center">
        <Link to="/" className="flex items-center">
          <img 
            src="/lovable-uploads/a62bb1ba-0892-46c2-a3c0-15b74883be21.png" 
            alt="Cruig" 
            className="h-8"
          />
        </Link>
      </header>
      
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-lg border-gray-200 animate-fade-in">
          <CardHeader className="space-y-1">
            <CardTitle className="text-xl text-center">Recuperar senha</CardTitle>
            <CardDescription className="text-center">
              {!isSuccess 
                ? 'Digite seu e-mail para receber um link de recuperação de senha'
                : 'Verifique seu e-mail para instruções de redefinição de senha'}
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {!isSuccess ? (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <div className="relative">
                    <AtSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                    <Input
                      placeholder="E-mail"
                      type="email"
                      autoComplete="email"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        if (error) setError(null);
                      }}
                      className={`pl-10 border-2 ${error ? 'border-red-500 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-brand-primary focus:ring-brand-primary'}`}
                      disabled={isSubmitting}
                    />
                    {error && (
                      <div className="flex items-center mt-1 text-red-500 text-sm">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        <span>{error}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-[#87ab0c] hover:bg-[#758f0d] text-white font-medium py-2.5 shadow-md transition-colors"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="animate-spin h-4 w-4 mr-2" />
                      Enviando...
                    </>
                  ) : 'Enviar e-mail de recuperação'}
                </Button>
              </form>
            ) : (
              <div className="text-center py-4">
                <div className="bg-green-50 p-4 rounded-lg mb-4">
                  <div className="flex justify-center mb-3">
                    <CheckCircle className="h-10 w-10 text-green-500" />
                  </div>
                  <h3 className="font-medium text-green-700 mb-2">E-mail enviado com sucesso!</h3>
                  <p className="text-green-600">
                    Enviamos um e-mail para <strong>{email}</strong> com instruções para redefinir sua senha.
                  </p>
                </div>
                <p className="text-gray-600 text-sm mt-4">
                  Não recebeu o e-mail? Verifique sua caixa de spam ou{' '}
                  <button 
                    className="text-[#87ab0c] hover:underline"
                    onClick={() => setIsSuccess(false)}
                  >
                    tente novamente
                  </button>.
                </p>
              </div>
            )}
          </CardContent>
          
          <CardFooter className="flex justify-center">
            <Link to="/auth" className="flex items-center text-gray-600 hover:text-gray-900 text-sm">
              <ArrowLeft className="h-4 w-4 mr-1" />
              Voltar para o login
            </Link>
          </CardFooter>
        </Card>
      </main>
    </div>
  );
}
