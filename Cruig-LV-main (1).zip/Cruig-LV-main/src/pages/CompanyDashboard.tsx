
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToast } from "@/hooks/use-toast";
import { DashboardSidebar } from '@/components/dashboard/DashboardSidebar';
import { DashboardMobileHeader } from '@/components/dashboard/DashboardMobileHeader';
import { CompanyDashboardOverview } from '@/components/company/CompanyDashboardOverview';
import { CompanyMessages } from '@/components/company/CompanyMessages';
import { CompanyFavorites } from '@/components/company/CompanyFavorites';
import { CompanyRatings } from '@/components/company/CompanyRatings';
import { CompanySettings } from '@/components/company/CompanySettings';
import { CompanySubscription } from '@/components/company/CompanySubscription';
import { CompanyCampaigns } from '@/components/company/CompanyCampaigns';
import { Loader2 } from "lucide-react";
import { useAuth } from '@/hooks/useAuth';
import { ExtendedUserMetadata } from '@/types/auth';

// Definir tipos adequados
interface CompanyDashboardProps {
  // Adicionar props aqui se necessário
}

const CompanyDashboard: React.FC<CompanyDashboardProps> = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const { user, isLoading: authLoading, isCompany, signOut } = useAuth();
  
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [companyData, setCompanyData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Extrair aba dos parâmetros da URL - usa useCallback para evitar re-renders
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const tab = searchParams.get('tab');
    if (tab) {
      setActiveTab(tab);
    }
  }, [location]);

  // Verificar permissão de acesso
  useEffect(() => {
    if (!authLoading && !isCompany) {
      console.log("Usuário não é empresa, redirecionando...");
      navigate('/auth');
    }
  }, [authLoading, isCompany, navigate]);

  // Carregar dados do usuário
  useEffect(() => {
    // Configurar dados da empresa
    if (user) {
      const userMeta = user.user_metadata as ExtendedUserMetadata;
      
      setCompanyData({
        id: user?.id || '1',
        nome: userMeta?.name || 'Empresa',
        email: user?.email || 'empresa@exemplo.com',
        tipoConta: 'empresa',
        isLoggedIn: true,
        perfil: {
          nome: userMeta?.name || 'Empresa',
          logo: userMeta?.avatar || "https://source.unsplash.com/200x200/?company",
          setor: "Tecnologia",
          descricao: "Empresa de tecnologia focada em soluções inovadoras.",
          perfilCompleto: true,
          verificado: true
        },
        subscription: {
          active: false,
          plan: null,
          trialEnds: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
        }
      });
      setIsLoading(false);
    }
  }, [user]);
  
  // Lidar com comportamento responsivo em efeito separado
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      if (!mobile && !sidebarOpen) {
        setSidebarOpen(true);
      } else if (mobile && sidebarOpen) {
        setSidebarOpen(false);
      }
    };
    
    window.addEventListener('resize', handleResize);
    handleResize();
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [sidebarOpen]);

  const handleLogout = useCallback(async () => {
    try {
      const result = await signOut();
      if (result.success) {
        // O próprio signOut já faz o redirecionamento
        console.log("Logout bem-sucedido");
      }
    } catch (error) {
      console.error("Error during logout:", error);
    }
  }, [signOut]);

  const handleTabChange = useCallback((tab: string) => {
    setActiveTab(tab);
    // Atualizar URL sem recarregar a página
    const url = new URL(window.location.href);
    url.searchParams.set('tab', tab);
    window.history.pushState({}, '', url);
    
    // Fechar sidebar no mobile ao selecionar uma aba
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  }, []);

  // Safe setter function para o estado do sidebar
  const handleSetSidebarOpen = useCallback((isOpen: boolean) => {
    setSidebarOpen(isOpen);
  }, []);

  if (isLoading || authLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-brand-primary" />
      </div>
    );
  }

  // Valores derivados - useMemo para evitar recálculos a cada render
  const isSubscribed = useMemo(() => companyData?.subscription?.active === true, [companyData]);
  const unreadMessagesCount = 3; // Isso viria de uma API em produção

  // Conteúdo baseado na aba ativa - evita cálculos em cada render
  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <CompanyDashboardOverview userData={companyData} />;
      case 'messages':
        return <CompanyMessages />;
      case 'favorites':
        return <CompanyFavorites />;
      case 'campaigns':
        return <CompanyCampaigns />;
      case 'ratings':
        return <CompanyRatings />;
      case 'settings':
        return <CompanySettings userData={companyData} />;
      case 'subscription':
        return <CompanySubscription />;
      default:
        return <CompanyDashboardOverview userData={companyData} />;
    }
  };

  return (
    <div className="min-h-screen bg-brand-secondary/30 flex flex-col">
      <DashboardMobileHeader
        sidebarOpen={sidebarOpen}
        setSidebarOpen={handleSetSidebarOpen}
      />

      <div className="flex flex-1 overflow-hidden">
        <DashboardSidebar
          userData={companyData}
          activeTab={activeTab}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={handleSetSidebarOpen}
          handleTabChange={handleTabChange}
          handleLogout={handleLogout}
          unreadMessagesCount={unreadMessagesCount}
          isSubscribed={isSubscribed}
        />
        
        <div className="flex-1 overflow-auto p-4 md:p-8">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default CompanyDashboard;
