
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useToast } from "@/hooks/use-toast";
import { useAuth } from '@/hooks/useAuth';
import { DashboardSidebar } from '@/components/dashboard/DashboardSidebar';
import { DashboardMobileHeader } from '@/components/dashboard/DashboardMobileHeader';
import { DashboardContent } from '@/components/dashboard/DashboardContent';
import { Loader2 } from "lucide-react";
import { ExtendedUserMetadata } from '@/types/auth';

const Dashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const { user, isLoading: authLoading, isCreator, isCompany, signOut } = useAuth();
  
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [userData, setUserData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Extrair a aba dos parâmetros da URL
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const tab = searchParams.get('tab');
    if (tab) {
      setActiveTab(tab);
    }
  }, [location]);

  // Verificar permissão de acesso e redirecionar para o dashboard correto
  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        navigate('/auth');
        return;
      }
      
      // Redirecionar para o dashboard apropriado com base no tipo de usuário
      if (isCompany) {
        navigate('/empresa-dashboard');
      }
    }
  }, [authLoading, isCreator, isCompany, user, navigate]);

  // Carregar dados do usuário e lidar com comportamento responsivo
  useEffect(() => {
    if (user) {
      // Converter user_metadata para nosso tipo estendido para TypeScript
      const userMeta = user.user_metadata as ExtendedUserMetadata;
      
      setUserData({
        id: user?.id || '1',
        nome: userMeta?.name || 'Criador',
        email: user?.email || 'criador@exemplo.com',
        tipoConta: userMeta?.userType || 'criador',
        isLoggedIn: true,
        perfil: {
          nome: userMeta?.name || 'Criador',
          avatar: userMeta?.avatar || "https://source.unsplash.com/200x200/?person",
          username: userMeta?.username || `@${userMeta?.name?.toLowerCase().replace(/\s/g, '') || 'creator'}`,
          bio: userMeta?.bio || "",
          nicho: userMeta?.niches || ["moda", "lifestyle"],
          perfilCompleto: true,
          verificado: userMeta?.verified || false,
          redeSocial: {
            instagram: userMeta?.socialNetworks?.instagram || {
              connected: false,
              username: `@${userMeta?.name?.toLowerCase().replace(/\s/g, '') || 'creator'}`,
              followers: "12.5k",
              engagement: "4.2%"
            },
            youtube: userMeta?.socialNetworks?.youtube,
            tiktok: userMeta?.socialNetworks?.tiktok,
            twitter: userMeta?.socialNetworks?.twitter
          }
        }
      });
      
      setIsLoading(false);
    }
    
    // Lidar com layout responsivo
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) {
        setSidebarOpen(false);
      }
    };
    
    window.addEventListener('resize', handleResize);
    handleResize();
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [user]);

  const handleLogout = async () => {
    const result = await signOut();
    if (result.success) {
      navigate('/');
    }
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    // Atualizar URL sem recarregar a página
    const url = new URL(window.location.href);
    url.searchParams.set('tab', tab);
    window.history.pushState({}, '', url);
    
    // Fechar sidebar no mobile ao selecionar uma aba
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  if (isLoading || authLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="flex flex-col items-center">
          <Loader2 className="h-12 w-12 animate-spin text-brand-primary mb-4" />
          <p className="text-lg font-medium">Carregando...</p>
        </div>
      </div>
    );
  }

  // Valores derivados
  const isSubscribed = false; // Isso viria dos dados do usuário em produção
  const unreadMessagesCount = 3; // Isso viria de uma API em produção

  return (
    <div className="min-h-screen bg-brand-secondary/30 flex flex-col">
      <DashboardMobileHeader
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
      />

      <div className="flex flex-1 overflow-hidden">
        <DashboardSidebar
          userData={userData}
          activeTab={activeTab}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
          handleTabChange={handleTabChange}
          handleLogout={handleLogout}
          unreadMessagesCount={unreadMessagesCount}
          isSubscribed={isSubscribed}
        />
        
        <div className="flex-1 overflow-auto p-4 md:p-8">
          <DashboardContent activeTab={activeTab} userData={userData} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
