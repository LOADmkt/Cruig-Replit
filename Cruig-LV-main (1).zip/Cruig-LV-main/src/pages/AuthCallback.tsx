import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { handleOAuthCallback, updateUserAfterOAuth } from '@/services/authService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

const AuthCallback: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [needsUserType, setNeedsUserType] = useState(false);
  const [processingUserType, setProcessingUserType] = useState(false);
  
  useEffect(() => {
    const processOAuthCallback = async () => {
      try {
        setLoading(true);
        const result = await handleOAuthCallback();
        
        if (!result.success) {
          toast({
            title: 'Erro na autenticação',
            description: result.error || 'Ocorreu um erro durante a autenticação. Por favor, tente novamente.',
            variant: 'destructive',
          });
          navigate('/auth');
          return;
        }
        
        // Check if the user has a userType already
        const userType = result.user?.user_metadata?.userType;
        
        if (!userType) {
          // New user, need to select user type
          setNeedsUserType(true);
        } else {
          // Existing user, navigate to appropriate dashboard
          navigateToDashboard(userType);
        }
      } catch (error: any) {
        console.error('Error during OAuth callback:', error);
        toast({
          title: 'Erro na autenticação',
          description: error.message || 'Ocorreu um erro durante a autenticação.',
          variant: 'destructive',
        });
        navigate('/auth');
      } finally {
        setLoading(false);
      }
    };
    
    processOAuthCallback();
  }, [navigate, toast]);
  
  const navigateToDashboard = (userType: string) => {
    if (userType === 'empresa') {
      navigate('/dashboard/empresa');
    } else if (userType === 'criador') {
      navigate('/dashboard/criador');
    } else if (userType === 'admin') {
      navigate('/dashboard/admin');
    } else {
      navigate('/');
    }
    
    toast({
      title: 'Login realizado com sucesso',
      description: 'Você foi autenticado com o Google.',
    });
  };
  
  const handleSelectUserType = async (userType: 'criador' | 'empresa') => {
    try {
      setProcessingUserType(true);
      const result = await updateUserAfterOAuth(userType);
      
      if (!result.success) {
        toast({
          title: 'Erro ao configurar perfil',
          description: result.error || 'Ocorreu um erro ao configurar seu perfil. Por favor, tente novamente.',
          variant: 'destructive',
        });
        return;
      }
      
      navigateToDashboard(userType);
    } catch (error: any) {
      console.error('Error updating user after OAuth:', error);
      toast({
        title: 'Erro ao configurar perfil',
        description: error.message || 'Ocorreu um erro ao configurar seu perfil.',
        variant: 'destructive',
      });
    } finally {
      setProcessingUserType(false);
    }
  };
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FBF7E1]/30">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="h-12 w-12 animate-spin text-[#94C700]" />
          <p className="text-lg font-medium">Processando autenticação...</p>
        </div>
      </div>
    );
  }
  
  if (needsUserType) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FBF7E1]/30 p-4">
        <Card className="w-full max-w-md border-gray-200 shadow-lg">
          <CardHeader className="space-y-1 text-center">
            <CardTitle className="text-2xl">Bem-vindo ao Cruig</CardTitle>
            <p className="text-gray-500">Por favor, selecione o tipo de perfil que deseja criar</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Button
                variant="default"
                className="bg-[#94C700] hover:bg-[#75a300] py-8 flex flex-col items-center justify-center"
                onClick={() => handleSelectUserType('criador')}
                disabled={processingUserType}
              >
                {processingUserType ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    <span className="font-medium">Criador</span>
                  </>
                )}
              </Button>
              <Button
                variant="default"
                className="bg-[#94C700] hover:bg-[#75a300] py-8 flex flex-col items-center justify-center"
                onClick={() => handleSelectUserType('empresa')}
                disabled={processingUserType}
              >
                {processingUserType ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                    <span className="font-medium">Empresa</span>
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // This should not be reached under normal circumstances
  return null;
};

export default AuthCallback;
