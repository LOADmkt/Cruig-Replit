
import { useEffect, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import AdminLogin from "@/components/admin/AdminLogin";
import { AdminDashboardLayout } from "@/components/admin/AdminDashboardLayout";
import { Loader2 } from "lucide-react";

const Admin = () => {
  const { user, isLoading: authLoading, isAdmin, isAuthenticated } = useAuth();
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (!authLoading) {
      setLoading(false);
      
      // If user is authenticated but not admin, redirect to appropriate dashboard
      if (isAuthenticated && !isAdmin) {
        toast({
          title: "Acesso negado",
          description: "Você não tem permissão para acessar o painel administrativo.",
          variant: "destructive"
        });
        
        // Redirect to appropriate dashboard
        navigate('/');
      }
    }
  }, [authLoading, isAdmin, isAuthenticated, navigate, toast]);

  const handleLogin = (email: string, password: string) => {
    // For MVP demo, accept hardcoded admin credentials
    if (email === "admin@cruig.com" && password === "admin123") {
      localStorage.setItem("admin_auth", JSON.stringify({
        token: "admin-token-demo",
        expiry: new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString()
      }));
      
      navigate(0); // Refresh page to trigger reauth
      
      toast({
        title: "Login bem-sucedido",
        description: "Bem-vindo ao painel administrativo."
      });
    } else {
      toast({
        title: "Falha na autenticação",
        description: "E-mail ou senha incorretos.",
        variant: "destructive"
      });
    }
  };

  if (loading || authLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-brand-secondary/30">
        <div className="flex flex-col items-center">
          <Loader2 className="h-12 w-12 animate-spin text-brand-primary mb-4" />
          <p className="text-lg font-medium text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  // If user is not authenticated as admin, show login screen
  if (!isAdmin) {
    return <AdminLogin onLogin={handleLogin} />;
  }

  return <AdminDashboardLayout />;
};

export default Admin;
