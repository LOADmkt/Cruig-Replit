
import React from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PaymentCancelled() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-lg bg-white rounded-lg shadow-lg p-8 text-center">
        <div className="w-20 h-20 rounded-full bg-amber-100 flex items-center justify-center mx-auto mb-6">
          <AlertCircle className="h-12 w-12 text-amber-500" />
        </div>
        
        <h1 className="text-2xl font-bold text-amber-600 mb-2">
          Pagamento cancelado
        </h1>
        
        <p className="text-gray-600 mb-8">
          Seu pagamento foi cancelado. Nenhum valor foi cobrado.
          Você pode tentar novamente ou entrar em contato com o suporte se precisar de ajuda.
        </p>
        
        <div className="space-y-3">
          <Button asChild>
            <Link to="/dashboard?tab=subscription">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Voltar para os planos
            </Link>
          </Button>
          
          <Button asChild variant="outline" className="w-full">
            <Link to="/dashboard">
              Ir para o Dashboard
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
