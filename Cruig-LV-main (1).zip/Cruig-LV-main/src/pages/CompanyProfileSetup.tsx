
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { ArrowRight, Check, Loader2 } from 'lucide-react';

export default function CompanyProfileSetup() {
  const navigate = useNavigate();
  const { user, isLoading: authLoading, isCompany } = useAuth();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    name: user?.user_metadata?.name || '',
    description: '',
    industry: '',
    website: '',
    phone: '',
    address: '',
    logo: null as File | null
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [step, setStep] = useState(1);
  const totalSteps = 2;
  
  // Check if user is authorized to access this page
  useEffect(() => {
    if (!authLoading && !isCompany) {
      navigate('/auth');
    }
  }, [authLoading, isCompany, navigate]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData(prev => ({
      ...prev,
      logo: file
    }));
  };
  
  const nextStep = () => {
    setStep(prev => Math.min(prev + 1, totalSteps));
  };
  
  const prevStep = () => {
    setStep(prev => Math.max(prev - 1, 1));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Here you would normally save the profile data to your database
      // For now, we'll just simulate a successful update
      setTimeout(() => {
        toast({
          title: "Perfil configurado com sucesso!",
          description: "Sua empresa está pronta para usar a plataforma."
        });
        navigate('/empresa-dashboard');
      }, 1500);
    } catch (error: any) {
      console.error("Error setting up profile:", error);
      toast({
        title: "Erro ao configurar perfil",
        description: error.message || "Ocorreu um erro ao salvar os dados da empresa.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (authLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-brand-primary" />
      </div>
    );
  }
  
  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome da Empresa</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Insira o nome da sua empresa"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="industry">Setor de Atuação</Label>
              <Input
                id="industry"
                name="industry"
                value={formData.industry}
                onChange={handleChange}
                placeholder="Ex: Tecnologia, Moda, Alimentos..."
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Faça uma breve descrição sobre sua empresa"
                rows={4}
                required
              />
            </div>
            
            <div className="flex justify-end">
              <Button onClick={nextStep} className="bg-brand-primary">
                Próximo <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        );
        
      case 2:
        return (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="website">Website</Label>
              <Input
                id="website"
                name="website"
                value={formData.website}
                onChange={handleChange}
                placeholder="https://www.seusite.com"
                type="url"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="(00) 00000-0000"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="address">Endereço</Label>
              <Input
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="Rua, número, cidade, estado"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="logo">Logo da Empresa</Label>
              <Input
                id="logo"
                name="logo"
                type="file"
                onChange={handleFileChange}
                accept="image/*"
                className="cursor-pointer"
              />
              <p className="text-xs text-gray-500">Formatos aceitos: JPG, PNG. Tamanho máximo: 2MB.</p>
            </div>
            
            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={prevStep}>
                Voltar
              </Button>
              
              <Button 
                type="submit" 
                className="bg-brand-primary" 
                disabled={isSubmitting}
                onClick={handleSubmit}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processando...
                  </>
                ) : (
                  <>
                    Concluir <Check className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div className="min-h-screen bg-brand-secondary/30 flex items-center justify-center p-4">
      <Card className="w-full max-w-xl">
        <CardHeader>
          <CardTitle className="text-2xl">Configure o perfil da sua empresa</CardTitle>
          <CardDescription>
            Preencha as informações sobre sua empresa para começar a usar a plataforma.
          </CardDescription>
          
          <div className="mt-4">
            <div className="flex items-center justify-between">
              {Array.from({ length: totalSteps }, (_, i) => (
                <div key={i} className="flex items-center">
                  <div
                    className={`rounded-full h-8 w-8 flex items-center justify-center ${
                      step > i + 1
                        ? 'bg-green-500 text-white'
                        : step === i + 1
                        ? 'bg-brand-primary text-white'
                        : 'bg-gray-200 text-gray-500'
                    }`}
                  >
                    {step > i + 1 ? <Check className="h-4 w-4" /> : i + 1}
                  </div>
                  {i < totalSteps - 1 && (
                    <div
                      className={`h-1 w-16 ${
                        step > i + 1 ? 'bg-green-500' : 'bg-gray-200'
                      }`}
                    ></div>
                  )}
                </div>
              ))}
            </div>
            <div className="flex justify-between mt-2">
              <span className="text-xs">Informações Básicas</span>
              <span className="text-xs">Detalhes de Contato</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={handleSubmit}>
            {renderStep()}
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
