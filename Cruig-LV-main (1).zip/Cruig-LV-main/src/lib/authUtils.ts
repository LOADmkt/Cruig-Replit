
/**
 * Check if we're in development mode
 */
export const isDevelopment = import.meta.env.MODE === 'development';

/**
 * Store the JWT in a cookie
 */
export const storeAuthCookie = (token: string, expiresIn: number): void => {
  try {
    const secure = window.location.protocol === 'https:';
    
    // Store in a cookie
    document.cookie = `auth-token=${token}; path=/; max-age=${expiresIn}; SameSite=Strict; ${secure ? 'Secure;' : ''}`;
    
    // Also save a flag indicating authentication status (not the token itself)
    localStorage.setItem('auth-status', 'authenticated');
    
    console.log('Auth cookie stored successfully');
  } catch (error) {
    console.error('Error storing auth cookie:', error);
  }
};

/**
 * Clear the auth cookie
 */
export const clearAuthCookie = (): void => {
  try {
    document.cookie = 'auth-token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT; SameSite=Strict;';
    localStorage.removeItem('auth-status');
    
    // Clear any cached user data
    localStorage.removeItem('userData');
    
    console.log('Auth cookie cleared successfully');
  } catch (error) {
    console.error('Error clearing auth cookie:', error);
  }
};

/**
 * Set user type state based on metadata
 */
export const getUserTypes = (userType?: string) => {
  const isAdmin = userType === 'admin';
  const isCreator = userType === 'criador';
  const isCompany = userType === 'empresa';
  
  return { isAdmin, isCreator, isCompany };
};

/**
 * Get auth token from cookies
 */
export const getAuthToken = (): string | null => {
  try {
    const cookies = document.cookie.split(';');
    for (const cookie of cookies) {
      const [name, value] = cookie.trim().split('=');
      if (name === 'auth-token') {
        return value;
      }
    }
    return null;
  } catch (error) {
    console.error('Error getting auth token:', error);
    return null;
  }
};

/**
 * Create auth headers for API requests
 */
export const createAuthHeaders = (): Headers => {
  const headers = new Headers();
  headers.append('Content-Type', 'application/json');
  
  const token = getAuthToken();
  if (token) {
    headers.append('Authorization', `Bearer ${token}`);
  }
  
  return headers;
};

/**
 * Check if token is expired
 */
export const isTokenExpired = (token: string): boolean => {
  try {
    const base64Url = token.split('.')[1];
    if (!base64Url) {
      console.error('Invalid token format: no payload part found');
      return true;
    }
    
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => `%${(`00${c.charCodeAt(0).toString(16)}`).slice(-2)}`)
        .join('')
    );

    const { exp } = JSON.parse(jsonPayload);
    if (!exp) {
      console.error('No expiration found in token');
      return true;
    }
    
    const expired = exp * 1000 < Date.now();
    if (expired) {
      console.log('Token is expired');
    }
    
    return expired;
  } catch (error) {
    console.error('Error checking token expiration:', error);
    return true; // Assume expired if we can't parse it
  }
};

/**
 * Parse JWT token and extract user info
 */
export const parseJwtToken = (token: string) => {
  try {
    const base64Url = token.split('.')[1];
    if (!base64Url) {
      console.error('Invalid token format: no payload part found');
      return null;
    }
    
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => `%${(`00${c.charCodeAt(0).toString(16)}`).slice(-2)}`)
        .join('')
    );

    return JSON.parse(jsonPayload);
  } catch (error) {
    console.error('Error parsing JWT token:', error);
    return null;
  }
};

/**
 * Clear all user data from localStorage
 */
export const clearUserData = () => {
  try {
    const keysToRemove = [
      'userData',
      'userProfile',
      'userPreferences',
      'lastActivity',
      'notifications',
      'recentSearches',
      'favorites'
    ];
    
    keysToRemove.forEach(key => localStorage.removeItem(key));
    
    // Also clear session storage items that might contain user data
    sessionStorage.clear();
    
    console.log('User data cleared successfully');
  } catch (error) {
    console.error('Error clearing user data:', error);
  }
};
