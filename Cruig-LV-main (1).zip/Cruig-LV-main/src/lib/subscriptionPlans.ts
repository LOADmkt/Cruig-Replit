
export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  priceRaw?: number;
  period?: string;
  billingCycle?: 'monthly' | 'yearly';
  totalPrice?: number;
  monthlyPrice?: number;
  popular?: boolean;
  color?: string;
  features: string[];
  buttonText: string;
  description: string;
}

// Format price function for displaying prices consistently
export function formatPrice(price: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  }).format(price);
}

/**
 * Get plans for creators
 */
export function getCreatorPlans(): SubscriptionPlan[] {
  return [
    {
      id: 'mensal',
      name: 'Mensal',
      price: 147,
      period: 'por mês',
      billingCycle: 'monthly',
      popular: false,
      color: 'blue',
      features: [
        'Acesso a todos os criadores',
        'Mensagens ilimitadas',
        'Perfil premium destacado',
        'Filtros avançados de busca',
        'Suporte prioritário'
      ],
      buttonText: 'Começar agora',
      description: 'Ideal para testar a plataforma sem compromisso de longo prazo.'
    },
    {
      id: 'semestral',
      name: 'Semestral',
      price: 127,
      period: 'por mês',
      billingCycle: 'monthly',
      monthlyPrice: 127,
      totalPrice: 762,
      popular: true,
      color: 'green',
      features: [
        'Todos os recursos do plano Mensal',
        'Economia de 15% sobre o valor mensal',
        'Analytics avançados',
        'Exportação de dados',
        'Webinars exclusivos'
      ],
      buttonText: 'Melhor custo-benefício',
      description: 'Nossa opção mais popular com o melhor custo-benefício.'
    },
    {
      id: 'anual',
      name: 'Anual',
      price: 997,
      period: 'por ano',
      billingCycle: 'yearly',
      monthlyPrice: 83,
      totalPrice: 997,
      popular: false,
      color: 'purple',
      features: [
        'Todos os recursos do plano Semestral',
        'Maior economia (>40% sobre o mensal)',
        'Suporte VIP prioritário',
        'Consultoria personalizada',
        'Acesso antecipado a novos recursos'
      ],
      buttonText: 'Economize mais',
      description: 'Máxima economia para quem quer compromisso a longo prazo.'
    }
  ];
}

/**
 * Get plans for companies
 */
export function getCompanyPlans(): SubscriptionPlan[] {
  return [
    {
      id: 'mensal',
      name: 'Mensal',
      price: 197,
      period: 'por mês',
      billingCycle: 'monthly',
      popular: false,
      color: 'blue',
      features: [
        'Acesso a todos os criadores',
        'Até 20 mensagens por mês',
        'Até 3 campanhas publicadas',
        'Filtros básicos de busca',
        'Suporte por email'
      ],
      buttonText: 'Começar agora',
      description: 'Ideal para pequenas empresas e testes iniciais.'
    },
    {
      id: 'semestral',
      name: 'Semestral',
      price: 170,
      period: 'por mês',
      billingCycle: 'monthly',
      monthlyPrice: 170,
      totalPrice: 1020,
      popular: true,
      color: 'green',
      features: [
        'Mensagens ilimitadas',
        'Campanhas ilimitadas',
        'Filtros avançados de busca',
        'Analytics de campanhas',
        'Suporte prioritário'
      ],
      buttonText: 'Melhor custo-benefício',
      description: 'Nossa opção mais popular para empresas em crescimento.'
    },
    {
      id: 'anual',
      name: 'Anual',
      price: 1524,
      period: 'por ano',
      billingCycle: 'yearly',
      monthlyPrice: 127,
      totalPrice: 1524,
      popular: false,
      color: 'purple',
      features: [
        'Todos os recursos do plano Semestral',
        'Maior economia (>35% sobre o mensal)',
        'Suporte dedicado',
        'Consultoria de campanhas',
        'Acesso prioritário a criadores premium'
      ],
      buttonText: 'Economize mais',
      description: 'Economia máxima para empresas com estratégia contínua.'
    }
  ];
}

// Function to get a specific plan by ID
export function getPlanById(planId: string, userType: 'creator' | 'company'): SubscriptionPlan | undefined {
  const plans = userType === 'creator' ? getCreatorPlans() : getCompanyPlans();
  return plans.find(plan => plan.id === planId);
}

// Function to get annual price (20% discount)
export function getAnnualPrice(monthlyPrice: number): number {
  const annualDiscount = 0.20; // 20% discount
  return Math.round(monthlyPrice * 12 * (1 - annualDiscount));
}

// Function to get plans with annual pricing
export function getPlansWithAnnualPricing(userType: 'creator' | 'company'): SubscriptionPlan[] {
  const monthlyPlans = userType === 'creator' ? getCreatorPlans() : getCompanyPlans();
  
  return monthlyPlans.map(plan => ({
    ...plan,
    id: `${plan.id}_annual`,
    billingCycle: 'yearly',
    period: 'anual',
    totalPrice: getAnnualPrice(plan.price),
    monthlyPrice: Math.round((getAnnualPrice(plan.price) / 12) * 100) / 100,
    price: getAnnualPrice(plan.price),
    priceRaw: plan.price,
    description: `${plan.description} (Faturamento anual)`
  }));
}

// Function to get all plans (monthly and annual)
export function getAllPlans(userType: 'creator' | 'company'): SubscriptionPlan[] {
  const monthlyPlans = userType === 'creator' ? getCreatorPlans() : getCompanyPlans();
  const annualPlans = getPlansWithAnnualPricing(userType);
  
  return [...monthlyPlans, ...annualPlans];
}
