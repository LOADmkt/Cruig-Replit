
import { supabase } from './supabaseClient';

export interface Referral {
  id: string;
  name: string;
  email: string;
  status: 'active' | 'inactive';
  date: string;
  amount: number;
}

export interface AffiliateStats {
  balance: number;
  totalEarned: number;
  pendingWithdrawal: number;
  referralsCount: number;
}

export async function getAffiliateLink() {
  try {
    const { data: user } = await supabase.auth.getUser();
    if (!user || !user.user) {
      throw new Error('User not authenticated');
    }
    
    // Check if user already has an affiliate link
    const { data: existingLinks, error: fetchError } = await supabase
      .from('affiliate_links')
      .select('*')
      .eq('creator_id', user.user.id)
      .limit(1);
    
    if (fetchError) throw fetchError;
    
    if (existingLinks && existingLinks.length > 0) {
      return { 
        success: true, 
        code: existingLinks[0].code,
        link: `${window.location.origin}/inscricao?ref=${existingLinks[0].code}` 
      };
    }
    
    // Generate a new code if none exists
    const code = generateAffiliateCode(user.user.id);
    
    const { error: insertError } = await supabase
      .from('affiliate_links')
      .insert({
        creator_id: user.user.id,
        code: code
      });
    
    if (insertError) throw insertError;
    
    return { 
      success: true, 
      code: code,
      link: `${window.location.origin}/inscricao?ref=${code}` 
    };
  } catch (error) {
    console.error('Error with affiliate link:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
}

// Generate a unique affiliate code based on user ID
function generateAffiliateCode(userId: string): string {
  const baseString = userId.replace(/-/g, '').substring(0, 8);
  const timestamp = new Date().getTime().toString(36).substring(0, 4);
  return `${baseString}${timestamp}`;
}

// For demo purposes, we'll use cached data until we implement the actual Supabase functions
export async function getAffiliateStats(): Promise<AffiliateStats> {
  try {
    // In a real implementation, this would fetch from Supabase
    // For now, we'll use mock data
    return {
      balance: 75,
      totalEarned: 175,
      pendingWithdrawal: 0,
      referralsCount: 7
    };
  } catch (error) {
    console.error('Error fetching affiliate stats:', error);
    return {
      balance: 0,
      totalEarned: 0,
      pendingWithdrawal: 0,
      referralsCount: 0
    };
  }
}

export async function requestWithdrawal(amount: number) {
  try {
    const { data: user } = await supabase.auth.getUser();
    if (!user || !user.user) {
      throw new Error('User not authenticated');
    }
    
    if (amount < 100) {
      throw new Error('Minimum withdrawal amount is R$ 100,00');
    }
    
    const { error } = await supabase
      .from('withdrawal_requests')
      .insert({
        creator_id: user.user.id,
        amount: amount
      });
    
    if (error) throw error;
    
    return { success: true };
  } catch (error) {
    console.error('Error requesting withdrawal:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
}
