
import { cn } from "@/lib/utils";

// Button animation classes
export const buttonAnimation = "transition-all duration-200 transform hover:scale-102 active:scale-98";

// Hover effects
export const hoverEffects = {
  subtle: "hover:brightness-105",
  glow: "hover:shadow-md hover:shadow-primary/20",
  lift: "hover:-translate-y-1",
  grow: "hover:scale-105"
};

// Loading animations
export const loadingAnimation = "animate-pulse";

// Card animations
export const cardAnimation = "transition-all duration-300 hover:shadow-lg";

// Combine animations
export function combineAnimations(...animations: string[]): string {
  return cn(...animations);
}
