
export type LoginData = {
  email: string;
  password: string;
};

export type RegistrationData = {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  userType?: 'criador' | 'empresa' | 'admin';
};

export const validateLoginData = (data: LoginData) => {
  const errors: Record<string, string> = {};

  // Validar email
  if (!data.email) {
    errors.email = "E-mail é obrigatório";
  } else if (!/\S+@\S+\.\S+/.test(data.email)) {
    errors.email = "E-mail inválido";
  }

  // Validar senha
  if (!data.password) {
    errors.password = "Senha é obrigatória";
  } else if (data.password.length < 6) {
    errors.password = "Senha deve ter pelo menos 6 caracteres";
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export const validateRegistrationData = (data: RegistrationData) => {
  const errors: Record<string, string> = {};

  // Validar nome
  if (!data.name) {
    errors.name = "Nome é obrigatório";
  } else if (data.name.length < 3) {
    errors.name = "Nome deve ter pelo menos 3 caracteres";
  }

  // Validar email
  if (!data.email) {
    errors.email = "E-mail é obrigatório";
  } else if (!/\S+@\S+\.\S+/.test(data.email)) {
    errors.email = "E-mail inválido";
  }

  // Validar senha
  if (!data.password) {
    errors.password = "Senha é obrigatória";
  } else if (data.password.length < 6) {
    errors.password = "Senha deve ter pelo menos 6 caracteres";
  } else if (!/[A-Z]/.test(data.password)) {
    errors.password = "Senha deve ter pelo menos uma letra maiúscula";
  } else if (!/\d/.test(data.password)) {
    errors.password = "Senha deve ter pelo menos um número";
  }

  // Validar confirmação de senha
  if (!data.confirmPassword) {
    errors.confirmPassword = "Confirmação de senha é obrigatória";
  } else if (data.password !== data.confirmPassword) {
    errors.confirmPassword = "As senhas não coincidem";
  }

  // Validar tipo de usuário
  if (!data.userType) {
    errors.userType = "Selecione o tipo de conta";
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export const getPasswordStrength = (password: string): number => {
  if (!password) return 0;
  
  let strength = 0;
  
  // Comprimento
  if (password.length >= 8) strength += 1;
  if (password.length >= 12) strength += 1;
  
  // Números
  if (/\d/.test(password)) strength += 1;
  
  // Letras maiúsculas e minúsculas
  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength += 1;
  
  // Caracteres especiais
  if (/[^a-zA-Z0-9]/.test(password)) strength += 1;
  
  return Math.min(strength, 4);
};

// Adding missing functions needed by other components
export const isValidEmail = (email: string): boolean => {
  return /\S+@\S+\.\S+/.test(email);
};

export const isValidPassword = (password: string): boolean => {
  return password.length >= 6;
};

export const passwordsMatch = (password: string, confirmPassword: string): boolean => {
  return password === confirmPassword;
};
