
import { FilterConfig, FilterOption } from '@/types/filters';
import { MultiSelectOption } from '@/components/multi-select/types';

// Function to convert a filter config object to an array of FilterConfig
export function convertFilterConfigToArray(config: Record<string, FilterConfig>): FilterConfig[] {
  return Object.keys(config).map(key => ({
    field: key,
    ...config[key]
  }));
}

// Function to convert string options to FilterOption objects if needed
export function normalizeFilterOptions(options: string[] | FilterOption[] | undefined): FilterOption[] {
  if (!options || options.length === 0) return [];
  
  if (typeof options[0] === 'string') {
    return (options as string[]).map(opt => ({
      value: opt,
      label: opt
    }));
  }
  
  return options as FilterOption[];
}

// Convert FilterOption[] to MultiSelectOption[] for use with the MultiSelect component
export function getMultiSelectOptions(options: FilterOption[] | string[] | undefined): MultiSelectOption[] {
  if (!options) return [];
  
  // Handle string arrays
  if (options.length > 0 && typeof options[0] === 'string') {
    return (options as string[]).map(option => ({
      value: option,
      label: option
    }));
  }
  
  // Handle FilterOption arrays
  return (options as FilterOption[]).map(option => ({
    value: option.value,
    label: option.label
  }));
}
