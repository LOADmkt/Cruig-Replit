
import { useState, useEffect, useCallback } from 'react';

// Adicionar campos ao SubscriptionData
export interface SubscriptionData {
  active: boolean;
  plan: string | null; // identificador do plano
  planName: string | null; // nome do plano para exibição
  expiresAt: string | null; // data de expiração ISO string
}

interface SubscriptionResponse {
  success: boolean;
  error?: string;
}

export function useSubscription() {
  const [subscription, setSubscription] = useState<SubscriptionData>({
    active: false,
    plan: null,
    planName: null,
    expiresAt: null
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const refreshSubscription = useCallback(() => {
    setIsLoading(true);
    setError(null);
    try {
      const userData = localStorage.getItem('userData');
      if (userData) {
        const parsedUserData = JSON.parse(userData);
        const subscriptionData: SubscriptionData = {
          active: parsedUserData.subscription?.active || false,
          plan: parsedUserData.subscription?.plan || null,
          planName: parsedUserData.subscription?.planName || null,
          expiresAt: parsedUserData.subscription?.expiresAt || null
        };
        setSubscription(subscriptionData);
      } else {
        setSubscription({ active: false, plan: null, planName: null, expiresAt: null });
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Error fetching subscription'));
      setSubscription({ active: false, plan: null, planName: null, expiresAt: null });
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshSubscription();
  }, [refreshSubscription]);

  const subscribeToPlan = async (planId: string): Promise<SubscriptionResponse> => {
    setIsLoading(true);
    setError(null);
    try {
      // Simulação de chamada à API para iniciar a assinatura
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Simulação de sucesso: atualiza os dados do usuário no localStorage
      const userData = JSON.parse(localStorage.getItem('userData') || '{}');
      userData.subscription = {
        active: true,
        plan: planId,
        startDate: new Date().toISOString(),
        endDate: new Date(new Date().setDate(new Date().getDate() + 30)).toISOString()
      };
      localStorage.setItem('userData', JSON.stringify(userData));
      refreshSubscription();
      return { success: true };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error subscribing to plan';
      setError(err instanceof Error ? err : new Error(errorMessage));
      return { success: false, error: errorMessage };
    } finally {
      setIsLoading(false);
    }
  };

  const cancelSubscription = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // Simulação de chamada à API para cancelar a assinatura
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Simulação de sucesso: atualiza os dados do usuário no localStorage
      const userData = JSON.parse(localStorage.getItem('userData') || '{}');
      userData.subscription = {
        active: false,
        canceledAt: new Date().toISOString()
      };
      localStorage.setItem('userData', JSON.stringify(userData));
      refreshSubscription();
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Error canceling subscription'));
    } finally {
      setIsLoading(false);
    }
  };

  // Adicionar os campos necessários que estavam faltando
  const usageCount = {
    messages: 5, // exemplo: usuário enviou 5 mensagens
    campaigns: 2, // exemplo: usuário criou 2 campanhas
    maxFreeMessages: 10, // limite para contas gratuitas
    maxFreeCampaigns: 3  // limite para contas gratuitas
  };

  const hasReachedMessageLimit = usageCount.messages >= usageCount.maxFreeMessages;
  const hasReachedCampaignLimit = usageCount.campaigns >= usageCount.maxFreeCampaigns;

  // Retornar o objeto com os novos campos
  return {
    subscription,
    isLoading,
    error,
    subscribeToPlan,
    cancelSubscription,
    refreshSubscription,
    usageCount,
    hasReachedMessageLimit,
    hasReachedCampaignLimit
  };
}
