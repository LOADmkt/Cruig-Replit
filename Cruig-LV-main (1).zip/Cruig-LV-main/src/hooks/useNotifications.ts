
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabaseClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  type: "message" | "campaign" | "system";
  read: boolean;
  related_id: string | null;
  created_at: string;
}

export function useNotifications() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { isAuthenticated, user } = useAuth();

  const { data: notifications = [], isLoading, isError, error } = useQuery({
    queryKey: ["notifications", user?.id],
    queryFn: async () => {
      try {
        if (!isAuthenticated || !user) {
          console.log("User not authenticated, returning empty notifications array");
          return [];
        }

        const { data, error } = await supabase
          .from("notifications")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false });

        if (error) {
          console.error("Error fetching notifications:", error);
          throw error;
        }

        return Array.isArray(data) ? data : [];
      } catch (error) {
        console.error("Error in notifications query:", error);
        // Return empty array instead of throwing error to prevent breaking the UI
        return [];
      }
    },
    enabled: isAuthenticated && !!user,
    staleTime: 1000 * 60, // 1 minuto
  });

  const { mutate: markAsRead } = useMutation({
    mutationFn: async (notificationId: string) => {
      if (!isAuthenticated || !user) {
        throw new Error("Usuário não autenticado");
      }

      const { error } = await supabase
        .from("notifications")
        .update({ read: true })
        .eq("id", notificationId)
        .eq("user_id", user.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notifications", user?.id] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: "Não foi possível marcar a notificação como lida: " + error.message,
        variant: "destructive",
      });
    }
  });

  // Ensure notifications is always an array, even if the query returns undefined
  const safeNotifications = Array.isArray(notifications) ? notifications : [];
  
  // Calcular o número de notificações não lidas
  const unreadCount = safeNotifications.filter(n => !n.read).length;

  return {
    notifications: safeNotifications,
    isLoading,
    isError,
    error,
    markAsRead,
    unreadCount
  };
}
