
import { useState } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabaseClient';
import { getUserTypes } from '@/lib/authUtils';

export function useSessionManagement() {
  const [isLoading, setIsLoading] = useState(false);

  // Função para atualizar o token de sessão
  const refreshSession = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase.auth.refreshSession();
      
      if (error) {
        console.error('Erro ao atualizar sessão:', error);
        throw error;
      }
      
      if (data.session) {
        return { success: true, session: data.session };
      } else {
        return { success: false, error: 'Não foi possível atualizar a sessão' };
      }
    } catch (error) {
      console.error('Erro ao atualizar sessão:', error);
      return { success: false, error };
    } finally {
      setIsLoading(false);
    }
  };
  
  // Função para atualizar dados do usuário
  const updateUserData = async (userData: Partial<User['user_metadata']>) => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase.auth.updateUser({
        data: userData,
      });
      
      if (error) {
        return { success: false, error };
      }

      return { success: true, user: data.user };
    } catch (error: any) {
      console.error("Erro ao atualizar dados do usuário:", error);
      return { success: false, error };
    } finally {
      setIsLoading(false);
    }
  };

  return {
    refreshSession,
    updateUserData,
    isLoading
  };
}
