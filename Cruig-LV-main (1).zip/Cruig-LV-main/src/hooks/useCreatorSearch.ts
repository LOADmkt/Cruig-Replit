
import { useState, useEffect, useCallback } from 'react';
import { getCreators, type Creator, type CreatorFilterOptions } from '@/services/creatorService';

export type { Creator };

export function useCreatorSearch(
  searchTerm: string,
  filters: Record<string, any>,
  orderBy: string = 'relevance'
) {
  const [creators, setCreators] = useState<Creator[]>([]);
  const [total, setTotal] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  
  // Wrap setCurrentPage with useCallback to avoid re-renders
  const handleSetCurrentPage = useCallback((page: number) => {
    setCurrentPage(page);
  }, []);
  
  // Fetch creators when search term, filters, order, or page changes
  useEffect(() => {
    const fetchCreators = async () => {
      try {
        setIsLoading(true);
        
        const result = await getCreators({
          search: searchTerm,
          filters: filters as CreatorFilterOptions,
          orderBy,
          page: currentPage,
          limit: 9
        });
        
        setCreators(result.creators);
        setTotal(result.total);
        setError(null);
      } catch (err) {
        console.error('Error fetching creators:', err);
        setError(err instanceof Error ? err : new Error('Error fetching creators'));
        // Keep previous results in case of error
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchCreators();
  }, [searchTerm, filters, orderBy, currentPage]);
  
  return {
    creators,
    total,
    isLoading,
    error,
    currentPage,
    setCurrentPage: handleSetCurrentPage
  };
}
