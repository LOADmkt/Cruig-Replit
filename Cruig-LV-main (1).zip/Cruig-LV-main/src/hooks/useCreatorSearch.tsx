
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';

export interface SocialNetwork {
  type: string;
  username?: string;
  followers?: string;
  engagement?: string;
  connected?: boolean;
}

export interface Creator {
  id: string | number;
  name: string;
  profileImage?: string;
  bio?: string;
  niches?: string[];
  location?: string;
  verified?: boolean;
  socialNetworks?: SocialNetwork[];
  rating?: number;
  campaignCount?: number;
  completedCampaigns?: number;
  engagement?: string;
  totalFollowers?: string;
  frequentCollaborations?: string[];
}

export interface FilterOptions {
  niches?: string[];
  locations?: string[];
  minFollowers?: number;
  maxFollowers?: number;
  platforms?: string[];
  verification?: boolean;
  gender?: string;
  ageRange?: [number, number];
  languages?: string[];
  engagementRate?: [number, number];
  priceTier?: string;
  availableFor?: string[];
}

const TEST_CREATORS: Creator[] = [
  {
    id: '1',
    name: 'Ana Silva',
    profileImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&h=300&fit=crop',
    niches: ['Moda', 'Beleza'],
    verified: true,
    socialNetworks: [
      { type: 'instagram', followers: '120K', engagement: '3.2%' },
      { type: 'tiktok', followers: '250K', engagement: '5.7%' }
    ],
    location: 'São Paulo, SP',
    bio: 'Criadora de conteúdo sobre moda e lifestyle há 5 anos.'
  },
  {
    id: '2',
    name: 'Carlos Mendes',
    profileImage: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&h=300&fit=crop',
    niches: ['Tecnologia', 'Games'],
    verified: true,
    socialNetworks: [
      { type: 'youtube', followers: '750K', engagement: '4.1%' },
      { type: 'instagram', followers: '85K', engagement: '2.8%' }
    ],
    location: 'Rio de Janeiro, RJ',
    bio: 'Revisor de tecnologia e gamer profissional.'
  },
  {
    id: '3',
    name: 'Juliana Costa',
    profileImage: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=300&h=300&fit=crop',
    niches: ['Fitness', 'Saúde'],
    verified: false,
    socialNetworks: [
      { type: 'instagram', followers: '98K', engagement: '6.5%' },
      { type: 'youtube', followers: '45K', engagement: '4.7%' }
    ],
    location: 'Belo Horizonte, MG',
    bio: 'Personal trainer e nutricionista compartilhando dicas de bem-estar.'
  },
  {
    id: '4',
    name: 'Rafael Almeida',
    profileImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop',
    niches: ['Finanças', 'Educação'],
    verified: true,
    socialNetworks: [
      { type: 'youtube', followers: '320K', engagement: '3.9%' },
      { type: 'instagram', followers: '65K', engagement: '2.1%' }
    ],
    location: 'Brasília, DF',
    bio: 'Especialista em educação financeira para jovens adultos.'
  },
  {
    id: '5',
    name: 'Marina Rocha',
    profileImage: 'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=300&h=300&fit=crop',
    niches: ['Viagens', 'Gastronomia'],
    verified: false,
    socialNetworks: [
      { type: 'instagram', followers: '187K', engagement: '5.3%' },
      { type: 'twitter', followers: '56K', engagement: '4.0%' }
    ],
    location: 'Florianópolis, SC',
    bio: 'Viajante em tempo integral compartilhando experiências pelo mundo.'
  },
  {
    id: '6',
    name: 'Pedro Henrique',
    profileImage: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&h=300&fit=crop',
    niches: ['Humor', 'Entretenimento'],
    verified: true,
    socialNetworks: [
      { type: 'tiktok', followers: '1.2M', engagement: '12.7%' },
      { type: 'instagram', followers: '450K', engagement: '8.4%' }
    ],
    location: 'Salvador, BA',
    bio: 'Comediante e criador de conteúdo de entretenimento.'
  },
  {
    id: '7',
    name: 'Camila Santos',
    profileImage: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&h=300&fit=crop',
    niches: ['Maternidade', 'Lifestyle'],
    verified: false,
    socialNetworks: [
      { type: 'instagram', followers: '76K', engagement: '7.8%' },
      { type: 'youtube', followers: '32K', engagement: '6.1%' }
    ],
    location: 'Curitiba, PR',
    bio: 'Mãe de dois compartilhando o dia a dia da maternidade real.'
  },
  {
    id: '8',
    name: 'Gabriel Torres',
    profileImage: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&h=300&fit=crop',
    niches: ['Música', 'Arte'],
    verified: true,
    socialNetworks: [
      { type: 'instagram', followers: '210K', engagement: '4.5%' },
      { type: 'tiktok', followers: '650K', engagement: '9.2%' }
    ],
    location: 'Recife, PE',
    bio: 'Músico e produtor cultural independente.'
  }
];

export function useCreatorSearch(
  searchTerm: string = '',
  filters: FilterOptions = {},
  orderBy: string = 'relevancia',
  itemsPerPage: number = 12
) {
  const [creators, setCreators] = useState<Creator[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [isError, setIsError] = useState<boolean>(false);

  // Função para carregar criadores - aqui estamos usando dados de teste
  // Em produção, seria uma chamada para o Supabase
  const loadCreators = async () => {
    try {
      setIsLoading(true);
      setIsError(false);

      // Em uma implementação real, isso seria uma chamada para o Supabase
      // const { data, error, count } = await supabase
      //   .from('creators')
      //   .select('*', { count: 'exact' })
      //   .ilike('name', `%${searchTerm}%`)
      //   .range((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage - 1)
      
      // Simular tempo de carregamento
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Filtrar por termo de busca (nome, nicho, localização)
      let filteredCreators = [...TEST_CREATORS];
      
      if (searchTerm) {
        filteredCreators = filteredCreators.filter(creator => 
          creator.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          creator.niches?.some(niche => niche.toLowerCase().includes(searchTerm.toLowerCase())) ||
          creator.location?.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }
      
      // Aplicar filtros
      if (filters.niches && filters.niches.length > 0) {
        filteredCreators = filteredCreators.filter(creator => 
          creator.niches?.some(niche => filters.niches?.includes(niche))
        );
      }
      
      if (filters.locations && filters.locations.length > 0) {
        filteredCreators = filteredCreators.filter(creator =>
          filters.locations?.includes(creator.location || '')
        );
      }
      
      if (filters.platforms && filters.platforms.length > 0) {
        filteredCreators = filteredCreators.filter(creator =>
          creator.socialNetworks?.some(network => 
            filters.platforms?.includes(network.type)
          )
        );
      }
      
      if (filters.verification !== undefined) {
        filteredCreators = filteredCreators.filter(creator => 
          creator.verified === filters.verification
        );
      }
      
      // Ordenar
      switch (orderBy) {
        case 'seguidores':
          filteredCreators.sort((a, b) => {
            const aTotal = Number(a.socialNetworks?.[0]?.followers?.replace(/[^0-9]/g, '') || 0);
            const bTotal = Number(b.socialNetworks?.[0]?.followers?.replace(/[^0-9]/g, '') || 0);
            return bTotal - aTotal;
          });
          break;
        case 'engajamento':
          filteredCreators.sort((a, b) => {
            const aRate = Number(a.socialNetworks?.[0]?.engagement?.replace(/[^0-9.]/g, '') || 0);
            const bRate = Number(b.socialNetworks?.[0]?.engagement?.replace(/[^0-9.]/g, '') || 0);
            return bRate - aRate;
          });
          break;
        case 'recentes':
          // Simular ordenação por data - em uma implementação real, seria por data de criação
          filteredCreators.reverse();
          break;
        // case 'relevancia' é o padrão, não precisa ordenar
      }
      
      setTotal(filteredCreators.length);
      
      // Simular paginação
      const start = (currentPage - 1) * itemsPerPage;
      const end = start + itemsPerPage;
      const paginatedCreators = filteredCreators.slice(start, end);
      
      setCreators(paginatedCreators);
    } catch (error) {
      console.error('Erro ao buscar criadores:', error);
      setIsError(true);
      setCreators([]);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCreators();
  }, [searchTerm, currentPage, orderBy, JSON.stringify(filters)]);

  return {
    creators,
    total,
    isLoading,
    isError,
    currentPage,
    setCurrentPage,
    refresh: loadCreators
  };
}
