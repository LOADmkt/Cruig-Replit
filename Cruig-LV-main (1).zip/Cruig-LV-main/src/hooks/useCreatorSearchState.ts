
import { useState } from 'react';
import { type CreatorFilterOptions } from '@/services/creatorService';

export function useCreatorSearchState() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [orderBy, setOrderBy] = useState('relevancia');
  const [isFiltering, setIsFiltering] = useState(false);
  const [activeFilters, setActiveFilters] = useState<CreatorFilterOptions>({
    nicho: [],
    seguidores: '',
    localizacao: [],
    redeSocial: [],
    verificado: false,
    superCreator: false,
    faixaEtaria: [],
    generoPrincipal: [],
    engajamentoMinimo: 0,
    tipoConteudo: [],
    faixaPreco: ''
  });

  const safeActiveFilters: CreatorFilterOptions = {
    nicho: Array.isArray(activeFilters.nicho) ? activeFilters.nicho : [],
    localizacao: Array.isArray(activeFilters.localizacao) ? activeFilters.localizacao : [],
    redeSocial: Array.isArray(activeFilters.redeSocial) ? activeFilters.redeSocial : [],
    seguidores: typeof activeFilters.seguidores === 'string' ? activeFilters.seguidores : '',
    verificado: Boolean(activeFilters.verificado),
    superCreator: Boolean(activeFilters.superCreator),
    faixaEtaria: Array.isArray(activeFilters.faixaEtaria) ? activeFilters.faixaEtaria : [],
    generoPrincipal: Array.isArray(activeFilters.generoPrincipal) ? activeFilters.generoPrincipal : [],
    engajamentoMinimo: typeof activeFilters.engajamentoMinimo === 'number' ? activeFilters.engajamentoMinimo : 0,
    tipoConteudo: Array.isArray(activeFilters.tipoConteudo) ? activeFilters.tipoConteudo : [],
    faixaPreco: typeof activeFilters.faixaPreco === 'string' ? activeFilters.faixaPreco : ''
  };

  return {
    searchTerm,
    setSearchTerm,
    showFilters,
    setShowFilters,
    orderBy,
    setOrderBy,
    isFiltering,
    setIsFiltering,
    activeFilters: safeActiveFilters,
    setActiveFilters
  };
}
