
import { useState, useEffect } from 'react';

type SubscriptionStatus = {
  isSubscribed: boolean;
  subscriptionTier: 'free' | 'basic' | 'premium' | 'enterprise';
  expiryDate: Date | null;
  hasReachedCampaignLimit: boolean;
  hasReachedMessageLimit: boolean;
  remainingSearches: number;
  totalSearches: number;
  remainingMessages: number;
  totalMessages: number;
  remainingCampaigns: number;
  totalCampaigns: number;
};

export function useSubscriptionStatus() {
  const [status, setStatus] = useState<SubscriptionStatus>({
    isSubscribed: false,
    subscriptionTier: 'free',
    expiryDate: null,
    hasReachedCampaignLimit: false,
    hasReachedMessageLimit: false,
    remainingSearches: 3,
    totalSearches: 3,
    remainingMessages: 0,
    totalMessages: 5,
    remainingCampaigns: 0,
    totalCampaigns: 3
  });
  
  const [isLoadingStatus, setIsLoadingStatus] = useState(false);

  const loadSubscriptionData = () => {
    // Check if we have subscription data in localStorage
    const storedData = localStorage.getItem('subscriptionStatus');
    if (storedData) {
      try {
        const parsedData = JSON.parse(storedData);
        
        // Convert string dates back to Date objects
        if (parsedData.expiryDate) {
          parsedData.expiryDate = new Date(parsedData.expiryDate);
        }
        
        setStatus(parsedData);
      } catch (error) {
        console.error("Error parsing subscription data", error);
        // If there's an error, we'll use the default status
      }
    } else {
      // For demo purposes, simulate a subscription check
      // In a real app, this would be an API call to verify subscription status
      
      // Get user data from localStorage
      const userData = localStorage.getItem('userData');
      if (userData) {
        try {
          const user = JSON.parse(userData);
          const email = user.email || '';
          
          // For demo: if email contains "premium", give premium subscription
          if (email.includes('premium')) {
            const expiryDate = new Date();
            expiryDate.setMonth(expiryDate.getMonth() + 1);
            
            const premiumStatus: SubscriptionStatus = {
              isSubscribed: true,
              subscriptionTier: 'premium',
              expiryDate,
              hasReachedCampaignLimit: false,
              hasReachedMessageLimit: false,
              remainingSearches: 999,
              totalSearches: 999,
              remainingMessages: 999,
              totalMessages: 999,
              remainingCampaigns: 10,
              totalCampaigns: 10
            };
            
            setStatus(premiumStatus);
            localStorage.setItem('subscriptionStatus', JSON.stringify(premiumStatus));
          } else {
            // Default free plan
            localStorage.setItem('subscriptionStatus', JSON.stringify(status));
          }
        } catch (error) {
          console.error("Error reading user data", error);
        }
      }
    }
  };

  useEffect(() => {
    loadSubscriptionData();
  }, []);

  const refreshSubscriptionStatus = () => {
    setIsLoadingStatus(true);
    
    // Simulate API request with a timeout
    setTimeout(() => {
      loadSubscriptionData();
      setIsLoadingStatus(false);
    }, 800);
  };

  return {
    ...status,
    isLoadingStatus,
    refreshSubscriptionStatus
  };
}
