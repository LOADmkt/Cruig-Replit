
import { useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase, isSupabaseConfigured } from '@/lib/supabaseClient';
import { useToast } from '@/hooks/use-toast';
import { storeAuthCookie, clearAuthCookie } from '@/lib/authUtils';

export function useAuthOperations() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  // Função de login
  const signIn = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });
      
      if (error) {
        toast({
          title: "Erro no login",
          description: error.message,
          variant: "destructive",
        });
        return { success: false, error };
      }
      
      // Armazenar informações no localStorage para persistência
      if (data.session) {
        storeAuthCookie(data.session.access_token, (new Date(data.session.expires_at || 0).getTime() - Date.now()) / 1000);
      }
      
      return { success: true, session: data.session };
    } catch (error: any) {
      console.error("Erro durante login:", error);
      toast({
        title: "Erro inesperado",
        description: "Ocorreu um erro durante o login. Tente novamente mais tarde.",
        variant: "destructive",
      });
      return { success: false, error };
    } finally {
      setIsLoading(false);
    }
  };
  
  // Função de cadastro
  const signUp = async (email: string, password: string, userData: any) => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: userData,
          emailRedirectTo: `${window.location.origin}/auth/verify`
        }
      });
      
      if (error) {
        toast({
          title: "Erro no cadastro",
          description: error.message,
          variant: "destructive",
        });
        return { success: false, error };
      }
      
      toast({
        title: "Cadastro realizado com sucesso!",
        description: "Verifique seu e-mail para confirmar sua conta.",
      });
      
      return { success: true, session: data.session, user: data.user };
    } catch (error: any) {
      console.error("Erro durante cadastro:", error);
      toast({
        title: "Erro inesperado",
        description: "Ocorreu um erro durante o cadastro. Tente novamente mais tarde.",
        variant: "destructive",
      });
      return { success: false, error };
    } finally {
      setIsLoading(false);
    }
  };
  
  // Função de logout completamente reescrita para garantir limpeza total
  const signOut = async () => {
    try {
      setIsLoading(true);
      
      // 1. Limpar cookies e localStorage antes de chamar signOut do Supabase
      clearAuthCookie();
      localStorage.removeItem('auth-status');
      localStorage.removeItem('userData');
      
      // 2. Chamar signOut do Supabase para destruir a sessão do servidor
      const { error } = await supabase.auth.signOut({
        scope: 'global' // Garantir que todas as sessões sejam destruídas
      });
      
      if (error) {
        console.error("Erro no Supabase durante logout:", error);
        // Mesmo com erro no Supabase, forçar redirecionamento
        setTimeout(() => {
          window.location.href = '/auth';
        }, 100);
        return { success: true };
      }
      
      // 3. Notificar usuário
      toast({
        title: "Logout realizado",
        description: "Você saiu da sua conta com sucesso.",
      });
      
      // 4. Forçar redirecionamento para garantir estado limpo
      setTimeout(() => {
        window.location.href = '/auth';
      }, 100);
      
      return { success: true };
    } catch (error: any) {
      console.error("Erro durante logout:", error);
      // Forçar redirecionamento mesmo com erro
      setTimeout(() => {
        window.location.href = '/auth';
      }, 100);
      return { success: true };
    } finally {
      setIsLoading(false);
    }
  };

  return {
    signIn,
    signUp,
    signOut,
    isLoading
  };
}
