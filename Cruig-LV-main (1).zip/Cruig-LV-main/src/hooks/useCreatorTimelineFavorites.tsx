
import { useState, useEffect, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabaseClient';

export function useCreatorTimelineFavorites() {
  const [favorites, setFavorites] = useState<(string | number)[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const { toast } = useToast();
  const { user, isAuthenticated } = useAuth();

  // Carregar favoritos do localStorage ou do Supabase
  useEffect(() => {
    const loadFavorites = async () => {
      setIsLoading(true);

      try {
        if (isAuthenticated && user) {
          // Em uma implementação real, isso seria uma chamada para o Supabase
          // const { data, error } = await supabase
          //   .from('favorites')
          //   .select('creator_id')
          //   .eq('user_id', user.id);
          
          // if (error) throw error;
          
          // const favoriteIds = data.map(item => item.creator_id);
          // setFavorites(favoriteIds);
          
          // Por enquanto, usamos localStorage mesmo quando autenticado
          const storedFavorites = localStorage.getItem(`creator_favorites_${user.id}`);
          if (storedFavorites) {
            try {
              const parsedFavorites = JSON.parse(storedFavorites);
              setFavorites(Array.isArray(parsedFavorites) ? parsedFavorites : []);
            } catch (err) {
              console.error('Erro ao parsear favoritos:', err);
              setFavorites([]);
            }
          }
        } else {
          // Quando não autenticado, use localStorage
          const storedFavorites = localStorage.getItem('creator_favorites');
          if (storedFavorites) {
            try {
              const parsedFavorites = JSON.parse(storedFavorites);
              setFavorites(Array.isArray(parsedFavorites) ? parsedFavorites : []);
            } catch (err) {
              console.error('Erro ao parsear favoritos:', err);
              setFavorites([]);
            }
          }
        }
      } catch (error) {
        console.error('Erro ao carregar favoritos:', error);
        toast({
          title: "Erro ao carregar favoritos",
          description: "Não foi possível carregar seus criadores favoritos.",
          variant: "destructive",
        });
        setFavorites([]);
      } finally {
        setIsLoading(false);
      }
    };

    loadFavorites();
  }, [isAuthenticated, user, toast]);

  // Função para alternar favorito - use functional state updates to prevent infinite loops
  const toggleFavorite = useCallback((creatorId: string | number) => {
    setFavorites((prevFavorites) => {
      try {
        const index = prevFavorites.indexOf(creatorId);
        let newFavorites;

        if (index !== -1) {
          // Remover dos favoritos
          newFavorites = prevFavorites.filter(id => id !== creatorId);
        } else {
          // Adicionar aos favoritos
          newFavorites = [...prevFavorites, creatorId];
        }

        // Salvar no localStorage (temporário ou para usuários não autenticados)
        if (isAuthenticated && user) {
          localStorage.setItem(`creator_favorites_${user.id}`, JSON.stringify(newFavorites));
        } else {
          localStorage.setItem('creator_favorites', JSON.stringify(newFavorites));
        }

        return newFavorites;
      } catch (error) {
        console.error('Erro ao modificar favoritos:', error);
        toast({
          title: "Erro ao atualizar favoritos",
          description: "Não foi possível atualizar seus criadores favoritos.",
          variant: "destructive",
        });
        return prevFavorites;
      }
    });
  }, [isAuthenticated, user, toast]);

  return {
    favorites,
    toggleFavorite,
    isLoading
  };
}
