
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

interface DashboardData {
  isLoading: boolean;
  error: string | null;
  data: any;
}

export function useDashboardData(endpoint: string): DashboardData {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<any>(null);
  const { toast } = useToast();

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        
        // For MVP, using mock data
        // In production, this would be: const response = await fetch(`/api/${endpoint}`);
        
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // Mock data based on endpoint
        let mockData;
        
        if (endpoint === 'company/dashboard') {
          mockData = {
            activeCampaigns: 3,
            completedCampaigns: 7,
            contractedCreators: 12,
            campaigns: [
              { 
                id: '1', 
                name: 'Campanha Verão 2024', 
                status: 'ativa', 
                creators: 5, 
                startDate: '2024-05-01', 
                endDate: '2024-06-30',
                budget: 'R$ 15.000',
                creatorType: 'Moda e Lifestyle'
              },
              { 
                id: '2', 
                name: 'Lançamento Produto X', 
                status: 'pausada', 
                creators: 3, 
                startDate: '2024-04-15', 
                endDate: '2024-05-15',
                budget: 'R$ 8.000',
                creatorType: 'Tech e Games'
              },
              { 
                id: '3', 
                name: 'Black Friday 2024', 
                status: 'planejamento', 
                creators: 0, 
                startDate: '2024-11-15', 
                endDate: '2024-11-30',
                budget: 'R$ 25.000',
                creatorType: 'Moda e Lifestyle'
              }
            ]
          };
        } else if (endpoint === 'creator/dashboard') {
          mockData = {
            invites: 2,
            activeCampaigns: 1,
            estimatedEarnings: 'R$ 3.200',
            campaigns: [
              {
                id: '1',
                companyName: 'Moda Verão',
                campaignName: 'Campanha Verão 2024',
                status: 'ativa',
                payment: 'R$ 1.800',
                deadline: '2024-06-30'
              },
              {
                id: '2',
                companyName: 'Tech Solutions',
                campaignName: 'Lançamento Produto X',
                status: 'convite',
                payment: 'R$ 1.400',
                deadline: '2024-05-15'
              }
            ],
            openCampaigns: [
              {
                id: '3',
                companyName: 'Beauty Corp',
                campaignName: 'Lançamento Linha Natural',
                budget: 'R$ 1.000-2.000',
                deadline: '2024-07-30',
                requirements: 'Mínimo 10k seguidores'
              },
              {
                id: '4',
                companyName: 'Esportes Radical',
                campaignName: 'Nova Coleção Esportiva',
                budget: 'R$ 1.500-3.000',
                deadline: '2024-08-15',
                requirements: 'Foco em esportes outdoor'
              }
            ]
          };
        } else if (endpoint === 'admin/dashboard') {
          mockData = {
            companies: 24,
            creators: 158,
            campaigns: 42,
            activeUsers: 96,
            recentUsers: [
              {
                id: '1',
                name: 'João Silva',
                email: 'joao@empresa.com',
                type: 'empresa',
                status: 'ativo',
                registeredAt: '2024-04-28'
              },
              {
                id: '2',
                name: 'Maria Costa',
                email: 'maria@criador.com',
                type: 'criador',
                status: 'ativo',
                registeredAt: '2024-04-29'
              },
              {
                id: '3',
                name: 'Pedro Santos',
                email: 'pedro@empresa.com',
                type: 'empresa',
                status: 'ativo',
                registeredAt: '2024-04-30'
              }
            ],
            recentCampaigns: [
              {
                id: '1',
                name: 'Campanha Verão 2024',
                company: 'Moda Verão',
                status: 'ativa',
                creators: 5,
                createdAt: '2024-04-20'
              },
              {
                id: '2',
                name: 'Lançamento Produto X',
                company: 'Tech Solutions',
                status: 'revisão',
                creators: 0,
                createdAt: '2024-04-30'
              }
            ]
          };
        }
        
        setData(mockData);
        setError(null);
      } catch (err: any) {
        console.error(`Error fetching ${endpoint} data:`, err);
        setError(err.message || 'Erro ao carregar dados');
        toast({
          variant: "destructive",
          title: "Erro ao carregar dados",
          description: "Não foi possível carregar os dados do dashboard. Tente novamente.",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [endpoint, toast]);

  return { isLoading, error, data };
}
