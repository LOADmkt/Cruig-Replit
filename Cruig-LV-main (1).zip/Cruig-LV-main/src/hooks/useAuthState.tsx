
import { useState, useEffect, useCallback } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase, isSupabaseConfigured } from '@/lib/supabaseClient';
import { storeAuthCookie, clearAuthCookie, getUserTypes } from '@/lib/authUtils';

export function useAuthState() {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isCreator, setIsCreator] = useState(false);
  const [isCompany, setIsCompany] = useState(false);

  // Função para atualizar o estado com os dados da sessão
  const handleSessionUpdate = useCallback((currentSession: Session | null) => {
    if (currentSession) {
      const currentUser = currentSession.user;
      
      setSession(currentSession);
      setUser(currentUser);
      setIsAuthenticated(true);
      
      // Determinar o tipo de usuário com base nos metadados
      const userType = currentUser?.user_metadata?.userType as string;
      const { isAdmin: admin, isCreator: creator, isCompany: company } = getUserTypes(userType);
      
      setIsAdmin(admin);
      setIsCreator(creator);
      setIsCompany(company);
      
      // Armazenar o token da sessão em cookie
      if (currentSession.expires_at) {
        const expiresIn = (new Date(currentSession.expires_at * 1000).getTime() - Date.now()) / 1000;
        storeAuthCookie(currentSession.access_token, expiresIn);
      }
      
      console.log("Sessão atualizada com sucesso:", userType);
    } else {
      clearAuthState();
    }
  }, []);
  
  // Função para limpar o estado de autenticação
  const clearAuthState = useCallback(() => {
    setUser(null);
    setSession(null);
    setIsAuthenticated(false);
    setIsAdmin(false);
    setIsCreator(false);
    setIsCompany(false);
    clearAuthCookie();
    console.log("Estado de autenticação limpo");
  }, []);

  // Inicializar autenticação
  useEffect(() => {
    let isMounted = true;
    
    // Verificar se o Supabase está configurado
    if (!isSupabaseConfigured()) {
      console.warn('Supabase não está configurado corretamente.');
      setIsLoading(false);
      return () => { isMounted = false; };
    }
    
    // Primeiro configurar o listener de eventos de autenticação
    const { data } = supabase.auth.onAuthStateChange((event, currentSession) => {
      if (!isMounted) return;
      
      console.info('Estado de autenticação alterado:', event);
      
      if (event === 'SIGNED_OUT') {
        clearAuthState();
      } else if (currentSession) {
        handleSessionUpdate(currentSession);
      }
    });
    
    // Em seguida verificar se já existe uma sessão ativa
    supabase.auth.getSession().then(({ data: { session: currentSession } }) => {
      if (!isMounted) return;
      
      if (currentSession) {
        console.info('Sessão atual:', currentSession.user.id);
        handleSessionUpdate(currentSession);
      } else {
        console.info('Nenhuma sessão atual');
        clearAuthState();
      }
      
      setIsLoading(false);
    }).catch(error => {
      if (!isMounted) return;
      
      console.error('Erro ao verificar sessão:', error);
      clearAuthState();
      setIsLoading(false);
    });
    
    // Cleanup
    return () => {
      isMounted = false;
      if (data && data.subscription) {
        data.subscription.unsubscribe();
      }
    };
  }, [handleSessionUpdate, clearAuthState]);

  return {
    user,
    session,
    isLoading,
    isAuthenticated,
    isAdmin,
    isCreator,
    isCompany,
    handleSessionUpdate,
    clearAuthState
  };
}
