
import { supabase } from '@/lib/supabaseClient';

// Tipo do criador
export interface Creator {
  id: string | number;
  name: string;
  username?: string;
  bio?: string;
  avatar?: string;
  location?: string;
  verified: boolean;
  followers?: number;
  engagement?: string;
  niches?: string[];
  priceRange?: {
    min: number;
    max: number;
  };
  socialNetworks?: {
    [key: string]: string;
  };
  socialMedia?: {
    platform: string;
    username?: string;
    followers?: number;
    engagement?: string;
    connected?: boolean;
  }[];
  rating?: number;
  portfolio?: {
    id: string | number;
    title: string;
    description?: string;
    image?: string;
    imageUrl?: string;
    link?: string;
  }[];
  availability?: string;
  targetAudience?: string[];
  // Changed to accept both string and string[] to fix the type mismatch
  experience?: string | string[];
  brandSatisfaction?: string;
  completedCampaigns?: number;
  campaignsCompleted?: number;
  campaignsActive?: number;
}

// Interface para opções de filtro
export interface CreatorFilterOptions {
  niches?: string[];
  minFollowers?: number;
  maxFollowers?: number;
  location?: string[];
  verified?: boolean;
  engagement?: {
    min?: number;
    max?: number;
  };
  priceRange?: {
    min?: number;
    max?: number;
  };
  // Brazilian Portuguese specific filters
  nicho?: string[];
  seguidores?: string;
  localizacao?: string[];
  redeSocial?: string[];
  verificado?: boolean;
  superCreator?: boolean;
  faixaEtaria?: string[];
  generoPrincipal?: string[];
  engajamentoMinimo?: number;
  tipoConteudo?: string[];
  faixaPreco?: string;
}

// Alias para compatibilidade com código existente
export type CreatorFilters = CreatorFilterOptions;

// Interface para parâmetros de busca
interface GetCreatorsParams {
  search?: string;
  filters?: CreatorFilterOptions;
  orderBy?: string;
  page?: number;
  limit?: number;
}

// Função que busca criadores com filtros e paginação
export const getCreators = async ({
  search = '',
  filters = {},
  orderBy = 'relevance',
  page = 1,
  limit = 9
}: GetCreatorsParams): Promise<{ creators: Creator[]; total: number }> => {
  try {
    // No futuro, isso seria uma requisição ao Supabase
    // Por enquanto, vamos usar um delay simulado e dados mock

    // Simular tempo de carregamento
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Mock de dados para criadores
    const mockCreators: Creator[] = Array.from({ length: 20 }, (_, i) => ({
      id: `creator-${i + 1}`,
      name: `Criador ${i + 1}`,
      username: `creator${i + 1}`,
      bio: `Bio do criador ${i + 1}. Especializado em conteúdo digital e influência nas redes sociais.`,
      avatar: `https://source.unsplash.com/100x100/?person&v=${i}`,
      location: ['São Paulo', 'Rio de Janeiro', 'Belo Horizonte', 'Curitiba'][i % 4],
      verified: i % 3 === 0,
      followers: Math.floor(Math.random() * 900000) + 100000,
      engagement: `${(Math.random() * 8 + 2).toFixed(1)}%`,
      niches: [
        ['moda', 'lifestyle'][i % 2],
        ['beleza', 'viagem', 'gastronomia', 'tecnologia'][i % 4],
      ],
      priceRange: {
        min: Math.floor(Math.random() * 500) + 500,
        max: Math.floor(Math.random() * 2000) + 2000
      },
      socialNetworks: {
        instagram: `creator${i + 1}`,
        tiktok: i % 2 === 0 ? `creator${i + 1}` : undefined,
        youtube: i % 3 === 0 ? `CreatorChannel${i + 1}` : undefined
      },
      rating: Math.floor(Math.random() * 2) + 3,
      campaignsCompleted: Math.floor(Math.random() * 20),
      campaignsActive: Math.floor(Math.random() * 3),
      portfolio: Array.from({ length: Math.floor(Math.random() * 5) + 1 }, (_, j) => ({
        id: `portfolio-${i}-${j}`,
        title: `Projeto ${j + 1}`,
        description: `Descrição do projeto ${j + 1} do criador ${i + 1}`,
        imageUrl: `https://source.unsplash.com/400x300/?portfolio&v=${i}${j}`
      })),
      availability: ['Imediata', '1-2 semanas', '3-4 semanas'][i % 3],
      targetAudience: [
        ['18-24 anos', 'Feminino', 'Urbano'],
        ['25-34 anos', 'Masculino', 'Tech'],
        ['18-34 anos', 'Todos', 'Fashion']
      ][i % 3],
      // Changed from string[] to string to match the interface
      experience: `${i % 5 + 1}+ anos`,
      brandSatisfaction: `${Math.floor(Math.random() * 11) + 90}%`,
    }));

    // Aplicar busca por texto
    let filteredCreators = [...mockCreators];
    
    if (search) {
      const searchLower = search.toLowerCase();
      filteredCreators = filteredCreators.filter(creator => 
        creator.name.toLowerCase().includes(searchLower) || 
        creator.username?.toLowerCase().includes(searchLower) || 
        creator.niches?.some(niche => niche.toLowerCase().includes(searchLower))
      );
    }

    // Aplicar filtros
    if (filters.niches && filters.niches.length > 0) {
      filteredCreators = filteredCreators.filter(creator => 
        creator.niches?.some(niche => 
          filters.niches?.includes(niche)
        )
      );
    }

    if (filters.verified) {
      filteredCreators = filteredCreators.filter(creator => creator.verified);
    }

    if (filters.location && filters.location.length > 0) {
      filteredCreators = filteredCreators.filter(creator => 
        creator.location && filters.location?.includes(creator.location)
      );
    }

    if (filters.minFollowers) {
      filteredCreators = filteredCreators.filter(creator => 
        (creator.followers || 0) >= (filters.minFollowers || 0)
      );
    }

    if (filters.maxFollowers) {
      filteredCreators = filteredCreators.filter(creator => 
        (creator.followers || 0) <= (filters.maxFollowers || Infinity)
      );
    }

    // Aplicar ordenação
    switch (orderBy) {
      case 'followers_desc':
        filteredCreators.sort((a, b) => (b.followers || 0) - (a.followers || 0));
        break;
      case 'followers_asc':
        filteredCreators.sort((a, b) => (a.followers || 0) - (b.followers || 0));
        break;
      case 'engagement_desc':
        filteredCreators.sort((a, b) => {
          const engA = parseFloat((a.engagement || '0').replace('%', ''));
          const engB = parseFloat((b.engagement || '0').replace('%', ''));
          return engB - engA;
        });
        break;
      case 'campaigns_desc':
        filteredCreators.sort((a, b) => (b.campaignsCompleted || 0) - (a.campaignsCompleted || 0));
        break;
      case 'rating_desc':
        filteredCreators.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      default: // 'relevance' - padrão por relevância
        // Já está em ordem de relevância
        break;
    }

    // Aplicar paginação
    const startIndex = (page - 1) * limit;
    const paginatedCreators = filteredCreators.slice(startIndex, startIndex + limit);

    return {
      creators: paginatedCreators,
      total: filteredCreators.length
    };
  } catch (error) {
    console.error('Erro ao buscar criadores:', error);
    return { creators: [], total: 0 };
  }
};

// Função para buscar um único criador pelo ID
export const getCreator = async (id: string | number): Promise<Creator | null> => {
  try {
    // Simular tempo de carregamento
    await new Promise(resolve => setTimeout(resolve, 500));

    // Mock para um criador específico
    const creator: Creator = {
      id,
      name: `Criador ${id}`,
      username: `creator${id}`,
      bio: `Bio do criador ${id}. Especialista em criação de conteúdo para diversas plataformas digitais, com foco em engajamento e autenticidade. Trabalha com marcas de vários segmentos trazendo uma abordagem única para cada campanha.`,
      avatar: `https://source.unsplash.com/400x400/?person&v=${id}`,
      location: 'São Paulo',
      verified: true,
      followers: 253000,
      engagement: '4.7%',
      niches: ['moda', 'lifestyle', 'viagem'],
      priceRange: {
        min: 1500,
        max: 5000
      },
      socialNetworks: {
        instagram: `creator${id}`,
        tiktok: `creator${id}`,
        youtube: `CreatorChannel${id}`
      },
      rating: 4.8,
      campaignsCompleted: 24,
      campaignsActive: 2,
      portfolio: [
        {
          id: 'p1',
          title: 'Campanha Verão 2025',
          description: 'Parceria com marca de moda praia sustentável',
          imageUrl: 'https://source.unsplash.com/600x400/?summer,fashion'
        },
        {
          id: 'p2',
          title: 'Review de Tecnologia',
          description: 'Análise de smartphone lançamento',
          imageUrl: 'https://source.unsplash.com/600x400/?smartphone,tech'
        },
        {
          id: 'p3',
          title: 'Tour na Europa',
          description: 'Série de conteúdos em parceria com agência de turismo',
          imageUrl: 'https://source.unsplash.com/600x400/?europe,travel'
        }
      ],
      availability: '1-2 semanas',
      targetAudience: ['18-34 anos', 'Feminino', 'Interessados em lifestyle'],
      experience: '5+ anos',
      brandSatisfaction: '97%',
    };

    return creator;
  } catch (error) {
    console.error(`Erro ao buscar criador ${id}:`, error);
    return null;
  }
};

// Função para checar se um usuário segue um criador
export const getFollowStatus = async (userId: string, creatorId: string | number): Promise<boolean> => {
  // Simular chamada à API
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // Retorno mockado (50% de chance de seguir)
  return Math.random() > 0.5;
};

// Função para seguir/deixar de seguir um criador
export const toggleFollowCreator = async (userId: string, creatorId: string | number, isFollowing: boolean): Promise<boolean> => {
  // Simular chamada à API
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Simular sucesso na operação
  return true;
};
