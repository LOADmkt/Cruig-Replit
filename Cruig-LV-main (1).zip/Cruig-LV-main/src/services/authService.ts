
import { supabase } from '@/lib/supabaseClient';
import { isTokenExpired } from '@/lib/authUtils';

/**
 * Verificar se a sessão atual é válida
 */
export const checkSession = async () => {
  try {
    const { data } = await supabase.auth.getSession();
    const session = data.session;

    if (!session) {
      console.log('Nenhuma sessão encontrada');
      return { valid: false, reason: 'no-session' };
    }

    if (isTokenExpired(session.access_token)) {
      console.log('Token expirado');
      return { valid: false, reason: 'expired' };
    }

    return { valid: true };
  } catch (error) {
    console.error('Erro ao verificar sessão:', error);
    return { valid: false, reason: 'error', error };
  }
};

/**
 * Login com Google
 */
export const signInWithGoogle = async () => {
  try {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
      }
    });
    
    if (error) {
      return { success: false, error: error.message };
    }
    
    return { success: true, data };
  } catch (error: any) {
    console.error("Erro ao realizar login com Google:", error);
    return { success: false, error: error.message };
  }
};

/**
 * Processa callback de autenticação OAuth
 */
export const handleOAuthCallback = async () => {
  try {
    const { data, error } = await supabase.auth.getSession();
    
    if (error) {
      console.error('Erro ao processar callback OAuth:', error);
      return { success: false, error: error.message };
    }
    
    if (!data.session?.user) {
      return { success: false, error: 'Nenhuma sessão de usuário encontrada' };
    }
    
    return { 
      success: true, 
      user: data.session.user,
      session: data.session
    };
  } catch (error: any) {
    console.error('Erro ao processar callback OAuth:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Atualiza tipo de usuário após autenticação OAuth
 */
export const updateUserAfterOAuth = async (userType: 'criador' | 'empresa') => {
  try {
    const { data, error } = await supabase.auth.updateUser({
      data: { userType }
    });
    
    if (error) {
      console.error('Erro ao atualizar tipo de usuário:', error);
      return { success: false, error: error.message };
    }
    
    return { success: true, user: data.user };
  } catch (error: any) {
    console.error('Erro ao atualizar tipo de usuário:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Solicitar redefinição de senha
 */
export const requestPasswordReset = async (email: string) => {
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/reset-password`,
    });
    
    if (error) {
      console.error('Erro ao solicitar redefinição de senha:', error);
      return { success: false, error: error.message };
    }
    
    return { success: true };
  } catch (error: any) {
    console.error('Erro ao solicitar redefinição de senha:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Redefinir senha
 */
export const resetPassword = async (newPassword: string) => {
  try {
    const { error } = await supabase.auth.updateUser({
      password: newPassword
    });
    
    if (error) {
      console.error('Erro ao redefinir senha:', error);
      return { success: false, error: error.message };
    }
    
    return { success: true };
  } catch (error: any) {
    console.error('Erro ao redefinir senha:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Verificar email
 */
export const verifyEmail = async (token: string) => {
  try {
    // O Supabase não tem uma API específica para verificar email manualmente,
    // então aqui estamos verificando se o token está na URL e se o usuário está autenticado
    const { data, error } = await supabase.auth.getSession();
    
    if (error) {
      console.error('Erro ao verificar email:', error);
      return { success: false, error: error.message };
    }
    
    if (!data.session) {
      return { 
        success: false, 
        error: 'Token inválido ou expirado. Por favor, solicite um novo email de verificação.' 
      };
    }
    
    // Se chegou até aqui, o token é válido e o usuário está autenticado
    return { success: true };
  } catch (error: any) {
    console.error('Erro ao verificar email:', error);
    return { success: false, error: error.message };
  }
};
