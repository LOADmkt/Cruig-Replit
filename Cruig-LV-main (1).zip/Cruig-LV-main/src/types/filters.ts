
export interface FilterOption {
  value: string;
  label: string;
}

export interface FilterConfig {
  label: string;
  type: string;
  options?: FilterOption[] | string[];
  defaultValue: any;
  clearable: boolean;
  min?: number;
  max?: number;
  step?: number;
  field?: string;
  valueLabels?: Record<string, string>;
  formatValue?: (value: any) => string;
  formatter?: (value: any) => string;
}

export interface FilterContextType {
  filters: Record<string, any>;
  setFilter: (key: string, value: any) => void;
  removeFilter: (key: string) => void;
  clearFilters: () => void;
  resetFilters: () => void;
  activeFilterCount: number;
}
