
import { User, Session } from '@supabase/supabase-js';

export interface AuthContextType {
  user: User | null;
  session: Session | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isCreator: boolean;
  isCompany: boolean;
  signIn: (email: string, password: string) => Promise<{ success: boolean, error?: any, session?: Session }>;
  signUp: (email: string, password: string, userData: any) => Promise<{ success: boolean, error?: any, user?: User, session?: Session }>;
  signOut: () => Promise<{ success: boolean, error?: any }>;
  resetPassword: (email: string) => Promise<{ success: boolean; error?: any; }>;
  updatePassword: (newPassword: string) => Promise<{ success: boolean; error?: any; }>;
  updateUserData: (userData: any) => Promise<{ success: boolean; user?: User; error?: any; }>;
  refreshSession: () => Promise<{ success: boolean; session?: Session; error?: any; }>;
}

export interface ExtendedUserMetadata {
  name?: string;
  avatar?: string;
  username?: string;
  bio?: string;
  niches?: string[];
  verified?: boolean;
  userType?: 'admin' | 'criador' | 'empresa';
  role?: string;
  socialNetworks?: {
    instagram?: {
      connected: boolean;
      username: string;
      followers: string;
      engagement: string;
    };
    youtube?: {
      connected: boolean;
      username: string;
      followers: string;
      engagement: string;
    };
    tiktok?: {
      connected: boolean;
      username: string;
      followers: string;
      engagement: string;
    };
    twitter?: {
      connected: boolean;
      username: string;
      followers: string;
      engagement: string;
    };
  };
  [key: string]: any;
}
