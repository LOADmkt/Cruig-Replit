
export interface FilterOption {
  value: string;
  label: string;
}

export interface FilterConfig {
  field?: string;
  label: string;
  type: 'multi-select' | 'select' | 'toggle' | 'slider' | 'date-range';
  options?: FilterOption[] | string[];
  iconClass?: string;
  placeholder?: string;
}
