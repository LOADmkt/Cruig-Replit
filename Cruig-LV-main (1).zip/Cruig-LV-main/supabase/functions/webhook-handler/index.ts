
// supabase/functions/webhook-handler/index.ts
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

serve(async (req) => {
  try {
    // Get the Stripe webhook secret
    const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
    if (!webhookSecret) {
      throw new Error("STRIPE_WEBHOOK_SECRET is not set");
    }

    // Get the signature from the header
    const signature = req.headers.get("stripe-signature");
    if (!signature) {
      return new Response("Missing stripe-signature header", { status: 400 });
    }

    // Initialize Stripe
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2023-10-16",
    });

    // Get request body as text for signature verification
    const body = await req.text();

    // Verify webhook signature
    let event;
    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
    } catch (error) {
      console.error(`Webhook signature verification failed: ${error.message}`);
      return new Response(`Webhook signature verification failed: ${error.message}`, {
        status: 400,
      });
    }

    // Initialize Supabase client with service role for admin operations
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    // Handle different event types
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object;
        
        // Extract metadata from session
        const userId = session.metadata?.userId;
        const planId = session.metadata?.planId;
        const userType = session.metadata?.userType;
        const referralCode = session.metadata?.referralCode;

        if (!userId) {
          console.error("No userId found in session metadata");
          break;
        }

        // Get subscription details
        const subscriptionId = session.subscription;
        if (!subscriptionId) {
          console.error("No subscription ID found in session");
          break;
        }

        const subscription = await stripe.subscriptions.retrieve(subscriptionId as string);
        
        // Update subscribers table
        await supabaseClient.from("subscribers").upsert({
          user_id: userId,
          email: session.customer_email as string,
          stripe_customer_id: session.customer as string,
          subscribed: true,
          subscription_tier: planId,
          plan: planId,
          user_type: userType,
          subscription_id: subscriptionId as string,
          subscription_end: new Date(subscription.current_period_end * 1000).toISOString(),
          updated_at: new Date().toISOString(),
        }, { onConflict: "user_id" });

        console.log(`Updated subscription for user ${userId}, plan ${planId}`);
        
        // Process referral if present
        if (referralCode) {
          const { data: affiliateLinks } = await supabaseClient
            .from('affiliate_links')
            .select('*')
            .eq('code', referralCode)
            .limit(1);
          
          if (affiliateLinks && affiliateLinks.length > 0) {
            const creatorId = affiliateLinks[0].creator_id;
            
            // Check if referral already exists
            const { data: existingReferrals } = await supabaseClient
              .from('referrals')
              .select('*')
              .eq('referred_user_id', userId)
              .limit(1);
              
            if (!existingReferrals || existingReferrals.length === 0) {
              // Create new referral record
              await supabaseClient.from('referrals').insert({
                affiliate_link_id: affiliateLinks[0].id,
                referred_user_id: userId,
                status: 'completed',
                completed_at: new Date().toISOString(),
                commission_amount: 25.00, // R$25 fixed commission
              });
              
              console.log(`Created referral record for affiliate ${creatorId} and user ${userId}`);
            }
          }
        }
        
        break;
      }

      case "customer.subscription.updated": {
        const subscription = event.data.object;
        const customerId = subscription.customer as string;

        // Find user by customer ID
        const { data: subscribers, error } = await supabaseClient
          .from("subscribers")
          .select("*")
          .eq("stripe_customer_id", customerId);

        if (error || !subscribers.length) {
          console.error(`No subscriber found for customer ${customerId}:`, error);
          break;
        }

        const subscriber = subscribers[0];
        await supabaseClient.from("subscribers").update({
          subscribed: subscription.status === "active",
          subscription_end: new Date(subscription.current_period_end * 1000).toISOString(),
          updated_at: new Date().toISOString(),
        }).eq("id", subscriber.id);

        console.log(`Updated subscription status for customer ${customerId} to ${subscription.status}`);
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object;
        const customerId = subscription.customer as string;

        // Find user by customer ID
        const { data: subscribers, error } = await supabaseClient
          .from("subscribers")
          .select("*")
          .eq("stripe_customer_id", customerId);

        if (error || !subscribers.length) {
          console.error(`No subscriber found for customer ${customerId}:`, error);
          break;
        }

        const subscriber = subscribers[0];
        await supabaseClient.from("subscribers").update({
          subscribed: false,
          subscription_end: new Date().toISOString(), // Set to current time as subscription is now canceled
          updated_at: new Date().toISOString(),
        }).eq("id", subscriber.id);

        console.log(`Marked subscription as canceled for customer ${customerId}`);
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    console.error(`Webhook error: ${error.message}`);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
});
