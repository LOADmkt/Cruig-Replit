
// supabase/functions/create-checkout/index.ts
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Parse request body
    const { userType, planId, referralCode } = await req.json();

    // Get authentication token from request header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Missing Authorization header");
    }
    
    // Initialize Supabase client with anon key (for authentication)
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? ""
    );

    // Verify user session
    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError) throw new Error(`Authentication error: ${userError.message}`);
    if (!userData.user) throw new Error("User not authenticated");

    // Initialize Stripe
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");
    const stripe = new Stripe(stripeKey, { apiVersion: "2023-10-16" });

    // Find or create Stripe customer
    const customers = await stripe.customers.list({ email: userData.user.email, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
    } else {
      const newCustomer = await stripe.customers.create({ 
        email: userData.user.email,
        metadata: { user_id: userData.user.id }
      });
      customerId = newCustomer.id;
    }

    // Determine price based on plan and user type
    let priceId;
    if (userType === "creator") {
      if (planId === "mensal") priceId = "price_creator_monthly";
      else if (planId === "semestral") priceId = "price_creator_semiannual";
      else if (planId === "anual") priceId = "price_creator_annual";
      else throw new Error("Invalid plan ID");
    } else if (userType === "company") {
      if (planId === "mensal") priceId = "price_company_monthly";
      else if (planId === "semestral") priceId = "price_company_semiannual";
      else if (planId === "anual") priceId = "price_company_annual";
      else throw new Error("Invalid plan ID");
    } else {
      throw new Error("Invalid user type");
    }

    // NOTE: In a production environment, you would fetch the actual Stripe Price IDs
    // from your database rather than using placeholders

    // Create Stripe Checkout session
    const metadata = {
      userId: userData.user.id,
      planId: planId,
      userType: userType,
    };
    
    // Add referral code to metadata if present
    if (referralCode) {
      metadata.referralCode = referralCode;
    }
    
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ["card"],
      line_items: [
        {
          price: priceId, // This would be a real Stripe Price ID in production
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: `${req.headers.get("origin")}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.headers.get("origin")}/payment-cancelled`,
      metadata: metadata,
    });

    return new Response(
      JSON.stringify({ url: session.url }),
      { 
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200 
      }
    );
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("Create checkout error:", errorMessage);
    
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});
